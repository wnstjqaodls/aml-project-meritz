/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.rba.server.type03.RBA_50.RBA_50_04.RBA_50_04_04;


import java.util.HashMap;
import java.util.List;

import org.omg.CORBA.UserException;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
 * <pre>
 * 부서별내부통제점검항목관리
 * </pre>
 * @author lcj
 * @version 1.0
 * @history 1.0 2018-05-10
 */
public class RBA_50_04_04_01 extends GetResultObject {

	private static RBA_50_04_04_01 instance = null;
	/**
	* getInstance
	* @return RBA_50_04_04_01
	*/
	public static  RBA_50_04_04_01 getInstance() {
		synchronized(RBA_50_04_04_01.class) {
			if (instance == null) {
				instance = new RBA_50_04_04_01();
			}
		}
		return instance;
	}

	/**
	* <pre>
	* 부서별내부통제점검항목관리 조회
	* </pre>
	* @param input
	* @return
	*/
	public DataObj doSearch(DataObj input) throws UserException {

		DataObj output = null;
		DataSet gdRes = null;

		try {

			output = MDaoUtilSingle.getData("RBA_50_04_04_01_getSearch1", input);

			if (output.getCount("BRNO") > 0) {
				gdRes = Common.setGridData(output);
			} else {
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
				output.put("WINMSG" ,MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
			}

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException ex) {
			Log.logAML(Log.ERROR, this, "doSearch", ex.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", ex.toString());
		}
		return output;
	}


	/**
	* <pre>
	* 부서별내부통제점검항목관리 조회
	* </pre>
	* @param input
	* @return
	*/
	public DataObj doSearch2(DataObj input) throws UserException {

		DataObj output = null;
		DataSet gdRes = null;

		try {
			/*
			 * output = MDaoUtilSingle.getData("RBA_50_04_04_01_getSearch1", input);
			 * input.put("AML_TJ_BRNO_YN", output.getText("AML_TJ_BRNO_YN"));
			 */
			output = MDaoUtilSingle.getData("RBA_50_04_04_01_getSearch2", input);

			if (output.getCount("CNTL_ELMN_C") > 0) {
				gdRes = Common.setGridData(output);
			} else {
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
				output.put("WINMSG" ,MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
			}
			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException ex) {
			Log.logAML(Log.ERROR, this, "doSearch2", ex.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", ex.toString());
		}
		return output;
	}



	/**
	* <pre>
	* 부점별 통제요소 맵핑 데이터 저장
	* </pre>
	* @param input
	* @return
	*/
	public DataObj doSave(DataObj input) throws AMLException {

		DataObj output = new DataObj();
		MDaoUtil mDao = null;
        List gdReq = null;

		try {
			mDao = new MDaoUtil();
			mDao.begin();

			gdReq = (List) input.get("gdReq");
			int gdReq_size = gdReq.size();

			output = new DataObj();

			String loginId = ((SessionHelper) input.get("SessionHelper")).getLoginId();

			//mDao.setData("RBA_50_04_04_01_doSave_DELETE", input);

			for (int i = 0; i < gdReq_size; i++) {

				HashMap inputMap = (HashMap) gdReq.get(i);
				inputMap.put("BRNO", input.get("BRNO") );
				inputMap.put("DR_OP_JKW_NO", loginId );
				mDao.setData("RBA_50_04_04_01_doSave_INSERT", inputMap);
				/*
				 * if(input.get("USE_KBN") != null && !"".equals(input.get("USE_KBN"))&&
				 * !"N".equals(input.get("USE_KBN"))) { if("Y".equals(input.get("USE_KBN"))) {
				 * mDao.setData("RBA_50_04_03_01_doSave_INSERT", inputMap); } }
				 */
			}
			mDao.commit();

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다"));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다"));

		} catch (AMLException ex) {
			if(mDao != null) {
				mDao.rollback();
			}
			Log.logAML(Log.ERROR, this, "doSave", ex.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", ex.toString());
		}finally{
			//DB Close
			if (mDao != null) {
				mDao.close();
			}
		}
		return output;
	}

}
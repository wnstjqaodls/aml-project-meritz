<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 보고항목  미리보기                   
* Author          : 
* Since           : 2019. 06. 10.
********************************************************************************************************************************************
--%>
<%@ page import="java.util.*" %>
<%@ page import="com.gtone.aml.basic.common.util.*" %>
<%@ page import="com.gtone.aml.basic.common.data.DataObj" %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01.AML_20_01_01_90" %>
<%@ page import="com.ss.common.util.security.damo.damoManager" %>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%

	String SSPS_DL_CRT_DT = Util.nvl(request.getParameter("SSPS_DL_CRT_DT"));
	String SSPS_DL_ID = Util.nvl(request.getParameter("SSPS_DL_ID"));
	String BTN_SAVE_F = Util.nvl(request.getParameter("BTN_SAVE_F"));
	String DL_P_NM = Util.nvl(request.getParameter("CS_NM"));
	String INDV_CORP_CCD = Util.nvl(request.getParameter("INDV_CORP_CCD"));
	
	DataObj input_01  = new DataObj();	
	input_01.add("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	input_01.add("SSPS_DL_ID",SSPS_DL_ID);
	
	DataObj output_org 		= AML_20_01_01_90.getInstance().getOrganization_Kofiu();				//보고기관정보 [Organization] : 보고기관정보 가져오기	
	DataObj output_mst 		= AML_20_01_01_90.getInstance().getMaster_Basic_Kofiu(input_01);		//취합내용 및 의심정도 정보 [Master] : STR XML정보 가져오기
	DataObj output_mstRep 	= AML_20_01_01_90.getInstance().getMaster_Report(input_01);		//의심스러운 거래에 대한 서술 [SuspicionReport] : STR XML 의심내역정보 가져오기
	
	String MAX_PROC_FALG = output_mst.getText("MAX_PROC_FALG"); // {0: 정상, 1: 오류, '': 로그없음} 
	
	request.setAttribute("SSPS_DL_ID",SSPS_DL_ID);
	request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	request.setAttribute("DL_P_NM",DL_P_NM);	
	request.setAttribute("INDV_CORP_CCD",INDV_CORP_CCD);
	
	request.setAttribute("output_org",output_org);
	request.setAttribute("output_mst",output_mst); 
	
	damoManager damo = new damoManager();
	String SYNTHETICOPINION = (String)output_mstRep.get("SYNTHETICOPINION");
	output_mstRep.put("SYNTHETICOPINION", damo.pDecrypt(SYNTHETICOPINION));
	
	request.setAttribute("output_mstRep",output_mstRep);
	request.setAttribute("BTN_SAVE_F",BTN_SAVE_F);
	request.setAttribute("parentViewId",request.getParameter("parentViewId"));
	request.setAttribute("parentViewName",request.getParameter("parentViewName"));
	
%>
<style>
.popup-content {
    padding: 5px 40px;
} 
.textarea-box {
    padding: 6px 8px;
    background-color: #faf9f8;
    border: 1px solid #ccc;
    width: 100%;
}
</style>
<script>
	var GridObj3 = null;	//의심유형코드
	var GridObj4 = null;
	var GridObj5 = null;	//거래내역[Transaction]
	var GridObj6 = null;	//거래자역할 [Transaction]_[UserRelation]
	var GridObj7 = null;
	var GridObj8 = null;
	var GridObj9 = null;	//계약정보 Account
	var GridObj10 = null;	//첨부파일 FileAttach
	var GridObj31 = null;	//의심유형세부코드
	var GridObj61 = null;	//계약관계 [Transaction]_[AccountRelation]
	var GridObj70 = null;	//거래자정보[User]
	var GridObj71 = null;
	var GridObj72 = null;	//거래자정보 User 상세조회
	var GridObj81 = null;
	var GridObj51 = null;	//타행계좌 [Transaction]_[OtherBank]
	var GridObj52 = null;	//유가증권 [Transaction]_[Securities]
	var GridObj53 = null;	//외환및환전 [Transaction]_[ForeignExchange]
	var GridObj54 = null;	//증권 [Transaction]_[Stock]
	var GridObj91 = null;	//거래자간의 관계 InterUserRelation
	var GridObj92 = null;	//보고항목 체크로그 목록
    var overlay = new Overlay();    
    var selectObjGrid5 = {};
    var grid70Flag = "N";	//거래자정보[User] 데이터를 클릭했는지 여부(클릭했으면 'Y')

	var v_custGbn = "";
    
    // [ Initialize ]
    $(document).ready(function(){
        setupGrids3();
        setupGrids31();
        setupGrids5();
        setupGrids6();
        setupGrids61();
        setupGrids53();
        setupGrids52();
        setupGrids51();
        setupGrids54();
        setupGrids70();
        setupGrids72();
        setupGrids9();
        setupGrids91();
        setupGrids10();
        setupGrids92();
        $('.dx-datagrid-header-panel').css("display", "none");
     	// 수정가능여부
        if("${BTN_SAVE_F}" == "Y")
        	setInitVal(false);
        else
        	setInitVal(true);
        calcBytes();        

    });
    
	/* setup */
    function setupGrids3() {     
    	//의심유형코드
    	GridObj3 = $("#GTDataGrid03_Area").dxDataGrid({
    		"gridId"          : "GTDataGrid01"
            ,"height" : 'calc(25vh - 50px)'
            ,"elementAttr" : { class: "grid-table-type" }
            ,"export" : {
        		        allowExportSelectedData : true
        		       ,enabled                 : true
        		       ,excelFilterEnabled      : true
              }
        	,"onExporting" : function (e) {
		        		var workbook = new ExcelJS.Workbook();
		        		var worksheet = workbook.addWorksheet("Sheet1");
        			    DevExpress.excelExporter.exportDataGrid({
        			        component: e.component,
        			        worksheet : worksheet
        			    }).then(function(){
        			        workbook.xlsx.writeBuffer().then(function(buffer) {
        			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_201","의심유형코드')}.xlsx");
        			        });
        			    });
        			    e.cancel = true;
        	}
            ,"allowColumnReordering": true
            ,"allowColumnResizing"  : true
            ,"columnResizingMode" : 'widget'
            ,"cacheEnabled"         : false
            ,"cellHintEnabled"      : true
            ,"columnAutoWidth"      : true
            ,"columnFixing" : {"enabled": true}
            ,"filterRow" : {"visible": false}
            ,"hoverStateEnabled"     : true
            ,"loadPanel"             : {"enabled": false}
            ,pager: {
    	    	visible: true
    	    	,showNavigationButtons: true
    	    	,showInfo: true
    	    }
    	    ,paging: {
    	    	enabled : true
    	    	,pageSize : 20
    	    }
	 	   	,scrolling : {
	            mode            : "standard"
	           ,preloadEnabled  : false
	        }
            ,"remoteOperations"      : {
                 "filtering" : false
                ,"grouping"  : false
                ,"paging"    : false
                ,"sorting"   : false
                ,"summary"   : false
             }
            ,"rowAlternationEnabled" : true
            ,"searchPanel"           : {
                 "visible" : false
                ,"width"   : 250
             }
            ,"selection"             : {
                 "allowSelectAll"    : true
                ,"deferred"          : false
                ,"mode"              : "single"
                ,"selectAllMode"     : "allPages"
                ,"showCheckBoxesMode": "always"
             }
            ,"showBorders"           : true
            ,"showColumnLines"       : true
            ,"showRowLines"          : true
            ,"sorting"               : {"mode": "multiple"}
            ,"width"                 : "inherit"
            ,"wordWrapEnabled"       : false
//             ,"summary": {
//                  "totalItems": [{
//                      "column"       : "QUESTIONTITLECODE"
//                     ,"summaryType"  : "count",
//                     valueFormat: "fixedPoint",
//                     alignment: "left"
//                  }],
//                  texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
//              }
            ,"columns" : [
                 {"dataField": "QUESTIONTITLECODE","caption": '${msgel.getMsg("AML_20_01_01_90_120","*의심유형코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "QUESTIONTITLE","caption": '${msgel.getMsg("AML_20_01_01_90_121","의심유형")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true}
             ]
            ,"onInitialized" : function(e) {
            	doSearchSuspicionTitle();
            }
    	}).dxDataGrid("instance");
    }
    
    function setupGrids31()
    {     
    	//의심유형세부코드
    	GridObj31 = $("#GTDataGrid31_Area").dxDataGrid({
    		"gridId"          : "GTDataGrid31"
                ,"height" : 'calc(30vh - 50px)'
                	,"elementAttr" : { class: "grid-table-type" }
                ,"export" : {
            		        allowExportSelectedData : true
            		       ,enabled                 : true
            		       ,excelFilterEnabled      : true
                  }
            	,"onExporting" : function (e) {
		            		var workbook = new ExcelJS.Workbook();
		            		var worksheet = workbook.addWorksheet("Sheet1");
            			    DevExpress.excelExporter.exportDataGrid({
            			        component: e.component,
            			        worksheet : worksheet,
            			    }).then(function(){
            			        workbook.xlsx.writeBuffer().then(function(buffer){
            			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_202','의심유형세부코드')}.xlsx");
            			        });
            			    });
            			    e.cancel = true;
            	}
            	,"allowColumnReordering": true
            	   ,"allowColumnResizing"  : true
            	   , "columnResizingMode" : 'widget'
            	   ,"cacheEnabled"         : false
            	   ,"cellHintEnabled"      : true
            	   ,"columnAutoWidth"      : true
            	   ,"columnFixing" : {"enabled": true}
            	   ,"editing" : {
            	        "mode"          : "batch"
            	       ,"allowUpdating" : true
            	       ,"allowAdding"   : true
            	       ,"allowDeleting" : false
            	    }
            	   ,"filterRow" : {"visible": false}
            	   ,"hoverStateEnabled"     : true
            	   ,"loadPanel"             : {"enabled": false}
            	   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
            	   ,"remoteOperations"      : {
            	        "filtering" : false
            	       ,"grouping"  : false
            	       ,"paging"    : false
            	       ,"sorting"   : false
            	       ,"summary"   : false
            	    }
            	   ,"rowAlternationEnabled" : true
            	   ,"searchPanel"           : {
            	        "visible" : false
            	       ,"width"   : 250
            	    }
            	   ,"selection"             : {
            	        "allowSelectAll"    : true
            	       ,"deferred"          : false
            	       ,"mode"              : "single"
            	       ,"selectAllMode"     : "allPages"
            	       ,"showCheckBoxesMode": "always"
            	    }
            	   ,"showBorders"           : true
            	   ,"showColumnLines"       : true
            	   ,"showRowLines"          : true
            	   ,"sorting"               : {"mode": "multiple"}
            	   ,"width"                 : "inherit"
            	   ,"wordWrapEnabled"       : false
//             	   ,"summary": {
//             	        "totalItems": [{
//             	            "column"       : "QUESTIONCODE"
//             	           ,"summaryType"  : "count",
//             	           valueFormat: "fixedPoint",
//             	           alignment: "left"
//             	        }],
//             	        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
//             	    }
            	   ,"columns" : [
            	        {"dataField": "QUESTIONCODE","caption": '${msgel.getMsg("AML_20_01_01_90_122","*의심유형세부코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 120},
            	        {"dataField": "QUESTION","caption": '${msgel.getMsg("AML_20_01_01_90_123","의심유형세부코드명")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true}
            	    ]
            	   ,"onCellClick" : function(e) {
            	        if (e.data) {
            	            
            	        }
            	    }
                ,"onInitialized" : function(e) {
                	doSearchSuspicionQuestion();
                }
        	}).dxDataGrid("instance");
    }
    
    function setupGrids5() {        
    	//거래내역[Transaction]
    	GridObj5 = $("#GTDataGrid05_Area").dxDataGrid({
    		"gridId"          : "GTDataGrid05"
                ,"height" : 'calc(40vh - 50px)'
                	,"elementAttr" : { class: "grid-table-type" }
                ,"export" : {
            		        allowExportSelectedData : true
            		       ,enabled                 : true
            		       ,excelFilterEnabled      : true
                  }
            	,"onExporting" : function (e) {
		            		var workbook = new ExcelJS.Workbook();
		            		var worksheet = workbook.addWorksheet("Sheet1");
            			    DevExpress.excelExporter.exportDataGrid({
            			        component: e.component,
            			        worksheet:worksheet,
            			        autoFilterEnabled: true,
            			    }).then(function() {
            			        workbook.xlsx.writeBuffer().then(function(buffer) {
            			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_203','거래내역')}.xlsx");
            			        });
            			    });
            			    e.cancel = true;
            	}
            	,"allowColumnReordering": true
            	   ,"allowColumnResizing"  : true
            	   ,"cacheEnabled"         : false
            	   ,"cellHintEnabled"      : true
            	   ,"columnAutoWidth"      : true
            	   ,"columnFixing" : {"enabled": true}
            	   ,"editing" : {
            	        "mode"          : "batch"
            	       ,"allowUpdating" : true
            	       ,"allowAdding"   : true
            	       ,"allowDeleting" : false
            	    }
            	   ,"filterRow" : {"visible": false}
            	   ,"hoverStateEnabled"     : true
            	   ,"loadPanel"             : {"enabled": false}
            	   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
            	   ,"remoteOperations"      : {
            	        "filtering" : false
            	       ,"grouping"  : false
            	       ,"paging"    : false
            	       ,"sorting"   : false
            	       ,"summary"   : false
            	    }
            	   ,"rowAlternationEnabled" : true
            	   ,"searchPanel"           : {
            	        "visible" : false
            	       ,"width"   : 250
            	    }
            	   ,"selection"             : {
            	        "allowSelectAll"    : true
            	       ,"deferred"          : false
            	       ,"mode"              : "single"
            	       ,"selectAllMode"     : "allPages"
            	       ,"showCheckBoxesMode": "always"
            	    }
            	   ,"showBorders"           : true
            	   ,"showColumnLines"       : true
            	   ,"showRowLines"          : true
            	   ,"sorting"               : {"mode": "multiple"}
            	   ,"width"                 : "inherit"
            	   ,"wordWrapEnabled"       : false
//             	   ,"summary": {totalItems: [{column: 'SEQ', summaryType: 'count', valueFormat: "fixedPoint"}],
//             		   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
            	   ,"columns" : [
            	        {"dataField": "SEQ",			"caption": 'SEQ',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 80},
            	        {"dataField": "DDATE",			"caption": '${msgel.getMsg("AML_20_01_02_01_004","거래일자")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "DTIME",			"caption": '${msgel.getMsg("AML_20_01_01_08_100","거래시간")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 80},
            	        {"dataField": "CHANNELCODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_124","*거래채널코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "CHANNEL",		"caption": '${msgel.getMsg("AML_20_02_02_01_090","거래채널")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        
            	        {"dataField": "MEANCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_125","*거래수단코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "MEAN",			"caption": '${msgel.getMsg("AML_20_02_02_01_091","거래수단")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "METHODCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_126","*거래종류코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "METHOD",			"caption": '${msgel.getMsg("AML_20_02_02_01_093","거래종류")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "GOODSCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_127","*거래상품코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        
            	        {"dataField": "GOODS",			"caption": '${msgel.getMsg("AML_20_01_01_90_128","거래상품")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "MONEYTYPECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_129","*통화코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "MONEYTYPE",		"caption": '${msgel.getMsg("AML_20_01_01_90_130","통화")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible" : false},
            	        {"dataField": "KRWAMOUNT",		"caption": '${msgel.getMsg("AML_20_01_01_90_012","원화금액")}',"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "FOREIGNAMOUNT",	"caption": '${msgel.getMsg("AML_20_07_01_01_048","외국환금액")}',"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        
            	        {"dataField": "USDAMOUNT",			"caption": '${msgel.getMsg("AML_20_01_01_90_013","달러화환산금액")}',"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "ORGNAMECODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_131","*금융기관코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "ORGNAME",			"caption": '${msgel.getMsg("AML_20_01_01_90_041","금융기관")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "BRANCHOFFICE",		"caption": '${msgel.getMsg("AML_20_01_01_90_132","지점")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "BRANCHOFFICECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_133","*지점코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        
            	        {"dataField": "BRANCHOFFICEZIPCODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_134","*지점우편번호")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            	        {"dataField": "GNL_AC_NO",				"caption": 'GNL_AC_NO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
            	        {"dataField": "GDS_NO",					"caption": 'GDS_NO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false}
            	    ]
            	   ,"onCellClick" : function(e) {
            	        if (e.data) {
            	            Grid5CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
            	        }
            	    }
                ,"onInitialized" : function(e) {
                	doSearchTransaction();
                }
        	}).dxDataGrid("instance");
    }
    
    //Grid 클릭 - 거래내역[Transaction]
    function Grid5CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId)
    {
        selectObjGrid5 = obj;
        doSearchTransUserRelation(obj);			//거래자역할 Transaction__UserRelation
		doSearchTransAccountRelation(obj);		//거래에 대한 계약관계 [Transaction]_[AccountRelation]
		doSearchTransSecurities(obj);			//거래에 대한 유가증권[Transaction]_[Securities]
		doSearchTransForeignExchange(obj);		//거래에 대한 외환및환전 [Transaction]_[ForeignExchange]
		doSearchTransOtherBank(obj);			//거래에 대한 타행계좌 [Transaction]_[OtherBank]
		doSearchTransStock(obj);
    }
    
    function setupGrids6(){        
    	//거래에 대한 거래자역할 [Transaction]_[UserRelation]
    	GridObj6 = $("#GTDataGrid06_Area").dxDataGrid({
    		"gridId"          : "GTDataGrid06"
                ,"height" : 'calc(25vh - 50px)'
                ,"elementAttr" : { class: "grid-table-type" }
                ,"export" : {
            		        allowExportSelectedData : true
            		       ,enabled                 : true
            		       ,excelFilterEnabled      : true
                  }
            	,"onExporting" : function (e) {
		            		var workbook = new ExcelJS.Workbook();
		            		var worksheet = workbook.addWorksheet("Sheet1");
            			    DevExpress.excelExporter.exportDataGrid({
            			        component: e.component,
            			        worksheet:worksheet,
            			        autoFilterEnabled: true,
            			    }).then(function() {
            			        workbook.xlsx.writeBuffer().then(function(buffer) {
            			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_204','거래에 대한 거래자역할')}.xlsx");
            			        });
            			    });
            			    e.cancel = true;
            	}
            	,"allowColumnReordering": true
            	   ,"allowColumnResizing"  : true
            	   , "columnResizingMode" : 'widget'
            	   ,"cacheEnabled"         : false
            	   ,"cellHintEnabled"      : true
            	   ,"columnAutoWidth"      : true
            	   ,"columnFixing" : {"enabled": true}
            	   ,"filterRow" : {"visible": false}
            	   ,"hoverStateEnabled"     : true
            	   ,"loadPanel"             : {"enabled": false}
            	   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
            	   ,"remoteOperations"      : {
            	        "filtering" : false
            	       ,"grouping"  : false
            	       ,"paging"    : false
            	       ,"sorting"   : false
            	       ,"summary"   : false
            	    }
            	   ,"rowAlternationEnabled" : true
            	   ,"searchPanel"           : {
            	        "visible" : false
            	       ,"width"   : 250
            	    }
            	   ,"selection"             : {
            	        "allowSelectAll"    : true
            	       ,"deferred"          : false
            	       ,"mode"              : "single"
            	       ,"selectAllMode"     : "allPages"
            	       ,"showCheckBoxesMode": "always"
            	    }
            	   ,"showBorders"           : true
            	   ,"showColumnLines"       : true
            	   ,"showRowLines"          : true
            	   ,"sorting"               : {"mode": "multiple"}
            	   ,"width"                 : "inherit"
            	   ,"wordWrapEnabled"       : false
//             	   ,"summary": {totalItems: [{column: 'RELATIONROLE', alignment:'left', summaryType: 'count', valueFormat: "fixedPoint"}],
//             		   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
            	   ,"columns" : [
            	        {"dataField": "RELATIONROLE",		"caption": '${msgel.getMsg("AML_20_01_01_90_135","거래자역할")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
            	        {"dataField": "RELATIONROLECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_136","*거래자역할코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
            	        {"dataField": "REALNUMBER",			"caption": '${msgel.getMsg("AML_20_01_01_90_137","*실명확인번호")}'
            	        	, customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; }
            	            ,"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
            	        {"dataField": "REALNUMBERCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_138","*실명확인번호구분코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 120},
            	        {"dataField": "REALNUMBERCODENAME",	"caption": '${msgel.getMsg("AML_20_01_01_90_139","실명확인번호구분명")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
            	        {"dataField": "INSURELDESC",		"caption": '${msgel.getMsg("AML_20_01_01_90_140","관계설명")}',"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
            	        {"dataField": "CS_NM",				"caption": '${msgel.getMsg("AML_20_01_01_04_044","성명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
            	        {"dataField": "NATIONALITY",		"caption": '${msgel.getMsg("AML_20_01_01_90_141","국가명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
            	        {"dataField": "NATIONALITYCODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_142","국가코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
            	        {"dataField": "RNMCNO",				"caption": 'RNMCNO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
            	    ]
        	}).dxDataGrid("instance");
    }
    
    function setupGrids61() {        
    	//거래에 대한 계약관계 [Transaction]_[AccountRelation]
    	GridObj61 = $("#GTDataGrid61_Area").dxDataGrid({
            "gridId"          : "GTDataGrid61"
        		,"height" : 'calc(22vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function()  {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_205','거래에 대한 계약관계')}.xlsx");
        						});
        					});
        					e.cancel = true;
        		}
        		,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,"columnResizingMode" : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'ORGNAMECODE', alignment:'left', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {"dataField": "ORGNAMECODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_143","*금융기관코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 130},
        		        {"dataField": "ORGNAME",			"caption": '${msgel.getMsg("AML_20_01_01_08_014","금융기관명")}',			"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 140},
        		        {"dataField": "ACCOUNTNUMBER",		"caption": '${msgel.getMsg("AML_20_01_01_90_144","*계좌번호")}',			"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
        		        {"dataField": "ACCOUNTROLECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_145","*계좌유형구분코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
        		        {"dataField": "ACCOUNTROLE",		"caption": '${msgel.getMsg("AML_20_01_01_90_146","계좌유형구분명")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true}
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    function setupGrids53(){        
    	//거래에 대한 외환및환전 [Transaction]_[ForeignExchange]
    	GridObj53 = $("#GTDataGrid53_Area").dxDataGrid({
                 "gridId"          : "GTDataGrid53"
        		,"height" : 'calc(22vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
        					var workbook = new ExcelJS.Workbook();
        					var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet : worksheet,
        						autoFilterEnabled: true,
        					}).then(function(){
        						workbook.xlsx.writeBuffer().then(function(buffer){
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_206','거래에 대한 외환및환전')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   , columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'PURPOSE', alignment:'left', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {"dataField": "PURPOSE",		"caption": '${msgel.getMsg("AML_20_01_01_90_147","외환거래목적명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "PURPOSECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_148","*외환거래목적코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true}
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    function setupGrids52() {        
    	//거래에 대한 유가증권[Transaction]_[Securities]
    	GridObj52 = $("#GTDataGrid52_Area").dxDataGrid({
            "gridId"          : "GTDataGrid52"
        		,"height" : 'calc(22vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function()  {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_207','거래에 대한 유가증권')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   , columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'SECURITIESTYPE', alignment:'left', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {"dataField": "SECURITIESTYPE",		"caption": '${msgel.getMsg("AML_20_01_01_90_149","유가증권종류명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "SECURITIESTYPECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_150","*유가증권종류코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
        		        {"dataField": "SECURITIESNUMBER",	"caption": '${msgel.getMsg("AML_20_01_10_32_002","유가증권번호")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "ORGNAME",			"caption": '${msgel.getMsg("AML_20_01_01_90_151","지급금융기관명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "ORGNAMECODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_152","*지급금융기관코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
        		        
        		        {"dataField": "BRANCHOFFICE",		"caption": '${msgel.getMsg("AML_20_01_01_90_153","지급영업점명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "ISSUEORGNAME",		"caption": '${msgel.getMsg("AML_20_01_01_90_154","발행금융기관명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "ISSUEORGNAMECODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_155","*발행금융기관코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
        		        {"dataField": "ISSUEBRANCHOFFICE",	"caption": '${msgel.getMsg("AML_20_01_01_90_156","발행영업점명")}',"alignment": "center","allowResizing": true,"allowSearch": true,"width": 100},
        		        {"dataField": "ISSUEAMOUNT",		"caption": '${msgel.getMsg("AML_20_01_10_32_007","금액")}',"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        
        		        {"dataField": "ISSUEDATE",			"caption": '${msgel.getMsg("AML_20_01_10_32_008","발행일자")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 100},
        		        {"dataField": "ISSUERDIV",			"caption": '${msgel.getMsg("AML_20_01_01_90_157","발행인구분")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ISSUERDIVCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_158","*발행인구분코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
        		        {"dataField": "REALNUMBER",			"caption": '${msgel.getMsg("AML_20_01_01_90_137","*실명확인번호")}'
        		        	, customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; }
							,"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110
						},
        		        {"dataField": "REALNUMBERCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_159","실명확인번호구분코드")}',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 110},
        		        
        		        {"dataField": "SSPS_DL_CRT_DT",		"caption": 'SSPS_DL_CRT_DT',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
        		        {"dataField": "SSPS_DL_ID",			"caption": 'SSPS_DL_ID',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
        		        {"dataField": "GNL_AC_NO",			"caption": 'GNL_AC_NO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
        		        {"dataField": "GDS_NO",				"caption": 'GDS_NO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
        		        {"dataField": "DL_DT",				"caption": 'DL_DT',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false},
        		        {"dataField": "DL_SQ",				"caption": 'DL_SQ',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false}
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    function setupGrids51() {        
    	//거래에 대한 타행계좌 [Transaction]_[OtherBank]
    	GridObj51 = $("#GTDataGrid51_Area").dxDataGrid({
            "gridId"          : "GTDataGrid51"
        		,"height" : 'calc(22vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_208','거래에 대한 타행계좌')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,"columnResizingMode" : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"export" : {
        		        "allowExportSelectedData"   : true
        		       ,"excelFilterEnabled"        : true
        		       ,"fileName"                  : "타행계좌"
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {
//         		        "totalItems": [{
//         		            "column"       : "ACCOUNTNUMBER"
//         		           ,"summaryType"  : "count",
//         		           valueFormat: "fixedPoint",
//         		           alignment: "left"
//         		        }],
//         		        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		        ,"columns" : [
        		        {
        		            "dataField": "ACCOUNTNUMBER",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_037","송/수취계좌번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "ACCOUNTHOLDERTYPECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_209","*계좌주구분코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90          
        		        },{
        		            "dataField": "ACCOUNTHOLDERTYPE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_210","*계좌주구분명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "NAME",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_211","계좌주명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "NATIONALITYCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_212","*상대국가코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "NATIONALITY",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_213","상대국가명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "ORGNAMECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_214","*금융기관코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "ORGNAME",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_215","*금융기관명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "BRANCHOFFICEZIPCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_216","*영업점우편번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "BRANCHOFFICECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_217","상대영업점코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "BRANCHOFFICE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_218","상대영업점명")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true
        		        },{
        		            "dataField": "SSPS_DL_CRT_DT",
        		            "caption": 'SSPS_DL_CRT_DT',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false
        		        },{
        		            "dataField": "SSPS_DL_ID",
        		            "caption": 'SSPS_DL_ID',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false
        		        },{
        		            "dataField": "GNL_AC_NO",
        		            "caption": 'GNL_AC_NO',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false
        		        },{
        		            "dataField": "GDS_NO",
        		            "caption": 'GDS_NO',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false
        		        },{
        		            "dataField": "DL_DT",
        		            "caption": 'DL_DT',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false
        		        },{
        		            "dataField": "DL_SQ",
        		            "caption": 'DL_SQ',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90,
        		            "visible": false                                            
        		        }
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    function setupGrids54() {        
    	//거래에 대한 증권 [Transaction]_[STOCK]
    	GridObj54 = $("#GTDataGrid54_Area").dxDataGrid({
            "gridId"          : "GTDataGrid54"
        		,"height" : 'calc(22vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_227','거래에 대한 증권')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,"columnResizingMode" : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"export" : {
        		        "allowExportSelectedData"   : true
        		       ,"excelFilterEnabled"        : true
        		       ,"fileName"                  : "증권"
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {
//         		        "totalItems": [{
//         		            "column"       : "ACCOUNTNUMBER"
//         		           ,"summaryType"  : "count",
//         		           valueFormat: "fixedPoint",
//         		           alignment: "left"
//         		        }],
//         		        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		        ,"columns" : [
        		        	{
        		                "dataField": "TRANSTYPECODE",
        		                "caption": '거래종류코드',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "TRANSTYPE",
        		                "caption": '거래종류',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90          
        		            },{
        		                "dataField": "STOCKNAME",
        		                "caption": '종목명',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "QUANTITY",
        		                "caption": '매매수량',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "ORGNAMECODE",
        		                "caption": '*금융기관코드',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "ORGNAME",
        		                "caption": '금융기관명',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "BRANCHOFFICEZIPCODE",
        		                "caption": '*영업점우편번호',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "BRANCHOFFICECODE",
        		                "caption": '상대영업점코드',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "BRANCHOFFICE",
        		                "caption": '상대영업점명',
        		                "alignment": "left",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 100
        		            },{
        		                "dataField": "SSPS_DL_CRT_DT",
        		                "caption": 'SSPS_DL_CRT_DT',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false
        		            },{
        		                "dataField": "SSPS_DL_ID",
        		                "caption": 'SSPS_DL_ID',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false
        		            },{
        		                "dataField": "GNL_AC_NO",
        		                "caption": 'GNL_AC_NO',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false
        		            },{
        		                "dataField": "GDS_NO",
        		                "caption": 'GDS_NO',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false
        		            },{
        		                "dataField": "DL_DT",
        		                "caption": 'DL_DT',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false
        		            },{
        		                "dataField": "DL_SQ",
        		                "caption": 'DL_SQ',
        		                "alignment": "center",
        		                "allowResizing": true,
        		                "allowSearch": true,
        		                "allowSorting": true,
        		                "width": 90,
        		                "visible": false                                            
        		            }
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) { 
        		        
        		        }
        		    }
        }).dxDataGrid("instance");
    } 
    
    function setupGrids70() {     
    	//거래자정보[User]
    	GridObj70 = $("#GTDataGrid70_Area").dxDataGrid({
            "gridId"          : "GTDataGrid70"
        		,"height" : 'calc(25vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
        					var workbook = new ExcelJS.Workbook();
        					var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_219','거래자정보')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {
//         		        "totalItems": [{
//         		            "column"       : "NAME"
//         		           ,"summaryType"  : "count",
//         		           valueFormat: "fixedPoint",
//         		           alignment: "left"
//         		        }],
//         		        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
//         		    }
        		   ,"columns" : [
        		        {"dataField": "NAME",				"caption": '${msgel.getMsg("AML_20_02_02_01_057","거래자명")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 130},
        		        {"dataField": "REALNUMBER",			"caption": '${msgel.getMsg("AML_20_01_01_90_137","*실명확인번호")}'		
        		        	, customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; }
        		        	, "alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": "130px"},
        		        {"dataField": "REALNUMBERCODE",		"caption": '${msgel.getMsg("AML_20_01_01_90_138","*실명확인번호구분코드")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": "140px"},
        		        {"dataField": "REALNUMBERTYPENAME",	"caption": '${msgel.getMsg("AML_20_01_01_90_139","실명확인번호구분명")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
        		        {"dataField": "NATIONALITYCODE",	"caption": '${msgel.getMsg("AML_20_01_01_90_160","*국적코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": "90px"},
        		        {"dataField": "NATIONALITY",		"caption": '${msgel.getMsg("AML_20_04_01_01_024","국적")}',			"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
        		        {"dataField": "INDV_CORP_CCD",		"caption": '${msgel.getMsg("AML_20_01_13_01_014","개인법인구분")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
        		        {"dataField": "RNMCNO",				"caption": 'RNMCNO',												"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		        	Grid70CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    // Grid 클릭시 - 거래자정보[User]
    function Grid70CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId) {
    	doSearchUserDetailInfo(obj);
    }
    
    function setupGrids72() {     
    	//거래자정보 User 상세조회
    	GridObj72 = $("#GTDataGrid72_Area").dxDataGrid({
                 "gridId"          : "GTDataGrid72"
        		,"height" : 'calc(22vh - 50px)'
        	    ,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
        					var workbook = new ExcelJS.Workbook();
        					var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_220','거래자정보 User 상세조회')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {
//         		        "totalItems": [{
//         		            "column"       : "REALNUMBER"
//         		           ,"summaryType"  : "count",
//         		           valueFormat: "fixedPoint",
//         		           alignment: "left"
//         		        }],
//         		        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
//         		    }
        		   ,"columns" : [
        		        {"dataField": "REALNUMBER","caption": 'REALNUMBER',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,
        		            "width": 120
        		        },
        		        {"dataField": "REALNUMBERCODE",			"caption": 'REALNUMBERCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "REALNUMBERTYPENAME",		"caption": 'REALNUMBERTYPENAME',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "NATIONALITY",			"caption": 'NATIONALITY',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "NATIONALITYCODE",		"caption": 'NATIONALITYCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "PHONE",					"caption": 'PHONE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "PHONEHANDPHONE",			"caption": 'PHONEHANDPHONE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "ADDRESS",				"caption": 'ADDRESS',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ADDRESSZIPCODE",			"caption": '*ADDRESSZIPCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ADDRESSCOMPANY",			"caption": 'ADDRESSCOMPANY',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ADDRESSCOMPANYZIPCODE",	"caption": '*ADDRESSCOMPANYZIPCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "PHONECOMPANY",			"caption": 'PHONECOMPANY',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "MIXEDREALNUMBER",		"caption": 'MIXEDREALNUMBER',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIRTHDAY",				"caption": 'BIRTHDAY',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "CEONAME",				"caption": 'CEONAME',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "CEOREALNUMBER",			"caption": 'CEOREALNUMBER',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "KSICCODE",				"caption": '*KSICCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "KSIC",					"caption": 'KSIC',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "GENDER",					"caption": 'GENDER',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "GENDERCODE",				"caption": '*GENDERCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "PASSPORTNO",				"caption": 'PASSPORTNO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "COMPANY",				"caption": 'COMPANY',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "DEPTNAME",				"caption": 'DEPTNAME',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "POSITION",				"caption": 'POSITION',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "OCCUPATIONTYPE",			"caption": 'OCCUPATIONTYPE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "OCCUPATIONTYPECODE",		"caption": '*OCCUPATIONTYPECODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIZNO",					"caption": 'BIZNO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ISHIGHASSET",			"caption": 'ISHIGHASSET',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "CORPNO",					"caption": 'CORPNO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIZADDRESS",				"caption": 'BIZADDRESS',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIZADDRESSZIPCODE",		"caption": '*BIZADDRESSZIPCODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIZTELNO",				"caption": 'BIZTELNO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "HOMEPAGEURL",			"caption": 'HOMEPAGEURL',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "BIZSCALE",				"caption": 'BIZSCALE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "BIZSCALECODE",			"caption": '*BIZSCALECODE',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ISBANKINGORGAN",			"caption": 'ISBANKINGORGAN',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ISNONPROFITCORP",		"caption": 'ISNONPROFITCORP',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "ISNATIONALPUBLICGROUP",	"caption": 'ISNATIONALPUBLICGROUP',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        
        		        {"dataField": "ISSTOCKLIST",		"caption": 'ISSTOCKLIST',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "STOCKLISTINFO",		"caption": 'STOCKLISTINFO',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
        		        {"dataField": "PSTN_CD",			"caption": 'PSTN_CD',"alignment": "center","allowResizing": true,"allowSearch": true,"width": 90,"visible": false},
        		        {"dataField": "SSPS_DL_RNMCNO_F",	"caption": 'SSPS_DL_RNMCNO_F',"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90,"visible": false}
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        }).dxDataGrid("instance");
    }
    
    function setupGrids9() {     
    	//계약정보 Account
    	GridObj9 = $("#GTDataGrid09_Area").dxDataGrid({
            "gridId"          : "GTDataGrid09"
        		,"height" : 'calc(30vh - 50px)'
        	    ,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet:worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_221','계약정보')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : true
        		       ,"allowAdding"   : true
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'ORGNAME', alignment:'center', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {
        		            "dataField": "ORGNAME",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_041","금융기관")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "ORGNAMECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_131","*금융기관코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100  
        		        },{
        		            "dataField": "BRANCHOFFICE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_132","지점")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90
        		        },{
        		            "dataField": "BRANCHOFFICECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_133","*지점코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90
        		        },{
        		            "dataField": "BRANCHOFFICEZIPCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_134","*지점우편번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90
        		        },{
        		            "dataField": "ACCOUNTNUMBER",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_161","*계약번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 110
        		        },{
        		            "dataField": "REGDATE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_162","*계약개설일")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90
        		        },{
        		            "dataField": "ACCOUNTUSER",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_163","*계약주실명확인번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; },
        		            "width": 130
        		        },{
        		            "dataField": "ACCOUNTUSERCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_164","*계약주실명확인번호구분")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 120
        		        },{
        		            "dataField": "AGENTFLAG",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_165","대리인존재여부")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90  
        		        },{
        		            "dataField": "AGENTUSER",
        		            "caption": '${msgel.getMsg("AML_20_07_01_01_027","대리인실명확인번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; },
        		            "width": 100
        		         },{
        		            "dataField": "AGENTUSERCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_166","대리인실명확인번호구분")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 120
        		         },{
        		            "dataField": "ACCOUNTOPENPURPOSE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_167","계약개설목적")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 110
        		         },{
        		            "dataField": "ACCOUNTOPENPURPOSECODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_168","*계약개설목적코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 110                                   
        		        }
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        		   ,"onInitialized" : function(e) {
        			   doSearchAccount();
                   }
        }).dxDataGrid("instance");
    }
    
    function setupGrids91() {     
    	//거래자간의 관계 InterUserRelation
    	GridObj91 = $("#GTDataGrid91_Area").dxDataGrid({
                 "gridId"          : "GTDataGrid91"
        		,"height" : 'calc(25vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet : worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer){
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_222','거래자간의 관계')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : true
        		       ,"allowAdding"   : true
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'RELATION', alignment:'center', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {
        		            "dataField": "RELATION",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_169","거래자관계명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 90
        		        },{
        		            "dataField": "RELATIONCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_170","*거래자관계코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 100
        		        },{
        		            "dataField": "PRINCIPALUSER",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_171","*계좌주실명확인번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; },
        		            "width": 110
        		        },{
        		            "dataField": "PRINCIPALUSERCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_172","*계좌주실명확인구분코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 120
        		        },{
        		            "dataField": "PARTICIPANTUSER",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_173","*관계인실명확인번호")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            customizeText: function(cellInfo){let val = cellInfo.value ; if (!val) return "" ; return val.substring(0,7) + "******"; },
        		            "allowSorting": true
        		        },{
        		            "dataField": "PARTICIPANTUSERCODE",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_174","*관계인실명확인구분코드")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true
        		        },{
        		            "dataField": "REMARK",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_175","관계명")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true                          
        		        }
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            
        		        }
        		    }
        		   ,"onInitialized" : function(e) {
        			   doSearchInterUserRelation();
                   }
        }).dxDataGrid("instance");
    }
    
    function setupGrids10() {     
    	//첨부파일 FileAttach
    	GridObj10 = $("#GTDataGrid10_Area").dxDataGrid({
                 "gridId"          : "GTDataGrid10"
        		,"height" : 'calc(25vh - 50px)'
        		,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : false
        				   ,excelFilterEnabled      : true
        		  }
        		   ,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,"columnResizingMode" : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : true
        		       ,"allowAdding"   : true
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {
//         		        "totalItems": [{
//         		            "column"       : "USER_FILE_NM"
//         		           ,"summaryType"  : "count",
//         		           valueFormat: "fixedPoint"
//         		        }],
//         		        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'},
//         		    }
        		   ,"columns" : [
        		        {
        		            "dataField": "USER_FILE_NM",
        		            "caption": 'FILENAME',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            allowEditing: false,
        		            "cssClass": "link"                                   
        		        },{
        		            "dataField": "FILE_PATH",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_176","파일경로")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "visible": false
        		        },{
        		            "dataField": "PHSC_FILE_NM",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_177","파일물리이름")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "visible": false
        		        },{
        		            "dataField": "FILE_SEQ",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_178","파일일련번호")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "visible": false
        		        }
        		    ]
        		   ,"onCellClick" : function(e) {
        		        if (e.data) {
        		            Grid10CellClick('gridId', e.data, e.rowIndex, e.columnIndex, e.column.dataField);
        		        }
        		    }
        		   ,"onInitialized" : function(e) {
        			   doSearchFileAttach();
                   }
        }).dxDataGrid("instance");
    }
    
    
    function setupGrids92() {     
    	//보고항목 체크로그 목록
    	GridObj92 = $("#GTDataGrid92_Area").dxDataGrid({
            "gridId"          : "GTDataGrid92"
        		,"height" : 'calc(30vh - 50px)'
        			,"elementAttr" : { class: "grid-table-type" }
        		,"export" : {
        					allowExportSelectedData : true
        				   ,enabled                 : true
        				   ,excelFilterEnabled      : true
        		  }
        		,"onExporting" : function (e) {
		        			var workbook = new ExcelJS.Workbook();
		        			var worksheet = workbook.addWorksheet("Sheet1");
        					DevExpress.excelExporter.exportDataGrid({
        						component: e.component,
        						worksheet : worksheet,
        						autoFilterEnabled: true,
        					}).then(function() {
        						workbook.xlsx.writeBuffer().then(function(buffer) {
        							saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_90_223','보고항목 체크로그 목록')}.xlsx");
        						});
        					});
        					e.cancel = true;
                		}
        		,"allowColumnReordering": true
        		   ,"allowColumnResizing"  : true
        		   ,columnResizingMode : 'widget'
        		   ,"cacheEnabled"         : false
        		   ,"cellHintEnabled"      : true
        		   ,"columnAutoWidth"      : true
        		   ,"columnFixing" : {"enabled": true}
        		   ,"editing" : {
        		        "mode"          : "batch"
        		       ,"allowUpdating" : false
        		       ,"allowAdding"   : false
        		       ,"allowDeleting" : false
        		    }
        		   ,"filterRow" : {"visible": false}
        		   ,"hoverStateEnabled"     : true
        		   ,"loadPanel"             : {"enabled": false}
        		   ,pager: {
	           	    	visible: true
	           	    	,showNavigationButtons: true
	           	    	,showInfo: true
	           	    }
	           	    ,paging: {
	           	    	enabled : true
	           	    	,pageSize : 20
	           	    }
	       	 	   	,scrolling : {
	       	            mode            : "standard"
	       	           ,preloadEnabled  : false
	       	        }
        		   ,"remoteOperations"      : {
        		        "filtering" : false
        		       ,"grouping"  : false
        		       ,"paging"    : false
        		       ,"sorting"   : false
        		       ,"summary"   : false
        		    }
        		   ,"rowAlternationEnabled" : true
        		   ,"searchPanel"           : {
        		        "visible" : false
        		       ,"width"   : 250
        		    }
        		   ,"selection"             : {
        		        "allowSelectAll"    : true
        		       ,"deferred"          : false
        		       ,"mode"              : "single"
        		       ,"selectAllMode"     : "allPages"
        		       ,"showCheckBoxesMode": "always"
        		    }
        		   ,"showBorders"           : true
        		   ,"showColumnLines"       : true
        		   ,"showRowLines"          : true
        		   ,"sorting"               : {"mode": "multiple"}
        		   ,"width"                 : "inherit"
        		   ,"wordWrapEnabled"       : false
//         		   ,"summary": {totalItems: [{column: 'SQ', alignment:'center', summaryType: 'count', valueFormat: "fixedPoint"}],
//         			   texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}}
        		   ,"columns" : [
        		        {
        		            "dataField": "SQ",
        		            "caption": 'SEQ',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 50
        		        },{
        		            "dataField": "PROC_FALG_NM",
        		            "caption": '${msgel.getMsg("AML_20_02_10_02_006","처리구분")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true,
        		            "width": 60
        		        },{
        		            "dataField": "PROC_CTNT",
        		            "caption": '${msgel.getMsg("AML_20_01_01_90_179","체크에러항목")}',
        		            "alignment": "left",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true
        		        },{
        		            "dataField": "HNDL_DY_TM",
        		            "caption": '${msgel.getMsg("AML_20_02_10_02_011","처리일시")}',
        		            "alignment": "center",
        		            "allowResizing": true,
        		            "allowSearch": true,
        		            "allowSorting": true
        		        }
        		    ]
        		   ,"onCellClick" : function(e) {
//         		        if (e.data) {
//         		            clickGrid1Cell('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
//         		        }
        		    }
        		    ,"onInitialized" : function(e) {
        		    	doSearchFiuLog("init");
                    }
        }).dxDataGrid("instance");
    }
    
    function setInitVal(flag){
    	//~~~ 의심스러운 거래에 대한 서술 ~~~
		/*
		form1.CWHO.readOnly 				= flag;		//의심거래자
		form1.CWHEN.readOnly 				= flag;		//거래발생일
		form1.CWHERE.readOnly 				= flag;		//거래발생장소
		form1.CWHAT.readOnly 				= flag;		//금융거래수단
		form1.CHOW.readOnly 				= flag;		//금융거래방법
		form1.CWHY.readOnly 				= flag;		//혐의거래 판단 사유
		form1.SYNTHETICOPINION.readOnly 	= flag;		//종합의견
		form1.BRANCHOFFICESCORE.readOnly 	= flag;		//영업점의심점수
		form1.ETCPECULARITYTYPE.readOnly 	= flag;		//기타 특징 및 유형
		form1.ORGSCORE.readOnly 			= flag;		//본점의심점수
		*/
		
		//~~~ 거래자정보 [User] ~~~
		//form1.combo_US_NTN_CD.disabled          = flag;
		form1.US_PHONE_AREA.readOnly 			= flag;		//전화번호2
		form1.US_PHONE_ECNO.readOnly 			= flag;		//전화번호3
		form1.US_PHONE_NO.readOnly 			= flag;		//전화번호3
		form1.US_BIRTHDAY.readOnly 			= flag;		//생년월일/설립일
		form1.US_ADDRESSZIPCODE.readOnly 	= flag;		//우편번호[자택/본점]
		form1.US_ADDRESS_BSC.readOnly 			= flag;		//주소(자택/본점)
		form1.US_ADDRESS_DNG.readOnly 			= flag;		//주소(자택/본점)
		
		$("#US_PHONE_AREA").attr("readonly",flag);		//핸드폰번호
		$("#US_PHONE_ECNO").attr("readonly",flag);		//핸드폰번호
		$("#US_PHONE_NO").attr("readonly",flag);		//핸드폰번호
		$("#US_BIRTHDAY").attr("readonly",flag);		//핸드폰번호
		$("#US_ADDRESSZIPCODE").attr("readonly",flag);		//핸드폰번호
		$("#US_ADDRESS_BSC").attr("readonly",flag);		//핸드폰번호
		$("#US_ADDRESS_DNG").attr("readonly",flag);		//핸드폰번호
		
		
		//~~~ [개인의 경우] ~~~
		//form1.US_PHONEHANDPHONE_NATI.readOnly 	= flag;		//핸드폰번호
		$("#US_PHONEHANDPHONE_AREA").attr("readonly",flag);		//핸드폰번호
		$("#US_PHONEHANDPHONE_ECNO").attr("readonly",flag);		//핸드폰번호
		$("#US_PHONEHANDPHONE_NO").attr("readonly",flag);		//핸드폰번호
		$("#US_COMPANY").attr("readonly",flag);		//직장명
		$("#US_DEPTNAME").attr("readonly",flag);	//부서명
		$("#US_POSITION").attr("readonly",flag);		//직위
		$("#US_ADDRESSCOMPANYZIPCODE").attr("readonly",flag);	//우편번호(직장)
		$("#US_ADDRESSCOMPANY_BSC").attr("readonly",flag);	//주소(직장)
		$("#US_ADDRESSCOMPANY_DNG").attr("readonly",flag);	//주소(직장)
		$("#combo_US_OCCUPATION").attr("readonly",flag);	//직업구분
		
		//~~~ [법인 및 단체의 경우] ~~~
		$("#US_HOMEPAGEURL").attr("readonly",flag);	    //홈페이지	
		$("#US_CORPNO").attr("readonly",flag);			//법인등록번호
		$("#US_BIZTELNO_AREA").attr("readonly",flag);	//전화번호(사업장)
		$("#US_BIZTELNO_ECNO").attr("readonly",flag);	//전화번호(사업장)
		$("#US_BIZTELNO_NO").attr("readonly",flag);		//전화번호(사업장)
		$("#US_BIZADDRESSZIPCODE").attr("readonly",flag);	//우편번호(사업장)
		$("#US_BIZADDRESS_BSC").attr("readonly",flag);  //주소(사업장)
		$("#US_BIZADDRESS_DNG").attr("readonly",flag);	//주소(사업장)
 
		form1.combo_ISNATIONAL.disabled 	= flag;		//국가공공단체여부
		form1.combo_ISBANKINGORGAN.disabled = flag;		//금융기관여부
		form1.combo_BIZSCALE.disabled 	= flag;			//기업규모
		form1.combo_ISSTOCKLIST.disabled = flag;	//상장여부
		form1.combo_ISNONPROFITCORP.disabled  = flag;	//비영리법인여부
		
		
		if(!flag){
			//~~~ 의심스러운 거래에 대한 서술 ~~~
			/*
			form1.CWHO.className 	= "input_text01";					//의심거래자
			form1.CWHEN.className 	= "input_text01";					//거래발생일
			form1.CWHERE.className 	= "input_text01";					//거래발생장소
			form1.CWHAT.className 	= "input_text01";					//금융거래수단
			form1.CHOW.className 	= "input_text01";					//금융거래방법
			form1.CWHY.className 	= "input_text01";					//혐의거래 판단 사유
			form1.SYNTHETICOPINION.className 	= "input_text01";		//종합의견
			form1.BRANCHOFFICESCORE.className 	= "input_text01";		//영업점의심점수
			form1.ETCPECULARITYTYPE.className 	= "input_text01";		//기타 특징 및 유형
			form1.ORGSCORE.className 			= "input_text01";		//본점의심점수
			*/
			
			//~~~ 거래자정보 [User] ~~~
			form1.US_PHONE_AREA.className 			= "input_text01";		//전화번호2
			form1.US_PHONE_ECNO.className 			= "input_text01";		//전화번호3
			form1.US_PHONE_NO.className 			= "input_text01";		//전화번호3
			form1.US_BIRTHDAY.className 		= "input_text01";		//생년월일/설립일
			form1.US_ADDRESSZIPCODE.className 	= "input_text01";		//우편번호[자택/본점]
			form1.US_ADDRESS_BSC.className 			= "input_text01";		//주소(자택/본점)
			form1.US_ADDRESS_DNG.className 			= "input_text01";		//주소(자택/본점)
			
			//~~~ [개인의 경우] ~~~
			//form1.US_PHONEHANDPHONE_NATI.className 	= "input_text01";		//핸드폰번호
			form1.US_PHONEHANDPHONE_AREA.className 	= "input_text01";		//핸드폰번호
			form1.US_PHONEHANDPHONE_ECNO.className 	= "input_text01";		//핸드폰번호
			form1.US_PHONEHANDPHONE_NO.className 	= "input_text01";		//핸드폰번호
			form1.US_COMPANY.className 			= "input_text01";		//직장명
			form1.US_DEPTNAME.className 		= "input_text01";		//부서명
			form1.US_POSITION.className 		= "input_text01";		//직위
			form1.US_ADDRESSCOMPANYZIPCODE.className = "input_text01";	//우편번호(직장)
			form1.US_ADDRESSCOMPANY_BSC.className 	= "input_text01";		//주소(직장)
			form1.US_ADDRESSCOMPANY_DNG.className 	= "input_text01";		//주소(직장)
			
			//~~~ [법인 및 단체의 경우] ~~~
			form1.US_HOMEPAGEURL.className 		= "input_text01";		//홈페이지
			form1.US_CORPNO.className 			= "input_text01";		//법인등록번호
			//form1.US_BIZTELNO_NATI.className 		= "input_text01";		//전화번호(사업장)
			form1.US_BIZTELNO_AREA.className 		= "input_text01";		//전화번호(사업장)
			form1.US_BIZTELNO_ECNO.className 		= "input_text01";		//전화번호(사업장)
			form1.US_BIZTELNO_NO.className 		= "input_text01";		//전화번호(사업장)
			form1.US_BIZADDRESSZIPCODE.className = "input_text01";		//우편번호(사업장)
			form1.US_BIZADDRESS_BSC.className 		= "input_text01";		//주소(사업장)
			form1.US_BIZADDRESS_DNG.className 		= "input_text01";		//주소(사업장)
			
			form1.img_US_KSIC.style.display = "inline"; 	//업종코드버튼 보이게
		}
	}
	
    //SELECTBOX 선택시 hidden값 세팅하기
	function onSelectChange(obj){	

		if(obj.value == 'ALL') obj.value = '';
		
		if(obj.name == 'combo_US_NTN_CD'){
			//국적
			form1.US_NATIONALITYCODE.value = obj.value;
		}		
		if(obj.name == 'combo_US_OCCUPATION'){
			//직업구분
			form1.US_OCCUPATIONTYPECODE.value = obj.value;			
		}
		if(obj.name == 'combo_US_GENDER'){
			//성별
			form1.US_GENDERCODE.value = obj.value;			
		}
		if(obj.name == 'combo_US_ISHIGHASSET'){
			//고액자산가여부
			form1.US_ISHIGHASSET.value = obj.value;			
		}
		
		if(obj.name == 'combo_ISBANKINGORGAN'){
			//금융기관여부
			form1.US_ISBANKINGORGAN.value = obj.value;			
		}
		if(obj.name == 'combo_BIZSCALE'){
			//기업규모
			form1.US_BIZSCALECODE.value = obj.value;			
		}
		if(obj.name == 'combo_ISNONPROFITCORP'){
			//비영리법인여부
			form1.US_ISNONPROFITCORP.value = obj.value;			
		}
		if(obj.name == 'combo_ISSTOCKLIST'){
			//상장여부
			form1.US_ISSTOCKLIST.value = obj.value;
			
			if(obj.value == 'Y'){
				//form1.combo_US_STOCKLISTINFO.style.display = 'block';
				form1.combo_US_STOCKLISTINFO.disabled = false;
			} else {
				//form1.combo_US_STOCKLISTINFO.style.display = 'none';
				form1.US_STOCKLISTINFO.value = "";
				form1.combo_US_STOCKLISTINFO.disabled = true;
				$("#combo_US_STOCKLISTINFO").val("");
			}
			
			/*
			if(obj.value == 'Y'){
				//form1.US_STOCKLISTINFO.readOnly = false;
				//form1.US_STOCKLISTINFO.className = "input_text01";
				form1.combo_US_STOCKLISTINFO.disabled = false;
			}else{
				//form1.US_STOCKLISTINFO.readOnly = true;
				//form1.US_STOCKLISTINFO.className = "input_t_dis";
				form1.combo_US_STOCKLISTINFO.disabled = true;
			}*/
			
		}
		if(obj.name == 'combo_ISNATIONAL'){
			//국가공공단체여부
			form1.US_ISNATIONALPUBLICGROUP.value = obj.value;			
		}
		/*
		if(obj.name == 'combo_US_POSITION'){
			//직위
			var idx = obj.selectedIndex;
			form1.US_POSITION.value = obj.options[idx].text;
			form1.US_PSTN_CD.value = obj.value;
		}
		 */
		if(obj.name == 'combo_US_STOCKLISTINFO'){
			//상장여부
			form1.US_STOCKLISTINFO.value = obj.value;
		}
	}
    
    function doSearch() {        
    	form1.SSPS_DL_CRT_DT.value = "${SSPS_DL_CRT_DT}";
		form1.SSPS_DL_ID.value = "${SSPS_DL_ID}";
		form1.CS_NM.value = "${DL_P_NM}";
		form1.cs_nm.value = "${DL_P_NM}";
		form1.INDV_CORP_CCD.value = "${INDV_CORP_CCD}";
		form1.BTN_SAVE_F.value = "${BTN_SAVE_F}";
		
		form1.pageID.value = "AML_20_01_01_90";
		form1.methodID.value = "";
	    form1.target = "_self";
		form1.action = "<c:url value='/'/>0001.do";
			
		form1.submit();
    }
    
    function doSearch_end(data){
    	
    }
    
    function doClose(){
		//doSearch();
		//opener.doSearch();
		window.close(); 
	}
    
    //의심유형조회
	function doSearchSuspicionTitle() {		
		overlay.show(true, true);        
        var actionParam    = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getMaster_Suspicion_Title"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                           
            };
        sendService( actionParam.classID, actionParam.methodID, actionParam, doSearchCommon_end, doSearchCommon_end);
	}
    
	function doSearchCommon_end(gridData, data) {    	       
		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	GridObj3.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//의심유형세부코드조회
	function doSearchSuspicionQuestion() {		
		overlay.show(true, true);        
		//GridObj31.clearSelection();
		//GridObj31.option('dataSource', []);
		var actionParam    = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getMaster_Suspicion_Question"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                           
            };
		sendService(actionParam.classID, actionParam.methodID, actionParam, doSearch31Common_end, doSearch31Common_end);
	}
	
	function doSearch31Common_end(gridData, data) {    	       
		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	GridObj31.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//거래내역조회 Detail__Transaction
	function doSearchTransaction() {
		overlay.show(true, true);        
		//GridObj5.clearSelection();
		//GridObj5.option('dataSource', []); 
		var actionParam    = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_Basic_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"moneyType"			: "KRW"
            };
		sendService(actionParam.classID, actionParam.methodID, actionParam, doSearchTransaction_end, doSearchTransaction_end);
	}
	
	function doSearchTransaction_end(gridData, data) {
		
		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
            $.each(data.GRID_DATA,function(i,o){o.ROW_NUM=i;});
            //GridObj5.selectRow([0]);     
            GridObj5.option("dataSource", gridData);
            Grid5CellClick(GridObj5,gridData[0]);
        }
        overlay.hide();
	}
	
	//거래자역할 Transaction__UserRelation
	function doSearchTransUserRelation(grdObj) {
		overlay.show(true, true);        
		GridObj6.clearSelection();
		GridObj6.option('dataSource', []); 
		var actionParam    = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_UserRelation_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_TM"				: grdObj.DTIME
               ,"DL_SQ"				: grdObj.SEQ
            };
	    sendService(actionParam.classID, actionParam.methodID, actionParam, doSearchUserRelation_end, doSearchUserRelation_end);
	}
	
	//결과값 - 거래자역할 Transaction__UserRelation
	function doSearchUserRelation_end(gridData, data) {
		overlay.hide();
		var realNumber = "", realNumberBfr = "";
		var chkFlag = "Y";
		var gridObjTmp = new Object();
		var GridObj70Data = new Array();
		
		GridObj6.option("dataSource", gridData);
		
		GridObj70.clearSelection();
		GridObj70.option('dataSource', []); 
		
		
		for(var i = 0; i < gridData.length; i++) {
			var obj = gridData[i];
			
			realNumber = obj.REALNUMBER;
			
			if(realNumberBfr != realNumber){
				
				var objNew = new Object();
				
				objNew.NAME 				= obj.CS_NM;				//거래자명
				objNew.REALNUMBER 			= obj.REALNUMBER;			//실명번호
				objNew.REALNUMBERCODE 		= obj.REALNUMBERCODE;		//실명번호구분코드
				objNew.REALNUMBERTYPENAME 	= obj.REALNUMBERCODENAME;	//실명번호구분명
				objNew.NATIONALITYCODE 		= obj.NATIONALITYCODE;		//국가코드
				objNew.NATIONALITY 			= obj.NATIONALITY;			//국가명
				objNew.INDV_CORP_CCD 		= obj.INDV_CORP_CCD;		//개인법인구분
				objNew.RNMCNO 				= obj.RNMCNO;				//실명번호(암호화)
				objNew.REALNUMBERCODE 		= obj.REALNUMBERCODE;		//실명구분코드
				objNew.RELATIONROLECODE 	= obj.RELATIONROLECODE;		//거래자역할코드
				
				
				GridObj70Data.push(objNew);
				
				if(chkFlag == "Y") {
					//첫번째 데이터를 담는다.
					gridObjTmp.REALNUMBERCODE 		= obj.REALNUMBERCODE;		//실명번호구분코드
					gridObjTmp.REALNUMBERTYPENAME 	= obj.REALNUMBERCODENAME;	//실명번호구분명
					gridObjTmp.NAME 				= obj.CS_NM;				//거래자명
					gridObjTmp.NATIONALITYCODE 		= obj.NATIONALITYCODE;		//국적-코드
					gridObjTmp.INDV_CORP_CCD 		= obj.INDV_CORP_CCD;		//개인법인구분코드
					gridObjTmp.RNMCNO 		 		= obj.RNMCNO;				//실명번호(암호화)
					
					chkFlag = "N";
				}
				
				
			}
			realNumberBfr = obj.REALNUMBER;
		}	
		GridObj70.option('dataSource', GridObj70Data); 
	    
	    //거래자정보 첫행 클릭 
		doSearchUserDetailInfo(GridObj70Data[0]);
	}
	
	//거래에 대한 계약관계 [Transaction]_[AccountRelation]
	function doSearchTransAccountRelation(grdObj) {
		overlay.show(true, true);        
		GridObj61.clearSelection();
		GridObj61.option('dataSource', []); 
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_AccountRelation_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_TM"				: grdObj.DTIME
               ,"DL_SQ"				: grdObj.SEQ
            }
		 sendService(actionParam.classID, actionParam.methodID, actionParam, doSearch61Common_end, doSearch61Common_end);
	}
	
	function doSearch61Common_end(gridData, data) {    	       
		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	GridObj61.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//거래에 대한 외환및환전 [Transaction]_[ForeignExchange]
	function doSearchTransForeignExchange(grdObj) {

		if(grdObj.MEANCODE == "05" || grdObj.METHODCODE == "03") {
			form1.EXCH_PURPOSECODE.value = "99";
			form1.EXCH_PURPOSE.value = "기타";	
		}
		/*
		overlay.show(true, true);        
		GridObj53.clearSelection();
		GridObj53.option('dataSource', []);
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_ForeignExchange"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_TM"				: grdObj.DTIME
               ,"DL_SQ"				: grdObj.SEQ
            };
		sendService( actionParam.classID, actionParam.methodID, actionParam, doSearchTransForeignExchange_end, doSearchTransForeignExchange_end);
		*/
	}
	
	// 결과값 - 거래에 대한 외환및환전 [Transaction]_[ForeignExchange]
	function doSearchTransForeignExchange_end(gridData, data) {
		if(gridData.length > 0){
			var obj = gridData[0];
			if(obj.PURPOSECODE == undefined) return;
			
			form1.EXCH_PURPOSECODE.value = obj.PURPOSECODE;
			form1.EXCH_PURPOSE.value = obj.PURPOSE;			
		}				
	}
	
	//거래에 대한 유가증권[Transaction]_[Securities]
	function doSearchTransSecurities(grdObj) {
		overlay.show(true, true);        
		GridObj52.clearSelection();
		GridObj52.option('dataSource', []); 
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_Securities_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_TM"				: grdObj.DTIME
               ,"DL_SQ"				: grdObj.SEQ
            };
		 sendService( actionParam.classID, actionParam.methodID, actionParam, doSearch52Common_end, doSearch52Common_end);
	}
	
	function doSearch52Common_end(gridData, data) {    	       
		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	GridObj52.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//거래에 대한 타행계좌 [Transaction]_[OtherBank]
	function doSearchTransOtherBank(grdObj) {
		overlay.show(true, true);        
		GridObj51.clearSelection();
		GridObj51.option('dataSource', []); 
            var actionParam  = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_OtherBank"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_TM"				: grdObj.DTIME
               ,"DL_SQ"				: grdObj.SEQ
            };
            sendService( actionParam.classID, actionParam.methodID, actionParam, doSearchTransOtherBank_end, doSearchTransOtherBank_end);
	}
	
	//결과값 - 거래에 대한 타행계좌 [Transaction]_[OtherBank]
	function doSearchTransOtherBank_end(gridData, data) {
		if(gridData.length > 0){
			var obj = gridData[0];
			if(obj.ACCOUNTNUMBER == undefined) return;
			
			form1.OTH_ACCOUNTNUMBER.value 			= obj.ACCOUNTNUMBER;			//송/수취계좌번호
			form1.OTH_ACCOUNTHOLDERTYPECODE.value 	= obj.ACCOUNTHOLDERTYPECODE;	//계좌주구분-코드
			form1.OTH_ACCOUNTHOLDERTYPE.value 		= obj.ACCOUNTHOLDERTYPE;		//계좌주구분-명
			form1.OTH_NAME.value 					= obj.NAME;						//계좌주명
			form1.OTH_NATIONALITYCODE.value 		= obj.NATIONALITYCODE;			//상대국가-코드
			form1.OTH_NATIONALITY.value 			= obj.NATIONALITY;				//상대국가-명
			form1.OTH_ORGNAMECODE.value 			= obj.ORGNAMECODE;				//금융기관-코드
			form1.OTH_ORGNAME.value 				= obj.ORGNAME;					//금융기관-명
			form1.OTH_BRANCHOFFICEZIPCODE.value 	= obj.BRANCHOFFICEZIPCODE;		//영업점우편번호
			form1.OTH_BRANCHOFFICECODE.value 		= obj.BRANCHOFFICECODE;			//상대영업점코드
			form1.OTH_BRANCHOFFICE.value 			= obj.BRANCHOFFICE;				//상대영업점
		}				
	}
	
	//거래에 대한 타행계좌 [Transaction]_[OtherBank]
	function doSearchTransStock(grdObj) {
		overlay.show(true, true);        
		GridObj54.clearSelection();
		GridObj54.option('dataSource', []); 
            var actionParam  = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Transaction_Stock_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}" 
               ,"GNL_AC_NO"			: grdObj.GNL_AC_NO
               ,"GDS_NO"			: grdObj.GDS_NO
               ,"DL_DT"				: grdObj.DDATE
               ,"DL_SQ"				: grdObj.SEQ
            };
            sendService( actionParam.classID, actionParam.methodID, actionParam, doSearchTransStock_end, doSearchTransStock_end);
	}
	
	function doSearchTransStock_end(gridData, data) {

		if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
			GridObj54.option("dataSource", gridData);
        }
        overlay.hide();   
        
        if(gridData.length > 0){
        	 
       		var obj = gridData[0];
       		if(obj.TRANSTYPECODE == undefined || obj.TRANSTYPECODE == "") return;
       		form1.STK_TRANSTYPECODE.value 			= obj.TRANSTYPECODE;			
   			form1.STK_TRANSTYPE.value 				= obj.TRANSTYPE;	
   			form1.STK_STOCKNAME.value 				= obj.STOCKNAME;		
   			form1.STK_QUANTITY.value 				= obj.QUANTITY;					
   			form1.STK_ORGNAMECODE.value 			= obj.ORGNAMECODE;				//금융기관-코드
   			form1.STK_ORGNAME.value 				= obj.ORGNAME;					//금융기관-명
   			form1.STK_BRANCHOFFICEZIPCODE.value 	= obj.BRANCHOFFICEZIPCODE;		//영업점우편번호
   			form1.STK_BRANCHOFFICECODE.value 		= obj.BRANCHOFFICECODE;			//상대영업점코드
   			form1.STK_BRANCHOFFICE.value 			= obj.BRANCHOFFICE;				//상대영업점
    		
		}	
         			
	}
	
	
	//거래자정보 [User] 조회
	var grObj = null;
	function doSearchUserDetailInfo(grdObj) {
		grObj = grdObj;
		overlay.show(true, true);
		
		if(grdObj.INDV_CORP_CCD == "1") {	//개인
			if(grdObj.RELATIONROLECODE == "01") {
				v_methodID = "getDetail_User_Suspicious_Personal";
				v_custGbn = "11";
			} else if(grdObj.RELATIONROLECODE == "02") {
				v_methodID = "getDetail_User_Company_Personal";
				v_custGbn = "12";
			} else { 
				v_methodID = "getDetail_User_Personal";
				v_custGbn = "13";
			}
		} else {	//법인
			if(grdObj.RELATIONROLECODE == "01") {
				v_methodID = "getDetail_User_Suspicious_Company";
				v_custGbn = "21";
			} else {
				v_methodID = "getDetail_User_Company";
				v_custGbn = "22";
			}
		}
		
		
		GridObj72.clearSelection();
		GridObj72.option('dataSource', []);
		 var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : v_methodID
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"    	: "${SSPS_DL_ID}"
               ,"RNMCNO"			: grdObj.RNMCNO
                            
            };
		  sendService( actionParam.classID, actionParam.methodID, actionParam, doSearchUserDetailInfo_end, doSearchUserDetailInfo_end);
	}
	
	//거래자정보 [User] 결과값
	function doSearchUserDetailInfo_end(data, grd70Obj) {
		overlay.hide();	
		GridObj72.option("dataSource", data);
		if(data.length > 0){
			
			GridObj70.selectRowsByIndexes(0);
			
			var obj = data[0];					
			var objMaster = grObj;
			
			if( objMaster == null ) {
				return;
			}
			//~~~~~~~ 공통영역 START ~~~~~~~
			form1.US_REALNUMBERCODE.value 		= objMaster.REALNUMBERCODE;			//실명번호구분-코드
			form1.US_REALNUMBERTYPENAME.value 	= objMaster.REALNUMBERTYPENAME;		//실명번호구분-명
			form1.US_NAME.value 				= objMaster.NAME;					//성명
			form1.US_NATIONALITYCODE.value 		= objMaster.NATIONALITYCODE;		//국적-코드
			form1.combo_US_NTN_CD.value 		= objMaster.NATIONALITYCODE;		//국적-콤보박스
			//form1.combo_US_NTN_CD.disabled 		= false;	
			form1.US_INDV_CORP_CCD.value 		= objMaster.INDV_CORP_CCD;			//개인법인구분코드
			
			grid70Flag = "Y";	//거래자정보[User] 데이터를 클릭했는지 여부(클릭했으면 'Y')
			//~~~~~~~ 공통영역 END ~~~~~~~
			if(objMaster.INDV_CORP_CCD == '1'){
				//개인
				if(v_custGbn == "13"){
					document.getElementById('divCust_1').style.display='none';
					document.getElementById('divCust_2').style.display='none';
				}else{
					document.getElementById('divCust_1').style.display='block';
					document.getElementById('divCust_2').style.display='none';
				}

			}else{
				//법인
				if(v_custGbn == "13"){
					document.getElementById('divCust_1').style.display='none';
					document.getElementById('divCust_2').style.display='none';
				}else{
					document.getElementById('divCust_1').style.display='none';
					document.getElementById('divCust_2').style.display='block';
				} 
			}
			
			// 실명번호가 없는 법인일 경우, 사업자번호를 넣어준다
			if(obj.REALNUMBER == undefined) obj.REALNUMBER = obj.BIZNO;
		 
			
			if(obj.REALNUMBER != undefined){
				//~~~~~~~ 공통영역 START ~~~~~~~
				form1.US_REALNUMBER.value 				= obj.REALNUMBER.substring(0,7) + "******" ; 	//실명번호(거래자실명번호)
				form1.US_PHONE_AREA.value 				= obj.PHONE_AREA;					//전화번호2
				form1.US_PHONE_ECNO.value 				= obj.PHONE_ECNO;					//전화번호3
				form1.US_PHONE_NO.value 				= obj.PHONE_NO;					//전화번호3
				form1.US_BIRTHDAY.value 				= obj.BIRTHDAY;					//생년월일/설립일
				form1.US_ADDRESSZIPCODE.value 			= obj.ADDRESSZIPCODE;			//우편번호[자택/본점]
				form1.US_ADDRESS_BSC.value 				= obj.ADDRESS_BSC;					//주소(자택/본점)
				form1.US_ADDRESS_DNG.value 				= obj.ADDRESS_DNG;					//주소(자택/본점)
				//form1.US_SSPS_DL_RNMCNO_F.value 		= obj.SSPS_DL_RNMCNO_F;			//이게 뭔지?
						 
				if(v_custGbn == "13" || v_custGbn == "22") {
					flag = true;
				} else {
					if("${BTN_SAVE_F}" == "Y")
						flag = false;
					else
						flag = true;
				}
				
				form1.US_PHONE_AREA.readOnly = flag;
				form1.US_PHONE_ECNO.readOnly = flag;
				form1.US_PHONE_NO.readOnly = flag;
				form1.US_BIRTHDAY.readOnly = flag;
				form1.US_ADDRESSZIPCODE.readOnly = flag;
				form1.US_ADDRESS_BSC.readOnly = flag;
				form1.US_ADDRESS_DNG.readOnly = flag;
				//~~~~~~~ 공통영역 END ~~~~~~~
				
				if(objMaster.INDV_CORP_CCD == '1') {
 
					//~~~~~~~ 개인의 경우 START ~~~~~~~
					//form1.US_PHONEHANDPHONE_NATI.value 			= obj.PHONEHANDPHONE_NATI;			//핸드폰번호
					form1.US_PHONEHANDPHONE_AREA.value 		= obj.PHONEHANDPHONE_AREA;			//핸드폰번호
					form1.US_PHONEHANDPHONE_ECNO.value 		= obj.PHONEHANDPHONE_ECNO;			//핸드폰번호
					form1.US_PHONEHANDPHONE_NO.value 		= obj.PHONEHANDPHONE_NO;			//핸드폰번호
					form1.US_GENDERCODE.value 				= obj.GENDERCODE;				//성별-코드
					form1.combo_US_GENDER.value 			= obj.GENDERCODE;					//성별-명			
					form1.US_ISHIGHASSET.value 				= obj.ISHIGHASSET;				//고액자산가여부
					var OCCUPATIONTYPECODE = obj.OCCUPATIONTYPECODE;	//직업구분-코드
					
					form1.US_OCCUPATIONTYPECODE.value 	= OCCUPATIONTYPECODE;				//직업구분-코드
					$("#combo_US_OCCUPATION").val(OCCUPATIONTYPECODE).prop("selected",true);				//직업구분-콤보박스
					/*
					if(OCCUPATIONTYPECODE.length == 2) {
						form1.US_OCCUPATIONTYPECODE.value 	= OCCUPATIONTYPECODE.substring(1);	//직업구분-코드
						$("#combo_US_OCCUPATION").val(OCCUPATIONTYPECODE.substring(1)).prop("selected",true);	//직업구분-콤보박스
					} else {
						form1.US_OCCUPATIONTYPECODE.value 	= OCCUPATIONTYPECODE;				//직업구분-코드
						$("#combo_US_OCCUPATION").val(OCCUPATIONTYPECODE).prop("selected",true);				//직업구분-콤보박스
					}
					*/
					//form1.combo_US_OCCUPATION.disabled = false;
					form1.US_COMPANY.value 					= obj.COMPANY;					//직장명
					form1.US_DEPTNAME.value 				= obj.DEPTNAME;					//부서명
					form1.US_POSITION.value 				= obj.POSITION;					//직위
					
					if(obj.ADDRESSCOMPANYZIPCODE != "" && obj.ADDRESSCOMPANYZIPCODE != "999999")
						form1.US_ADDRESSCOMPANYZIPCODE.value 	= obj.ADDRESSCOMPANYZIPCODE;	//우편번호(직장)
						
					form1.US_ADDRESSCOMPANY_BSC.value 			= obj.ADDRESSCOMPANY_BSC;			//주소(직장)
					form1.US_ADDRESSCOMPANY_DNG.value 			= obj.ADDRESSCOMPANY_DNG;			//주소(직장)
					
					
					form1.US_PHONEHANDPHONE_AREA.readOnly = flag;
					form1.US_PHONEHANDPHONE_ECNO.readOnly = flag;
					form1.US_PHONEHANDPHONE_NO.readOnly = flag;
					form1.US_GENDERCODE.readOnly = flag;
					form1.combo_US_GENDER.disabled = flag;
					form1.US_ISHIGHASSET.readOnly = flag;
					form1.US_OCCUPATIONTYPECODE.readOnly = flag;
					form1.combo_US_OCCUPATION.disabled = flag;
					form1.US_COMPANY.readOnly = flag;
					form1.US_DEPTNAME.readOnly = flag;
					form1.US_POSITION.readOnly = flag;
					form1.US_ADDRESSCOMPANYZIPCODE.readOnly = flag;
					form1.US_ADDRESSCOMPANY_BSC.readOnly = flag;
					form1.US_ADDRESSCOMPANY_DNG.readOnly = flag;
					//~~~~~~~ 개인의 경우 END ~~~~~~~
					
					//~~~~~~~ 법인의 경우 - INPUT BOX값을 빈값으로 처리 START ~~~~~~~
					form1.US_HOMEPAGEURL.value 			= "";	//홈페이지
					form1.US_CORPNO.value 				= "";	//법인등록번호
					form1.US_BIZSCALECODE.value 		= "";	//기업규모-코드
					//form1.US_BIZTELNO_NATI.value 			= "";	//전화번호(사업장)
					form1.US_BIZTELNO_AREA.value 			= "";	//전화번호(사업장)
					form1.US_BIZTELNO_ECNO.value 			= "";	//전화번호(사업장)
					form1.US_BIZTELNO_NO.value 			= "";	//전화번호(사업장)
					form1.US_KSICCODE.value 			= "";	//업종-코드
					form1.US_KSIC.value 				= "";	//업종-명
					form1.US_BIZADDRESSZIPCODE.value 	= "";	//우편번호(사업장)
					form1.US_BIZADDRESS_BSC.value 			= "";	//주소(사업장)
					form1.US_BIZADDRESS_DNG.value 			= "";	//주소(사업장)
					
					$("#combo_ISNATIONAL").val("N");		//국가공공단체여부
					//$("#combo_ISNATIONAL option[value='N']").attr("selected", "selected");		//국가공공단체여부
					//$("#US_ISNATIONALPUBLICGROUP option:eq(0)").prop("selected", true);		//국가공공단체여부
					//~~~~~~~ 법인의 경우 - INPUT BOX값을 빈값으로 처리 END ~~~~~~~
				} else {
					//~~~~~~~ 법인의 경우 START ~~~~~~~
					form1.US_CEONAME.value 					= obj.CEONAME;					//대표자명
					form1.US_BIZNO.value 					= obj.BIZNO;					//사업자등록번호
					form1.US_HOMEPAGEURL.value 				= obj.HOMEPAGEURL;				//홈페이지
					form1.US_CORPNO.value 					= obj.CORPNO;					//법인등록번호
	
					form1.US_ISNATIONALPUBLICGROUP.value 	= obj.ISNATIONALPUBLICGROUP;	//국가공공단체여부-코드
					form1.combo_ISNATIONAL.value 			= obj.ISNATIONALPUBLICGROUP;	//국가공공단체여부-콤보박스
					form1.combo_ISNATIONAL.disabled 		= false;
					form1.US_ISBANKINGORGAN.value 			= obj.ISBANKINGORGAN;			//금융기관여부-코드
					form1.combo_ISBANKINGORGAN.value 		= obj.ISBANKINGORGAN;			//금융기관여부-콤보박스
					form1.combo_ISBANKINGORGAN.disabled 	= false;
					form1.US_BIZSCALECODE.value 			= obj.BIZSCALECODE;  //obj.BIZSCALECODE;				//기업규모-코드
					form1.combo_BIZSCALE.value 				= obj.BIZSCALE; //obj.BIZSCALECODE;				//기업규모-콤보박스
					form1.combo_BIZSCALE.disabled 			= false;
					form1.US_ISSTOCKLIST.value 				= obj.ISSTOCKLIST;				//상장여부-코드
					form1.combo_ISSTOCKLIST.value 			= obj.ISSTOCKLIST;				//상장여부-콤보박스
					form1.combo_ISSTOCKLIST.disabled 		= false;
					form1.US_ISNONPROFITCORP.value 			= obj.ISNONPROFITCORP;			//비영리법인여부-코드
					form1.combo_ISNONPROFITCORP.value 		= obj.ISNONPROFITCORP;			//비영리법인여부-콤보박스
					form1.combo_ISNONPROFITCORP.disabled 	= false;
					//form1.US_BIZTELNO_NATI.value 				= obj.BIZTELNO_NATI;					//전화번호(사업장)
					form1.US_BIZTELNO_AREA.value 				= obj.BIZTELNO_AREA;					//전화번호(사업장)
					form1.US_BIZTELNO_ECNO.value 				= obj.BIZTELNO_ECNO;					//전화번호(사업장)
					form1.US_BIZTELNO_NO.value 				= obj.BIZTELNO_NO;					//전화번호(사업장)
					form1.US_KSICCODE.value 				= obj.KSICCODE;					//업종-코드
					form1.US_KSIC.value 					= obj.KSIC;						//업종-명
					form1.US_BIZADDRESSZIPCODE.value 		= obj.BIZADDRESSZIPCODE;		//우편번호(사업장)
					form1.US_BIZADDRESS_BSC.value 				= obj.BIZADDRESS_BSC;				//주소(사업장)
					form1.US_BIZADDRESS_DNG.value 				= obj.BIZADDRESS_DNG;				//주소(사업장)
					
					form1.US_CEONAME.readOnly = flag;
					form1.US_BIZNO.readOnly = flag;
					form1.US_HOMEPAGEURL.readOnly = flag;
					form1.US_CORPNO.readOnly = true;  //보고안함
					form1.combo_ISNATIONAL.disabled = flag;
					form1.combo_ISBANKINGORGAN.disabled = flag;
					form1.US_BIZSCALECODE.readOnly = flag;
					form1.combo_BIZSCALE.disabled = flag;
					form1.US_ISSTOCKLIST.readOnly = flag;
					form1.combo_ISSTOCKLIST.disabled = flag;
					form1.combo_US_STOCKLISTINFO.disabled = flag;
					form1.combo_ISNONPROFITCORP.disabled = flag;
					form1.US_BIZTELNO_AREA.readOnly = flag;
					form1.US_BIZTELNO_ECNO.readOnly = flag;
					form1.US_BIZTELNO_NO.readOnly = flag;
					form1.US_KSICCODE.readOnly = flag;
					form1.US_KSIC.readOnly = flag;
					if(flag == false) form1.img_US_KSIC.style.display = "inline";
					else form1.img_US_KSIC.style.display = "none";
					form1.US_BIZADDRESSZIPCODE.readOnly = flag;
					form1.US_BIZADDRESS_BSC.readOnly = flag;
					form1.US_BIZADDRESS_DNG.readOnly = flag;
					//~~~~~~~ 법인의 경우 END ~~~~~~~
					
					//~~~~~~~ 개인의 경우 - INPUT BOX값을 빈값으로 처리 START ~~~~~~~
					//form1.US_PHONEHANDPHONE_NATI.value 			= "";	//핸드폰번호
					form1.US_PHONEHANDPHONE_AREA.value 			= "";	//핸드폰번호
					form1.US_PHONEHANDPHONE_ECNO.value 		= "";	//핸드폰번호
					form1.US_PHONEHANDPHONE_NO.value 		= "";	//핸드폰번호
					form1.US_COMPANY.value 					= "";	//직장명
					form1.US_DEPTNAME.value 				= "";	//부서명
					form1.US_POSITION.value 				= "";	//직위
					form1.US_ADDRESSCOMPANY_BSC.value 			= "";	//주소(직장)
					form1.US_ADDRESSCOMPANY_DNG.value 			= "";	//주소(직장)
					form1.US_ADDRESSCOMPANYZIPCODE.value 	= "";	//우편번호(직장)
					//~~~~~~~ 개인의 경우 - INPUT BOX값을 빈값으로 처리 END ~~~~~~~
				}
				
				
				/*
				//혐의거래인이 아닌 경우, 전화번호,주소 업뎃 X
				if(form1.US_SSPS_DL_RNMCNO_F.value == ''){
					//전화번호
					form1.US_PHONE_AREA.readOnly 					= true;
					form1.US_PHONE_AREA.className 					= "input_t_dis";
					form1.US_PHONE_ECNO.readOnly 					= true;
					form1.US_PHONE_ECNO.className 					= "input_t_dis";
					form1.US_PHONE_NO.readOnly 					= true;
					form1.US_PHONE_NO.className 					= "input_t_dis";
					//우편번호[자택/본점]
					form1.US_ADDRESSZIPCODE.readOnly 			= true;
					form1.US_ADDRESSZIPCODE.className 			= "input_t_dis";
					//주소(자택/본점)
					form1.US_ADDRESS_BSC.readOnly 					= true;
					form1.US_ADDRESS_BSC.className 					= "input_t_dis";
					form1.US_ADDRESS_DNG.readOnly 					= true;
					form1.US_ADDRESS_DNG.className 					= "input_t_dis";
					//핸드폰번호
					//form1.US_PHONEHANDPHONE_NATI.readOnly 			= true;
					//form1.US_PHONEHANDPHONE_NATI.className 			= "input_t_dis";					
					form1.US_PHONEHANDPHONE_AREA.readOnly 			= true;
					form1.US_PHONEHANDPHONE_AREA.className 			= "input_t_dis";
					form1.US_PHONEHANDPHONE_ECNO.readOnly 			= true;
					form1.US_PHONEHANDPHONE_ECNO.className 			= "input_t_dis";
					form1.US_PHONEHANDPHONE_NO.readOnly 			= true;
					form1.US_PHONEHANDPHONE_NO.className 			= "input_t_dis";
					//우편번호(직장)
					form1.US_ADDRESSCOMPANYZIPCODE.readOnly 	= true;
					form1.US_ADDRESSCOMPANYZIPCODE.className 	= "input_t_dis";
					//주소(직장)
					form1.US_ADDRESSCOMPANY_BSC.readOnly 			= true;
					form1.US_ADDRESSCOMPANY_BSC.className 			= "input_t_dis";
					form1.US_ADDRESSCOMPANY_DNG.readOnly 			= true;
					form1.US_ADDRESSCOMPANY_DNG.className 			= "input_t_dis";
					//전화번호(사업장)
					//form1.US_BIZTELNO_NATI.readOnly 					= true;
					//form1.US_BIZTELNO_NATI.className 				= "input_t_dis";
					form1.US_BIZTELNO_AREA.readOnly 					= true;
					form1.US_BIZTELNO_AREA.className 				= "input_t_dis";
					form1.US_BIZTELNO_ECNO.readOnly 					= true;
					form1.US_BIZTELNO_ECNO.className 				= "input_t_dis";
					form1.US_BIZTELNO_NO.readOnly 					= true;
					form1.US_BIZTELNO_NO.className 				= "input_t_dis";
					//우편번호(사업장)
					form1.US_BIZADDRESSZIPCODE.readOnly 		= true;
					form1.US_BIZADDRESSZIPCODE.className 		= "input_t_dis";
					//주소(사업장)
					form1.US_BIZADDRESS_BSC.readOnly 				= true;
					form1.US_BIZADDRESS_BSC.className 				= "input_t_dis";
					form1.US_BIZADDRESS_DNG.readOnly 				= true;
					form1.US_BIZADDRESS_DNG.className 				= "input_t_dis";
				}
				*/
				
			}else{
				//~~~~~~~ 공통영역 START ~~~~~~~
				form1.US_REALNUMBER.value 				= objMaster.REALNUMBER.substring(0,7) + "******";
				form1.US_PHONE_AREA.value 				= '';
				form1.US_PHONE_ECNO.value 				= '';
				form1.US_PHONE_NO.value 				= '';
				form1.US_ADDRESS_BSC.value 				= '';
				form1.US_ADDRESS_DNG.value 				= '';
				form1.US_ADDRESSZIPCODE.value 			= '';							
				form1.US_BIRTHDAY.value 				= '';
				//~~~~~~~ 공통영역 END ~~~~~~~
				
				//~~~~~~~ 개인의 경우 START ~~~~~~~
				//form1.US_PHONEHANDPHONE_NATI.value 			= '';
				form1.US_PHONEHANDPHONE_AREA.value 			= '';
				form1.US_PHONEHANDPHONE_ECNO.value 			= '';
				form1.US_PHONEHANDPHONE_NO.value 			= '';
				form1.US_ADDRESSCOMPANY_BSC.value 			= '';	
				form1.US_ADDRESSCOMPANY_DNG.value 			= '';
				form1.US_ADDRESSCOMPANYZIPCODE.value 	= '';
				form1.combo_US_GENDER.value 					= '';
				form1.US_GENDERCODE.value 				= '';				
				form1.US_COMPANY.value 					= '';
				form1.US_DEPTNAME.value 				= '';
				form1.US_POSITION.value 				= '';
				//form1.US_PSTN_CD.value = '';
				//form1.combo_US_POSITION.value = '';
				//form1.US_OCCUPATIONTYPE.value = '';
				form1.US_ISHIGHASSET.value 				= '';
				form1.US_OCCUPATIONTYPECODE.value 		= '';	//국적
				form1.combo_US_OCCUPATION.value 		= '';	//국적
				//~~~~~~~ 개인의 경우 END ~~~~~~~
				
				//~~~~~~~ 법인의 경우 START ~~~~~~~
				form1.US_CEONAME.value 					= '';
				form1.US_BIZNO.value 					= '';
				form1.US_KSIC.value 					= '';
				form1.US_KSICCODE.value 				= '';
				form1.US_CORPNO.value 					= '';
				form1.US_BIZADDRESS_BSC.value 				= '';
				form1.US_BIZADDRESS_DNG.value 				= '';
				form1.US_BIZADDRESSZIPCODE.value 		= '';
				//form1.US_BIZTELNO_NATI.value 				= '';
				form1.US_BIZTELNO_AREA.value 				= '';
				form1.US_BIZTELNO_ECNO.value 				= '';
				form1.US_BIZTELNO_NO.value 				= '';
				form1.US_HOMEPAGEURL.value 				= '';
				form1.US_BIZSCALECODE.value 			= '';	//기업규모
				form1.US_ISBANKINGORGAN.value 			= '';	//hidden 금융기관여부
				form1.US_ISNONPROFITCORP.value 			= '';	//hidden 비영리법인여부
				form1.US_ISNATIONALPUBLICGROUP.value 	= '';	//hidden 국가공공단체여부
				form1.US_ISSTOCKLIST.value 				= '';	//hidden 상장여부
				form1.US_STOCKLISTINFO.value 			= '';	//hidden 상장여부

				form1.combo_ISNATIONAL.value 			= 'N';	//국가공공단체여부
				form1.combo_ISBANKINGORGAN.value 		= 'N';	//금융기관여부
				form1.combo_BIZSCALE.value 				= '';	//기업규모
				form1.combo_ISSTOCKLIST.value 			= 'N';	//상장여부
				form1.combo_US_STOCKLISTINFO.value 		= '';	//상장여부
				form1.combo_ISNONPROFITCORP.value 		= 'N';	//비영리법인여부
				
				//form1.US_STOCKLISTINFO.value = '';
				//form1.combo_US_STOCKLISTINFO.value = '';
				//~~~~~~~ 법인의 경우 END ~~~~~~~
			}						
		}
	}
	
	//계약정보 Account
	function doSearchAccount() {
		overlay.show(true, true);        
		//GridObj9.clearSelection();
		//GridObj9.option('dataSource', []); 
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_Account_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                
            };
		sendService( actionParam.classID, actionParam.methodID, actionParam, doSearch9Common_end, doSearch9Common_end);
	}
	
	function doSearch9Common_end(gridData, data) {    	        
	    if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	 GridObj9.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//거래자간의 관계 InterUserRelation
	function doSearchInterUserRelation() {
		overlay.show(true, true);        
		//GridObj91.clearSelection();
		//GridObj91.option('dataSource', []); 
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getDetail_InterUserRelation_Kofiu"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                
            }
		sendService( actionParam.classID, actionParam.methodID, actionParam, doSearch91Common_end, doSearch91Common_end);
	}
	
	function doSearch91Common_end(gridData, data) {    	        
	    if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
        	 GridObj91.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//첨부파일 FileAttach
	function doSearchFileAttach() {
		overlay.show(true, true);        
		//GridObj10.clearSelection();
		//GridObj10.option('dataSource', []);
		 var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "getFileAttach"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                
            }
		 sendService( actionParam.classID, actionParam.methodID, actionParam, doSearch10Common_end, doSearch10Common_end);
	}

	function doSearch10Common_end(gridData, data) {    	        
	    if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
	    	GridObj10.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	
	//보고항목 체크로그 목록조회
    function doSearchFiuLog(flag) {
		overlay.show(true, true);        
		//GridObj92.clearSelection();
		//GridObj92.option('dataSource', []); 
		var actionParam = {
                "pageID"            : $("input[name=pageID]","form[name=form1]").val()
               ,"classID"           : "AML_20_01_01_90"
               ,"methodID"          : "doSearchFiuLog"
               ,"SSPS_DL_CRT_DT"    : "${SSPS_DL_CRT_DT}"
               ,"SSPS_DL_ID"   		: "${SSPS_DL_ID}"                           
		}
		
		if (flag == "init") {
		    sendService( actionParam.classID, actionParam.methodID, actionParam, doSearch92Common_end, doSearch92Common_end);
		} else if (flag == "err") {
		    sendService( actionParam.classID, actionParam.methodID, actionParam, refeshFIULog, refeshFIULog);
		}
	}
    
	function doSearch92Common_end(gridData, data) {    	        
	    if (data&&data.GRID_DATA&&data.GRID_DATA.length>0) {
	    	GridObj92.option("dataSource", gridData);
        }
        overlay.hide();        
    }
	function refeshFIULog(gridData, data) {    	        
	    if (data&&data.GRID_DATA&&data.GRID_DATA.length > 0) {
	    	GridObj92.option("dataSource", gridData);
	    	GridObj92.refresh().then(function() {
	    	    GridObj92.focus();
	    	});
        }
        overlay.hide();        
    }
	//확인버튼 클릭시
	function doSaveCheck(){				
		if(grid70Flag == "N") {
    		//저장버튼 클릭시 - 거래자정보 Grid를 클릭했는지
    		showAlert("${msgel.getMsg('AML_20_01_01_90_119','거래자정보[User] 거래자를 클릭하세요.')}","WARN");
    		return false;
    	}
		
		if(!checkValue("chk")) return;

		if(!checkLength()) return;
		
		showAlert("${msgel.getMsg('AML_20_01_01_90_083','정상적으로 체크 완료하였습니다.')}","WARN");
	}
    
    /**
	 *  Validation check 저장
	 */
	function doSave(){
		if(grid70Flag == "N") {
    		//저장버튼 클릭시 - 거래자정보 Grid를 클릭했는지
    		showAlert("${msgel.getMsg('AML_20_01_01_90_119','거래자정보[User] 거래자를 클릭하세요.')}","WARN");
    		return false;
    	}
    	
		
		if(!checkValue("save")) return;

		if(!checkLength()) return;
		
		if(!chkUpdateValue()) return;
		
		showConfirm('${msgel.getMsg("AML_10_01_01_01_004","저장하시겠습니까?")}', "저장", doSaveAction);	
	}
    
   function doSaveAction() {
	    form1.pageID.value = "AML_20_01_01_91";
	    form1.classID.value = "AML_20_01_01_90";
        form1.methodID.value = "doSave";
        form1.action = "<c:url value='/'/>0001.do";
		form1.target = "MyFrame";
		form1.submit();
    }
    
    function doSave_end(ERRCODE) {
        if (ERRCODE == "00003") {
            showAlert("${msgel.getMsg('AML_20_01_01_90_224', '보고항목에 오류가 있습니다. 보고항목 체크로그 확인 후 저장해 주십시오.')}", "ERR", function() {
                doSearchFiuLog("err");
            });
        } else if (ERRCODE == "00000") {
            showAlert("${msgel.getMsg('AML_20_01_01_90_225', '정상처리되었습니다.')}", "INFO", function() {
                doSearch();
            });
        } else {
            showAlert("${msgel.getMsg('AML_20_01_01_90_226', '처리중 오류가 발생했습니다.')}", "ERR", function() {
                doSearch();
            });
        }
    }
	
	function checkLength() {
		if(!checkBytes("CWHO", "${msgel.getMsg('AML_20_01_01_90_018','의심거래자')}", 3000)){	
			return false;
		}		
		if(!checkBytes("CWHEN", "${msgel.getMsg('AML_20_07_01_01_038','거래발생일')}", 3000)){	
			return false;
		}		
		if(!checkBytes("CWHERE", "${msgel.getMsg('AML_20_01_01_90_019','거래발생장소')}", 3000)){	
			return false;
		}		
		if(!checkBytes("CWHAT", "${msgel.getMsg('AML_20_01_01_90_020','금융거래수단')}", 3000)){	
			return false;
		}
		if(!checkBytes("CHOW", "${msgel.getMsg('AML_20_01_01_90_021','금융거래방법')}", 3000)){	
			return false;
		}				
		if(!checkBytes("CWHY", "${msgel.getMsg('AML_20_01_01_90_027','혐의거래 판단 사유')}", 3000)){	
			return false;
		}
		if(!checkBytes("ETCPECULARITYTYPE", "${msgel.getMsg('AML_20_01_01_90_024','기타 특징 및 유형')}", 3000)){	
			return false;
		}
		if(!checkBytes("SYNTHETICOPINION", "${msgel.getMsg('AML_20_01_01_03_028','종합의견')}", 6000)){	
			return false;
		}

		//금칙어체크
		if(!chkContens("CWHO","${msgel.getMsg('AML_20_01_01_90_018','의심거래자')}")){	
			return false;
		}
		if(!chkContens("CWHEN","${msgel.getMsg('AML_20_07_01_01_038','거래발생일')}")){	
			return false;
		}
		if(!chkContens("CWHERE", "${msgel.getMsg('AML_20_01_01_90_019','거래발생장소')}")){	
			return false;
		}
		if(!chkContens("CWHAT", "${msgel.getMsg('AML_20_01_01_90_020','금융거래수단')}")){	
			return false;
		}
		if(!chkContens("CHOW", "${msgel.getMsg('AML_20_01_01_90_021','금융거래방법')}")){	
			return false;
		}
		if(!chkContens("CWHY", "${msgel.getMsg('AML_20_01_01_90_027','혐의거래 판단 사유')}")){	
			return false;
		}
		if(!chkContens("ETCPECULARITYTYPE", "${msgel.getMsg('AML_20_01_01_90_024','기타 특징 및 유형')}")){	
			return false;
		}
		if(!chkContens("SYNTHETICOPINION", "${msgel.getMsg('AML_20_01_01_03_028','종합의견')}")){	
			return false;
		}
		
		//고객정보
		if(!checkBytes("US_REALNUMBER", "${msgel.getMsg('AML_20_01_01_04_003','실명번호')}", 15)){	
			return false;
		}
		if(!checkBytes("US_REALNUMBERCODE", "${msgel.getMsg('AML_20_01_02_01_121','실명번호구분')}", 2)){	
			return false;
		}
		if(!checkBytes("US_NATIONALITYCODE", "${msgel.getMsg('AML_20_04_01_01_024','국적')}", 2)){	
			return false;
		}
		if(!checkBytes("US_PHONE_AREA", "${msgel.getMsg('AML_20_01_01_90_053','전화번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_PHONE_ECNO", "${msgel.getMsg('AML_20_01_01_90_053','전화번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_PHONE_NO", "${msgel.getMsg('AML_20_01_01_90_053','전화번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_BIRTHDAY", "${msgel.getMsg('AML_20_01_01_90_054','생년월일/설립일')}", 8)){	
			return false;
		}
		if(!checkBytes("US_ADDRESSZIPCODE", "${msgel.getMsg('AML_20_01_01_90_055','우편번호[자택/본점]')}", 6)){	
			return false;
		}
		if(!checkBytes("US_ADDRESS_BSC", "${msgel.getMsg('AML_20_01_01_90_056','주소(자택/본점)')}", 200)){	
			return false;
		}
		if(!checkBytes("US_ADDRESS_DNG", "${msgel.getMsg('AML_20_01_01_90_056','주소(자택/본점)')}", 200)){	
			return false;
		}
		
		//개인
		/*
		if(!checkBytes("US_PHONEHANDPHONE", "${msgel.getMsg('AML_20_01_01_90_058','핸드폰번호')}", 25)){	
			return false;
		}
		*/
		if(!checkBytes("US_PHONEHANDPHONE_AREA", "${msgel.getMsg('AML_20_01_01_90_058','핸드폰번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_PHONEHANDPHONE_ECNO", "${msgel.getMsg('AML_20_01_01_90_058','핸드폰번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_PHONEHANDPHONE_NO", "${msgel.getMsg('AML_20_01_01_90_058','핸드폰번호')}", 4)){	
			return false;
		}
		if(!checkBytes("US_COMPANY", "${msgel.getMsg('AML_20_01_01_04_023','직장명')}", 60)){	
			return false;
		}
		if(!checkBytes("US_DEPTNAME", "${msgel.getMsg('AML_20_01_01_05_013','부서명')}", 60)){	
			return false;
		}
		if(!checkBytes("US_POSITION", "${msgel.getMsg('AML_20_01_01_05_015','직위')}", 60)){	
			return false;
		}
		if(!checkBytes("US_ADDRESSCOMPANYZIPCODE", "우편번호(직장)", 6)){	
			return false;
		}
		if(!checkBytes("US_ADDRESSCOMPANY_BSC", "${msgel.getMsg('AML_20_01_01_90_065','주소(직장)')}", 200)){	
			return false;
		}
		if(!checkBytes("US_ADDRESSCOMPANY_DNG", "${msgel.getMsg('AML_20_01_01_90_065','주소(직장)')}", 200)){	
			return false;
		}
		
		//법인
		if(!checkBytes("US_HOMEPAGEURL", "${msgel.getMsg('AML_20_01_01_90_069','홈페이지')}", 200)){	
			return false;
		}
		if(!checkBytes("US_CORPNO", "${msgel.getMsg('AML_20_01_01_06_010','법인등록번호')}", 15)){	
			return false;
		}
		/*
		if(!checkBytes("US_STOCKLISTINFO", "상장정보", 30)){	
			return false;
		}
		if(!checkBytes("US_BIZTELNO_NATI", "${msgel.getMsg('AML_20_01_01_90_074', '전화번호(사업장)')}", 4)){	
			return false;
		}
		*/
		if(!checkBytes("US_BIZTELNO_AREA", "${msgel.getMsg('AML_20_01_01_90_074', '전화번호(사업장)')}", 4)){	
			return false;
		}
		if(!checkBytes("US_BIZTELNO_ECNO", "${msgel.getMsg('AML_20_01_01_90_074', '전화번호(사업장)')}", 4)){	
			return false;
		}
		if(!checkBytes("US_BIZTELNO_NO", "${msgel.getMsg('AML_20_01_01_90_074', '전화번호(사업장)')}", 4)){	
			return false;
		}
		if(!checkBytes("US_KSICCODE", "${msgel.getMsg('AML_20_01_01_04_031', '업종')}", 5)){	
			return false;
		}
		if(!checkBytes("US_BIZADDRESSZIPCODE", "${msgel.getMsg('AML_20_01_01_90_075', '우편번호(사업장)')}", 6)){	
			return false;
		}
		if(!checkBytes("US_BIZADDRESS_BSC", "${msgel.getMsg('AML_20_01_01_90_076', '주소(사업장)')}", 200)){	
			return false;
		}
		if(!checkBytes("US_BIZADDRESS_DNG", "${msgel.getMsg('AML_20_01_01_90_076', '주소(사업장)')}", 200)){	
			return false;
		}
		
		return true;
		
	}
	
	function js_GetBytes(obj_input) {
	 	var input_str;				 
		var len;					 
		var	cur_size = 0;			 
	 	 
		input_str = obj_input;
	 	len = input_str.length;
	 	 
		for (var i=0; i<len; i++){
	 		if (input_str.charCodeAt(i) > 127) cur_size += 2;
	 		else cur_size += 1;
	 	}
		
	 	return cur_size;
	}
		
	function checkBytes(obj_name, msg, pLimitSize) {		
        var obj = eval("document.form1."+obj_name);
        var limitLen = pLimitSize;
        var msgLimitLen = limitLen; //limitLen/2;                
        
        var valBytes = js_GetBytes(obj.value.trim());        
        
        if(valBytes > limitLen){
            obj.focus();
            showAlert(msg+" ${msgel.getMsg('AML_20_01_01_90_084','내용의 길이가 초과되었습니다.')}"+msgLimitLen+"${msgel.getMsg('AML_20_01_01_90_085','문자 초과')}"+"("+valBytes+")","WARN");    
            return false;
        }
        
        return true;
    }
	
	function doPopup(pCode,pflag){				
		if(pflag == "US_KSIC"){			
			form2.pageID.value = 'AML_20_01_01_30'; //업종코드 팝업	
			form2.paramGubn.value = pflag;
			form2.paramCode.value = pCode;
			form2.paramViewSave.value = "Y";
			form2.FUNC_NM.value  = "setValPopup";
			window_popup_open(form2.pageID.value, 420, 650, '');					
		}else{
			return;
		}
		
		form2.target = form2.pageID.value;
		form2.action = "<c:url value='/'/>0001.do";
		form2.submit();
	}
	
	function checkValue(gubn){
		var v_msg = "", v_msg_2 = "";
		//~~~~~~~~~ 의심스러운 거래에 대한 서술 [SuspicionReport] START
		if(form1.CWHO.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_018','의심거래자')}";		    
		}
		if(form1.CWHEN.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_07_01_01_038','거래발생일')}";		    
		}
		if(form1.CWHERE.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_019','거래발생장소')}";		    
		}
		if(form1.CWHAT.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_020','금융거래수단')}";		    
		}
		if(form1.CHOW.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_021','금융거래방법')}";		    
		}
		if(form1.BRANCHOFFICESCORE.value.trim() != "1"
				&& form1.BRANCHOFFICESCORE.value.trim() != "2"
				&& form1.BRANCHOFFICESCORE.value.trim() != "3"
				&& form1.BRANCHOFFICESCORE.value.trim() != "4"
				&& form1.BRANCHOFFICESCORE.value.trim() != "5"
				&& form1.BRANCHOFFICESCORE.value.trim() != ""
				) {			
			v_msg_2 += " ${msgel.getMsg('AML_20_01_01_90_089','영업점의심점수(1~5사이 정수)')}";		    
		}
		if(form1.ORGSCORE.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_090','본점의심점수')}";		    
		}
		if(form1.ORGSCORE.value.trim() != "1"
			&& form1.ORGSCORE.value.trim() != "2"
			&& form1.ORGSCORE.value.trim() != "3"
			&& form1.ORGSCORE.value.trim() != "4"
			&& form1.ORGSCORE.value.trim() != "5"
			) {			
			v_msg_2 += " ${msgel.getMsg('AML_20_01_01_90_091','본점의심점수(1~5사이 정수)')}";		    
		}
		if(form1.CWHY.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_092','혐의거래 판단사유')}";		    
		}
		if(form1.SYNTHETICOPINION.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_03_028','종합의견')}";
		}
		//~~~~~~~~~ 의심스러운 거래에 대한 서술 [SuspicionReport] END
		
		
		//타행계좌
		//if(GridObj51.totalCount() > 0){	
			if(form1.OTH_ACCOUNTNUMBER.value != ""){
				if(form1.OTH_ACCOUNTHOLDERTYPECODE.value == ""){
					v_msg += " ${msgel.getMsg('AML_20_01_01_90_095','[OtherBank]계좌구분코드')}";
				}
				if(form1.OTH_NATIONALITYCODE.value == ""){
					v_msg += " ${msgel.getMsg('AML_20_01_01_90_096','[OtherBank]상대국가코드')}";
				}
				if(form1.OTH_ORGNAMECODE.value == ""){
					v_msg += " ${msgel.getMsg('AML_20_01_01_90_097','[OtherBank]금융기관코드')}";
				}
				if(form1.OTH_BRANCHOFFICEZIPCODE.value == ""){
					v_msg += " ${msgel.getMsg('AML_20_01_01_90_098','[OtherBank]영업점우편번호')}";
				}
				if(form1.OTH_BRANCHOFFICECODE.value == ""){
					v_msg += " ${msgel.getMsg('AML_20_01_01_90_099','[OtherBank]상대영업점코드')}";
				}
			}
		//}
		
		//~~~~~~~~~ 거래자정보 [User] START
		if(form1.US_NATIONALITYCODE.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_104','[User]국적코드')}";
		}
		if(form1.US_ADDRESSZIPCODE.value.trim() == "") {			
			v_msg += " ${msgel.getMsg('AML_20_01_01_90_105','[User]우편번호(자택/본점)')}";
		}
		//~~~~~~~~~ 거래자정보 [User] END
		
		if(form1.US_INDV_CORP_CCD.value == "1") {
			//개인의 경우
			//20231013 직업구분 확인 로직 추가
			if(form1.US_OCCUPATIONTYPECODE.value.trim() == ""){
				v_msg += " ${msgel.getMsg('AML_20_01_01_05_012','직업구분')}";
			}
		} else if(form1.US_INDV_CORP_CCD.value == "2") {
			//법인의 경우
			if(form1.US_BIZSCALECODE.value == "") {
				v_msg += " ${msgel.getMsg('AML_20_01_01_90_116','[법인 및 단체의 경우]기업규모')}";
			}
			if($("#combo_ISSTOCKLIST option:selected").val() == "Y"  &&  $("#combo_US_STOCKLISTINFO option:selected").val() != ""  ) {
				v_msg += " ${msgel.getMsg('AML_20_01_01_90_117','[법인 및 단체의 경우]상장여부')}";
			}
			if(form1.US_KSICCODE.value == "") {
				v_msg += " ${msgel.getMsg('AML_20_01_01_90_118','[법인 및 단체의 경우]업종')}";
			}
		}
		
		
		
		if(v_msg != ""){
			showAlert("${msgel.getMsg('AML_20_01_01_90_111','필수항목입니다.')}"+" \n\n"+v_msg,"WARN");
			if(gubn != "save") return false;
		}
		if(v_msg_2 != ""){
			showAlert("${msgel.getMsg('AML_20_01_01_90_112','확인바랍니다.')}"+" \n\n"+v_msg_2,"WARN");
			if(gubn != "save") return false;
		}
		
		return true;
	}
	
	function chkUpdateValue(){
				
		var v_flag = true;
		var v_70B = 0, v_78B = 0, v_79B = 0;
		var v_67B = 0, v_68B = 0, v_88B = 0;
		var v_totCnt = 0;
		
		/*
		if("${output_mstRep.CWHO}".trim() != form1.CWHO.value.trim()){		//의심거래자
			v_67B++;
		}
		if("${output_mstRep.CWHEN}".trim() != form1.CWHEN.value.trim()){	//거래발생일
			v_67B++;
		}
		if("${output_mstRep.CWHERE}".trim() != form1.CWHERE.value.trim()){	//거래발생장소
			v_67B++;
		}
		if(form1.h_CWHAT.value.trim() != form1.CWHAT.value.trim()){			//금융거래수단
			v_67B++;
		}
		if(form1.h_CHOW.value.trim() != form1.CHOW.value.trim()){			//금융거래방법
			v_67B++;
		}
		if(form1.h_CWHY.value.trim() != form1.CWHY.value.trim()){			//혐의거래 판단 사유
			v_67B++;
		}
		if(form1.h_SYNTHETICOPINION.value.trim() != form1.SYNTHETICOPINION.value.trim()){	//종합의견
			v_67B++;
		}	
		if("${output_mstRep.ORGSCORE}".trim() != form1.ORGSCORE.value.trim()){	//본점의심점수
			v_67B++;
		}	
		
		
		if(form1.h_ETCPECULARITYTYPE.value.trim() != form1.ETCPECULARITYTYPE.value.trim()){	//기타 특징 및 유형
			v_68B++;
		}
		if("${output_mstRep.BRANCHOFFICESCORE}".trim() != form1.BRANCHOFFICESCORE.value.trim()){	//영업점의심점수
			v_88B++;
		}
		*/
		
		if(getCntUpdateUser() > 0){
			v_70B++;
		}
		if(getCntUpdateUserDtl("US1") > 0){
			v_78B++;
		}		
		if(getCntUpdateUserDtl("US2") > 0){
			v_79B++;
		}
		
		
		v_totCnt = v_70B+v_78B+v_79B+v_67B+v_68B+v_88B;
		
		if(v_totCnt <= 0){
			v_flag = false;
			showAlert("${msgel.getMsg('AML_20_01_01_90_113','수정사항이 없습니다.')}","WARN");
		}
		
		form1.cnt_70B.value = v_70B;	//거래자정보[User]
		form1.cnt_78B.value = v_78B;	//거래자정보[User] - 개인
		form1.cnt_79B.value = v_79B; 	//거래자정보[User] - 법인
		form1.cnt_67B.value = v_67B;	//의심거래자, 거래발생일, 거래발생장소, 금융거래수단, 금융거래방법, 혐의거래 판단 사유, 종합의견, 본점의심점수
		form1.cnt_68B.value = v_68B;	//기타 특징 및 유형
		form1.cnt_88B.value = v_88B;	//영업점의심점수
		
		return v_flag;
	}
	
	function getCntUpdateUser(){
		var vCnt=0;
		
		if(GridObj70.totalCount() > 0){
			var obj = GridObj70.getSelectedRowsData()[0];	
			
			if(obj.NATIONALITYCODE.trim() != form1.US_NATIONALITYCODE.value.trim()){
				vCnt++;
			}
		}
		
		return vCnt;
	}
	
	function getCntUpdateUserDtl(gubn){
		var vCnt=0;
		var vFlag = "";
		
		if(GridObj70.totalCount() > 0){
			var obj = GridObj70.getSelectedRowsData()[0];
			
			if(obj.INDV_CORP_CCD == '1' && gubn == "US1"){
				vFlag = "1";
			}else if(obj.INDV_CORP_CCD == '2' && gubn == "US2"){
				vFlag = "2";
			}
			
		}
		
		// 이거 로직 새로 해야함.
		if(GridObj72.totalCount() > 0){
			var obj = getDataSource(GridObj72)[0];

			var v_PHONE_AREA		= form1.US_PHONE_AREA.value.trim();				//전화번호(US_PHONE)
			var v_PHONE_ECNO		= form1.US_PHONE_ECNO.value.trim();				//전화번호(US_PHONE)
			var v_PHONE_NO			= form1.US_PHONE_NO.value.trim();				//전화번호(US_PHONE)
			var v_ADDRESS_BSC 		= form1.US_ADDRESS_BSC.value.trim();			//주소(자택/본점)
			var v_ADDRESS_DNG 		= form1.US_ADDRESS_DNG.value.trim();			//주소(자택/본점)
			var v_ADDRESSZIPCODE 	= form1.US_ADDRESSZIPCODE.value.trim();		//우편번호[자택/본점]
			var v_BIRTHDAY 			= form1.US_BIRTHDAY.value.trim();			//생년월일/설립일
			var v_NATIONALITYCODE 	= form1.US_NATIONALITYCODE.value.trim();	//국적
			
			if(vFlag == "1"){ //개인
				form1.hdn_DL_P_HSE_TEL_NO_AREA.value 	= v_PHONE_AREA;
				form1.hdn_DL_P_HSE_TEL_NO_ECNO.value 	= v_PHONE_ECNO;
				form1.hdn_DL_P_HSE_TEL_NO.value 	= v_PHONE_NO;
				form1.hdn_DL_P_HSE_ADDR_BSC.value 		= v_ADDRESS_BSC;
				form1.hdn_DL_P_HSE_ADDR_DNG.value 		= v_ADDRESS_DNG;
				form1.hdn_DL_P_HSE_PST_NO.value 	    = v_ADDRESSZIPCODE;
				form1.hdn_DL_P_BRTDY.value 		    	= v_BIRTHDAY;
				
			}else if(vFlag == "2"){	//법인
				form1.hdn_HD_BRNCH_TEL_NO_AREA.value 	= v_PHONE_AREA;
				form1.hdn_HD_BRNCH_TEL_NO_ECNO.value 	= v_PHONE_ECNO;
				form1.hdn_HD_BRNCH_TEL_NO.value 		= v_PHONE_NO;
				form1.hdn_HD_BRNCH_ADDR_BSC.value 		= v_ADDRESS_BSC;
				form1.hdn_HD_BRNCH_ADDR_DNG.value 		= v_ADDRESS_DNG;
				form1.hdn_HD_BRNCH_PST_NO.value 	    = v_ADDRESSZIPCODE;
				form1.hdn_FNDTN_DT.value 			    = v_BIRTHDAY;
				form1.hdn_RPRST_P_NTNLT_CD.value	    = v_NATIONALITYCODE;
			}
			
			if(vFlag == "1"){ //개인
				if(obj.PHONE_AREA.trim() != form1.hdn_DL_P_HSE_TEL_NO_AREA.value.trim()){
					vCnt++;
				}
				if(obj.PHONE_ECNO.trim() != form1.hdn_DL_P_HSE_TEL_NO_ECNO.value.trim()){
					vCnt++;
				}
				if(obj.PHONE_NO.trim() != form1.hdn_DL_P_HSE_TEL_NO.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESS_BSC.trim() != form1.hdn_DL_P_HSE_ADDR_BSC.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESS_DNG.trim() != form1.hdn_DL_P_HSE_ADDR_DNG.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESSZIPCODE.trim() != form1.hdn_DL_P_HSE_PST_NO.value.trim()){
					vCnt++;
				}
				if(obj.BIRTHDAY.trim() != form1.hdn_DL_P_BRTDY.value.trim()){
					vCnt++;
				}
				/*
				if(obj.PHONEHANDPHONE_NATI.trim() != form1.US_PHONEHANDPHONE_NATI.value.trim()){
					vCnt++;
				}
				*/
				if(obj.PHONEHANDPHONE_AREA.trim() != form1.US_PHONEHANDPHONE_AREA.value.trim()){
					vCnt++;
				}
				if(obj.PHONEHANDPHONE_ECNO.trim() != form1.US_PHONEHANDPHONE_ECNO.value.trim()){
					vCnt++;
				}
				if(obj.PHONEHANDPHONE_NO.trim() != form1.US_PHONEHANDPHONE_NO.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESSCOMPANY_BSC.trim() != form1.US_ADDRESSCOMPANY_BSC.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESSCOMPANY_DNG.trim() != form1.US_ADDRESSCOMPANY_DNG.value.trim()){
					vCnt++;
				}
				if( (obj.ADDRESSCOMPANYZIPCODE.trim() != "999999" || form1.US_ADDRESSCOMPANYZIPCODE.value.trim() != "")    
					&& (obj.ADDRESSCOMPANYZIPCODE.trim() != form1.US_ADDRESSCOMPANYZIPCODE.value.trim())  ){
					vCnt++;
				}
				if(obj.GENDERCODE.trim() != form1.US_GENDERCODE.value.trim()){
					vCnt++;
				}
				if(obj.COMPANY.trim() != form1.US_COMPANY.value.trim()){
					vCnt++;
				}				
				if(obj.DEPTNAME.trim() != form1.US_DEPTNAME.value.trim()){
					vCnt++;
				}
				if(obj.POSITION.trim() != form1.US_POSITION.value.trim()){
					vCnt++;
				}
				if(obj.OCCUPATIONTYPECODE.trim() != form1.US_OCCUPATIONTYPECODE.value.trim()){
					vCnt++;
				}
				if(obj.ISHIGHASSET.trim() != form1.US_ISHIGHASSET.value.trim()){
					vCnt++;
				}
									
			}else if(vFlag == "2"){ //법인

				if(obj.NATIONALITYCODE.trim() != form1.hdn_RPRST_P_NTNLT_CD.value.trim()){
					vCnt++;
				}
				
				if(obj.PHONE_AREA.trim() != form1.hdn_HD_BRNCH_TEL_NO_AREA.value.trim()){
					vCnt++;
				}
				if(obj.PHONE_ECNO.trim() != form1.hdn_HD_BRNCH_TEL_NO_ECNO.value.trim()){
					vCnt++;
				}
				if(obj.PHONE_NO.trim() != form1.hdn_HD_BRNCH_TEL_NO.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESS_BSC.trim() != form1.hdn_HD_BRNCH_ADDR_BSC.value.trim()){
					vCnt++;
				}
				if(obj.ADDRESS_DNG.trim() != form1.hdn_HD_BRNCH_ADDR_DNG.value.trim()){
					vCnt++;
				}
				
				if(obj.ADDRESSZIPCODE.trim() != form1.hdn_HD_BRNCH_PST_NO.value.trim()){
					vCnt++;
				}
				if(obj.BIRTHDAY.trim() != form1.hdn_FNDTN_DT.value.trim()){
					vCnt++;
				}				
				if(obj.KSICCODE.trim() != form1.US_KSICCODE.value.trim()){
					vCnt++;
				}
				if(obj.CORPNO.trim() != form1.US_CORPNO.value.trim()){
					vCnt++;
				}
				if(obj.BIZADDRESS_BSC.trim() != form1.US_BIZADDRESS_BSC.value.trim()){
					vCnt++;
				}
				if(obj.BIZADDRESS_DNG.trim() != form1.US_BIZADDRESS_DNG.value.trim()){
					vCnt++;
				}				
				if(obj.BIZADDRESSZIPCODE.trim() != form1.US_BIZADDRESSZIPCODE.value.trim()){
					vCnt++;
				}
				/*
				if(obj.BIZTELNO_NATI.trim() != form1.US_BIZTELNO_NATI.value.trim()){
					vCnt++;
				}
				*/
				if(obj.BIZTELNO_AREA.trim() != form1.US_BIZTELNO_AREA.value.trim()){
					vCnt++;
				}
				if(obj.BIZTELNO_ECNO.trim() != form1.US_BIZTELNO_ECNO.value.trim()){
					vCnt++;
				}
				if(obj.BIZTELNO_NO.trim() != form1.US_BIZTELNO_NO.value.trim()){
					vCnt++;
				}
				if(obj.HOMEPAGEURL.trim() != form1.US_HOMEPAGEURL.value.trim()){
					vCnt++;
				}
				if(obj.BIZSCALECODE.trim() != form1.US_BIZSCALECODE.value.trim()){
					vCnt++;
				}
				if(obj.ISBANKINGORGAN.trim() != form1.US_ISBANKINGORGAN.value.trim()){
					vCnt++;
				}
				if(obj.ISNONPROFITCORP.trim() != form1.US_ISNONPROFITCORP.value.trim()){
					vCnt++;
				}				
				if(obj.ISNATIONALPUBLICGROUP.trim() != form1.US_ISNATIONALPUBLICGROUP.value.trim()){
					vCnt++;
				}				
				if(obj.ISSTOCKLIST.trim() != form1.US_ISSTOCKLIST.value.trim()){
					vCnt++;
				}
				if(obj.STOCKLISTINFO.trim() != form1.US_STOCKLISTINFO.value.trim()){
					vCnt++;
				}
				
			}
		}
		
		return vCnt;
	}
	
	//팝업창에서 호출(받은 값 세팅.)
	function setValPopup(objInfo){
		
		if(objInfo.GUBUN == 'US_KSIC'){	//업종코드		
			form1.US_KSICCODE.value = objInfo.CODE_ID.trim();
			form1.US_KSIC.value = objInfo.CODE_NM.trim();		
		}		
	}
    
	function calcBytes(){     
        var obj = eval("document.form1.SYNTHETICOPINION");
        var obj_bytes = eval("document.form1.SYNTHETICOPINION_BYTES");       
        if(obj.value == ''){
        	obj_bytes.value = '0/6000 bytes'
        	return;         
        }
        var vContens = obj.value.trim();        
        var valBytes = js_GetBytes(vContens);
        var end_val = "/6000 bytes";
        
        obj_bytes.value = valBytes+end_val;
        
    }
	
	//입력한 내용 금칙어 및 제한글자수 체크
    function chkContens(obj_name,msg_name,limitLen,limitLen2){
    	var obj = eval("document.form1."+obj_name);
        var vContens = obj.value.trim();
        //금칙어체크
        if(isNotGoodWord(vContens)){
            showAlert(msg_name+" ${msgel.getMsg('AML_20_01_01_90_114','항목에 금칙어가 포함되어있습니다.')}","WARN");
            return false;
        }
        
        return true;        
    }
	

    //금칙어 체크(<,>,&,',\,",;) 
    function isNotGoodWord (val) {
        if (isEmpty(val)) return false;

        var chkVal = "<>&;\\\"\'";      

        for (var i = 0; i < chkVal.length; i++)
        {                       
            for (var j = 0; j < val.length; j++){               
                if (chkVal.charAt(i).indexOf( val.charAt(j) ) > -1) return true;
            }           
        }

        return false;
    }
    
    //Grid 클릭시 - 첨부파일 FileAttach
    function Grid10CellClick(id, obj, rowIdx, colIdx, columnId) {
        try {

        	$("#BOARD_ID"           ,"form[name=form1]").val("${SSPS_DL_CRT_DT}");
            $("#BOARD_SEQ"          ,"form[name=form1]").val("${SSPS_DL_ID}");
            $("input[name=FILE_NO]" ,"form[name=form1]").val(obj.FILE_SEQ);
            $("#FILE_TYPE"          ,"form[name=form1]").val("AML_20");

            form1.target = "_self";
            form1.action =  "<c:url value='/'/>0001.do?pageID=fileDownloadAML" ;
            form1.method = "post";
            form1.submit();
            
        } catch (e) {
            showAlert(e,"ERR");
        }
    }
	
</script>
<!-- 파일 삭제, 다운로드 -->
<form name="fileFrm" id="fileFrm" method="POST">
<input type="hidden" name="pageID" />
<input type="hidden" name="downFileName" id="downFileName" value="" />
<input type="hidden" name="orgFileName" id="orgFileName" value="" />
<input type="hidden" name="downFilePath" id="downFilePath" value="" />
<input type="hidden" name="downType" id="downType" value="" />
</form>
<form name="form2" method="post">
    <input type="hidden"  name="pageID" id="pageID"/>
	<input type="hidden"  name="classID" id="classID"/>
	<input type="hidden"  name="methodID" id="methodID"/>
	<input type="hidden"  name="paramCode" id="paramCode"/>
	<input type="hidden"  name="paramViewSave" id="paramViewSave"/>
	<input type="hidden"  name="paramGubn" id="paramGubn"/>
	<input type="hidden"  name="FUNC_NM" id="FUNC_NM" />
</form>
<!-- Main Body Start -->
<form name="form1" method="post">
    <input type="hidden" name="pageID" value="AML_20_01_01_90"  />
    <input type="hidden" name="classID"/>
	<input type="hidden" name="methodID"/>	
	<input type="hidden" name="SSPS_DL_CRT_DT" id="SSPS_DL_CRT_DT" value="${SSPS_DL_CRT_DT}"/>
	<input type="hidden" name="SSPS_DL_ID" id="SSPS_DL_ID"  value="${SSPS_DL_ID}"/>
	<input type="hidden" id="CS_NM" name="CS_NM"/>
	<input type="hidden" id="cs_nm" name="cs_nm"/>
	<input type="hidden" id="INDV_CORP_CCD" name="INDV_CORP_CCD"/>
	<input type="hidden" id="BTN_SAVE_F" name="BTN_SAVE_F"/>
	<input type="hidden" id="cnt_70B" name="cnt_70B"/>
	<input type="hidden" id="cnt_78B" name="cnt_78B"/>
	<input type="hidden" id="cnt_79B" name="cnt_79B"/>
	<input type="hidden" id="cnt_67B" name="cnt_67B"/>
	<input type="hidden" id="cnt_68B" name="cnt_68B"/>
	<input type="hidden" id="cnt_88B" name="cnt_88B"/>	
	<input type="hidden" name="hdn_DL_P_HSE_TEL_NO_AREA"/>
	<input type="hidden" name="hdn_DL_P_HSE_TEL_NO_ECNO"/>
	<input type="hidden" name="hdn_DL_P_HSE_TEL_NO"/>
	<input type="hidden" name="hdn_DL_P_HSE_ADDR_BSC"/>
	<input type="hidden" name="hdn_DL_P_HSE_ADDR_DNG"/>
	<input type="hidden" name="hdn_DL_P_HSE_PST_NO"/>
	<input type="hidden" name="hdn_DL_P_BRTDY"/>
	<input type="hidden" name="hdn_HD_BRNCH_TEL_NO_AREA"/>
	<input type="hidden" name="hdn_HD_BRNCH_TEL_NO_ECNO"/>
	<input type="hidden" name="hdn_HD_BRNCH_TEL_NO"/>
	<input type="hidden" name="hdn_HD_BRNCH_ADDR_BSC"/>
	<input type="hidden" name="hdn_HD_BRNCH_ADDR_DNG"/>
	<input type="hidden" name="hdn_HD_BRNCH_PST_NO"/>
	<input type="hidden" name="hdn_FNDTN_DT"/>
	<input type="hidden" name="hdn_RPRST_P_NTNLT_CD"/>	
	<input type="hidden" id="h_CWHAT" name="h_CWHAT" value="${output_mstRep.CWHAT}"/>
	<input type="hidden" id="h_CHOW" name="h_CHOW" value="${output_mstRep.CHOW}"/>
	<input type="hidden" id="h_CWHY" name="h_CWHY" value="${output_mstRep.CWHY}"/>
	<input type="hidden" id="h_ETCPECULARITYTYPE" name="h_ETCPECULARITYTYPE" value="${output_mstRep.ETCPECULARITYTYPE}"/>
	<input type="hidden" id="h_SYNTHETICOPINION" name="h_SYNTHETICOPINION" value="${output_mstRep.SYNTHETICOPINION}"/>
	<input type="hidden" id="parentViewId" name="parentViewId" value="${parentViewId}"/>	
	<input type="hidden" name="BOARD_ID"  id="BOARD_ID"/>
	<input type="hidden" name="BOARD_SEQ" id="BOARD_SEQ"/>
	<input type="hidden" name="FILE_SEQ"  id="FILE_SEQ"/>
	<input type="hidden" name="FILE_NO"   id="FILE_NO"/>
	<input type="hidden" name="FILE_TYPE" id="FILE_TYPE"/>
    <div>
        <table class="basic-table" style="width:100%;">
        <tr>
            <th class="title">${msgel.getMsg('AML_20_01_01_03_003','혐의거래ID')}</th>
            <td>                
                <input name="SSPS_DL_CRT_DT_VIEW" id="SSPS_DL_CRT_DT_VIEW" type="text" class="" value="${SSPS_DL_CRT_DT}-${SSPS_DL_ID}" style="width:100%" readonly="readonly">
            </td>
            <th class="title">${msgel.getMsg('AML_20_01_01_03_008','고객명')}</th>
            <td><input name="DL_P_NM" id="DL_P_NM" type="text" class="" value="${DL_P_NM}" style="width:100%" readonly="readonly"></td>            
        </tr>        
        </table>
    </div>
    <div id="div1" style="overflow-y:scroll;height:643px;vertical-align:top;outline:1px solid #CCCCCC;margin-top:10px;" >
	
<!-- ########## 보고기관정보 [Organization] START ########## -->
	   <div class="tab-content-bottom" style="margin-left:7px;">
			<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_026','보고기관정보 [Organization]')}</h4>
		</div>
	   	<table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82;margin-top:7px;margin-left:7px;">										
			<tr>
				<th class="title" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_03_01_016','보고기관')}
				</th>
				<td width="30%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="ORGNAMECODE" value='${output_org.ORGNAMECODE}' style="width:35%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="ORGNAME" value='${output_org.ORGNAME}' style="width:58%;" readonly="readonly"/>
				</td>
				<th class="title" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_03_01_018','보고담당자')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="MAINAUTHORUSERID" value='${output_org.MAINAUTHORUSERID}' style="width:35%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="MAINAUTHOR" value='${output_org.MAINAUTHOR}' style="width:58%;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_03_01_017','보고책임자')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="MANAGER" value='${output_org.MANAGER}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_03_01_019','연락처')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="PHONE" value='${output_org.PHONE}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_04_021','주소')}
				</th>
				<td colspan="3" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="ADDRESSZIPCODE" value='${output_org.ADDRESSZIPCODE}' style="width:13%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="ADDRESS" value='${output_org.ADDRESS}' style="width:84%;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_06_01_01_010','E-Mail')}
				</th>
				<td colspan="3" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="EMAIL" value='${output_org.EMAIL}' style="width:98%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
		</table>
<!-- ########## 보고기관정보 [Organization] END ########## -->

<!-- ########## 취합내용 및 의심정도 정보 [Master] START ########## -->
		<div class="tab-content-bottom" style="margin-left:7px;">
			<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_001','취합내용 및 의심정도 정보 [Master]')}</h4>
		</div>
		
		<table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">																				
			<tr>
				<th class="title" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_002','보고번호')}
				</th>
				<td width="30%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="FIUDOCNUM" value='${output_mst.FIUDOCNUM}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_115','종전문서번호')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="FORMERFIUDOCNUM" value='${output_mst.FORMERFIUDOCNUM}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_004','거래시작일자')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STARTDATE" value='${output_mst.STARTDATE}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_005','거래종료일자')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="ENDDATE" value='${output_mst.ENDDATE}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_006','입금횟수')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="INNERCOUNT" value='${output_mst.INNERCOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_007','출금횟수')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OUTERCOUNT" value='${output_mst.OUTERCOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_008','입금원화금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="INNERKRWAMOUNT" value='${output_mst.INNERKRWAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_009','출금원화금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OUTERKRWAMOUNT" value='${output_mst.OUTERKRWAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_010','입금달러화금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="INNERUSDAMOUNT" value='${output_mst.INNERUSDAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_011','출금달러화금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OUTERUSDAMOUNT" value='${output_mst.OUTERUSDAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_012','원화금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="KRWAMOUNT" value='${output_mst.KRWAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_013','달러화환산금액')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="USDAMOUNT" value='${output_mst.USDAMOUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_014','거래건수')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="COUNT" value='${output_mst.COUNT}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_015','보고유형')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="MESSAGETYPECODE" value='${output_mst.MESSAGETYPECODE}' style="width:94%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_04_02_002','보고일자')}
				</th>
				<td colspan="3" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="DOCSENDDATE" value='${output_mst.DOCSENDDATE}' style="width:35%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
		</table>
<!-- ########## 취합내용 및 의심정도 정보 [Master] END ########## -->

<!-- ########## 의심스러운 거래유형에 관한 정보 [Suspicion] START ########## -->
		<div class="tab-content-bottom" style="margin-left:7px; width:99%;">
			<div class="inner-top">
			   <div class="row">
				  <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_016','의심스러운 거래유형에 관한 정보 [Suspicion]')}</h4>
			   </div>
			<!-- 그리드영역 -->		    				
		    <div id="GTDataGrid03_Area"></div>
		    </div>
		    <div class="inner-bottom" >
		        <div class="row"></div>
		        <div id="GTDataGrid31_Area"></div>
		    </div>
	    </div>
<!-- ########## 의심스러운 거래유형에 관한 정보 [Suspicion] END ########## -->

<!-- ########## 의심스러운 거래에 대한 서술 [SuspicionReport] START ########## -->
		<div class="tab-content-bottom" style="margin-left:7px;">
			<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_017','의심스러운 거래에 대한 서술 [SuspicionReport]')}</h4>
		</div>
					
		<table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">																				
			<tr>
				<th class="title required" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_018','의심거래자')}
				</th>
				<td width="78%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="CWHO" value='${output_mstRep.CWHO}' style="width:98%;margin-left:7px;" readonly="readonly"/>
				</td>								
			</tr>
			<tr>
				<th class="title required" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_07_01_01_105','거래발생일')} 
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="CWHEN" value='${output_mstRep.CWHEN}' style="width:98%;margin-left:7px;" readonly="readonly"/>
				</td>														
			</tr>
			<tr>
				<th class="title required" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_019','거래발생장소')} 
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="CWHERE" value='${output_mstRep.CWHERE}' style="width:98%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title required" width="20%" height="60" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_020','금융거래수단')} 
				</th>
				<td bgcolor="#FFFFFF">
					<textarea name='CWHAT' rows='3' class='textarea-box' style="width:98%;margin-left:7px;" readonly>${output_mstRep.CWHAT}</textarea>
				</td>
			</tr>
			<tr>
				<th class="title required" width="20%" height="60" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_021','금융거래방법')} 
				</th>
				<td bgcolor="#FFFFFF">
					<textarea name='CHOW' rows='3' class='textarea-box' style="width:98%;margin-left:7px;" readonly>${output_mstRep.CHOW}</textarea>
				</td>
			</tr>
			<tr>
				<th class="title" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_022','영업점의심점수')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="BRANCHOFFICESCORE" value='${output_mstRep.BRANCHOFFICESCORE}' style="width:20%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title required" width="20%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_023','본점의심점수')} 
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="ORGSCORE" value='${output_mstRep.ORGSCORE}' style="width:20%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
				<th class="title required" width="20%" height="60" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_027','혐의거래 판단 사유')} 
				</th>
				<td width="30%" bgcolor="#FFFFFF">
					<textarea name='CWHY' rows='3' class='textarea-box' style="width:98%;margin-left:7px;" readonly>${output_mstRep.CWHY}</textarea>
				</td>								
			</tr>
			<tr>
				<th class="title" width="20%" height="60" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_024','기타 특징 및 유형')}
				</th>
				<td bgcolor="#FFFFFF">
					<textarea name='ETCPECULARITYTYPE' rows='3' class='textarea-box' style="width:98%;margin-left:7px;" readonly>${output_mstRep.ETCPECULARITYTYPE}</textarea>
				</td>
			</tr>
			<tr>
				<th class="title" width="20%" height="360" bgcolor="#F7F3E4">
					<!-- 종합의견 -->
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_03_077','종합의견')}<br><br>
					&nbsp;&nbsp;<input name="SYNTHETICOPINION_BYTES" type="text" class="input_invisible01_r" size="18" readonly="readonly">
				</th>
				<td bgcolor="#FFFFFF">
					<textarea name='SYNTHETICOPINION' rows='20' class='textarea-box' style="width:98%;margin-left:5px;" onkeyup="calcBytes()" onfocus="calcBytes()">${output_mstRep.SYNTHETICOPINION}</textarea>												
					<span style="color:blue">&nbsp;${msgel.getMsg('AML_20_01_01_90_025','금칙어 주의하세요.')}</span>
				</td>							
			</tr>
		</table>
<!-- ########## 의심스러운 거래에 대한 서술 [SuspicionReport] END ########## -->

<!-- ########## 거래내역 [Transaction] START ########## -->
		<div class="tab-content-bottom" style="margin:7px;">
			<div class="inner-top">
				<div class="processbox-tag primary">
			  	   <span class="tag-name">${msgel.getMsg('AML_20_01_01_90_028','상세내용 [Detail]')}</span>
				</div>
				<br/>
				<div style="display:inline-block;"><h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_029','거래내역 [Transaction]')}</h4></div><span style="color:orange;font-size:11px">&nbsp;${msgel.getMsg('AML_20_01_01_90_200','해당 거래를 클릭하면 아래 [UserRelation][AccountRelation][Insurance] 정보가 조회됩니다.')}</span>
			</div>
			<div class="inner-bottom">
		        <div id="GTDataGrid05_Area"></div>
		    </div>
	    </div>
<!-- ########## 거래내역 [Transaction] END ########## -->

<!-- ########## 거래에 대한 거래자역할 [Transaction]_[UserRelation] START ########## -->
       <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_031','거래에 대한 거래자역할 [Transaction]_[UserRelation]')}</h4>
			</div>
		    <div id="GTDataGrid06_Area"></div>
	    </div>
<!-- ########## 거래에 대한 거래자역할 [Transaction]_[UserRelation] END ########## -->

<!-- ########## 거래에 대한 계약관계 [Transaction]_[AccountRelation] START ########## -->
       <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_032','거래에 대한 계약관계 [Transaction]_[AccountRelation]')}</h4>
			</div>
		    <div id="GTDataGrid61_Area"></div>
	    </div>
<!-- ########## 거래에 대한 계약관계 [Transaction]_[AccountRelation] END ########## -->

<!-- ########## 거래에 대한 유가증권 [Transaction]_[Securities] START ########## -->
       <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_033','거래에 대한 유가증권 [Transaction]_[Securities]')}</h4>
			</div>
		    <div id="GTDataGrid52_Area"></div>
	    </div>
<!-- ########## 거래에 대한 유가증권 [Transaction]_[Securities] END ########## -->

<!-- ########## 거래에 대한 외환및환전 [Transaction]_[ForeignExchange] START ########## -->
       <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_034','거래에 대한 외환및환전 [Transaction]_[ForeignExchange]')}</h4>
			</div>
		    <div id="GTDataGrid53_Area"></div>
	    </div>
	    <table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">
	    	<tr>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_035','외환거래목적')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="EXCH_PURPOSECODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="EXCH_PURPOSE" style="width:77%;" readonly="readonly"/>
				</td>							
			</tr>
		</table>
<!-- ########## 거래에 대한 외환및환전 [Transaction]_[ForeignExchange] END ########## -->

<!-- ########## 거래에 대한 타행계좌 [Transaction]_[OtherBank] START ########## -->
       <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_036','거래에 대한 타행계좌 [Transaction]_[OtherBank]')}</h4>
			</div>
		    <div id="GTDataGrid51_Area" style="max-width:100%"></div>
	    </div>
	    
	    <table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">
	    	<tr>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_037','송/수취계좌번호')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_ACCOUNTNUMBER" style="width:92%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_039','계좌주명')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_NAME" style="width:90%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
			<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_038','계좌주구분')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_ACCOUNTHOLDERTYPECODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="OTH_ACCOUNTHOLDERTYPE" style="width:70%;" readonly="readonly"/>
				</td>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_041','금융기관')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_ORGNAMECODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="OTH_ORGNAME" style="width:70%;" readonly="readonly"/>
				</td>
			</tr>
			<tr>
			    <th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_040','상대국가')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_NATIONALITYCODE" style="width:20%;margin-left:7px;" readonly="readonly"/>	
					<input type="text" class="input_t_dis" name="OTH_NATIONALITY" style="width:70%;" readonly="readonly"/>	
				</td>
			    <th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_042','영업점우편번호')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_BRANCHOFFICEZIPCODE" style="width:90%;margin-left:7px;" readonly="readonly"/>	
				</td>
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_043','상대영업점코드')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_BRANCHOFFICECODE" style="width:92%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_044','상대영업점')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="OTH_BRANCHOFFICE" style="width:92%;margin-left:7px;" readonly="readonly"/>
				</td>
			</tr>
	    </table>
<!-- ########## 거래에 대한 타행계좌 [Transaction]_[OtherBank] END ########## -->

<!-- ########## 거래에 대한 증권 [Transaction]_[Stock] START ########## -->
		<div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_227','거래에 대한 증권 [Transaction]_[Stock]')}</h4>
			</div>
		    <div id="GTDataGrid54_Area" style="max-width:100%"></div>
	    </div>
	    
	    <table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">
	    	<tr>
	    		<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_02_02_01_093','거래종류')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_TRANSTYPECODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="STK_TRANSTYPE" style="width:70%;margin-left:7px;" readonly="readonly"/>
				</td>
				
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_228','매매종목명')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_STOCKNAME" style="width:90%;margin-left:7px;" readonly="readonly"/> 
				</td>
				
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_229','매매수량')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_QUANTITY" style="width:90%;margin-left:7px;" readonly="readonly"/> 
				</td>	
			</tr>
			
			<tr>
	    		<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_041','금융기관')}
				</th>
				<td width="25%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_ORGNAMECODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" name="STK_ORGNAME" style="width:70%;margin-left:7px;" readonly="readonly"/>
				</td> 
				
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_230','영업점코드')}
				</th>
				<td colspan="3" width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_BRANCHOFFICECODE" style="width:90%;margin-left:7px;" readonly="readonly"/> 
				</td>	
			</tr>
			  
			<tr>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_231','영업점명')}
				</th>
				<td width="25%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_BRANCHOFFICE" style="width:90%;margin-left:7px;" readonly="readonly"/> 
				</td>	
				  
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_042','영업점우편번호')}
				</th>
				<td colspan="3" width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" name="STK_BRANCHOFFICEZIPCODE" style="width:90%;margin-left:7px;" readonly="readonly"/> 
				</td>
			</tr>
	    </table>
<!-- ########## 거래에 대한 증권 [Transaction]_[Stock] START ########## -->




<!-- ########## 거래자정보 [User] START ########## -->
     <div class="tab-content-bottom" style="margin:7px;">
			<div class="inner-top" style="margin:7px;">
				<div class="processbox-tag primary">
			  	   <span class="tag-name">${msgel.getMsg('AML_20_01_01_90_051','거래자정보 [User]')}</span>
				</div>
				<span style="color:orange;font-size:11px">&nbsp;${msgel.getMsg('AML_20_01_01_90_052','거래자를 클릭하면 아래 상세 정보가 조회됩니다.')}</span>
			</div>
			<div class="inner-bottom">
		        <div id="GTDataGrid70_Area"></div>
		        <div style="display:none;">
	              <div id="GTDataGrid72_Area"></div>
	            </div>
		    </div>
	    </div>
				    
	    <table class="basic-table" style="width:99%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">
	    	<tr>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_04_01_01_007','실명확인번호')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_REALNUMBER" name="US_REALNUMBER" style="width:92%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_003','실명확인구분')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_REALNUMBERCODE" name="US_REALNUMBERCODE" style="width:25%;margin-left:7px;" readonly="readonly"/>
					<input type="text" class="input_t_dis" id="US_REALNUMBERTYPENAME" name="US_REALNUMBERTYPENAME" style="width:64%;" readonly="readonly"/>
					<input type="hidden" id="US_INDV_CORP_CCD" name="US_INDV_CORP_CCD">
					<input type="hidden" id="US_SSPS_DL_RNMCNO_F" name="US_SSPS_DL_RNMCNO_F">
				</td>
			</tr>
			<tr>
			   <th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_04_044','성명')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_NAME" name="US_NAME" style="width:90%;margin-left:7px;" readonly="readonly"/>	
				</td>
				<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_054','생년월일/설립일')}
				</th>
				<td width="20%" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_BIRTHDAY" name="US_BIRTHDAY" style="width:90%;margin-left:7px;" readonly="readonly"/>	
				</td>	
			</tr>
			<tr>
				<th class="title required" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_04_01_01_024','국적')} 
				</td>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_NATIONALITYCODE" name="US_NATIONALITYCODE" style="width:25%;margin-left:7px;" readonly="readonly"/>											
					<select name='combo_US_NTN_CD' id='combo_US_NTN_CD' class="dropdown" style="width:64%;" onChange="onSelectChange(this)" disabled>																
						<AMLTag:combobox_option	code="M004"	 initValue="" firstComboWord="CHOICE"/>
					</select>
				</td>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_053','전화번호')}
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_PHONE_AREA" name="US_PHONE_AREA" maxlength="4" style="width:28%;margin-left:7px;" readOnly/>
					<input type="text" class="input_t_dis" id="US_PHONE_ECNO" name="US_PHONE_ECNO" maxlength="4" style="width:28%;" readOnly/>
					<input type="text" class="input_t_dis" id="US_PHONE_NO" name="US_PHONE_NO" maxlength="4" style="width:28%;" readOnly/>
				</td>							
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4" >
					${msgel.getMsg('AML_20_01_01_90_055','우편번호[자택/본점]')}(<span style="color:brown">*</span>)
				</th>
				<td bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_ADDRESSZIPCODE" name="US_ADDRESSZIPCODE" style="width:92%;margin-left:7px;" readonly="readonly"/>
				</td>
				<th class="title" height="30" bgcolor="#F7F3E4">
					 
				</th>
				<td colspan="3" bgcolor="#FFFFFF">
					 
				</td>							
			</tr>
			<tr>
				<th class="title" height="30" bgcolor="#F7F3E4">
					&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_056','주소(자택/본점)')}
				</th>
				<td colspan="5" bgcolor="#FFFFFF">
					<input type="text" class="input_t_dis" id="US_ADDRESS_BSC" name="US_ADDRESS_BSC" style="width:47%;margin-left:7px;" readOnly/>
					<input type="text" class="input_t_dis" id="US_ADDRESS_DNG" name="US_ADDRESS_DNG" style="width:50%;" readOnly/>
				</td>							
			</tr>
	    </table>
<!-- ########## 거래자정보 [User] END ########## -->

<!-- ########## [개인의 경우] START ########## -->
   <div id="divCust_1" style="display:none;">
		 <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_057','[개인의 경우]')}</h4>
			</div>
	     </div>

			<table class="basic-table" style="width:98%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">																				
				<tr>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_058','핸드폰번호')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_PHONEHANDPHONE_AREA" name="US_PHONEHANDPHONE_AREA" maxlength="4" style="width:28%;margin-left:7px;" readOnly/>
						<input type="text" class="input_t_dis" id="US_PHONEHANDPHONE_ECNO" name="US_PHONEHANDPHONE_ECNO" maxlength="4" style="width:28%;" readOnly/>
						<input type="text" class="input_t_dis" id="US_PHONEHANDPHONE_NO" name="US_PHONEHANDPHONE_NO" maxlength="4" style="width:28%;" readOnly/>
					</td>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_05_007','성별')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_GENDERCODE" name="US_GENDERCODE" style="width:25%;margin-left:7px;" readonly="readonly"/>
						<!-- <input type="text" class="input_t_dis" id="US_GENDER" name="US_GENDER" style="width:64%;" readonly="readonly"/> -->
						<select name='combo_US_GENDER' id='combo_US_GENDER' class="dropdown" style="width:64%;" onChange="onSelectChange(this)" disabled>
							<AMLTag:combobox_option	code="M013"	 initValue="" firstComboWord="CHOICE"/>
						</select> 
					</td>
				</tr>
				<tr>
				    <th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_063','고액자산가여부')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_ISHIGHASSET" name="US_ISHIGHASSET" style="width:25%;margin-left:7px;" readonly="readonly"/>
						<select name='combo_US_ISHIGHASSET' id='combo_US_ISHIGHASSET' class="dropdown" style="width:64%;" onChange="onSelectChange(this)" disabled>
							<option class="dropdown-option" value="">${msgel.getMsg('AML_20_01_10_03_118','선택')}</option>
							<option class="dropdown-option" value='N'>N</option>
							<option class="dropdown-option" value='Y'>Y</option>
						</select>
					</td>
					<th class="title required" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_05_012','직업구분')} 
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_OCCUPATIONTYPECODE" name="US_OCCUPATIONTYPECODE" style="width:25%;margin-left:7px;" readonly="readonly"/>
						<!-- <input type="text" class="input_t_dis" name="US_OCCUPATIONTYPE" style="width:60%;" readonly="readonly"/>  -->
						<select name='combo_US_OCCUPATION' id='combo_US_OCCUPATION' class="dropdown" style="width:64%;" onChange="onSelectChange(this)" disabled>
							<AMLTag:combobox_option	code="M059"	 initValue="" firstComboWord="CHOICE"/>
						</select>
					</td>
				</tr>
				<tr>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_04_023','직장명')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_COMPANY" name="US_COMPANY" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>							
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_05_013','부서명')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_DEPTNAME" name="US_DEPTNAME" style="width:90%;margin-left:7px;" readonly="readonly"/>
					</td>
				</tr>
				<tr>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_05_015','직위')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_POSITION" name="US_POSITION" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_064','우편번호(직장)')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_ADDRESSCOMPANYZIPCODE" name="US_ADDRESSCOMPANYZIPCODE" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>
				</tr>
				<tr>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_065','주소(직장)')}
					</th>
					<td colspan="3" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_ADDRESSCOMPANY_BSC" name="US_ADDRESSCOMPANY_BSC" style="width:22%;margin-left:7px;" readOnly/>
						<input type="text" class="input_t_dis" id="US_ADDRESSCOMPANY_DNG" name="US_ADDRESSCOMPANY_DNG" style="width:75%;" readOnly/>
					</td>							
				</tr>
			</table>
			</div>
<!-- ########## [개인의 경우] END ########## -->

<!-- ########## [법인 및 단체의 경우] START ########## -->
		<div id="divCust_2" style="display:none;">
			<div class="tab-content-bottom" style="margin:7px;">
				<div class="row">
				    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_066','[법인 및 단체의 경우]')}</h4>
				</div>
		     </div>

			<table class="basic-table" style="width:98%;border:solid 1px #EADAD0; border-top-color:#C09D82; margin-top:7px;margin-left:7px;">																				
				<tr>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_05_016','대표자명')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_CEONAME" name="US_CEONAME" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_04_057','사업자등록번호')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_BIZNO" name="US_BIZNO" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>
				</tr>
				<tr>
				   <th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_067','홈페이지')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_HOMEPAGEURL" name="US_HOMEPAGEURL" style="width:90%;margin-left:7px;" readonly="readonly"/>
					</td>
					<th class="title required" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_06_015', '기업규모')} 
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_BIZSCALECODE" name="US_BIZSCALECODE" style="width:25%;margin-left:7px;" readonly="readonly"/>
						<select name='combo_BIZSCALE' id='combo_BIZSCALE' class="dropdown" style="width:60%;margin-left:7px;" onChange="onSelectChange(this)" disabled>
							<AMLTag:combobox_option	code="M030"	 initValue="" firstComboWord="CHOICE"/>
						</select>
					</td>
				</tr>
				<tr>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_068','국가공공단체여부')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="hidden" id="US_ISNATIONALPUBLICGROUP" name="US_ISNATIONALPUBLICGROUP"/>
						<select name='combo_ISNATIONAL' id='combo_ISNATIONAL' class="cond-select" style="width:30%;margin-left:7px;" onChange="onSelectChange(this)" disabled>
							<option value='N'>N</option>
							<option value='Y'>Y</option>
						</select>
					</td>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_069','금융기관여부')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="hidden" id="US_ISBANKINGORGAN" name="US_ISBANKINGORGAN"/>											
						<select name='combo_ISBANKINGORGAN' id='combo_ISBANKINGORGAN' class="cond-select" style="width:40%;margin-left:7px;" onChange="onSelectChange(this)" disabled>
							<option value='N'>N</option>
							<option value='Y'>Y</option>
						</select>
					</td>
				</tr>
				<tr>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_06_010','법인등록번호')}
					</th>
					<td width="20%" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_CORPNO" name="US_CORPNO" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>
					<th class="title" height="30" bgcolor="#F7F3E4">
						 
					</th>
					<td bgcolor="#FFFFFF">
						 
					</td>
				</tr>
				<tr>
					<th class="title required" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_072', '상장여부')} 
					</th>
					<td bgcolor="#FFFFFF">
						<input type="hidden" id="US_ISSTOCKLIST" name="US_ISSTOCKLIST"/>
						<select name='combo_ISSTOCKLIST' id='combo_ISSTOCKLIST' class="dropdown" style="width:30%;margin-left:7px;" onChange="onSelectChange(this)" disabled>
							<option class="dropdown-option" value="N">N</option>
							<option class="dropdown-option" value="Y">Y</option>
						</select>
						<input type="hidden" id="US_STOCKLISTINFO" name="US_STOCKLISTINFO"/>&nbsp;
						<select name='combo_US_STOCKLISTINFO' id='combo_US_STOCKLISTINFO' class="dropdown" style="width:60%;" onChange="onSelectChange(this)" disabled>
							<AMLTag:combobox_option	code="M060"	 initValue="" firstComboWord="CHOICE"/>
						</select>
					</td>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_073', '비영리법인여부')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="hidden" id="US_ISNONPROFITCORP" name="US_ISNONPROFITCORP"/>
						<select name='combo_ISNONPROFITCORP' id='combo_ISNONPROFITCORP' class="cond-select" style="width:40%;margin-left:7px;" onChange="onSelectChange(this)" disabled>
							<option value='N'>N</option>
							<option value='Y'>Y</option>
						</select>
					</td>							
				</tr>
				<tr>
				<th class="title required" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_04_031', '업종')} 
					</th>
					<td colspan="3" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_KSICCODE" name="US_KSICCODE" style="width:20%;margin-left:7px;" readonly="readonly"/>
						<input type="text" class="input_t_dis" id="US_KSIC" name="US_KSIC" style="width:70%;" readonly="readonly"/>
						<button class="btn-36" id="img_US_KSIC" name="img_US_KSIC"  style="cursor:pointer;display:none;" onClick="javascript:doPopup('M008','US_KSIC')">${msgel.getMsg('AML_20_01_01_09_200', '검색')}</button>
					</td>	
				</tr>
				<tr>
					<th class="title" width="15%" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_075', '우편번호(사업장)')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_BIZADDRESSZIPCODE" name="US_BIZADDRESSZIPCODE" style="width:92%;margin-left:7px;" readonly="readonly"/>
					</td>	
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_074', '전화번호(사업장)')}
					</th>
					<td bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_BIZTELNO_AREA" name="US_BIZTELNO_AREA" style="width:28%;margin-left:7px;" readOnly/>
						<input type="text" class="input_t_dis" id="US_BIZTELNO_ECNO" name="US_BIZTELNO_ECNO" style="width:28%;" readOnly/>
						<input type="text" class="input_t_dis" id="US_BIZTELNO_NO" name="US_BIZTELNO_NO" style="width:28%;" readOnly/>
					</td>						
				</tr>
				<tr>
					<th class="title" height="30" bgcolor="#F7F3E4">
						&nbsp;&nbsp;${msgel.getMsg('AML_20_01_01_90_076', '주소(사업장)')}
					</th>
					<td colspan="3" bgcolor="#FFFFFF">
						<input type="text" class="input_t_dis" id="US_BIZADDRESS_BSC" name="US_BIZADDRESS_BSC" style="width:47%;margin-left:7px;" readOnly/>
						<input type="text" class="input_t_dis" id="US_BIZADDRESS_DNG" name="US_BIZADDRESS_DNG" style="width:50%;" readOnly/>
					</td>							
				</tr>
			</table>
		</div>
<!-- ########## [법인 및 단체의 경우] END ########## -->

<!-- ########## 계약정보 [Account] START ########## -->
		<div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_077','계약정보 [Account]')}</h4>
			</div>
		    <div id="GTDataGrid09_Area"></div>
	    </div>
<!-- ########## 계약정보 [Account] END ########## -->

<!-- ########## 거래자간의 관계 [InterUserRelation] START ########## -->
		<div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_078','거래자간의 관계 [InterUserRelation]')}</h4>
			</div>
		    <div id="GTDataGrid91_Area"></div>
	    </div>
<!-- ########## 거래자간의 관계 [InterUserRelation] END ########## -->

<!-- ########## 첨부파일 [FileAttach] START ########## -->
		<div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_079','첨부파일 [FileAttach]')}</h4>
			</div>
		    <div id="GTDataGrid10_Area"></div>
	    </div>
<!-- ########## 첨부파일 [FileAttach] END ########## -->

<!-- ########## 보고항목 체크로그 목록 START ########## -->
	    <div class="tab-content-bottom" style="margin:7px;">
			<div class="row">
			    <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_90_080', '보고항목 체크로그 목록')}</h4>
			    &nbsp;&nbsp;
					<span style="color:red;font-size:12px"><% if(("1").equals(MAX_PROC_FALG)){ %>${msgel.getMsg('AML_20_01_01_90_081','[최종결과 : 오류]')}
					<%}else if(("0").equals(MAX_PROC_FALG)){%>${msgel.getMsg('AML_20_01_01_90_082','[최종결과 : 정상]')}<%}%></span>
			</div>
		    <div id="GTDataGrid92_Area"></div>
	    </div>
<!-- ########## 보고항목 체크로그 목록 END ########## -->
    <p>
</div>
    
    <p>
        <div class="button-area" style="float:right;margin-top:10px;">
        	${btnel.getButton(outputAuth, '{btnID:"sbtn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}        	
    		<%if("Y".equals(BTN_SAVE_F)) {%>
        	${btnel.getButton(outputAuth, '{btnID:"sbtn_03", cdID:"AML_20_01_01_11_sbtn_01", defaultValue:"check", mode:"U", function:"doSaveCheck", cssClass:"btn-36", show:"N"}')}
    		${btnel.getButton(outputAuth, '{btnID:"btn_02", cdID:"saveBtn", defaultValue:"저장", mode:"U", function:"doSave", cssClass:"btn-36"}')}
    		<%}%>
    		${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"doClose", cssClass:"btn-36", show:"N"}')}
    	</div>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td valign="top">
				<iframe name="submitFrame" name="submitFrame" width="0" height="0" marginwidth="0" marginheight="0" frameborder="0" scrolling="no"></iframe>
			</td>
		</tr>
	</table> 
</form>
<iframe id='MyFrame' name="MyFrame" height='0' width='0'></iframe>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" />
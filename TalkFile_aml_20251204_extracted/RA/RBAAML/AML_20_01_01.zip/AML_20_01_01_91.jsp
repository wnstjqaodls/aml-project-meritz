<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%> 
<%--
- File Name  : AML_20_01_01_91.jsp
- Author     : bmy
- Comment    : STR보고항목-저장
- Version    : 1.0
- history    : 1.0 2019-06-10
--%>
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_top.jsp" flush="true" />
<%
	DataObj dataObj = (DataObj) request.getAttribute("output");
	request.setAttribute("ERRCODE", dataObj.getText("ERRCODE"));
	request.setAttribute("ERRMSG", dataObj.getText("ERRMSG"));	

%>
<html>
<script language="JavaScript">
    parent.doSave_end("${ERRCODE}");
</script>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_bottom.jsp" flush="true" />	

<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 거래상세
*                   STR 取引詳細
*                   STR Transaction detailed.
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 3.
* Alteration      : 1. 신규 레이아웃 적용
*                   2. 코드 정리
*                   3. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>
<%@ include file="/WEB-INF/Package/AML/common/notitle_common_top.jsp" %>
<%
    //request
    String SSPS_DL_ID      = Util.nvl(request.getParameter("SSPS_DL_ID"    ));
    String SSPS_DL_CRT_DT  = Util.nvl(request.getParameter("SSPS_DL_CRT_DT"));
    String ctlBtn02        = Util.nvl(request.getParameter("ctlBtn02"));
    String approval        = Util.nvl(request.getParameter("approval"));

    request.setAttribute("SSPS_DL_ID"    ,SSPS_DL_ID    );
    request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
    
    String sDate = DateUtil.addDays(DateUtil.getDateString(), -30, "yyyy-MM-dd");
    String eDate = DateUtil.addDays(DateUtil.getDateString(), -0, "yyyy-MM-dd");

    request.setAttribute("stDate"         ,sDate         );
    request.setAttribute("edDate"         ,eDate         );
    request.setAttribute("sDate"          ,sDate         );
    request.setAttribute("eDate"          ,eDate         );
     
%>
<!-- Function Script -->
<script>
    var GridObj1 = null;
    var GridObj2 = null;
    var GridObj3 = null;
    var GridObj9 = null;

    $(document).ready(function(){
    	
    	setupGrids();
    	setupGrids2();
    	setupGrids3();
    	setupGrids4();
    	doSearch();
    	setupFilter("init");
        setupFilter2("init");
        setupFilter3("init");
        setupFilter4("init");
    	//doSearch03();
        $("div[class=popup-table-panel-left]").css("visibility","visible");
        $("div[class=popup-table-panel-right]").css("visibility","visible");
        
        $("#trxMinusBtn").css("display", "none");
        $("#trxPlusGrid").css("display", "none");
    });

    function setupGrids()
    {
        GridObj1 = $("#GTDataGridPopup81_Area").dxDataGrid({
        	"gridId"            	: "GTDataGrid01",
         	"height"            	: 'calc(60vh - 200px)',
         	"elementAttr"           : { class: "grid-table-type" },
         	"hoverStateEnabled"		: true,
            "wordWrapEnabled"		: false,
            "allowColumnResizing"	: true,
            "columnAutoWidth"		: true,
            "allowColumnReordering"	: true,
            "cacheEnabled"			: false,
            "cellHintEnabled"		: true,
            "showBorders"			: true,
    	    "onToolbarPreparing": makeToolbarButtonGrids,
            "showColumnLines"		: true,
            "showRowLines"			: true,
            export 					: {allowExportSelectedData : true ,enabled : true ,excelFilterEnabled : true},
		    onExporting: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer){
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_08_001','STR 혐의거래상세')}.xlsx");
			        });
			    });
			    e.cancel = true;
            },
            "sorting"				: {"mode": "multiple"},
            "remoteOperations"		: {
                "filtering": false,
                "grouping": false,
                "paging": false,
                "sorting": false,
                "summary": false
            },
            "editing"				: {
                "mode": "batch",
                "allowUpdating": false,
                "allowAdding": false,
                "allowDeleting": false
            },
            "filterRow"				: {"visible": false},
            "rowAlternationEnabled"	: true,
            "columnFixing"			: {"enabled": true},
            pager: {
       	    	visible: false
       	    	,showNavigationButtons: true
       	    	,showInfo: true
       	    },
       	    paging: {
       	    	enabled : false
       	    },
    	   	scrolling : {
               mode            : "standard"  /* standard에서 다른걸로 바꾸지 마세요!  거래추가시 전체 건수 가지고 오려면 standard로 해야함*/
              ,preloadEnabled  : false
            },
            "searchPanel"			: {
                "visible": false,
                "width": 250
            },
            "selection"				: {
                "allowSelectAll": true,
                "deferred": false,
                "mode": "multiple", /*single*/
                "selectAllMode": "allPages",
                "showCheckBoxesMode": "onClick"
            },
            "columns": [
            	{"dataField": "ACNT_NO"	,"caption": '${msgel.getMsg("AML_20_01_11_01_105","계좌번호")}'					,"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": true},
            	{"dataField": "DL_P_NM"		,"caption": '고객명'															,"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": true},
            	{"dataField": "DL_DT"		,"caption": '${msgel.getMsg("AML_21_01_01_01_001","거래일자")}'			,"cellTemplate": function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate(cellInfo.text)); },"alignment": "center","allowResizing": true,"allowSearch": true,"width": 100,"allowSorting": true},
				{"dataField": "DL_TM"		,"caption": '${msgel.getMsg("AML_20_01_01_08_100","거래시간")}'					,"alignment": "center","allowResizing": true,"allowSearch": true,"width": 70,"allowSorting": true},
	            {"dataField": "DL_SQ",			"caption": '${msgel.getMsg("AML_20_01_01_08_101","번호")}',		"alignment": "right","allowResizing": true,"allowSearch": true,"width": 60,"allowSorting": true},
	            {"dataField": "DL_TYP_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_102","거래유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
	            {"dataField": "DL_TYP_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_102","거래유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
	            {"dataField": "SMRY_TYP_CD",	"caption": '${msgel.getMsg("AML_20_01_01_08_103","적용유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
	            {"dataField": "SMRY_TYP_NM",	"caption": '${msgel.getMsg("AML_20_01_01_08_103","적용유형")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_WY_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_024","거래방법")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_WY_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_024","거래방법")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},

                {"dataField": "DL_CHNNL_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_026","거래채널")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_CHNNL_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_026","거래채널")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "DL_AMT",				"caption": '${msgel.getMsg("AML_20_01_11_01_106","거래금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "CSH",				"caption": '${msgel.getMsg("AML_20_01_01_08_104","현금")}',			"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "CHCK_AMT",			"caption": '${msgel.getMsg("AML_20_01_01_08_025","수표금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "EC_AMT",				"caption": '${msgel.getMsg("AML_20_01_01_08_105","정산금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "TFND_RA",			"caption": '${msgel.getMsg("AML_20_01_01_08_027","예수금잔액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                //{"dataField": "LN_AMT",				"caption": '${msgel.getMsg("AML_20_01_01_08_106","대출원금상환금액")}',	"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true},
                //{"dataField": "SPC",				"caption": '${msgel.getMsg("AML_20_01_01_08_107","거래매체")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "CPRTY_TRSNS_AC_NO",	"caption": '${msgel.getMsg("AML_20_01_01_08_108","상대대체계좌")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},

                {"dataField": "CPRTY_TRSNS_OGN_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_109","상대대체기관")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"allowEditing": true,"visible": false},
                {"dataField": "CPRTY_TRSNS_OGN_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_109","상대대체기관")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "CPRTY_TRSNS_FOGN_NM",	"caption": '${msgel.getMsg("AML_20_01_01_08_110","상대대체금융기관")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "CRNCY_CD",				"caption": '${msgel.getMsg("AML_20_01_01_08_111","통화코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "CRNCY_NM",				"caption": '${msgel.getMsg("AML_20_01_01_08_111","통화코드")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "FCRNCY_DL_AMT",			"caption": '${msgel.getMsg("AML_20_01_01_08_112","외화거래금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "USD_EXCH_AMT",			"caption": '${msgel.getMsg("AML_20_07_01_01_049","달러환산금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_Q",					"caption": '${msgel.getMsg("AML_20_01_01_08_113","거래수량")}',		"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "DL_UPRC",				"caption": '${msgel.getMsg("AML_20_01_01_08_114","거래단가")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STND_IS_CD",				"caption": '${msgel.getMsg("AML_20_01_01_08_115","표준종목")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},

				{"dataField": "STND_IS_CD_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_115","표준종목")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STR_DL_KND_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_116","STR거래종류")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STR_DL_KND_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_116","STR거래종류")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HANDLNG_BRN_CD",		"caption": '${msgel.getMsg("AML_20_07_01_01_050","취급지점")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HANDLNG_BRN_NM",		"caption": '${msgel.getMsg("AML_20_07_01_01_050","취급지점")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"width": 150,"allowSorting": true},
				{"dataField": "HNDL_P_ENO",			"caption": '${msgel.getMsg("AML_20_01_01_08_117","처리자사번")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HNDL_P_ENO_NM",		"caption": '${msgel.getMsg("AML_20_01_01_15_007","처리자")}',			"alignment": "left","allowResizing": true,"allowSearch": true,"width": 110,"allowSorting": true},
				//{"dataField": "DL_SMRY",			"caption": '${msgel.getMsg("AML_20_01_01_08_118","거래적용")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"width": 200,"allowSorting": true},
				{"dataField": "CRCT_CCD",			"caption": '${msgel.getMsg("AML_20_01_01_08_119","정정구분")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "CHRG_P_RPR_ST_CCD",	"caption": '${msgel.getMsg("AML_20_01_01_08_120","담당자보고상태")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},

				{"dataField": "RPR_TRGT_XCL_DL_CCD",	"caption": '${msgel.getMsg("AML_20_01_01_08_121","보고대상제외")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "SSPS_DL_CRT_DT",			"caption": '${msgel.getMsg("AML_20_01_01_08_122","혐의거래생성일자")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "SSPS_DL_ID",				"caption": '${msgel.getMsg("AML_20_09_02_01_105","혐의거래ID")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "GDS_NO",					"caption": '${msgel.getMsg("AML_21_01_01_01_109","상품번호")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
            ],
             "summary": {"totalItems": [                 {
                 "column": "DL_DT",
                 "summaryType": "count",
                 "valueFormat": "fixedPoint"
             }],
 				texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}

             },
           "onCellClick": function(e){ if(e.data ){ Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);        } }
        }).dxDataGrid("instance");
    }

    function setupGrids2()
    {
    	GridObj2 = $("#GTDataGridPopup82_Area").dxDataGrid({
        	"gridId"            	: "GTDataGrid01",
         	"height"            	: 'calc(35vh - 100px)',
         	"elementAttr"           : { class: "grid-table-type" },
         	"hoverStateEnabled"		: true,
            "wordWrapEnabled"		: false,
            "allowColumnResizing"	: true,
            "columnAutoWidth"		: true,
            "allowColumnReordering"	: true,
            "cacheEnabled"			: false,
            "cellHintEnabled"		: true,
            "showBorders"			: true,
            "showColumnLines"		: true,
            "showRowLines"			: true,
            "loadPanel" 			: { enabled: false },
            export 					: {allowExportSelectedData : true ,enabled : false ,excelFilterEnabled : true},
		    onExporting: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer) {
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_08_020','수표 상세정보')}.xlsx");
			        });
			    });
			    e.cancel = true;
            },
            "sorting"				: {"mode": "multiple"},
            "remoteOperations"		: {
                "filtering": false,
                "grouping": false,
                "paging": false,
                "sorting": false,
                "summary": false
            },
            "editing"				: {
                "mode": "batch",
                "allowUpdating": false,
                "allowAdding": false,
                "allowDeleting": false
            },
            "filterRow"				: {"visible": false},
            "rowAlternationEnabled"	: true,
            "columnFixing"			: {"enabled": true},
            pager: {
       	    	visible: false
       	    	,showNavigationButtons: true
       	    	,showInfo: true
       	    },
       	    paging: {
       	    	enabled : false
       	    	,pageSize : 20
       	    },
    	   	scrolling : {
               mode            : "virtual"
              ,preloadEnabled  : false
            },
            "searchPanel"			: {
                "visible": false,
                "width": 250
            },
            "selection"				: {
                "allowSelectAll": true,
                "deferred": false,
                "mode": "multiple",
                "selectAllMode": "allPages",
                "showCheckBoxesMode": "onClick"
            },
            "columns": [
                {"dataField": "COL0",	"caption": '${msgel.getMsg("AML_20_01_01_08_123","구분")}',			"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL1",	"caption": '${msgel.getMsg("AML_20_01_10_32_002","유가증권번호")}',		"cssClass" : "link","alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL2",	"caption": '${msgel.getMsg("AML_20_01_01_08_124","종료번호")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "COL3",	"caption": '${msgel.getMsg("AML_20_01_01_08_125","발행은행")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL4",	"caption": '${msgel.getMsg("AML_20_01_01_08_126","발행일")}',			"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL5",	"caption": '${msgel.getMsg("AML_20_01_01_08_127","권종코드")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "COL6",	"caption": '${msgel.getMsg("AML_20_01_01_08_128","배서자구분")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL7",	"caption": '${msgel.getMsg("AML_20_01_01_08_129","배서자명")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "COL8",	"caption": '${msgel.getMsg("AML_20_01_01_08_130","배서자실명확인번호")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},

                {"dataField": "SSPS_DL_CRT_DT",	"caption": '${msgel.getMsg("AML_20_01_01_08_122","혐의거래생성일자")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "SSPS_DL_ID",		"caption": '${msgel.getMsg("AML_20_09_02_01_105","혐의거래ID")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "GNL_AC_NO",		"caption": '${msgel.getMsg("AML_20_01_01_08_131","종합계좌번호")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "GDS_NO",			"caption": '${msgel.getMsg("AML_20_07_01_01_100","상품번호")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_DT",			"caption": '${msgel.getMsg("AML_20_01_01_08_132","DL_DT")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_SQ",			"caption": '${msgel.getMsg("AML_20_01_01_08_133","DL_SQ")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
            ],
//             "summary": {"totalItems": [                 {
//                 "column": "COL0",
//                 "summaryType": "count",
//     	        "alignment": "center"
//     	    }],texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
            "onCellClick": function(e){ if(e.data ){            Grid2CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);        } }
        }).dxDataGrid("instance");
    }

    function setupGrids3()
    {
    	GridObj3 = $("#GTDataGridPopup83_Area").dxDataGrid({
        	"gridId"            		: "GTDataGrid01",
         	"height"            		: 'calc(35vh - 64px)',
         	"elementAttr"           : { class: "grid-table-type" },
         	 "hoverStateEnabled"		: true,
             "wordWrapEnabled"			: false,
             "allowColumnResizing"		: true,
             "columnAutoWidth"			: true,
             "allowColumnReordering"	: true,
             "cacheEnabled"				: false,
             "cellHintEnabled"			: true,
     	    "onToolbarPreparing"		: makeToolbarButtonGrids,
             "showBorders"				: true,
             "showColumnLines"			: true,
             "showRowLines"				: true,
             export 					: {allowExportSelectedData : true ,enabled : false ,excelFilterEnabled : true},
 		    onExporting: function (e) {
 				const workbook = new ExcelJS.Workbook();
 			    const worksheet = workbook.addWorksheet("Sheet1");
 			    DevExpress.excelExporter.exportDataGrid({
 			        component: e.component,
 			        worksheet:worksheet,
 			        autoFilterEnabled: true,
 			    }).then(function() {
 			        workbook.xlsx.writeBuffer().then(function(buffer) {
 			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_08_029','대리인')}.xlsx");
 			        });
 			    });
 			    e.cancel = true;
             },
             "sorting"					: {"mode": "multiple"},
             "remoteOperations"			: {
                 "filtering": false,
                 "grouping": false,
                 "paging": false,
                 "sorting": false,
                 "summary": false
             },
             "editing"					: {
                 "mode": "batch",
                 "allowUpdating": false,
                 "allowAdding": false,
                 "allowDeleting": false
             },
             "filterRow"				: {"visible": false},
             "rowAlternationEnabled"	: true,
             "columnFixing"				: {"enabled": true},
             pager: {
        	    	visible: false
        	    	,showNavigationButtons: true
        	    	,showInfo: true
        	    },
        	    paging: {
        	    	enabled : false
        	    	,pageSize : 20
        	    },
     	   	scrolling : {
                mode            : "virtual"
               ,preloadEnabled  : false
             },
             "searchPanel"				: {
                 "visible": false,
                 "width": 250
             },
             "selection"				: {
                 "allowSelectAll": true,
                 "deferred": false,
                 "mode": "none",
                 "selectAllMode": "allPages",
                 "showCheckBoxesMode": "onClick"
             },
             scrolling   				: {mode: "virtual"},
             "columns": [
                 {"dataField": "AC_OWN_P_RLTNS_CD_NM",	"caption": '${msgel.getMsg("AML_20_01_01_08_134","대리인구분(명)")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "PRXY_NM",				"caption": '${msgel.getMsg("AML_20_07_01_01_023","대리인명")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "PRXY_RNM_NO_CCD_NM",	"caption": '${msgel.getMsg("AML_20_07_01_01_025","실명확인구분")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "PRXY_RNMCNO_VIEW",		"caption": '${msgel.getMsg("AML_20_07_01_01_027","대리인실명확인번호")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "PRXY_TEL_NO",			"caption": '${msgel.getMsg("AML_20_07_01_01_028","대리인전화번호")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                 {"dataField": "PRXY_NTNLT_NM",			"caption": '${msgel.getMsg("AML_20_07_01_01_029","대리인국적")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                 {"dataField": "PRXY_RLTNS",			"caption": '${msgel.getMsg("AML_20_07_01_01_024","계좌주관계")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                 {"dataField": "PPRXY_RNMCNO",			"caption": '${msgel.getMsg("AML_20_07_01_01_027","대리인실명확인번호")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                 {"dataField": "PRXY_RNM_NO_CCD",		"caption": '${msgel.getMsg("AML_20_07_01_01_025","실명확인구분")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                 {"dataField": "AGNC_EXTNT_CD",			"caption": '${msgel.getMsg("AML_20_01_01_08_134","대리인구분(명)")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
             ],
//              "summary": {"totalItems": [{
//                  "column": "AC_OWN_P_RLTNS_CD_NM",
//                  "summaryType": "count",
//          	     "alignment": "center"
//      	    }],texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
             "onCellClick": function(e){ if(e.data ){            Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);        } }
        }).dxDataGrid("instance");
    }
    
    function setupGrids4()
    {
    	GridObj9 = $("#GTDataGridPopup84_Area").dxDataGrid({
        	"gridId"            	: "GTDataGrid01",
         	"height"            	: 'calc(60vh - 200px)',
         	"elementAttr"           : { class: "grid-table-type" },
         	"hoverStateEnabled"		: true,
            "wordWrapEnabled"		: false,
            "allowColumnResizing"	: true,
            "columnAutoWidth"		: true,
            "allowColumnReordering"	: true,
            "cacheEnabled"			: false,
            "cellHintEnabled"		: true,
            "showBorders"			: true,
    	    "onToolbarPreparing"	: makeToolbarButtonGrids,
            "showColumnLines"		: true,
            "showRowLines"			: true,
            export 					: {allowExportSelectedData : true ,enabled : true ,excelFilterEnabled : true},
		    onExporting: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer){
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_08_001','혐의거래추가')}.xlsx");
			        });
			    });
			    e.cancel = true;
            },
            "sorting"				: {"mode": "multiple"},
            "remoteOperations"		: {
                "filtering": false,
                "grouping": false,
                "paging": false,
                "sorting": false,
                "summary": false
            },
            "editing"				: {
                "mode": "batch",
                "allowUpdating": false,
                "allowAdding": false,
                "allowDeleting": false
            },
            "filterRow"				: {"visible": false},
            "rowAlternationEnabled"	: true,
            "columnFixing"			: {"enabled": true},
            pager: {
       	    	visible: false
       	    	,showNavigationButtons: true
       	    	,showInfo: true
       	    },
       	    paging: {
       	    	enabled : false
       	    	,pageSize : 20
       	    },
    	   	scrolling : {
               mode            : "virtual"
              ,preloadEnabled  : false
            },
            "searchPanel"			: {
                "visible": false,
                "width": 250
            },
            "selection"				: {
                "allowSelectAll": true,
                "deferred": false,
                "mode": "multiple",
                "selectAllMode": "allPages",
                "showCheckBoxesMode": "onClick"
            },
            "columns": [
            	{"dataField": "GNL_AC_NO"	,"caption": '${msgel.getMsg("AML_20_01_11_01_105","계좌번호")}'					,"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": true},
            	{"dataField": "DL_P_NM"		,"caption": '고객명'															,"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": true},
            	{"dataField": "DL_DT"		,"caption": '${msgel.getMsg("AML_21_01_01_01_001","거래일자")}'			,"cellTemplate": function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate(cellInfo.text)); },"alignment": "center","allowResizing": true,"allowSearch": true,"width": 100,"allowSorting": true},
				{"dataField": "DL_TM"		,"caption": '${msgel.getMsg("AML_20_01_01_08_100","거래시간")}'					,"alignment": "center","allowResizing": true,"allowSearch": true,"width": 70,"allowSorting": true},
	            {"dataField": "DL_SQ",			"caption": '${msgel.getMsg("AML_20_01_01_08_101","번호")}',		"alignment": "right","allowResizing": true,"allowSearch": true,"width": 60,"allowSorting": true},
	            {"dataField": "DL_TYP_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_102","거래유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
	            {"dataField": "DL_TYP_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_102","거래유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
	            {"dataField": "SMRY_TYP_CD",	"caption": '${msgel.getMsg("AML_20_01_01_08_103","적용유형")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
	            {"dataField": "SMRY_TYP_NM",	"caption": '${msgel.getMsg("AML_20_01_01_08_103","적용유형")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_WY_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_024","거래방법")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_WY_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_024","거래방법")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},

                {"dataField": "DL_CHNNL_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_026","거래채널")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_CHNNL_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_026","거래채널")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "DL_AMT",				"caption": '${msgel.getMsg("AML_20_01_11_01_106","거래금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "CSH",				"caption": '${msgel.getMsg("AML_20_01_01_08_104","현금")}',			"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "CHCK_AMT",			"caption": '${msgel.getMsg("AML_20_01_01_08_025","수표금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "EC_AMT",				"caption": '${msgel.getMsg("AML_20_01_01_08_105","정산금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "TFND_RA",			"caption": '${msgel.getMsg("AML_20_01_01_08_027","예수금잔액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"width": 80,"allowSorting": true},
                {"dataField": "CPRTY_TRSNS_AC_NO",	"caption": '${msgel.getMsg("AML_20_01_01_08_108","상대대체계좌")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},

                {"dataField": "CPRTY_TRSNS_OGN_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_109","상대대체기관")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"allowEditing": true,"visible": false},
                {"dataField": "CPRTY_TRSNS_OGN_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_109","상대대체기관")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "CPRTY_TRSNS_FOGN_NM",	"caption": '${msgel.getMsg("AML_20_01_01_08_110","상대대체금융기관")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
                {"dataField": "CRNCY_CD",				"caption": '${msgel.getMsg("AML_20_01_01_08_111","통화코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "CRNCY_NM",				"caption": '${msgel.getMsg("AML_20_01_01_08_111","통화코드")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "FCRNCY_DL_AMT",			"caption": '${msgel.getMsg("AML_20_01_01_08_112","외화거래금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "USD_EXCH_AMT",			"caption": '${msgel.getMsg("AML_20_07_01_01_049","달러환산금액")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
                {"dataField": "DL_Q",					"caption": '${msgel.getMsg("AML_20_01_01_08_113","거래수량")}',		"alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "DL_UPRC",				"caption": '${msgel.getMsg("AML_20_01_01_08_114","거래단가")}',		"dataType": "number","format": "fixedPoint","alignment": "right","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STND_IS_CD",				"caption": '${msgel.getMsg("AML_20_01_01_08_115","표준종목")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},

				{"dataField": "STND_IS_CD_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_115","표준종목")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STR_DL_KND_CD",		"caption": '${msgel.getMsg("AML_20_01_01_08_116","STR거래종류")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "STR_DL_KND_NM",		"caption": '${msgel.getMsg("AML_20_01_01_08_116","STR거래종류")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HANDLNG_BRN_CD",		"caption": '${msgel.getMsg("AML_20_07_01_01_050","취급지점")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HANDLNG_BRN_NM",		"caption": '${msgel.getMsg("AML_20_07_01_01_050","취급지점")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"width": 150,"allowSorting": true},
				{"dataField": "HNDL_P_ENO",			"caption": '${msgel.getMsg("AML_20_01_01_08_117","처리자사번")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "HNDL_P_ENO_NM",		"caption": '${msgel.getMsg("AML_20_01_01_15_007","처리자")}',			"alignment": "left","allowResizing": true,"allowSearch": true,"width": 110,"allowSorting": true},
				//{"dataField": "DL_SMRY",			"caption": '${msgel.getMsg("AML_20_01_01_08_118","거래적용")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"width": 200,"allowSorting": true},
				{"dataField": "CRCT_CCD",			"caption": '${msgel.getMsg("AML_20_01_01_08_119","정정구분")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "CHRG_P_RPR_ST_CCD",	"caption": '${msgel.getMsg("AML_20_01_01_08_120","담당자보고상태")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},

				{"dataField": "RPR_TRGT_XCL_DL_CCD",	"caption": '${msgel.getMsg("AML_20_01_01_08_121","보고대상제외")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "SSPS_DL_CRT_DT",			"caption": '${msgel.getMsg("AML_20_01_01_08_122","혐의거래생성일자")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "SSPS_DL_ID",				"caption": '${msgel.getMsg("AML_20_09_02_01_105","혐의거래ID")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false},
				{"dataField": "GDS_NO",					"caption": '${msgel.getMsg("AML_21_01_01_01_109","상품번호")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"visible": false}
            ],
             "summary": {"totalItems": [                 {
                 "column": "DL_DT",
                 "summaryType": "count",
                 "valueFormat": "fixedPoint"
             }],
 				texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}

             },
            "onCellClick": function(e){ if(e.data ){        } }
        }).dxDataGrid("instance");
    }

    var selectObj = {};
    function doSearch()
    {
    	var p_frm = parent.document.form1;
    	   
        if (p_frm.GNL_AC_NO.value != '') {
            selectObj.classID             = "AML_20_01_01_08";
            selectObj.methodID            = "setStrSubPopMain08";
            selectObj.stDate = getDxDateVal("stDate",true);
            selectObj.edDate = getDxDateVal("edDate",true);
            selectObj.SSPS_DL_CRT_DT      = form1.SSPS_DL_CRT_DT.value;
            selectObj.SSPS_DL_ID          = form1.SSPS_DL_ID.value;
            selectObj.AML_ID              = form1.AML_ID.value;
            selectObj.AML_USER_NAME       = form1.AML_USER_NAME.value;
            selectObj.AML_ROLE_ID         = form1.AML_ROLE_ID.value;
            selectObj.AML_MASTER_BRANCH   = form1.AML_MASTER_BRANCH.value;
            selectObj.AML_BDPT_CD         = form1.AML_BDPT_CD.value;
            selectObj.AML_TEAM_LEADER_YN  = form1.AML_TEAM_LEADER_YN.value;
            selectObj.AML_TEL_NO          = form1.AML_TEL_NO.value;
            selectObj.GNL_AC_NO           = p_frm.GNL_AC_NO.value;
            sendService(selectObj.classID, selectObj.methodID, selectObj, doSearch_success, doSearch_fail);
        }
    }
    
    function doSearch_success(gridData, data)
    {	
        if (gridData.length > 0) {
            //GridObj1.selectRow(0, true);
            GridObj1.option("dataSource", gridData);
            Grid1CellClick(undefined, gridData[0], undefined, undefined, undefined, undefined, undefined);
        }
		 
    } 

    function doSearch_fail(data){
    	overlay.hide();
    }
    
    function Grid1CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId)
    {
    	console.log("Grid1CellClick");
        selectObj = obj;
        doSearch01();
        doSearch02();
    }
    

    function doSearch01()
    {
    	console.log("doSearch01 start ");
            var form1 = document.form1;
            var actionParam = {
                "classID"        : "AML_20_01_01_08"
               ,"methodID"       : "setStrSubPopSub08"
               ,"SSPS_DL_CRT_DT" : form1.SSPS_DL_CRT_DT.value
               ,"SSPS_DL_ID"     : form1.SSPS_DL_ID.value
               ,"GNL_AC_NO"      : selectObj.GNL_AC_NO
               ,"GDS_NO"         : selectObj.GDS_NO
               ,"DL_DT"          : selectObj.DL_DT
               ,"DL_SQ"          : selectObj.DL_SQ
             }
            sendService("AML_20_01_01_08", "setStrSubPopSub08" , actionParam, doSearch01_success, doSearch_fail);
    } 

    function doSearch01_success(gridData, data)
    {
    	
    	GridObj2.option("dataSource", gridData);
    	var param_data = data.PARAM_DATA;
    	console.log("param_data:"+JSON.stringify(param_data) );
    	
    	var par = new Object();
    	for(var j in param_data) {
    		 par[param_data[j]["KEY"]] = param_data[j]["VALUE"]
    	}
      /*   $("form[name='form1'] input[type=text]").each(function(i){
            $(this).val(par["param"+((i+1)>9?(i+1):"0"+(i+1))]);
        }); */
        
        $("form[name='form1'] input[type=text]").each(function(i){
        	if(i>2 && i<11)
            	$(this).val(par["param"+((i-0)>9?(i-2):"0"+(i-2))]);
        	else if (i>=11)
        		$(this).val(par["param"+((i)>9?(i):"0"+(i))]);
        });
        
		$("#trxPlusGrid").css("display", "none");
        
		//검색화면에서 조회할때는 거래추가 부분 주석 처리
        <% if(!"true".equals(approval)) { %>
        	form1.trxPlusBtn.disabled = true;
        	form1.trxMinusBtn.disabled = true;
        	form1.transactionDelBtn.disabled = true;
        	form1.transactionSavBtn.disabled = true;
        <% } %>
         
        
    }

    function doSearch02()
    {
    	console.log("doSearch02");
        if (GridObj3) {
            var form1 = document.form1;
            var actionParam = {
                    "classID"       : "AML_20_01_01_08"
                   ,"methodID"      : "setStrSubPopSub08_02"
                   ,"SSPS_DL_CRT_DT": form1.SSPS_DL_CRT_DT.value
                   ,"SSPS_DL_ID"    : form1.SSPS_DL_ID.value
                   ,"GNL_AC_NO"     : selectObj.GNL_AC_NO
                   ,"GDS_NO"        : selectObj.GDS_NO
                   ,"DL_DT"         : selectObj.DL_DT
                   ,"DL_SQ"         : selectObj.DL_SQ
                }
            sendService("AML_20_01_01_08", "setStrSubPopSub08_02" , actionParam, doSearch2_success, doSearch_fail);
        }
    }

    function doSearch2_success(gridData, data){
    	GridObj3.option("dataSource", gridData);
    }

    function Grid2CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId)
    {
        selectObj = obj;
        if(columnId == 'COL1'){ //CHCK_STRT_NO
        	doPopupCheck('update');
        }else if(columnId == 'COL4'){

        }
    }


    function doPopupCheck(gubn) {
		var p_frm		=  parent.document.form1;
		if(selectObj.GNL_AC_NO == '' || selectObj.GNL_AC_NO == undefined){
			showAlert("${msgel.getMsg('AML_20_01_01_08_200','추가할 계좌번호를 선택해주십시오.')}","WARN");
			return;
		}
		if(selectObj.COL1 == '' || gubn == '' || gubn == null){ //CHCK_STRT_NO
			gubn = 'new';
		}

		form2.pageID.value = 'AML_20_01_10_32';
		window_popup_open(form2.pageID.value, 800, 700, 'this');

	    form2.SSPS_DL_CRT_DT.value 	= form1.SSPS_DL_CRT_DT.value;
	    form2.SSPS_DL_ID.value 		= form1.SSPS_DL_ID.value;
	    form2.GNL_AC_NO.value 		= selectObj.GNL_AC_NO;
	    form2.GDS_NO.value 			= selectObj.GDS_NO;
	    form2.GDS_NO_VIEW.value 	= selectObj.GDS_NO; //form1.GDS_NO_VIEW.value;
	    form2.DL_DT.value 			= selectObj.DL_DT;
	    form2.DL_SQ.value 			= selectObj.DL_SQ;
	    form2.CHCK_STRT_NO.value 	= selectObj.COL1; //CHCK_STRT_NO
	    form2.RNMCNO.value 			= ''; //p_frm.RNMCNO_VIEW.value.replaceAll('-','');
	    form2.RNM_CNFR_CCD.value 	= p_frm.DL_P_RNM_NO_CCD.value;
	    form2.SSPS_DL_CRT_DT_VIEW.value = ''; //p_frm.SSPS_DL_CRT_DT_VIEW.value;
	    form2.ENDRS_P_NM.value 		= p_frm.DL_P_NM.value;
	    form2.BTN_SAVE_F.value 		= "Y";
	    form2.SCH_GUBN.value 		= gubn;


	    form2.target = form2.pageID.value;
		form2.action = "<c:url value='/'/>0001.do";
		form2.submit();

	}

    function doDeleteCheck(){
    	var rowData = GridObj2.getSelectedRowsData();

    	if(rowData.length < 1) {
            showAlert("${msgel.getMsg('AML_20_01_10_01_001','대상건이 존재하지 않습니다.')}","WARN");
            return;
        }

    	showConfirm('<fmt:message key="AML_10_01_01_01_007" initVal="삭제하시겠습니까?"/>', "삭제", doDeleteCheckAction);
	}

    function doDeleteCheckAction() {
    	var actionParam = {
                "classID"       : "AML_20_01_10_32"
               ,"methodID"      : "doDelete"
               ,"gridData": GridObj2.getSelectedRowsData()
            }
        sendService("AML_20_01_10_32", "doDelete" , actionParam, doDeleteCheck_end, doSearch_fail);
    }

    function doDeleteCheck_end(){
    	doSearch();
    }    

    function goAI(data){
    	parent.document.form1.DL_DT.value = data.DL_DT;
    	parent.document.form1.GDS_NO.value = data.GDS_NO;
    	parent.document.form1.DL_SQ.value = data.DL_SQ;
    	parent.setupTabPanel(4);
    }

    function doSearch03()
    {
        var p_frm = parent.document.form1;
            var form1 = document.form1;
            selectObj.classID             = "AML_20_01_01_08";
            selectObj.methodID            = "setStrSubPopMain08";
            selectObj.SSPS_DL_CRT_DT      = form1.SSPS_DL_CRT_DT.value;
            selectObj.SSPS_DL_ID          = form1.SSPS_DL_ID.value;
            selectObj.AML_ID              = form1.AML_ID.value;
            selectObj.AML_USER_NAME       = form1.AML_USER_NAME.value;
            selectObj.AML_ROLE_ID         = form1.AML_ROLE_ID.value;
            selectObj.AML_MASTER_BRANCH   = form1.AML_MASTER_BRANCH.value;
            selectObj.AML_BDPT_CD         = form1.AML_BDPT_CD.value;
            selectObj.AML_TEAM_LEADER_YN  = form1.AML_TEAM_LEADER_YN.value;
            selectObj.AML_TEL_NO          = form1.AML_TEL_NO.value;
            sendService("AML_20_01_01_08", "setStrSubPopMain08" , selectObj, doSearch_success, doSearch_fail);
    }

    function makeToolbarButtonGrids(e){

	    var cmpnt; cmpnt = e.component;
	    var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
	    var authC = "${outputAuth.C       }";  // 추가,수정 권한
	    var authD = "${outputAuth.D       }";  // 삭제 권한
	    if (useYN=="Y") {
	        var gridID       = e.element.attr("id");    // 그리드 아이디
	        var toolbarItems = e.toolbarOptions.items;
	        toolbarItems.splice(0, 0, {
	            "locateInMenu"  : "auto"
	            ,"location"     : "after"
	            ,"widget"       : "dxButton"
	            ,"name"         : "filterButton"
	            ,"width" :"100%"
	            ,"showText"     : "inMenu"
	            ,"options"      : {
	                     "icon"      : ""
	                   	,"elementAttr": { class: "btn-28 filter popupFilter" }
	        			,"text"      : ""
	                    ,"hint"      : '필터'
	                    ,"disabled"  : false
	                    ,"onClick"   : function(){
							if(gridID=="GTDataGridPopup81_Area"){
								setupFilter();
							}  else if(gridID=="GTDataGridPopup83_Area"){
								setupFilter3();
								}   else if(gridID=="GTDataGridPopup84_Area"){
									setupFilter4();
								}
							
	                    }
	             }
	        });
	    }
	}


    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup81_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_08_001','STR 혐의거래상세')}";
    	gridArrs[0] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }

    function setupFilter2(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup82_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_08_020','수표 상세정보')}";
    	gridArrs[1] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }

    function setupFilter3(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup83_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_08_029','대리인')}";
    	gridArrs[1] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }
    
    function setupFilter4(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup84_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_01_116','혐의거래추가')}";
    	gridArrs[1] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }

    function trxPlus() {
    	$("#trxPlusBtn").css("display", "none");
    	$("#trxMinusBtn").css("display", "inline");
        $("#trxPlusGrid").css("display", "block");
    }
    
    function trxMinus() {
    	$("#trxPlusBtn").css("display", "inline");
    	$("#trxMinusBtn").css("display", "none");
        $("#trxPlusGrid").css("display", "none");
    }
    
	function doSearchTrx() {
    	
	   	if($("#ACNT_NO").val() == "") {
	   		alert("계좌번호를 입력하세요.");
	   		return;
	   	}
	   	 
        selectObj.classID      = "AML_20_01_01_08";
        selectObj.methodID     = "doSearchTrx";
        selectObj.ACNT_NO      = $("#ACNT_NO").val();
        selectObj.DL_TYP_CD    = $("#DL_TYP_CD").val();
        selectObj.stDate       = getDxDateVal("stDate",true)
        selectObj.edDate       = getDxDateVal("edDate",true)
        sendService("AML_20_01_01_08", "doSearchTrx" , selectObj, doSearchTrx_success, doSearchTrx_end); 
	    
	}
	
	function doSearchTrx_success(gridData, data){
    	GridObj9.option("dataSource", gridData);
    }
	    
	function doSearchTrx_end() {
	 	parent.overlay.hide();
	}    
	
	 function dup_chk(selRow) {
	        for (var k = 0; k < GridObj1.totalCount(); k++) {
	            var selObj9 = selRow;
	            var selObj1 = getDataSource(GridObj1)[k];
	            var tradeVal  = selObj9.GNL_AC_NO + selObj9.DL_DT + selObj9.DL_SQ;
	            var suspisVal = selObj1.GNL_AC_NO + selObj1.DL_DT + selObj1.DL_SQ;
	            if (tradeVal == suspisVal) {
	                return true;
	            }
	        }
	        return false;
	    }
	
	
	function transactionAdd() {
     var rowsData = GridObj9.getSelectedRowsData();
     var selSize = rowsData.length;
     if (selSize==0) {
         alert("${msgel.getMsg('AML_10_09_01_01_004','선택된 건이 없습니다.')}");
         return;
     }
     
     var dataSource1 = GridObj1.getDataSource(); 
      
   	 if (GridObj1.totalCount() == 0){
   		 dataSource1 = new DevExpress.data.DataSource({store: new DevExpress.data.ArrayStore({key:"id", data:[]})});
   	     GridObj1.option ("dataSource", dataSource1);
   	 }else {
   		  
   	 } 
     
     for (var i = 0; i < selSize; i++) {
         var selRow = rowsData[i];
         if (!dup_chk(selRow)) {
         	//dataSource1.store().insert(selRow);
        	 dataSource1.store().push([{type:'insert', data:selRow}]); 
         }
     }
     
     dataSource1.reload();  
	}
	
	function transactionDel() {
        var rowsData = GridObj1.getSelectedRowsData();
        var selSize = rowsData.length;
        if (selSize==0) {
            alert("${msgel.getMsg('AML_10_09_01_01_004','선택된 건이 없습니다.')}");
            return;
        }
        
        var dataSource1 = GridObj1.getDataSource();
        
        for (var i = 0; i < selSize; i++) {
            var selRow = rowsData[i];
            dataSource1.store().remove(selRow); 
        }
        
        dataSource1.reload();
	}
	
	function transactionSav() {
		var gobj = $('#GTDataGridPopup81_Area').dxDataGrid('instance');
        gobj.saveEditData();
        
        //페이징 옵션 해제
        GridObj1.option("paging.enabled",false);
        
		var rowsCnt = GridObj1.totalCount();
		 
        if(!confirm("${msgel.getMsg('AML_10_09_01_01_003','저장하시겠습니까?')}")) return;
       
        var obj = new Object();
        obj.mode     = "save";
        obj.pageID   = "AML_20_01_01_08";
        obj.classID  = "AML_20_01_01_08";
        obj.methodID = "doSave";
        obj.SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
        obj.SSPS_DL_ID     = form1.SSPS_DL_ID.value;
        obj.GNL_AC_NO      = form1.GNL_AC_NO.value;
        obj.gridData       = GridObj1.getDataSource().items();
        sendService(obj.classID, obj.methodID, obj , transactionSav_success, doSearch_fail);
        
	}
	

    function transactionSav_success(gridData, data){
    	try {
	    	doSearch();
    	} catch (e) {
            showAlert(e,"ERR");
            overlay.hide();
        } finally {
            overlay.hide();
        }
    }
    
    
    
</script>
</head>

<style>
.linear-table .table-cell .title .txt {
font-size:12px;
}
 
.linear-wrap .linear-table .table-cell {
    width: auto;
    height: 35px;
}

.linear-table .table-cell .title {
    background-color: #eaeaea;
    padding: 5px 16px;
    min-width: 100px;
    height: 35px;
    text-align:center;
}

.table-cell .dropdown {
    font-family: SpoqR;
    font-size: 12px;
    line-height: 22px;
    color: #444;
    letter-spacing: -0.28px;
    padding: 7px 10px;
}

.linear-table .table-row {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    border-bottom: 1px solid #222;
}

.linear-table {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -moz-box-orient: vertical;
    -moz-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    border-collapse: separate;
    border-top: 1px solid #222;
}

.linear-table .content {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex
;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -moz-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    -moz-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    padding: 6px;
    height: 100%;
    width: auto;
}
.calendar input {
    width: 100px !important;
    padding-right: 0 !important;
    height: 30px;
    border: none;
}
input[type=text] {
    padding: 7px 10px;
    height: 30px;
    border: 1px solid #ccc;
    font-family: SpoqR;
    font-size: 14px;
    line-height: 22px;
    color: #48505d;
    letter-spacing: -0.28px;
}
.dropdown {
    font-family: SpoqR;
    font-size: 12px;
    line-height: 22px;
    color: #444;
    letter-spacing: -0.24px;
    position: relative;
    z-index: 1;
    width: 140px;
    white-space: nowrap;
    height: 32px;
    line-height: 36px;
    padding: 0 16px;
    border: 1px solid #ccc;
    background-color: #fff;
    text-align: left;
    background-image: url(/Package/design/images/common/svg/icon_dropdown_arrow24.svg);
    background-repeat: no-repeat;
    -webkit-background-size: 24px auto;
    background-size: 24px auto;
    background-position: 94% center;

</style>
<body>
<form name="form2" method="post" >
<input type="hidden" name="pageID" >
<input type="hidden" name="SSPS_DL_CRT_DT" >
<input type="hidden" name="SSPS_DL_ID" >
<input type="hidden" name="GNL_AC_NO" >
<input type="hidden" name="GDS_NO" >
<input type="hidden" name="GDS_NO_VIEW" >
<input type="hidden" name="DL_DT" >
<input type="hidden" name="DL_SQ" >
<input type="hidden" name="SCH_GUBN" >
<input type="hidden" name="PROC_GUBN" >
<input type="hidden" name="RNMCNO" >
<input type="hidden" name="RNM_CNFR_CCD" >
<input type="hidden" name="SSPS_DL_CRT_DT_VIEW" >
<input type="hidden" name="ENDRS_P_NM" >
<input type="hidden" name="CHCK_STRT_NO" >
<input type="hidden" name="BTN_SAVE_F" >
</form>

<form name="form1" method="post">
    <input type="hidden" name="pageID"  />
    <input type="hidden" name="classID" />
    <input type="hidden" name="methodID"/>
    <input type="hidden" name="SSPS_DL_CRT_DT"      value="${SSPS_DL_CRT_DT}"         			/>
    <input type="hidden" name="GNL_AC_NO" id="GNL_AC_NO"  			value="<c:out value='${param.GNL_AC_NO}'/>"	/>
    <input type="hidden" name="SSPS_DL_ID"          value="${SSPS_DL_ID}"               		/>
    <input type="hidden" name="AML_ID"              value="${ID}"                       		/>
    <input type="hidden" name="AML_USER_NAME"       value="${USER_NAME}"                		/>
    <input type="hidden" name="AML_ROLE_ID"         value="${ROLE_ID}"                  		/>
    <input type="hidden" name="AML_MASTER_BRANCH"   value="${MASTER_BRANCH}"            		/>
    <input type="hidden" name="AML_BDPT_CD"         value="${BDPT_CD}"                  		/>
    <input type="hidden" name="AML_TEAM_LEADER_YN"  value="${TEAM_LEADER_YN}"           		/>
    <input type="hidden" name="AML_TEL_NO"          value="${sessionAML.sAML_TEL_NO}"   		/> 
      
	<div class="cont-area3-right" style="width: 100%;">
		<div class="button-area" style="display: flex;justify-content: flex-end;">
		
	        <%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
	      		${btnel.getButton(outputAuth, '{btnID:"trxPlusBtn", cdID:"trxPlusBtn", defaultValue:"거래추가 열기", mode:"R", function:"trxPlus", cssClass:"btn-28", show:"N"}')}
	      		${btnel.getButton(outputAuth, '{btnID:"trxMinusBtn", cdID:"trxMinusBtn", defaultValue:"거래추가 닫기", mode:"R", function:"trxMinus", cssClass:"btn-28", show:"N"}')}
	      		${btnel.getButton(outputAuth, '{btnID:"transactionDelBtn", cdID:"transactionDelBtn", defaultValue:"거래삭제", mode:"R", function:"transactionDel", cssClass:"btn-28", show:"N"}')}
	      		${btnel.getButton(outputAuth, '{btnID:"transactionSavBtn", cdID:"transactionSavBtn", defaultValue:"거래저장", mode:"U", function:"transactionSav", cssClass:"btn-28", show:"N"}')}   
	  		<%} %>
	    </div>
	</div>
	
	<div class="tab-content-bottom" style="margin-top: 8px;">
	    <div id="GTDataGridPopup81_Area"></div>
	</div>
	 
	<div id="trxPlusGrid" name="trxPlusGrid" class="popup-grid-panel" ">
		<div class="panel-primary-left" style="width:100%;">
		    <div id="GTDataGrid3_HeaderArea" class="linear-wrap" style="margin-top:10px;" >
		    	<div class="linear-table">
			    	<div class="table-row">
				    	<div class="table-cell">
				    		${condel.getInputCustomerNo('{msgID:"AML_20_01_01_08_016", defaultValue:"계좌번호", name:"ACNT_NO", size:"20"}')}
				    	<div class="table-cell">
				    		${condel.getLabel('AML_20_01_01_08_102','거래유형')}&nbsp;
				    		<select name="DL_TYP_CD" id="DL_TYP_CD" class="dropdown" onChange='ccdChange(this)'>
				              ${condel.getSelectOption('','M045','9','ALL','ALL')}
				            </select>
				        </div>&nbsp;
				        <div class="table-cell">
				        ${condel.getLabel('AML_20_01_02_01_004','거래일자')}&nbsp;
				        	<div class='calendar'>
								${condel.getInputDateDx('stDate',stDate)} ~ ${condel.getInputDateDx('edDate',edDate)}
							</div>
						</div>
				    	</div>
			    	</div>
		    	</div>&nbsp;&nbsp;
		    	<div class="table-cell">
		    	<div class="button-area" style="display: flex;justify-content: flex-end;">
		    	 ${btnel.getButton(outputAuth, '{btnID:"btn_04", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearchTrx", cssClass:"btn-28", show:"N"}')}
			     ${btnel.getButton(outputAuth, '{btnID:"transactionAddBtn", cdID:"transactionAddBtn", defaultValue:"거래추가", mode:"R", function:"transactionAdd", cssClass:"btn-28", show:"N"}')}
			    </div>
			    </div>
			</div> 
		    <div class="tab-content-bottom" style="margin-top: 8px;">
		        <div id="GTDataGridPopup84_Area" style="z-index:3;"></div>
		    </div>      
		</div>
	</div> 
	
	<div class="info-area" style="margin-top: 8px;">
		<div class="info-left" style="width:50%">
			<div class="tab-content-bottom">
            	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_08_002','거래내역 상세정보')}</h4>
			</div>
	    
			<table class="basic-table" style="width:100%;maring-top:10px;">
	        <tbody>
				<tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_021','거래금액')}</th>
					<td><input name="COL0" type="text"  readonly="readonly"  style="text-align: right;" size="5"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_102','거래유형')}</th>
					<td><input name="COL1" type="text"  readonly="readonly" ></td>
				</tr>
				<tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_023','현금')}</th>
					<td><input name="COL2" type="text"  readonly="readonly"  style="text-align: right;"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_024','거래방법')}</th>
					<td><input name="COL3" type="text"  readonly="readonly"></td>
				</tr>
			    <tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_025','수표금액')}</th>
					<td><input name="COL4" type="text"  readonly="readonly"  style="text-align: right;"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_026','거래채널')}</th>
					<td><input name="COL5" type="text"  readonly="readonly" ></td>
			    </tr>
			    <tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_027','예수금잔액')}</th>
					<td><input name="COL6" type="text"  readonly="readonly"  style="text-align: right;"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_028','취급지점코드')}</th>
					<td><input name="COL7" type="text"  readonly="readonly" ></td>
			    </tr>
			</tbody>
     		</table>
    	</div>
    	<input name="COL8" type="text"  style="display: none;">
    	<input name="COL9" type="text"  style="display: none;">
	    <div class="info-right" style="width:50%">
			<div class="tab-content-bottom" style="maring-top:10px;">
				<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_08_013','상대/대체정보')}</h4>
			</div>
			<table class="basic-table" style="width:100%;maring-top:10px;">
		    <tbody>
				<tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_014','금융기관명')}</th>
					<td><input name="COL10" type="text"  readonly="readonly"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_015','계좌실명확인번호')}</th>
					<td><input name="CPRTY_TRSNS_AC_RNM_NO" type="text"  readonly="readonly"></td>
				</tr>
				<tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_016','계좌번호')}</th>
					<td><input name="CPRTY_TRSNS_AC_NO" type="text"  readonly="readonly"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_017','계좌실명확인구분')}</th>
					<td><input name="COL13" type="text"  readonly="readonly"></td>
				</tr>
				<tr>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_018','명')}</th>
					<td><input name="COL14" type="text"  readonly="readonly"></td>
					<th class="title">${msgel.getMsg('AML_20_01_01_08_019','계좌주국적')}</th>
					<td><input name="COL15" type="text"  readonly="readonly"></td>
				</tr>
			</tbody>
			</table>
		</div>
	</div>

	<div class="tab-content-bottom">
		<div class="cont-area3">
			<div class="cont-area3-left" style="width: 49%;">
				<div class="tab-content-bottom" style="margin-bottom: 8px;">
			   		<div class="cont-area3" style="padding-top: 0px;">
			   			<div class="cont-area3-left" style="width: 50%;">
			   				<div class="row" style="padding-top: 0px; padding-bottom: 0px;">
		      					<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_01_08_020','수표 상세정보')}</h4>
							</div>
			   			</div>
			   			<div class="cont-area3-right" style="width: 50%;">
				   			<div class="button-area" style="display: flex;justify-content: flex-end;">
								<button type="button" class="btn-28 filter" onclick="setupFilter2()"></button>
						         <%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
						       		${btnel.getButton(outputAuth, '{btnID:"btn_add", cdID:"addBtn", defaultValue:"추가", mode:"U", function:"doPopupCheck", cssClass:"btn-28", show:"N"}')}
						       		${btnel.getButton(outputAuth, '{btnID:"btn_del", cdID:"deleteBtn", defaultValue:"삭제", mode:"U", function:"doDeleteCheck", cssClass:"btn-28", show:"N"}')}
						   		<%} %>
						     </div>
			   			</div>
			   		</div>
				</div>
				<div id="GTDataGridPopup82_Area"></div>
			</div>
			<div class="arrow-area" style="width:2%; background-color: #fff;">
			</div>
			<div class="cont-area3-right" style="width: 49%;">
				<div id="GTDataGridPopup83_Area"></div>
			</div>
		</div>
	</div>
</form>
</body>
</html>
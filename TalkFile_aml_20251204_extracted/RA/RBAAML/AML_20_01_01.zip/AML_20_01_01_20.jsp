<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
- File Name  : AML_20_01_01_20.jsp
- Author     : syk, hikim
- Comment    : 대표자 정보 입력
               STR疑わしい取引の詳細(法人)
               President Info. Input
- Version    : 1.0
- history    : 1.0 2010-09-30
--%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 대표자 정보 입력
*                   STR疑わしい取引の詳細(法人)
*                   President Info. Input
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
********************************************************************************************************************************************
--%>

<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>

<%

	String AML_CUST_ID 	 	 		= jspeed.base.xml.XMLHelper.normalize(request.getParameter("AML_CUST_ID"))      		== null ? "" : request.getParameter("AML_CUST_ID");
	String RNM_NO_CCD_NM 	 	= jspeed.base.xml.XMLHelper.normalize(request.getParameter("RNM_NO_CCD_NM"))     == null ? "" : request.getParameter("RNM_NO_CCD_NM");
	String CS_NM 	 	 		= jspeed.base.xml.XMLHelper.normalize(request.getParameter("CS_NM"))      		== null ? "" : request.getParameter("CS_NM");
	
	request.setAttribute("AML_CUST_ID",AML_CUST_ID);
	request.setAttribute("RNM_NO_CCD_NM",RNM_NO_CCD_NM);
	request.setAttribute("CS_NM",CS_NM);
%>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" /> 

    <script language="JavaScript"> 
    <!-- 
    	var GridObj1 = null;
    	var GridObj2 = null;
	
        /** 
         * Initial function 
         */ 
     	function init() {
     		initPage();
     	 
     	}
        
    	function GTDataGrid01Init(id){
    		GridObj1 = initGrid(id, "AML_20_01_01_20_WiseGrid1","", "doSearch");
    	}

    	function GTDataGrid02Init(id){
    		GridObj2 = initGrid(id, "AML_20_01_01_20_WiseGrid1_dummy","");
    	}

        /** 
         * Search
         */ 
		function doSearch() { 

			var obj = new Object();

			var pageID		= "AML_20_01_01_20";
			var classID 	= "AML_20_01_01_20";
		    var methodID 	= "getSearch";

			obj.pageID = pageID;
			obj.classID = classID;
			obj.methodID = methodID;

			obj.AML_CUST_ID = form1.AML_CUST_ID.value;
			
			obj.jsFunction 		= "doSearch_end";
		    
			refresh(GridObj1, obj);
		    
        }
        
		function doSearch_end(){
			if(GridObj1.rowCount() > 0){
				doColumnSetting()
			}
		}

		function boxOptionSelect(boxId, value) {
			
			var selectBox = $(boxId);
			var maxLength = selectBox.length;

			if(value != null && value != ""){
				for (var i = 0; i < maxLength; i++) {
				    var option = selectBox.getElementsByTagName("OPTION")[i];
				    if (option.value == value) {
				    	selectBox[i].selected = "selected";
				    	return;
				    }
				}
			}

			selectBox[0].selected = "selected";
	    }
		
		function doColumnSetting(){
			obj = GridObj1.getRow(0);

			$("RPRST_P_NM").value = obj.RPRST_P_NM;
			$("RPRST_P_RNMCNO").value = obj.RPRST_P_RNMCNO;
			$("RPRST_P_TEL_NO").value = obj.RPRST_P_TEL_NO;
			$("RPRST_P_HSE_ADDR").value = obj.RPRST_P_HSE_ADDR;
			$("RPRST_P_HSE_PST_NO").value = obj.RPRST_P_HSE_PST_NO;

			boxOptionSelect("RPRST_P_RNM_NO_CCD", obj.RPRST_P_RNM_NO_CCD);
			boxOptionSelect("RPRST_P_NTNLT_CD", obj.RPRST_P_NTNLT_CD);
			boxOptionSelect("RPRST_P_SEX_CD", obj.RPRST_P_SEX_CD);
		}
		
		var zip_window = null;
		function findAddress(){
			if(zip_window != null)
			zip_window.close();
			zip_window = window_popup_open(form2, 480, 500, '','no');
			form2.pageID.value = 'AML_20_06_01_02';
			form2.target = 'AML_20_06_01_02_POPUP';
			form2.action = "<c:url value='/'/>0001.do"; 
			form2.submit();
			form2.target = '';
		}	

		function setAddress(address1, address2, seq){
			address1 = address1.replace(/\'/g, "");
			$("RPRST_P_HSE_ADDR").value = address1;
			$("SEQ").value = seq;
		}	

		function setZipcode(zipcode){
			$("RPRST_P_HSE_PST_NO").value=zipcode;
		}

		function onlyNumber(obj){
			var val = obj.value;
			var len = val.length;
			var rt_val = "";
			//alert(len);
			for(var i = 0; i < len ; i++){
				var chr = val.charAt(i);
				var ch = chr.charCodeAt();
				
				if(ch < 48 || ch > 57 ) {
			        //alert("특수문자를 사용할 수 없습니다");
			        //return;
					rt_val = rt_val;
				}else{
					rt_val = rt_val + chr;
				}
			}
			obj.value = rt_val;
			obj.focus();
			
		}
		
		function onlyNumber1(obj){
			var val = obj.value;
			var len = val.length;
			var rt_val = "";
			//alert(len);
			for(var i = 0; i < len ; i++){
				var chr = val.charAt(i);
				var ch = chr.charCodeAt();
				
				if(ch < 45 || ch > 57 || ch == 46 || ch == 47 ) {
			        //alert("특수문자를 사용할 수 없습니다");
			        //return;
					rt_val = rt_val;
				}else{
					rt_val = rt_val + chr;
				}
			}
			obj.value = rt_val;
			obj.focus();
			
		}

		function doSave(){
			if(!checkValue()) return;
		if(!confirm('<fmt:message key="AML_20_01_01_20_014"/>')) return;
			doSave_Action();
		}

		function checkValue(){
			
			if($("RPRST_P_NM").value == '' || $("RPRST_P_NM").value == undefined){
			alert("<fmt:message key="AML_20_01_01_20_015"/>");
				$("RPRST_P_NM").focus();
				return false;
			}
			
			if($("RPRST_P_RNMCNO").value == '' || $("RPRST_P_RNMCNO").value == undefined){
			alert("<fmt:message key="AML_20_01_01_20_016"/>");
				$("RPRST_P_RNMCNO").focus();
				return false;
			}

			if($("RPRST_P_RNM_NO_CCD").value == 'ALL'){
			alert("<fmt:message key="AML_20_01_01_20_017"/>");
				$("RPRST_P_RNM_NO_CCD").select();
				return false;
			}
			
			if($("RPRST_P_TEL_NO").value == '' || $("RPRST_P_TEL_NO").value == undefined){
			alert("<fmt:message key="AML_20_01_01_20_018"/>");
				$("RPRST_P_TEL_NO").focus();
				return false;
			}
			
			if($("RPRST_P_NTNLT_CD").value == 'ALL'){
			alert("<fmt:message key="AML_20_01_01_20_019"/>");
				$("RPRST_P_NTNLT_CD").select();
				return false;
			}
			
			if($("RPRST_P_SEX_CD").value == 'ALL'){
			alert("<fmt:message key="AML_20_01_01_20_020"/>");
				$("RPRST_P_SEX_CD").select();
				return false;
			}

			if($("RPRST_P_HSE_PST_NO").value == '' || $("RPRST_P_HSE_PST_NO").value == undefined){
			alert("<fmt:message key="AML_20_01_01_20_021"/>");
				return false;
			}
			
			if($("RPRST_P_HSE_ADDR").value == '' || $("RPRST_P_HSE_ADDR").value == undefined){
			alert("<fmt:message key="AML_20_01_01_20_022"/>");
				return false;
			}

			return true;
			
		}

		function remove_data(temp){
			for(var i=temp.rowCount()-1; i >= 0; i--) {
				temp.selectRow(i);
				temp.remove();
			}
		}
		
		function doSave_Action(){
			var Gubun = "";

			if(GridObj1.rowCount() > 0){
				Gubun = "U";
			} else {
				Gubun = "I";
			}

			if(GridObj2.rowCount()>0) {
				remove_data(GridObj2);
			}
			
			var addObj = new Object();
			addObj.RPRST_P_RNMCNO = $("RPRST_P_RNMCNO").value;
			addObj.RPRST_P_NM = $("RPRST_P_NM").value;
			addObj.RPRST_P_TEL_NO = $("RPRST_P_TEL_NO").value;
			addObj.RPRST_P_RNM_NO_CCD = $("RPRST_P_RNM_NO_CCD").value;
			addObj.RPRST_P_NTNLT_CD = $("RPRST_P_NTNLT_CD").value;
			addObj.RPRST_P_HSE_ADDR = $("RPRST_P_HSE_ADDR").value;
			addObj.RPRST_P_HSE_PST_NO = $("RPRST_P_HSE_PST_NO").value;
			addObj.RPRST_P_SEX_CD = $("RPRST_P_SEX_CD").value;
			addObj.GUBUN = Gubun;
			
			GridObj2.addLast(addObj);

			var obj = new Object();
		    obj.methodID = "doSave";
		    obj.classID = "AML_20_01_01_20";	
		    obj.jsFunction = "doSave_end";  
			obj.AML_CUST_ID = form1.AML_CUST_ID.value;
			
		    save(GridObj2,obj);
		}

		function doSave_end(){
			var obj = new Object();

			var slbRnmNoCCD = document.form1.RPRST_P_RNM_NO_CCD;
			var slbNtnltCd = document.form1.RPRST_P_NTNLT_CD;
			var idxRnmNoCCD = slbRnmNoCCD.selectedIndex;
			var idxNtnltCd = slbNtnltCd.selectedIndex;

			obj.company_COL0 = $("RPRST_P_NM").value;
			obj.company_COL1 = slbRnmNoCCD.options[idxRnmNoCCD].text;
			obj.company_COL2 = $("RPRST_P_RNMCNO").value;
			obj.company_COL3 = slbNtnltCd.options[idxNtnltCd].text;
			obj.company_COL5 = $("RPRST_P_TEL_NO").value;
			obj.company_COL6 = "("+$("RPRST_P_HSE_PST_NO").value+") "+$("RPRST_P_HSE_ADDR").value;

			opener.setValueCompany(obj);
			window.close();
		}
    --> 
    </script> 
    
<form name="form2" method="post" >
	<input type="hidden" name="pageID" > 
	<input type="hidden" name="classID" > 
	<input type="hidden" name="methodID" >
	<input type="hidden" name="IS_MNG"/>
</form>
<form name="form1"  method="post"> 

<input type="hidden" name="pageID" > 
<input type="hidden" name="classID" > 
<input type="hidden" name="methodID" >

<!-- Hidden Grid start -->
<div id="GTDataGrid01_Area" style="display:inline; width:1px; height:1px; overflow:hidden;">
   <script>initSizeGTDataGrid2('GTDataGrid01_Area','100','100','GTDataGrid01', '${path}/GTDataGridServlet', 'GTDataGrid01Init');</script>
</div>
<!-- <script>initSizeGTDataGrid('0','0','GTDataGrid01', '${path}/GTDataGridServlet','GTDataGrid01Init');</script> -->
<div id="GTDataGrid02_Area" style="display:inline; width:1px; height:1px; overflow:hidden;">
   <script>initSizeGTDataGrid2('GTDataGrid02_Area','100','100','GTDataGrid02', '${path}/GTDataGridServlet', 'GTDataGrid02Init');</script>
</div>
<!-- <script>initSizeGTDataGrid('0','0','GTDataGrid02', '${path}/GTDataGridServlet','GTDataGrid02Init');</script> -->
<!-- Hidden Grid end -->
    <table width="100%" border="0" > 
        <tr> 
            <td height="300" align="center" valign="top"> 
                <table width="100%" border="0" > 
                    <tr> 
                        <td> 
		                     <table width="100%" border="0"  style="margin-bottom:7px;">
							<tr>
								<td width="7" height="7" background="<c:url value='/'/>AML/images/co_bg01.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg02.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg02.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg02.gif"></td>
								<td width="7" background="<c:url value='/'/>AML/images/co_bg03.gif"></td>
							</tr>
							<tr>
								<td valign="bottom" background="<c:url value='/'/>AML/images/co_bg09.gif"><img src="<c:url value='/'/>AML/images/co_bg10.gif"></td>
								<td colspan="3" align="center" valign="top" class="com_bg01">
									<table width="100%" border="0" >
										<tr>
											<td align="left">
												<table border="0" >
													<tr>
														<td>
															<table border="0" align="left" >
																<tr>
																	<td><img src="<c:url value='/'/>AML/images/icon/icon02.gif" hspace="4"></td>
																<td class="sear_h"><fmt:message key="AML_20_01_01_20_001"/></td>
																	<td class="sear_b"><input name=AML_CUST_ID type="text" class="input_t_dis01" value="<c:out value='${AML_CUST_ID}'/>" /></td>
																	<td><img src="<c:url value='/'/>AML/images/icon/icon02.gif" hspace="4"></td>
																<td class="sear_h"><fmt:message key="AML_20_01_01_20_002"/></td>
																	<td class="sear_b"><input name="RNM_NO_CCD_NM" type="text" class="input_t_dis01" value="<c:out value='${RNM_NO_CCD_NM}'/>" /></td>
																</tr>
																<tr>
																	<td><img src="<c:url value='/'/>AML/images/icon/icon02.gif" hspace="4"></td>
																<td class="sear_h"><fmt:message key="AML_20_01_01_20_003"/></td>
																	<td colspan="4">
																		<input name="CS_NM" type="text" class="input_t_dis01" value="<c:out value='${CS_NM}'/>" size="15" />
																	</td>
																</tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
											<td>
												
											</td>
										</tr>
									</table>
								</td>
								<td valign="bottom" background="<c:url value='/'/>AML/images/co_bg04.gif"><img src="<c:url value='/'/>AML/images/co_bg05.gif"></td>
							</tr>
							<tr>
								<td height="7" background="<c:url value='/'/>AML/images/co_bg08.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg07.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg07.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg07.gif"></td>
								<td background="<c:url value='/'/>AML/images/co_bg06.gif"></td>
							</tr>
						</table>		                      
                        </td> 
                    </tr> 
                    <tr>
                    	<td>
                    		<table border="0"  class="btn_area01" width="100%">
								<tr>
								<td width="50%"><span class="btn3"><span><fmt:message key="AML_20_01_01_20_004"/></span></span></td>
								</tr>
							</table>
                    	</td>
                    </tr>
					<tr>
						<td>
							<table width="100%" border="0" >
								<tr>
									<td>
										<table width="100%" height="100%" border="0"  class="tbl_info" style="margin-bottom:7px;">
											<tr>
												<td class="tbl_Top">
												<fmt:message key="AML_20_01_01_20_005"/>
												</td>
												<td class="tbl_info_w">
													<input type="text" name="RPRST_P_NM" maxlength="100" size="20">
												</td>
											</tr>
											<tr>
												<td class="tbl_Top" width="15%">
												<fmt:message key="AML_20_01_01_20_006"/>
												</td>
												<td class="tbl_info_w" width="35%">
													<input type="text" name="RPRST_P_RNMCNO" maxlength="13" size="20" onkeyup="onlyNumber(this);" onkeypress="onlyNumber(this);" style="IME-MODE: disabled">
												</td>
											</tr>
											<tr>
												<td class="tbl_Top" width="15%">
												<fmt:message key="AML_20_01_01_20_007"/>
												</td>
												<td class="tbl_info_w" width="35%">
													<select name="RPRST_P_RNM_NO_CCD" class="select_box01">
														<AMLTag:combobox_option sqlID="" code="M002"  initValue="" firstComboWord='선택' />
													</select>
												</td>
											</tr>
											<tr>
												<td class="tbl_Top">
												<fmt:message key="AML_20_01_01_20_008"/>
												</td>
												<td class="tbl_info_w">
													<input type="text" name="RPRST_P_TEL_NO" maxlength="20" size="20" onkeyup="onlyNumber1(this);" onkeypress="onlyNumber1(this);" style='IME-MODE: disabled'>
												</td>
											</tr>
											<tr>
												<td class="tbl_Top">
												<fmt:message key="AML_20_01_01_20_009"/>
												</td>
												<td class="tbl_info_w">
													<select name="RPRST_P_NTNLT_CD" class="select_box01">
														<AMLTag:combobox_option sqlID="" code="M004"  initValue="" firstComboWord='선택' />
													</select>
												</td>
											</tr>
											<tr>
												<td class="tbl_Top">
												<fmt:message key="AML_20_01_01_20_010"/>
												</td>
												<td class="tbl_info_w">
													<select name="RPRST_P_SEX_CD" class="select_box01">
														<AMLTag:combobox_option sqlID="" code="M013"  initValue="" firstComboWord='선택' />
													</select>
												</td>
											</tr>
											<tr>
												<td class="tbl_Top">
												<fmt:message key="AML_20_01_01_20_011"/>
												</td>
												<td class="tbl_info_w">
													<table width="100%" border="0"  >
														<tr>
															<td width="70">
																<input name="RPRST_P_HSE_PST_NO" type="text" class="input_text01" value="" maxlength="6" size="6" readonly>&nbsp;<img src="<c:url value='/'/>AML/images/bt_search01.gif" align="absmiddle" OnClick="javascript:findAddress();" style="cursor: pointer"/>
																<input name="SEQ" type="hidden" value=""/>
															</td>
														</tr>
														<tr>
															<td><input name="RPRST_P_HSE_ADDR" type="text" class="input_text01" value="" maxlength="80" size="60" align="absmiddle"></td>
														</tr>
													</table>
												</td>
											</tr>

										</table>
									</td>
								</tr>
							</table>
						</td>
					</tr>		
                </table>
			    <table border="0" align="right" > 
					<tr>
						<td height="10px"></td>
					</tr>
					<tr>
		            <td width="100%" >
		            <span class="btn1_enable" onClick="javascript:doSave();">
		            	<a href="#" onClick="return false;">
		            		<span><fmt:message key="AML_20_01_01_20_012" initVal="저장"/></span>
		            	</a>
		            </span>
		            	<span class="btn1_enable" onClick="window.close()">
		            		<a href="#" onClick="return false;">
		            	<span><fmt:message key="AML_20_02_04_02_004" initVal="닫기"/></span></a>
		            	</span>
		            </td> 			           
			        </tr> 
			    </table>  
            </td> 
        </tr> 
    </table>                                    
</form> 
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" /> 

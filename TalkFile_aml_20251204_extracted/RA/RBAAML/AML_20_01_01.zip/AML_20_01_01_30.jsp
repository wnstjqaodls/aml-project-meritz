<%@ page language="java" contentType="text/html; charset=utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 공통코드 검색
*                   Code Popup Search
* Author          : 
* Since           : 2019. 06. 12.
********************************************************************************************************************************************
--%>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp"           %>
<%
	String paramCode   = Util.nvl(request.getParameter("paramCode"));
	String paramViewSave   = Util.nvl(request.getParameter("paramViewSave"));
	String paramGubn   = Util.nvl(request.getParameter("paramGubn"));

	request.setAttribute("paramCode",paramCode);
	request.setAttribute("paramViewSave",paramViewSave);
	request.setAttribute("paramGubn",paramGubn);
	
%>
<script>
    var GridObj1 = null;
    var overlay = new Overlay();
    
    // [ Initialize ]
    $(document).ready(function(){
        setupEvents();
        setupGrids();  
        doSearch();
        $(".cond-row").css("visibility","visible");
        $("input[name=SCH_CD]").val("${paramCode}");
        $("input[name=SCH_VAL]").focus();
    });

    /** 검색조건 셋업 */
    function setupEvents()
    {
        $("input[name=SCH_VAL]").keyup(function(e){
            if (e.which==13) doSearch();
        });
    }
    
    function setupGrids()
    {
        GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
        	gridId          				: "GTDataGrid1"
        	,"height"						:"calc(75vh - 200px)"
        		,"elementAttr": { class: "grid-table-type" }
        	,"allowColumnReordering": true
        	   ,"allowColumnResizing"  : true
        	   ,columnResizingMode : 'widget'
        	   ,"cacheEnabled"         : false
        	   ,"cellHintEnabled"      : true
        	   ,"columnAutoWidth"      : true
        	   ,"columnFixing" : {"enabled": false}
        	   ,export 					: {allowExportSelectedData : true ,enabled : true ,excelFilterEnabled : true},
		    onExporting: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer) {
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${pageTitle}.xlsx");
			        });
			    });
			    e.cancel = true;
            }
        	   ,"filterRow" : {"visible": false}
        	   ,"hoverStateEnabled"     : true
        	   ,"loadPanel"             : {"enabled": false}
        	   ,"paging"                : {"enabled": false}
        	   ,"remoteOperations"      : {
        	        "filtering" : false
        	       ,"grouping"  : false
        	       ,"paging"    : false
        	       ,"sorting"   : false
        	       ,"summary"   : false
        	    }
        	   ,"rowAlternationEnabled" : true
        	   ,"searchPanel"           : {
        	        "visible" : false
        	       ,"width"   : 250
        	    }
        	   ,"selection"             : {
        	        "allowSelectAll"    : true
        	       ,"deferred"          : false
        	       ,"mode"              : "single"
        	       ,"selectAllMode"     : "allPages"
        	       ,"showCheckBoxesMode": "always"
        	    }
        	   ,"scrolling"             : { mode: "virtual" }
        	   ,"showBorders"           : true
        	   ,"showColumnLines"       : true
        	   ,"showRowLines"          : true
        	   ,"sorting"               : {"mode": "multiple"}
        	   ,"width"                 : "inherit"
        	   ,"wordWrapEnabled"       : false
        	   ,"summary": {
        	        "totalItems": [{
        	            "column"       : "CNTNT"
        	           ,"summaryType"  : "count",
        	           valueFormat: "fixedPoint"
        	        }],
        	        texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
        	    }
        	   ,"columns" : [
        	        {"dataField": "CNTNT",		"caption": '${msgel.getMsg("AML_20_01_01_30_001","코드")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": "120px"},
        	        {"dataField": "CD_NM",		"caption": '${msgel.getMsg("AML_20_01_01_30_002","코드명")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true},
        	        {"dataField": "GR_CD_NM",	"caption": 'GR_CD_NM',											"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 10,"visible": false}
        	    ]
        	   ,"onCellClick" : function(e) {
        	        if (e.data) {
        	            
        	        }
        	    }
        }).dxDataGrid("instance");
    }
    
    function closeCancel() { self.close(); }
    
    function doSelectData()
    {
        var selectedItem = GridObj1.getSelectedRowsData()[0];
        if( selectedItem == null || selectedItem == "" || selectedItem == undefined) {
			showAlert("${msgel.getMsg('adm.message.no.select','선택된 항목이 없습니다.')}","WARN");
			return;
		}
        if (selectedItem && selectedItem.CNTNT && opener['${param.FUNC_NM}']) {
            opener['${param.FUNC_NM}']({'GUBUN':'${paramGubn}','CODE_ID':selectedItem.CNTNT,'CODE_NM':selectedItem.CD_NM});
            self.close();
        }
    }

    function doSearch()
    {   
    	overlay.show(true, true);
    	GridObj1.clearSelection();
	    GridObj1.option('dataSource', []);
	    
            var actionParam   = {
                "pageID"    : "AML_20_01_01_30"
               ,"classID"   : "AML_20_01_01_30"
               ,"methodID"  : "doSearch"
               ,"SCH_CD"    : "${paramCode}"
               ,"SCH_VAL"   : $("input[name=SCH_VAL]").val()
            }
        sendService(actionParam.classID, actionParam.methodID, actionParam, doSearch_success, doSearch_fail);
    }
    
    function doSearch_success(gridData, data){
    	overlay.hide();
    	var grdTitle = "";
    	GridObj1.option("dataSource", gridData);
    	$("input[name=SCH_CD]").val("${paramCode}");
		document.all.SCH_CD.readOnly = true;
		$("input[name=SCH_VAL]").focus();
		return;
    }
    
    function doSearch_fail(data){
    	overlay.hide();
    }
</script>
<form name="form1" onSubmit="return false;" onkeydown="doEnterEvent('doSearch');">
    <div class="inquiry-table">
        <div class="table-row">
            <div class="table-cell">
                ${condel.getLabel("AML_20_02_02_90_125","상위코드")}
                <input name="SCH_CD" type="text" style="width:80px">
            </div>
            <div class="table-cell">
                 ${condel.getLabel("AML_20_02_02_90_126","코드 / 명")}
                <input name="SCH_VAL" type="text"  maxlength="20" style="width:120px">
            </div>
         </div>
        </div>
    </div>
    <div class="btn-area" style="float:right;margin : 7px">
          ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}
    </div>										
    <div class="tab-content-bottom">
		<div class="row"></div>	
        <div id = "GTDataGrid1_Area" style="width:90%;margin-left:25px;margin-right:10px;"></div>
    </div>
    <div class="btn-area" style="text-align:right;margin-top:10px;margin-right:10px;">
        ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"selBtn", defaultValue:"선택", mode:"R", function:"doSelectData", cssClass:"btn-36"}')}
        ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"closeCancel", cssClass:"btn-36"}')}
    </div>  
</form>
<%@ include file="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" %>
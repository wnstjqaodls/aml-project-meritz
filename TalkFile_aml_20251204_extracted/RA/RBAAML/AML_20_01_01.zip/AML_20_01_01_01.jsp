<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 파일생성
*                   STR ファイル生成
*                   STR Create
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 7. 5.
* Alteration      : 1. 코드 정리
*                   2. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>
<%@ page import="java.text.ParseException" %>
<%@ page import="com.gtone.aml.basic.common.log.Log"%>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%
    String startDate = Util.nvl(request.getParameter("startDate"));
    String endDate   = Util.nvl(request.getParameter("endDate"  ));

    try{
        if(("").equals(startDate)) {
        	startDate = DateUtil.addDays(DateUtil.getDateString(), -90, "yyyy-MM-dd");
        }
        if(("").equals(endDate)) {
        	endDate = DateUtil.addDays(DateUtil.getDateString(), 0, "yyyy-MM-dd");
        }
        }catch(ParseException e){
        	Log.logAML(Log.ERROR, e);
        }

    request.setAttribute("startDate",startDate);
    request.setAttribute("endDate"  ,endDate  );
%>
<script src="${contextPath}/Package/ext/js/state_validate.js"></script>
<script>
    //[ Attributes ]
    var GridObj1 = null;
    var overlay  = new Overlay();
	var pageID	 = "AML_20_01_01_01";
	var classID  = "AML_20_01_01_01";
    var dataSource = [];

    // [ Initialize ]
    $(document).ready(function(){
        setupGrids();
        $("#sbtn_07").hide();
        $("#sbtn_08").hide();

        setupFilter("init");
    });

    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid1_Area";
    	//gridObj.title = "STR검색";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }
    function doSearch() {
    	if(!fromToDateChechk("startDate", "endDate"))return;

        overlay.show(true, true);

        var params = new Object();
		var methodID = "getSearch";
		overlay.show(true, true);
		params.pageID = pageID;
		params.startDate = getDxDateVal("startDate", true);
		params.endDate   = getDxDateVal("endDate"  , true);
		params.CS_NM           = $("#CS_NM"                ,"form[name=form1]").val();
		params.aml_cust_id     = $("#AML_CUST_ID"          ,"form[name=form1]").val().replace('-','');
		params.branchCode      = $("input[name=branchCode]","form[name=form1]").val();
		params.RPR_PRGRS_CCD   = $("#RPR_PRGRS_CCD"        ,"form[name=form1]").val();

		sendService(classID, methodID, params, doSearch_success, doSearch_fail);

    }

    /*Search Success CallBack*/
    function doSearch_success(data,jsonData) {
        GridObj1.refresh();
        GridObj1.option("dataSource",data);

        setTimeout(function(){overlay.hide();},1000);
        var selObj = $("#RPR_PRGRS_CCD").val();

        var gobj = $('#GTDataGrid1_Area').dxDataGrid('instance');
        gobj.option("editing.allowUpdating", true);

        if (selObj != "99") {
            GridObj1.columnOption("FIU_NO", 'visible', false);
            GridObj1.columnOption("FIU_REG_DT", 'visible', false);
        }
        overlay.hide();
    }

    /*Search Fail CallBack*/
	function doSearch_fail(){
		overlay.hide();
	}

    /** Grid click */
    function Grid1CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId){
        if (columnId == "SSPS_DL_CRT_DT_A") {
            form2.pageID.value = 'AML_20_01_10_03';
            window_popup_open(form2.pageID.value, 1500, 850, '');
            form2.SSPS_DL_CRT_DT.value  = obj.SSPS_DL_CRT_DT;
            form2.SSPS_DL_ID.value      = obj.SSPS_DL_ID;
            form2.GNL_AC_NO.value      = obj.GNL_AC_NO
            form2.target = form2.pageID.value;
            form2.action = "<c:url value='/'/>0001.do";
            form2.submit();
        } else if (columnId == "RSK_GRD_MRK") {
            form2.pageID.value = 'AML_10_04_01_04';
            window_popup_open(form2.pageID.value, 1000, 950, '', 'yes');
            form2.aml_cust_id.value = obj.DL_P_AML_CUST_ID;
            form2.KYC_TMS_CCD.value = 'K';
            form2.target = form2.pageID.value;
            form2.action = "<c:url value='/'/>0001.do";
            form2.submit();
        } else if (columnId == "RSK_MRK") {
            form2.pageID.value = 'AML_20_01_10_02';
            window_popup_open(form2.pageID.value, 800, 600, '', 'yes');
            form2.aml_cust_id.value          = obj.DL_P_AML_CUST_ID;
            form2.SSPS_DL_CRT_DT.value  = obj.SSPS_DL_CRT_DT;
            form2.SSPS_DL_ID.value      = obj.SSPS_DL_ID;
            form2.KYC_TMS_CCD.value     = 'T';
            form2.target = form2.pageID.value;
            form2.action = "<c:url value='/'/>0001.do";
            form2.submit();
        } /* else if (columnId == "DL_P_AML_CUST_ID" || columnId == "DL_P_NM") {
            var win = window_popup_open(form2, 1000,720, '','no','no');
            form2.pageID.value          = 'AML_30_01_01_01';
            form2.SSPS_DL_CRT_DT.value  = obj.SSPS_DL_CRT_DT;
            form2.clientID.value        = obj.DL_P_AML_CUST_ID;
            form2.cs_nm.value           = obj.DL_P_NM;
            form2.target = 'AML_30_01_01_01_POPUP';
            form2.action = "<c:url value='/'/>0001.do?dis_flag=P";
            form2.submit();
            return;
        } */ else if(columnId == "TRSMT_ST_NM") {
        	if(obj.RPR_PRGRS_CCD == '99' || obj.RPR_PRGRS_CCD == '10' ) {
            	doDownload();
            	form2.XML_FILE.value= obj.SND_RCPT_FILE_NM;
            } else {
                return;
            }
        } else if(columnId == "DL_P_NM" ) { //거래자명
        	form2.pageID.value = 'AML_20_01_01_90'; //STR보고항목미리보기
            window_popup_open(form2.pageID.value, 1000, 880, '','no','no');
            form2.SSPS_DL_CRT_DT.value = obj.SSPS_DL_CRT_DT;
            form2.SSPS_DL_ID.value = obj.SSPS_DL_ID;
            form2.DL_P_AML_CUST_ID.value = obj.DL_P_AML_CUST_ID; //고객관리번호(KEY)
			form2.INDV_CORP_CCD.value = obj.INDV_CORP_CCD;
			form2.cs_nm.value = obj.DL_P_NM;
            form2.BTN_SAVE_F.value = obj.RPR_PRGRS_CCD == "10"?"N":"Y";
            form2.target = form2.pageID.value;
            form2.action = "<c:url value='/'/>0001.do";
            form2.submit();
        } else if (columnId == "FILE_ATT_YN" & obj.FILE_ATT_YN == "Yes") {
			$("input[name=BOARD_ID]").val("STR");	//downtype
            $("input[name=SSPS_DL_CRT_DT]" ).val(obj.SSPS_DL_CRT_DT );
            $("input[name=SSPS_DL_ID]" ).val(obj.SSPS_DL_ID );
            $("input[name=pageID]").val("AML_90_01_03_06");
            $("input[name=classID]").val("AML_20_01_10_03");
            $("input[name=methodID]").val("doFileSearch");
            window_popup_open(form2, 700, 270, '','yes');
            form2.target = "frame_notice";
            form2.action = "<c:url value='/'/>0001.do" ;
            form2.submit();
            return;
        } else {
            return;
        }

    }

	//그리드를 엑셀로 다운로드
    function doDownload() {
    	var vPageUrl = pageUrl.replace(/<(\/span|span)([^>]*)>/gi,"");

    	form2.pageUrl.value = vPageUrl;
    	form2.pageID.value = "AML_00_03_01_01";
    	form2.allFileDown.value="one";
    	window_popup_open(form2.pageID.value, 600, 320, '','yes');
    	form2.target = form2.pageID.value;
    	form2.action = "<c:url value='/'/>0001.do";
    	form2.submit();
    }

	//보고파일 일괄 다운로드
    function doDownloadAll() {
    	var vPageUrl = pageUrl.replace(/<(\/span|span)([^>]*)>/gi,"");

    	form2.pageUrl.value = vPageUrl;
    	form2.pageID.value = "AML_00_03_01_01";
    	form2.allFileDown.value="all";
    	window_popup_open(form2.pageID.value, 600, 300, '','yes');
    	form2.target = form2.pageID.value;
    	form2.action = "<c:url value='/'/>0001.do";
    	form2.submit();
    }
 // 그리드 > 파일 다운로드 사유 등록 팝업후 보고파일 다운로드
    function comletedAction(result) {
		 if(result =="1"){
              form2.GUBUN.value = "S";
              form2.action = "<c:url value='/'/>0001.do?pageID=download_http" ;
              form2.target = 'down_frame1';
              form2.submit();
		 }
	}

    /** File Creation */
    function doSave(gubun){
        if(!isGridSelected(GridObj1)) {
        	showAlert("${msgel.getMsg('AML_20_01_01_01_002','선택된 혐의거래가 없습니다.\\n혐의거래 목록에서 선택 후 처리하세요')}", 'WARN');
            return;
        }
        var selectedRows = GridObj1.getSelectedRowsData();
        var selSize = selectedRows.length;
		var obj = null;

        for(var i = 0; i< selSize; i++) {
			obj = selectedRows[i];
			if ( obj.RPR_PRGRS_CCD == '10' ) {
				showAlert("${msgel.getMsg('AML_20_01_01_01_091','보고완료 된 건은 파일생성 할 수 없습니다.')}", 'WARN');
				return;
			}
		}


        if (gubun == 9) { // Complete
            //if (!confirm('${msgel.getMsg("AML_20_01_02_01_041","파일생성 하시겠습니까?")}')){ return; }
            showConfirm("${msgel.getMsg('AML_20_01_02_01_041','파일생성 하시겠습니까?')}", '${msgel.getMsg("AML_00_00_01_01_025","저장")}',function(){
            	var params = new Object();
        		var methodID = "doWorkFlowProcess";
        		overlay.show(true, true);
        		params.pageID = pageID;
        		params.gubun = gubun; // 9 - v;
        		params.gridData = selectedRows;

        		sendService(classID, methodID, params, doSave_success, doSave_fail);
    		});

        }

    }

    function doSave_success(gridData, param, jsonData){
        try {
   	    	GridObj1.refresh();
   	        GridObj1.option("dataSource",gridData);
	   	     refreshApprovalCount();
		   	  if (param && param.ERRCODE == "00001") {
					showAlert(param.ERRMSG, "ERR");
				}
	         doSearch();
   		} catch (e) {
   	        showAlert(e,'ERR');
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }

    function doSave_fail(){
    	overlay.hide();
    }

    function ccdChange(sel) {
        var selObj = $("#RPR_PRGRS_CCD").val();

        if (selObj =="99"){
        	//20110420 보고정보저장  필요시 OPEN

            GridObj1.columnOption("FIU_NO", 'visible', true);
            GridObj1.columnOption("FIU_REG_DT", 'visible', true);
            $("#Table0").hide();
            $("#sbtn_07").show();
            $("#sbtn_08").show();
        } else if(selObj =="9") {
        	$("#Table0").css("display", "inline-block");
            GridObj1.columnOption("FIU_NO", 'visible', false);
            GridObj1.columnOption("FIU_REG_DT", 'visible', false);
            $("#sbtn_07").hide();
            $("#sbtn_08").hide();
        } else if(selObj =="10") {
        	$("#Table0").hide();
            GridObj1.columnOption("FIU_NO", 'visible', false);
            GridObj1.columnOption("FIU_REG_DT", 'visible', false);
            $("#sbtn_07").show();
            $("#sbtn_08").show();
        } else {
        	$("#Table0").hide();
            GridObj1.columnOption("FIU_NO", 'visible', false);
            GridObj1.columnOption("FIU_REG_DT", 'visible', false);
            $("#sbtn_07").hide();
            $("#sbtn_08").hide();
        }
        doSearch();
    }

    /**
     * 파일 일괄 다운로드
     */
    function allFileSaveCheck() {
    	if(!isGridSelected(GridObj1)){
    		showAlert("${msgel.getMsg('AML_20_01_01_12_014','다운로드할 대상을 선택하십시오.')}", 'WARN');
            return;
        }
    	 var selObj = GridObj1.getSelectedRowsData();

    	if(selObj.length==1){
        	showAlert("${msgel.getMsg('AML_20_01_01_01_058', '선택 된 건 수가 2건 이상일때 일괄다운로드가 가능합니다.')}" , 'WARN');
            return;
        }

        //다운로드 사유 입력
        doDownloadAll();

    }
    function allFileSave() {

    	var comFileArray = "";
        var count = 0;
        var selObj = GridObj1.getSelectedRowsData();

        for(i=0; i< selObj.length; i++){
            obj = selObj[i];
            if(obj.SND_RCPT_FILE_NM != "") {
                comFileArray += obj.SND_RCPT_FILE_NM + ","
                count++;
            }
        }

	    showConfirm("${msgel.getMsg('AML_20_01_01_01_059', '일괄파일다운로드 하시겠습니까? zip파일로 생성됩니다.')}", "일괄다운로드", function(){

			overlay.show(true, true);

			var params = new Object();
			var methodID = "allFileSave";
			params.pageID = pageID;
			params.comFileArray   = comFileArray;

			sendService(classID, methodID, params, allFileSave_success, allFileSave_fail);
		});
    }

    function allFileSave_success(data, param, jsonData) {
        try {
        	allFileSaveEnd();
   		} catch (e) {
   	        showAlert(e,'ERR');
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }

    function allFileSave_fail(){
    	overlay.hide();
    }


    function allFileSaveEnd() {
    	$("[name=pageID]"     ,"form[name=fileFrm]").val(pageID);
    	$("#downFileName"     ,"form[name=fileFrm]").val("STR_XML_FILE.zip");
    	$("#orgFileName"        ,"form[name=fileFrm]").val("STR_XML_FILE.zip");
    	$("#downFilePath"      ,"form[name=fileFrm]").val("STR");
    	$("#downType"          ,"form[name=fileFrm]").val("AML");
    	fileFrm.target = "_self";
    	fileFrm.action = "${ctx}/common/fileDownload.do";
    	fileFrm.method = "post";
    	fileFrm.submit();
    }

	function doReportSave() {

    	var grid1 = $('#GTDataGrid1_Area').dxDataGrid('instance');
        grid1.saveEditData();

        if(!isGridSelected(GridObj1)){
        	showAlert("${msgel.getMsg('AML_20_01_01_01_060', '보고완료할 대상을 선택하십시오.')}" , 'WARN');
            return;
        }

		showConfirm("${msgel.getMsg('AML_20_01_01_01_061', '보고완료 처리 하시겠습니까?')}", '${msgel.getMsg("AML_00_00_01_01_025","저장")}',function(){
			overlay.show(true, true);

			var methodID = "doReportSave";
			var rowsData = GridObj1.getSelectedRowsData();
			var params = new Object();
			params.pageID = pageID;
			params.reportDate   = getDxDateVal("reportDate", true);
			params.gridData = rowsData;

			sendService(classID, methodID, params, doSave_end, doSave_end);
		});

    }

    function makeToolbarButtonGrids(e){

        var cmpnt; cmpnt = e.component;
        var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
        var authC = "${outputAuth.C       }";  // 추가,수정 권한
        var authD = "${outputAuth.D       }";  // 삭제 권한
        if (useYN=="Y") {
            var gridID       = e.element.attr("id");    // 그리드 아이디
            var toolbarItems = e.toolbarOptions.items;
            toolbarItems.splice(0, 0, {
                "locateInMenu"  : "auto"
                ,"location"     : "after"
                ,"widget"       : "dxButton"
                ,"name"         : "filterButton"
                ,"showText"     : "inMenu"
                ,"options"      : {
                         "icon"      : ""
                       	,"elementAttr": { class: "btn-28 filter" }
            			,"text"      : ""
                        ,"hint"      : '필터'
                        ,"disabled"  : false
                        ,"onClick"   : function(){
								setupFilter();
                        }
                 }
            });
        }
    }


    /**
     * FIU Save
     */
    function doFiuSave() {

    	var grid1 = $('#GTDataGrid1_Area').dxDataGrid('instance');
        grid1.saveEditData();


        if(!CheckValue(GridObj1)){
            return;
        }
        if(!isGridSelected(GridObj1)){
            showAlert("${msgel.getMsg('AML_20_01_01_01_060', '보고완료할 대상을 선택하십시오.')}", 'WARN');
            return;
        }

		showConfirm("${msgel.getMsg('AML_20_01_01_01_061', '보고완료 처리 하시겠습니까?')}",'${msgel.getMsg("AML_00_00_01_01_025","저장")}',function(){
			overlay.show(true, true);

			var rowsData = GridObj1.getSelectedRowsData();
	        var params = new Object();
			var methodID = "doFiuSave";
			overlay.show(true, true);
			params.pageID = pageID;
			params.gridData = rowsData;

			sendService(classID, methodID, params, doSave_end, doSave_end);
		});

    }

    function doSave_end(data, param, jsonData) {
		overlay.hide();

		if (param && param.ERRCODE == "00001") {
			showAlert(param.ERRMSG, "ERR");
		}

		doSearch();
	}

    function CheckValue(gObj){
        var selObj = gObj.getSelectedRowsData();
    	for(i=0; i < selObj.length; i++){
            obj = selObj[i];
            if(obj.FIU_NO=="" ||obj.FIU_REG_DT=="") {
            	showAlert("${msgel.getMsg('AML_20_01_01_01_057','KoFIU 등록번호와 등록일은 필수입니다.')}" , 'WARN');
                return false;
            }

            if(obj.RPR_PRGRS_CCD == '10' ) {
            	showAlert("${msgel.getMsg('AML_20_01_01_01_092','보고완료 된 건 입니다.')}" , 'WARN');
                return false;
            }
        }
        return true;
    }

    /** 그리드 셋업 */
    function setupGrids(){
		GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
        dataSource					: dataSource
       ,gridId          				: "GTDataGrid1"
       ,elementAttr: { class: "grid-table-type" }
       ,"width"						:"100%"
       ,"height"						:"calc(85vh - 150px)"
   	   ,"hoverStateEnabled"     : true
   	   ,"wordWrapEnabled"      	: false
   	   ,"allowColumnResizing"   	: true
   	   ,"columnAutoWidth"       : true
   	   ,"allowColumnReordering"	: true
   	   ,"cacheEnabled"          	: false
   	   ,"cellHintEnabled"       	: true
   	   ,"loadPanel"             		: { enabled: false }
   	   ,"showBorders"           	: true
   	   ,"showColumnLines"       : true
   	   ,"showRowLines"          	: true
   	   ,"columnResizingMode"   : "widget" /* "widget" "nextColumn" */
   	   ,"export" 						: {"allowExportSelectedData" : false ,"enabled" : false ,"excelFilterEnabled" : false ,"fileName" : "gridExport"}
   	   ,"sorting"						: {"mode": "multiple"}
   	   ,"editing" 						: {"mode" : "cell" ,"allowUpdating" : false}
   	   ,"remoteOperations" 		: {"filtering" : false ,"grouping"  : false ,"paging"    : false ,"sorting"   : false ,"summary"   : false}
   	   ,"filterRow"             		: {"visible": false}
   	   ,"rowAlternationEnabled" : true
   	   ,"columnFixing"          	: {"enabled": true}
	   ,pager: {
	    	visible: true
	    	,showNavigationButtons: true
	    	,showInfo: true
	    }
	   ,paging: {
	    	enabled : true
	    	,pageSize : 20
	    }
		,scrolling : {
	        mode            : "standard"
	       ,preloadEnabled  : false
	    }
   	   ,"searchPanel" 				: {"visible" : true ,"width": 250}
   	   ,"selection" 					: {"allowSelectAll" : true ,"deferred" : false ,"mode" : "multiple" ,"selectAllMode" : "allPages" ,"showCheckBoxesMode": "always"}
   	   ,"onToolbarPreparing"	: makeToolbarButtonGrids
   	   ,"columns" : [
   		 {"dataField" : "SSPS_DL_ID" 					,"caption" : '${msgel.getMsg("AML_20_01_01_03_003","혐의거래ID")}' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible": false}
 		,{"dataField" : "SSPS_DL_CRT_DT" 			,"caption" : '${msgel.getMsg("AML_20_01_01_01_046","혐의거래일")}' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true , "visible": false}
 		,{"dataField" : "SSPS_DL_CRT_DT_A" 		,"caption": '${msgel.getMsg("AML_20_02_10_01_002","추출일자")}' ,"cssClass" : "link" ,"dataType" : "string" ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible" : true ,"allowEditing"  : false}
 		,{"dataField" : "DL_P_NM"						,"caption" : '${msgel.getMsg("AML_20_01_11_01_102","고객명")}' ,"cssClass" : "link" ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,width: 60}
 		,{"dataField" : "DL_P_AML_CUST_ID" 				,"caption" : '${msgel.getMsg("AML_20_01_02_01_030","고객관리번호")}' ,"alignment" : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible" : true}
 		,{"dataField" : "RNMCNO_VIEW"		,"caption" : '${msgel.getMsg("AML_20_01_01_01_048","실명확인번호")}' ,"alignment" : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false, "visible" : false
    	   			, cellTemplate: function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate_GTONE(cellInfo.text,"RNMCNO")); }}
 		,{"dataField": "DL_P_RNM_NO_CCD_NM"	,"caption" : '${msgel.getMsg("AML_20_01_11_01_104","실명확인구분")}' ,"alignment" : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField" : "DL_P_RNM_NO_CCD" 		,"caption" : '실명확인구분코드' ,"alignment" : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible" : false}
 		,{"dataField" : "SSPS_TYP_CD"				,"caption" : '혐의코드' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible" : false}
 		,{"dataField" : "SSPS_TYP_NM" 				,"caption" : '${msgel.getMsg("AML_20_01_01_03_005","혐의명")}' ,"alignment" : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField" : "RSK_GRD_MRK" 				,"caption" : '${msgel.getMsg("AML_20_01_11_01_112","KYC점수")}' ,"cssClass" : "link" ,"dataType"  : "number" ,"precision" : 4 ,"alignment" : "right" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,width: 60}
 		,{"dataField" : "RSK_GRD_CD" 					,"caption" : '${msgel.getMsg("AML_20_01_11_01_113","KYC등급")}' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible" : false}
 		,{"dataField" : "RSK_GRD_CD_NM" 			,"caption" : '${msgel.getMsg("AML_20_01_11_01_113","KYC등급")}' ,"cssClass" : "green" ,"alignment" : "center"  ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,width: 60}
 		,{"dataField" : "RSK_MRK" 						,"caption" : '${msgel.getMsg("AML_20_01_11_01_115","혐의점수")}' ,"cssClass" : "link" ,"alignment" : "right" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,"visible" : false ,width: 60}
 		,{"dataField" : "RSK_GRD"						,"caption" : '${msgel.getMsg("AML_20_01_11_01_116","혐의등급")}' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"   : false}
 		,{"dataField" : "RSK_GRD_NM" 				,"caption" : '${msgel.getMsg("AML_20_01_11_01_116","혐의등급")}' ,"cssClass"  : "green"  ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,"visible"   : false ,width: 60}
 		,{"dataField" : "RNMCNO" 							,"caption" : '실명확인번호' ,"alignment" : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,"visible"   : false}
 		,{"dataField" : "DL_AMT"						,"caption" : '${msgel.getMsg("AML_20_01_01_08_021","거래금액")}' ,"dataType"  : "number" ,"format"    : "fixedPoint" ,"alignment" : "right" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false ,width: 140}
 		,{"dataField" : "SSPS_DL_CNT"				,"caption" : '지점수' ,"cssClass"      : "link" ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "MN_DL_BRN_CD"				,"caption" : '지점코드' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "MN_DL_BRN_NM"				,"caption" : '지점명' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "RPR_CCD_NM"					,"caption" : '${msgel.getMsg("AML_20_01_01_01_012","진행상태")}' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField": "RPR_COMPLITE_DT"			,"caption": '${msgel.getMsg("AML_20_02_02_01_049","보고일자")}' ,"alignment": "center" ,"dataType" : "string" ,cellTemplate : function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate(cellInfo.text)); }
 				,"allowResizing": true ,"allowSearch": true ,"width": 90 ,"allowSorting": true}
 		,{"dataField" : "RPR_PRGRS_CCD" 			,"caption" : '확인코드' ,"alignment"     : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "RPR_CHRG_P_NM"			,"caption" : '담당자' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "RPR_RSPSB_P_NM" 			,"caption" : '책임자' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"visible"       : false}
 		,{"dataField" : "DOC_NO"						,"caption" : '${msgel.getMsg("AML_20_01_01_01_070","문서번호")}' ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField" : "INDV_CORP_CCD"				,"caption" : '개인법인구분' ,"visible"       : false}
 		,{"dataField" : "TRSMT_ST_NM"				,"caption" : '${msgel.getMsg("AML_20_01_01_01_100","KoFIU보고파일")}' ,"cssClass" : "link" ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField" : "SND_RCPT_FILE_NM" 		,"caption" : 'KoFIU보고파일' ,"visible"       : false}
 		,{"dataField" : "TRSMT_ST_CD"				,"caption" : '파일상태' ,"visible"       : false}
 		,{"dataField" : "J_1"								,"caption" : '지점 의심스러운거래 등급'	,"visible"       : false}
 		,{"dataField" : "J_2"								,"caption" : '지점 의심스러운거래 유형' ,"visible"       : false}
 		,{"dataField" : "B_1"								,"caption" : '본점 의심스러운거래 등급'	,"visible"       : false}
 		,{"dataField" : "B_2"								,"caption" : '본점 의심스러운거래 유형' ,"visible"       : false}
 		,{"dataField" : "CS_TYP_CD"					,"caption" : '고객 유형 코드' ,"visible"       : false}
 		,{"dataField" : "FILE_ATT_YN"					,"caption" : '${msgel.getMsg("AML_20_01_01_01_101","첨부파일")}' ,"cssClass"      : "link" ,"alignment"     : "center" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : false}
 		,{"dataField" : "FIU_NO"							,"caption" : '${msgel.getMsg("AML_20_01_01_01_102","KoFIU 등록번호")}' ,"alignment"     : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : true, "cssClass": "required"}
 		,{"dataField" : "FIU_REG_DT"					,"caption" : '${msgel.getMsg("AML_20_01_01_01_103","KoFIU 등록일")}' ,"alignment"     : "left" ,"allowResizing" : true ,"allowSearch"   : true ,"allowSorting"  : true ,"allowEditing"  : true, "cssClass": "required"}
 		,{"dataField" : "RNMCNO_HIDDEN"			,"caption" : '실명확인번호' ,"visible"       : false}
 		,{"dataField" : "ROW_NUM"						,"dataType"      : "number" ,"visible"       : false}
 		,{"dataField" : "GNL_AC_NO"			,"caption" : '계좌번호' ,"visible"       : false}
   	    ]
//    	    ,"summary": { totalItems: [{column     : "SSPS_DL_CRT_DT_A", summaryType: "count", valueFormat: "fixedPoint"}],
// 			texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
// 		}
   	    ,"onCellClick" : function(e) {
   		    if(e.data ){
   		        Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
   		    }
   	        if (e.component.isRowSelected(e.key)) {
   	           if(e.column.dataField == "FIU_NO"){
   	               e.component.editCell(e.rowIndex,e.columnIndex);
   	           }
   	           if(e.column.dataField == "FIU_REG_DT") {
   	               e.component.editCell(e.rowIndex,e.columnIndex);
   	           }
   	        }
   	    }
   	   ,"onRowInserting" : function(e) {
   	        e.data.ROW_NUM  = e.component.totalCount();
   	    },
	   	onInitialized : function(e) {
	    	doSearch();
	    }
	}).dxDataGrid("instance");

    }
</script>
<!-- 파일 다운로드 -->
<form name="fileFrm" id="fileFrm" method="POST">
<input type="hidden" name="pageID" />
<input type="hidden" name="downFileName" id="downFileName" value="" />
<input type="hidden" name="orgFileName" id="orgFileName" value="" />
<input type="hidden" name="downFilePath" id="downFilePath" value="" />
<input type="hidden" name="downType" id="downType" value="" />
</form>
<form name="form2" id="form2" method="post">
    <input type="hidden" name="pageID"          >
    <input type="hidden" name="classID"         >
    <input type="hidden" name="methodID"        >
    <input type="hidden" name="SSPS_DL_ID"      >   <!-- ${msgel.getMsg('AML_20_01_01_01_045','혐의거래')}ID -->
    <input type="hidden" name="SSPS_DL_CRT_DT"  >   <!-- ${msgel.getMsg('AML_20_01_01_01_046','혐의거래일')} -->
    <input type="hidden" name="DL_P_AML_CUST_ID"     >   <!-- ${msgel.getMsg('AML_20_01_02_01_030','고객관리번호')}  -->
    <input type="hidden" name="clientID"        >
    <input type="hidden" name="KYC_TMS_CCD"     >
    <input type="hidden" name="aml_cust_id"          >   <!-- ${msgel.getMsg('AML_20_01_02_01_030','고객관리번호')} -->
    <input type="hidden" name="RNMCNO"           >   <!-- ${msgel.getMsg('AML_20_01_01_04_003','실명확인번호')} -->
    <input type="hidden" name="cs_nm"           >   <!-- ${msgel.getMsg('AML_20_01_01_01_047','거래자명')} -->
    <input type="hidden" name="GUBUN"           >
    <input type="hidden" name="XML_FILE"        >
    <input type="hidden" name="CS_TYP_CD"       >
    <input type="hidden" name="BOARD_ID"        >
    <input type="hidden" name="BOARD_SEQ"       >
    <input type="hidden" name="FILE_TYPE"       >
    <input type="hidden" name="INDV_CORP_CCD">
	<input type="hidden" name="BTN_SAVE_F" >
	<input type="hidden" name="pageUrl" >
	<input type="hidden" name="allFileDown" >
	<input type="hidden" name="GNL_AC_NO" >
</form>
<!-- Main Body Start -->
<form name="form1" id="form1" method="post">
    <input type="hidden" name="pageID"     />
    <input type="hidden" name="manualID"     />
    <input type="hidden" name="classID"    />
    <input type="hidden" name="methodID"   />
<div class="inquiry-table type1">
    <div class="table-row" style="width: 33%;">
        <div class="table-cell">
            ${condel.getLabel("AML_20_01_01_01_011","추출일자")}
            <div class="content"><div class='calendar'>
            ${condel.getInputDateDx('startDate',startDate)} ~ ${condel.getInputDateDx('endDate',endDate)}
            </div></div>
        </div>
		<div class="table-cell">
            ${condel.getLabel('AML_20_01_11_01_001','거래지점')}
            ${condel.getBranchSearch('branchCode','ALL')}
		</div>
	</div>
    <div class="table-row" style="width: 21%;">
        <div class="table-cell">
           ${condel.getLabel('AML_20_01_01_01_012','진행상태')}
           <div class="content">
             <select name="RPR_PRGRS_CCD" id="RPR_PRGRS_CCD" class="dropdown" onChange='ccdChange(this)'>
                ${condel.getSelectOption('','A029','9','ALL','ALL')}
            </select>
           </div>
        </div>
        <div class="table-cell">
            ${condel.getLabel('AML_20_01_02_01_030','고객관리번호')}
            ${condel.getInputCustomerNo('AML_CUST_ID')}
        </div>
	</div>
	  <div class="table-row" style="width: 46%;">
	   <div class="table-cell">
	   ${condel.getLabel('AML_20_01_01_03_008','고객명')}
	   <div class="content">
          <input name="CS_NM" id="CS_NM" type="text" class="cond-input-text" />
        </div>
          </div>
           <div class="table-cell"></div>
	  </div>
</div>
	<div class="button-area" style="display: flex;justify-content: flex-end;">
            ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}
            ${btnel.getButton(outputAuth, '{btnID:"sbtn_06", cdID:"AML_20_01_01_01_sbtn_06", defaultValue:"파일생성", mode:"C", function:"doSave(9)", cssClass:"btn-36"}')}
            ${btnel.getButton(outputAuth, '{btnID:"sbtn_07", cdID:"fiuSaveBtn", defaultValue:"보고완료", mode:"C", function:"doFiuSave", cssClass:"btn-36"}')}
            ${btnel.getButton(outputAuth, '{btnID:"sbtn_08", cdID:"allReportFileDownBtn", defaultValue:"보고파일일괄다운로드", mode:"C", function:"allFileSaveCheck", cssClass:"btn-36"}')}
            ${btnel.getButton(outputAuth, '{btnID:"sbtn_05", cdID:"RBA010", defaultValue:"다운로드", mode:"C", function:"doDownload", cssClass:"btn-36"}')}
    </div>
<div>
   	<div class="tab-content-bottom" style="margin-top: 8px;">
    	<div id="GTDataGrid1_Area"></div>
    </div>
</div>
<iframe name="down_frame1" width="0" height="0" frameborder="0" marginheight="0" marginwidth="0" scrolling="no"></iframe>
<iframe id='frame_notice' name="frame_notice" frameborder="0" width="0" height="0" scrolling="no" ></iframe>
</form>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_bottom.jsp" flush="true" />
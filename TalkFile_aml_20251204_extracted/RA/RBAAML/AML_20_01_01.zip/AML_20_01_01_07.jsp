<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 계좌상세
*                   STR 口座詳細
*                   STR Account deatiled.
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 1.
* Alteration      : 1. 신규 레이아웃 적용
*                   2. 코드 정리
*                   3. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>
<%@ include file="/WEB-INF/Package/AML/common/notitle_common_top.jsp" %>
<%
	String amlType = jspeed.base.property.PropertyService.getInstance().getProperty("aml.config","amlType");
    String SSPS_DL_ID     = Util.nvl(request.getParameter("SSPS_DL_ID"    ));
    String SSPS_DL_CRT_DT = Util.nvl(request.getParameter("SSPS_DL_CRT_DT"));
    request.setAttribute("SSPS_DL_ID",SSPS_DL_ID);
    request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
    request.setAttribute("amlType",amlType);
%>
<script>
    var GridObj1 = null;
    var GridObj2 = null;
    var new_obj;

    $(document).ready(function(){
    	setupGrids();
    	setupGrids2();
    	setupFilter("init");
    	setupFilter2("init");
    	doSearch();
    	columnHidden();
    });

    function columnHidden(){
    	//보험일 경우 : 대리권범위코드 보이게 처리
    	if(form1.amlType.value == "03"){
    		$("#GTDataGridPopup72_Area").dxDataGrid("columnOption","AGNC_EXTNT_CD_NM","visible", true);
    	}else{
    		$("#GTDataGridPopup72_Area").dxDataGrid("columnOption","AGNC_EXTNT_CD_NM","visible", false);
    	}
    }

    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup71_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_07_001','STR Alerts 계좌상세')}";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }

    function setupFilter2(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup72_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_01_01_07_002','대리인정보')}";
    	gridArrs[1] = gridObj;

    	setupGridFilter2(gridArrs, FLAG);
    }

    function setupGrids() {
        GridObj1 = $("#GTDataGridPopup71_Area").dxDataGrid({
        	gridId            		: "GTDataGrid01",
        	elementAttr: { class: "grid-table-type" },
         	height            		: 'calc(45vh - 50px)',
        	hoverStateEnabled		: true,
            wordWrapEnabled			: false,
            allowColumnResizing		: true,
            columnAutoWidth			: true,
            allowColumnReordering	: true,
            cacheEnabled			: false,
    	    onToolbarPreparing		: makeToolbarButtonGrids,
            cellHintEnabled			: true,
            showBorders				: true,
            showColumnLines			: true,
            showRowLines			: true,
            loadPanel            	: {enabled: false  },
            export 					: {allowExportSelectedData : true ,enabled : true ,excelFilterEnabled : true},
		    onExporting				: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer) {
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_07_001','STR Alerts 계좌상세')}.xlsx");
			        });
			    });
			    e.cancel = true;
            },
            sorting					: {mode: "multiple"},
            remoteOperations		: {
                filtering: false,
                grouping: false,
                paging: false,
                sorting: false,
                summary: false
            },
            filterRow				: {visible: false},
            rowAlternationEnabled	: true,
            columnFixing			: {enabled: true},
            pager: {
       	    	visible: true
       	    	,showNavigationButtons: true
       	    	,showInfo: true
       	    },
       	    paging: {
       	    	enabled : true
       	    	,pageSize : 20
       	    },
    	   	scrolling : {
               mode            : "standard"
              ,preloadEnabled  : false
            },
            searchPanel				: {
                visible: false,
                width: 250
            },
            selection				: {
                allowSelectAll: true,
                deferred: false,
                mode: "none",
                selectAllMode: "allPages",
                showCheckBoxesMode: "onClick"
           },
           columns: [
        	   {dataField: "ACNT_NO"		,caption: '${msgel.getMsg("AML_20_01_01_08_016","계좌번호")}'	,"cssClass" : "link" 	,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true
           	   	,"cellTemplate": function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate_GTONE(cellInfo.text,"ACNT_NO")); }
           	   }
        	   ,{dataField: "CS_NM"			,caption: '고객명'	,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true}
               ,{dataField: "AC_OPN_BRN_NM",		caption: '${msgel.getMsg("AML_20_07_01_01_019","계좌개설지점명")}'			,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true}
               ,{dataField: "MN_DL_DPRT_NM",		caption: '${msgel.getMsg("AML_20_07_01_01_020","주거래지점명")}'						,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true}
        	   ,{dataField: "AC_OPN_BRN_PST_NO",	caption: '${msgel.getMsg("AML_20_01_01_07_104","계좌개설지점우편번호")}'		,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true}
        	   ,{dataField: "AC_OPN_PRXY_F",		caption: '${msgel.getMsg("AML_20_01_01_07_105","계좌개설대리인여부")}'		,alignment: "center",allowResizing: true,allowSearch: true,allowSorting: true}
        	   ,{dataField: "GDS_NO"		,caption: '${msgel.getMsg("AML_20_07_01_01_100","상품번호")}'						,alignment: "center",allowResizing: true,allowSearch: true,allowSorting: true,visible: false}
               ,{dataField: "GNL_AC_NO"		,caption: '${msgel.getMsg("AML_20_01_01_07_100","계좌번호(명)")}'					,alignment: "left",allowResizing: true,allowSearch: true,allowSorting: true,visible: false}
               ,{dataField: "GDS_OPN_BRN_CD",	caption: '${msgel.getMsg("AML_20_01_01_07_102","계좌개설지점코드")}'				,alignment: "center",allowResizing: true,allowSearch: true,allowSorting: true,visible: false}
               ,{dataField: "MN_DL_DPRT_CD",	caption: '${msgel.getMsg("AML_20_01_01_07_103","주거래지점코드")}'				,alignment: "center",allowResizing: true,allowSearch: true,allowSorting: true,visible: false}
               
            ]
//             summary:{
//                        totalItems: [{
//                            column      : 'GNL_AC_NO_VIEW',
//                	        "summaryType": "count",
//             	        "alignment": "center",
//     					"valueFormat": "fixedPoint"
//             	    }],texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
//            }

           ,"onCellClick": function(e){
               if(e.data ){
               	Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
               }
            }
        }).dxDataGrid("instance");
    }

    function setupGrids2() {
		GridObj2 = $("#GTDataGridPopup72_Area").dxDataGrid({
        	gridId            		: "GTDataGrid02",
        	elementAttr: { class: "grid-table-type" },
         	height            		: 'calc(55vh - 50px)',
         	"hoverStateEnabled"		: true,
            "wordWrapEnabled"		: false,
            "allowColumnResizing"	: true,
            "columnAutoWidth"		: true,
            "allowColumnReordering"	: true,
            "cacheEnabled"			: false,
            "cellHintEnabled"		: true,
            "showBorders"			: true,
            "showColumnLines"		: true,
    	    "onToolbarPreparing"	: makeToolbarButtonGrids,
            "showRowLines"			: true,
            loadPanel            	: {enabled: false  },
            export				: {
                "allowExportSelectedData": true,
                "enabled": true,
                "excelFilterEnabled": true
            },
            onExporting				: function (e) {
		    	var workbook = new ExcelJS.Workbook();
		    	var worksheet = workbook.addWorksheet("Sheet1");
			    DevExpress.excelExporter.exportDataGrid({
			        component: e.component,
			        worksheet:worksheet,
			        autoFilterEnabled: true,
			    }).then(function() {
			        workbook.xlsx.writeBuffer().then(function(buffer) {
			            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_01_07_002','대리인정보')}.xlsx");
			        });
			    });
			    e.cancel = true;
            },
            "sorting"				: {"mode": "multiple"},
            "remoteOperations"		: {
                "filtering": false,
                "grouping": false,
                "paging": false,
                "sorting": false,
                "summary": false
            },
            "filterRow"				: {"visible": false},
            "rowAlternationEnabled"	: true,
            "columnFixing"			: {"enabled": true},
            pager: {
       	    	visible: true
       	    	,showNavigationButtons: true
       	    	,showInfo: true
       	    },
       	    paging: {
       	    	enabled : true
       	    	,pageSize : 20
       	    },
    	   	scrolling : {
               mode            : "standard"
              ,preloadEnabled  : false
            },
            "searchPanel"			: {
                "visible": false,
                "width": 250
            },
            "selection"				: {
                "allowSelectAll": true,
                "deferred": false,
                "mode": "none",
                "selectAllMode": "allPages",
                "showCheckBoxesMode": "onClick"
            },
            "columns": [
                {"dataField": "PRXY_NM",				"caption": '${msgel.getMsg("AML_20_07_01_01_023","대리인명")}',		"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "PRXY_GB_NM",				"caption": '${msgel.getMsg("AML_20_01_01_08_134","대리인구분")}',		"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "PRXY_RNM_NO_CCD",		"caption": '${msgel.getMsg("AML_20_01_11_01_104","실명확인구분")}',		"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "PRXY_CS_NO",				"caption": '${msgel.getMsg("AML_20_07_01_01_027","대리인실명번호")}',	"alignment": "center","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "CNTY_NATI_CRYP",			"caption": '${msgel.getMsg("AML_20_07_01_01_028","대리인전화번호")}',	"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "CNTY_AREA_CRYP",			"caption": '${msgel.getMsg("AML_20_07_01_01_028","대리인전화번호")}',	"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "CNTY_ECNO_CRYP",			"caption": '${msgel.getMsg("AML_20_07_01_01_028","대리인전화번호")}',	"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "CNTY_NO_CRYP",			"caption": '${msgel.getMsg("AML_20_07_01_01_028","대리인전화번호")}',	"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "PRXY_NTNLT_NM",			"caption": '${msgel.getMsg("AML_20_07_01_01_029","대리인국적")}',		"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "AC_OWN_P_RLTNS_CD_NM",	"caption": '${msgel.getMsg("AML_20_07_01_01_024","계좌주관계")}',		"alignment": "left","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "AGNC_EXTNT_CD_NM",		"caption": '${msgel.getMsg("AML_20_01_11_01_122","대리권범위코드명")}',		"alignment": "center","allowResizing": "true","allowSearch": "true","allowSorting": "true"},
                {"dataField": "AGNC_EXTNT_CD",		"caption": '${msgel.getMsg("AML_20_01_11_01_122","대리권범위코드명")}', "visible":false},
                {"dataField": "PRXY_RNMCNO_VIEW",		"caption": '${msgel.getMsg("AML_20_07_01_01_027","대리인실명확인번호")}',	"alignment": "center","allowResizing": "true","allowSearch": "true","allowSorting": "true", "visible":false}
                
            ]
//             summary: { totalItems: [{column     : "PRXY_NM", summaryType: "count", valueFormat: "fixedPoint"}],
// 				texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
// 			},
             ,"onCellClick": function(e){
                if(e.data ){
                	Grid2CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, undefined);
                }
             }
        }).dxDataGrid("instance");
	}

    function doSearch() {

        GridObj1.clearSelection();
	    GridObj1.option('dataSource', []);

        var methodID = "doSearch";
        var params   = new Object();
    	params.SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
    	params.SSPS_DL_ID = form1.SSPS_DL_ID.value;
    	params.AML_ID = form1.AML_ID.value;
    	params.AML_USER_NAME = form1.AML_USER_NAME.value;
    	params.AML_ROLE_ID = form1.AML_ROLE_ID.value;
    	params.AML_MASTER_BRANCH = form1.AML_MASTER_BRANCH.value;
    	params.AML_BDPT_CD = form1.AML_BDPT_CD.value;
    	params.AML_TEAM_LEADER_YN = form1.AML_TEAM_LEADER_YN.value;
    	params.AML_TEL_NO = form1.AML_TEL_NO.value;
        sendService("AML_20_01_01_07", "setStrSubPopMain07", params, doSearch_success, doSearch_fail);
    }

    function doSearch_success(gridData, data) {
        new_obj = new Object();
        var methodID = "setStrSubPopSub07";
        var p_frm    = parent.document.form1;
        new_obj.classID  = "AML_20_01_01_07";
        new_obj.methodID = methodID;
        if (gridData.length > 0) {
        	GridObj1.option("dataSource", gridData);
            var obj = gridData[0];
            new_obj.SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
            new_obj.SSPS_DL_ID = form1.SSPS_DL_ID.value;
            new_obj.GNL_AC_NO = obj.GNL_AC_NO;
            new_obj.GDS_NO = obj.GDS_NO;
            
            p_frm.GNL_AC_NO.value = obj.GNL_AC_NO;
            p_frm.ACNT_NO.value = obj.ACNT_NO;
        	
            sendService("AML_20_01_01_07", methodID, new_obj, doSearch2_success, doSearch_fail);
        }
    }

    function makeToolbarButtonGrids(e){

	    var cmpnt; cmpnt = e.component;
	    var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
	    var authC = "${outputAuth.C       }";  // 추가,수정 권한
	    var authD = "${outputAuth.D       }";  // 삭제 권한
	    if (useYN=="Y") {
	        var gridID       = e.element.attr("id");    // 그리드 아이디
	        var toolbarItems = e.toolbarOptions.items;
	        toolbarItems.splice(0, 0, {
	            "locateInMenu"  : "auto"
	            ,"location"     : "after"
	            ,"widget"       : "dxButton"
	            ,"name"         : "filterButton"
	            ,"width" :"100%"
	            ,"showText"     : "inMenu"
	            ,"options"      : {
	                     "icon"      : ""
	                   	,"elementAttr": { class: "btn-28 filter popupFilter" }
	        			,"text"      : ""
	                    ,"hint"      : '필터'
	                    ,"disabled"  : false
	                    ,"onClick"   : function(){
							if(gridID=="GTDataGridPopup71_Area"){
								setupFilter();
							} else if(gridID=="GTDataGridPopup72_Area"){
								setupFilter2();
							} else {}
	                    }
	             }
	        });
	    }
	}



    function doSearch2_success(gridData, data){
        if (gridData.length > 0) {
        	GridObj2.option("dataSource", gridData);
        }
    }

    function doSearch_fail(data){
    }
    /*
	 *	link
	 */
    function Grid1CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId) {
        
    	var new_obj = new Object();
        var methodID = "setStrSubPopSub07"
        var p_frm        = parent.document.form1;
        new_obj.classID = "AML_20_01_01_07";
        new_obj.methodID = methodID;
        if(columnId == 'ACNT_NO'){
        	p_frm.GNL_AC_NO.value = obj.GNL_AC_NO;
            p_frm.ACNT_NO.value = obj.ACNT_NO;
            parent._dvTab(3);
        }else{
            new_obj.SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
            new_obj.SSPS_DL_ID = form1.SSPS_DL_ID.value;
            new_obj.GNL_AC_NO = obj.GNL_AC_NO;
            new_obj.GDS_NO = obj.GDS_NO;
            sendService("AML_20_01_01_07", methodID, new_obj, doSearch2_success, doSearch_fail);
        }
    }
	/*
	 *	detail
	 */
    function Grid2CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId) {
        
    	var new_obj = new Object();
        var methodID = "setStrSubPopSub07"
        var p_frm        = parent.document.form1;
        new_obj.classID = "AML_20_01_01_07";
        new_obj.methodID = methodID;
        if(columnId == 'ACNT_NO'){
        	p_frm.GNL_AC_NO.value = obj.GNL_AC_NO;
            p_frm.ACNT_NO.value = obj.ACNT_NO;
            parent._dvTab(3);
        }else{
            new_obj.SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
            new_obj.SSPS_DL_ID = form1.SSPS_DL_ID.value;
            new_obj.GNL_AC_NO = obj.GNL_AC_NO;
            new_obj.GDS_NO = obj.GDS_NO;
            sendService("AML_20_01_01_07", methodID, new_obj, doSearch2_success, doSearch_fail);
        }
    }
</script>
</head>
<body style="height:50%">
<form name="form1" method=post>
    <input type="hidden" name="pageID"      />
    <input type="hidden" name="classID"     />
    <input type="hidden" name="methodID"    />
    <input type="hidden" name="SSPS_DL_CRT_DT"      value="${SSPS_DL_CRT_DT}"           />
    <input type="hidden" name="SSPS_DL_ID"          value="${SSPS_DL_ID}"               />
    <input type="hidden" name="AML_ID"              value="${ID}"                       />
    <input type="hidden" name="AML_USER_NAME"       value="${USER_NAME}"                />
    <input type="hidden" name="AML_ROLE_ID"         value="${ROLE_ID}"                  />
    <input type="hidden" name="AML_MASTER_BRANCH"   value="${MASTER_BRANCH}"            />
    <input type="hidden" name="AML_BDPT_CD"         value="${BDPT_CD}"                  />
    <input type="hidden" name="AML_TEAM_LEADER_YN"  value="${TEAM_LEADER_YN}"           />
    <input type="hidden" name="AML_TEL_NO"          value="${sessionAML.sAML_TEL_NO}"   />
    <input type="hidden" name="amlType"          value="${amlType}"               />

	<div class="tab-content-bottom" style="margin-top: 8px;">
		<div id="GTDataGridPopup71_Area"></div>
	</div>

	<div class="tab-content-bottom" style="margin-top: 8px;">
		<div id="GTDataGridPopup72_Area"></div>
	</div>

</form>
</body>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
- File Name  : download_http.jsp
- Author     : syk, hikim
- Comment    : STR File Download
- Version    : 1.0
               1.1
- history    : 1.0 2010-09-30
               1.1 2015-05-08 ksy
                   - STR/CTR 보고파일 복호화 내용추가
              2025.10.15 5.0 에서 BASE64로 암호화한 파일 복호화 (7.0버전은 download_http.jsp BASE64 암복호화 합니다.)
                         5.0과 7.0 방식이 서로 달라서 처리방식 분리함
               
--%>
<%@ page import="java.io.*"                         %>
<%@ page import="com.gtone.aml.server.config.*"     %>
<%@ page import="com.gtone.aml.util.SEED"           %>
<%@ page import="com.gtone.aml.basic.common.log.Log"%>
<%@ page   import="com.itplus.common.server.user.SessionHelper" %>
<%@ page   import="com.gtone.aml.user.SessionAML"  %>
<%@ page   import="com.gtone.aml.server.common.commonUtil"  %>
<%
	SessionHelper helper = new  SessionHelper(session);
	SessionAML sessionAML = (SessionAML) Class.forName(commonUtil.getAMLSessionClassName()).getConstructor(new Class[] {HttpServletRequest.class}).newInstance(new Object[] {request});

	String LOGIN_ID = sessionAML.getsAML_LOGIN_ID();
	if(LOGIN_ID == null || "".equals(LOGIN_ID)) {
		out.print("<script>alert('잘못된 접근입니다.');</script>");
		return;
	}
    
	String file_name     = jspeed.base.xml.XMLHelper.normalize(request.getParameter("XML_FILE"));
	if(file_name.indexOf("/")>=0 || file_name.indexOf("\\")>=0)
	{
	    throw new Exception("FILE NAME ERROR");
	}
	
	if(file_name.indexOf("\n")>=0 || file_name.indexOf("\r")>=0)
	{
	    throw new Exception("FILE NAME ERROR");
	}        
	String GUBUN = jspeed.base.xml.XMLHelper.normalize(request.getParameter("GUBUN"));    
	
	String gubunPath = "S".equals(GUBUN)?"str":"ctr";
	
	 
	String Path = SiteServerConfig.getInstance().getApServer_STR_FILE_PATH();
	
	if("ctr".equals(gubunPath) ){
	    Path = SiteServerConfig.getInstance().getApServer_CTR_FILE_PATH();
	}
	
    String Full = Path +gubunPath+"/" + file_name;        
    
    File file = new File(Full);  
    response.setContentType("text/xml"); 
 
    String Agent=request.getHeader("USER-AGENT");
    
    if(Agent.indexOf("MSIE")>=0){
        int i=Agent.indexOf('M',2); 
        String IEV=Agent.substring(i+5,i+8);
        if(IEV.equalsIgnoreCase("5.5")){
               response.setHeader("Content-Disposition", "filename="+new String(file_name.getBytes("utf-8"),"8859_1"));
        }else{
               response.setHeader("Content-Disposition", "attachment;filename="+new String(file_name.getBytes("utf-8"),"8859_1")); 
        }
    } else {
         response.setHeader("Content-Disposition", "attachment;filename="+new String(file_name.getBytes("utf-8"),"8859_1"));
    }
    
    out.clear();
    out=pageContext.pushBody(); 
     
    BufferedInputStream fin = new BufferedInputStream(new FileInputStream(file));  
    BufferedOutputStream outs = new BufferedOutputStream(response.getOutputStream());
    String content=null;
    byte b[] = new byte[5 * 1024 * 1024];  //max=5M byte 
     
    if (file.isFile()) {  
        try { 
             SEED seed = new SEED();
            int read = 0;  
            while ((read = fin.read(b)) != -1){
                content = new String(b,0,read);
           }
            outs.write(seed.decrptCharSet_asis(content, "UTF-8").toString().trim().getBytes("EUC-KR"));
            outs.flush();
            outs.close();  
            fin.close(); 
        } catch(Exception e) {
            Log.logAML(Log.ERROR, e);              
            response.reset();
            response.setContentType("text/html;charset=utf-8");
            out.println("<script language='javascript'>");
            out.println("alert('No Data File...');");
            out.println("</script>");
        } finally {
          if(outs != null) outs.close();
          if(fin  != null) fin.close();
        }
    }

%>


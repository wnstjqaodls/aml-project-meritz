<%@ page language="java" contentType="text/html; charset=utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 고객 검색
*                   Code Popup Search
* Author          :
* Since           : 2019. 06. 12.
********************************************************************************************************************************************
--%>
<%
	String paramCode   = Util.nvl(request.getParameter("paramCode"));
	String paramViewSave   = Util.nvl(request.getParameter("paramViewSave"));
	String paramGubn   = Util.nvl(request.getParameter("paramGubn"));

	request.setAttribute("paramCode",paramCode);
	request.setAttribute("paramViewSave",paramViewSave);
	request.setAttribute("paramGubn",paramGubn);
%>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp"           %>
<script>
    var GridObj1 = null;
    var overlay = new Overlay();

    // [ Initialize ]
    $(document).ready(function(){
        setupEvents();
        setupGrids();
        $(".cond-row").css("visibility","visible");
        $("input[name=SCH_VAL]").focus();
    });

    /** 검색조건 셋업 */
    function setupEvents()
    {
        $("input[name=SCH_VAL]").keyup(function(e){
            if (e.which==13) doSearch();
        });
    }

    function setupGrids()
    {
        GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
        	"gridId"          				: "GTDataGrid1"
            	,"height"						:"calc(80vh - 180px)"
            		,"elementAttr": { class: "grid-table-type" }
            		,"allowColumnReordering": true
            		   ,"allowColumnResizing"  : true
            		   ,columnResizingMode : 'widget'
            		   ,"cacheEnabled"         : false
            		   ,"cellHintEnabled"      : true
            		   ,"columnAutoWidth"      : true
            		   ,"columnFixing" : {"enabled": true}
            		   ,"export" 					: {allowExportSelectedData : false ,enabled : false ,excelFilterEnabled : false}
            		   ,"filterRow" : {"visible": false}
            		   ,"hoverStateEnabled"     : true
            		   ,"loadPanel"             : {"enabled": false}
            		   ,"paging"                : {"enabled": false}
            		   ,"remoteOperations"      : {
            		        "filtering" : false
            		       ,"grouping"  : false
            		       ,"paging"    : false
            		       ,"sorting"   : false
            		       ,"summary"   : false
            		    }
            		   ,"rowAlternationEnabled" : true
            		   ,"searchPanel"           : {
            		        "visible" : false
            		       ,"width"   : 250
            		    }
            		   ,"selection"             : {
            		        "allowSelectAll"    : true
            		       ,"deferred"          : false
            		       ,"mode"              : "single"
            		       ,"selectAllMode"     : "allPages"
            		       ,"showCheckBoxesMode": "always"
            		    }
            		   ,"scrolling"             : { mode: "virtual" }
            		   ,"showBorders"           : true
            		   ,"showColumnLines"       : true
            		   ,"showRowLines"          : true
            		   ,"sorting"               : {"mode": "multiple"}
            		   ,"width"                 : "inherit"
            		   ,"wordWrapEnabled"       : false
            		   ,"summary": {
            		        "totalItems": [{
            		            "column"       : "CS_NM"
            		           ,"summaryType"  : "count"
            		        }]
            		    }
            		   ,"columns" : [
            		        {"dataField": "CS_NM",				"caption": '${msgel.getMsg("AML_20_01_11_01_102","고객명")}',		"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 120},
            		        {"dataField": "RNMCNO",				"caption": '${msgel.getMsg("AML_21_01_01_01_106","고객번호")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 90},
            		        {"dataField": "INDV_CORP_CCD_NM",	"caption": '${msgel.getMsg("AML_20_01_01_30_001","고객구분")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 80},
            		        {"dataField": "RNM_CNFR_CCD_NM",	"caption": '${msgel.getMsg("AML_20_07_01_01_025","실명확인구분")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 120},
            		        {"dataField": "AML_CUST_ID",				"caption": '${msgel.getMsg("AML_21_01_02_01_100","실명확인번호")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 130},
            		        {"dataField": "RNM_CNFR_CCD",		"caption": 'RNM_CNFR_CCD',										"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 10,"visible": false },
            		        {"dataField": "NTN_CD",				"caption": '${msgel.getMsg("AML_20_01_01_30_002","국적코드")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true},
            		        {"dataField": "NTN_NM",				"caption": 'NTN_NM',											"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 10,"visible": false},
            		        {"dataField": "RNMCNO",				"caption": 'RNMCNO',												"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true,"width": 10,"visible": false }
            		    ]
            		   ,"onCellClick" : function(e) {
            		        if (e.data) {

            		        }
            		    }
            }).dxDataGrid("instance");
    }

    function closeCancel() { self.close(); }

    function doSelectData()
    {
        var selectedItem = GridObj1.getSelectedRowsData()[0];
        if( selectedItem == null || selectedItem == "" || selectedItem == undefined) {
			showAlert("${msgel.getMsg('adm.message.no.select','선택된 항목이 없습니다.')}","WARN");
			return;
		}
        if (selectedItem && selectedItem.CS_NM && opener['${param.FUNC_NM}']) {
            opener['${param.FUNC_NM}']({'GUBUN':'${paramGubn}','CS_NM':selectedItem.CS_NM,'RNM_CNFR_CCD':selectedItem.RNM_CNFR_CCD,'RNMCNO':selectedItem.RNMCNO
            						   ,'AML_CUST_ID':selectedItem.AML_CUST_ID,'NTN_CD':selectedItem.NTN_CD,'NTN_NM':selectedItem.NTN_NM});
            self.close();
        }
    }

    function doSearch()
    {

    	var vSCH_GUBN = $("#SCH_GUBN").val();
    	var vSCH_VAL = $("input[name=SCH_VAL]").val();
    	var vGNL_AC_NO = "";
    	var vAML_CUST_ID = "";
    	var vRNMCNO = "";
    	var vCS_NM = "";

    	if(vSCH_VAL == ""){
			showAlert('<fmt:message key="AML_90_01_03_01_001" initVal="검색어를 입력하세요."/>',"WARN");
			return;
		}

    	if(vSCH_GUBN == 'GNL_AC_NO'){
    		vGNL_AC_NO = vSCH_VAL;
		}else if(vSCH_GUBN == 'AML_CUST_ID'){
			vAML_CUST_ID = vSCH_VAL;
		}else if(vSCH_GUBN == 'RNMCNO'){
			vRNMCNO = vSCH_VAL;
		}else if(vSCH_GUBN == 'CS_NM'){
			vCS_NM = vSCH_VAL;
		}

    	overlay.show(true, true);
    	GridObj1.clearSelection();
	    GridObj1.option('dataSource', []);
            var actionParam  = {
                "pageID"    : "AML_20_01_01_31"
               ,"classID"   : "AML_20_01_01_30"
               ,"methodID"  : "doSearchCustList"
               ,"GNL_AC_NO" : vGNL_AC_NO
               ,"AML_CUST_ID" 	: vAML_CUST_ID
               ,"RNMCNO" 	: vRNMCNO
               ,"CS_NM" 	: vCS_NM
            }
        sendService(actionParam.classID, actionParam.methodID, actionParam, doSearch_success, doSearch_fail);
    }

    function doSearch_success(gridData, data){
    	overlay.hide();
    	GridObj1.option("dataSource", gridData);

		$("input[name=SCH_VAL]").focus();

		return;
    }

    function doSearch_fail(data){
    	overlay.hide();
    }

</script>
<form name="form1" onSubmit="return false;" onkeydown="doEnterEvent('doSearch');">
     <div class="inquiry-table">
        <div class="table-row" >
            <div class="table-cell">
            	<select name='SCH_GUBN' id='SCH_GUBN' class="dropdown" style="width:40%;">
                	<option class="dropdown-option" value='GNL_AC_NO' selected>${msgel.getMsg('AML_20_01_01_08_016','계좌번호')}</option>
					<option class="dropdown-option" value='RNMCNO'>${msgel.getMsg('AML_20_02_02_90_124','고객번호')}</option>
					<option class="dropdown-option" value='AML_CUST_ID'>${msgel.getMsg('AML_20_01_02_01_020','실명확인번호')}</option>
					<option class="dropdown-option" value='CS_NM'>${msgel.getMsg('AML_20_01_01_03_008','고객명')}</option>
				</select>
				<input name="SCH_VAL" type="text" class="cond-input-text" maxlength="20" style="width:150">
            </div>
        </div>
    </div>
     <div class="btn-area" style="float:right;margin-top:10px;margin-right:10px;">
    ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}
    </div>
    <div class="tab-content-bottom">
        <div class="row"></div>
        <div id="GTDataGrid1_Area"></div>
    </div>
     <div class="btn-area" style="float:right;margin-top:10px;margin-right:10px;">
        ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"selBtn", defaultValue:"선택", mode:"R", function:"doSelectData", cssClass:"btn-36"}')}
        ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"closeCancel", cssClass:"btn-36"}')}
    </div>
</form>
<%@ include file="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" %>
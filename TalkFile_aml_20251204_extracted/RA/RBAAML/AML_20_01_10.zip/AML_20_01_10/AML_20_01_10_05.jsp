<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%> 
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 첨부파일저장
*                   添付ファイル
*                   Attached File Save
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2011. 4. 11.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
********************************************************************************************************************************************
* Modifier        : 송지윤
* Update          : 2017. 7. 24.
* Alteration      : 1. 코드 정리
*                   2. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>
<%@ page import="com.gtone.aml.basic.common.data.DataObj" %>
<%@ page import="com.gtone.aml.basic.common.util.*"  %>
<%@ page import="com.gtone.aml.user.SessionAMLUtil" %>
<%@ page import="jspeed.base.http.MultipartRequest" %>
<%@ page import="jspeed.base.property.PropertyService" %>
<%@ page import="com.gtone.express.server.helper.MessageHelper" %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03"  %>
<%
	DataObj output;
    String LANG_CD 	 = Util.getLangCD( pageContext.getRequest().getLocale().toString() ); // 언어 정의 변수
    //FILE_GUBUN=STR
	String uploadfile = PropertyService.getInstance().getProperty("aml.config","upload.file");
	String fileChk = "N";
	String fileExt = ""; 
	String fileExt1 = "";
	
	String FILE_GUBUN   = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("FILE_GUBUN")));
	
	String ERRCODE = "00000"; // 정상처리 인경우 
	String ERRMSG  = MessageHelper.getInstance().getMessage("0002",LANG_CD,"정상 처리되었습니다.");
	String WINMSG  = MessageHelper.getInstance().getMessage("0002",LANG_CD,"정상 처리되었습니다.");
	
	SessionAMLUtil amlUtil = new SessionAMLUtil();
	
	int uploadFileSize = 50 * 1024 * 1024; // 50M (Max)
	MultipartRequest req = null;
	
	try {
		
		String [] filestr;
		req = new MultipartRequest(request, uploadFileSize);
		String masterBranch =  req.getParameter("MASTER_BRANCH");

		if ("Y".equals(masterBranch)) { 
			filestr = req.getParameterValues("NOTI_ATTACH_M");
		} else {
			filestr = req.getParameterValues("NOTI_ATTACH");
		}
		
		for(int i = 0; i < filestr.length; i++) {
			fileChk = "N";
			if( filestr[i].equals("") ) {
				//fileExt = filestr[i].substring(filestr[i].length() - 3, filestr[i].length());
				fileChk = "Y";
			} else {
				//fileChk = "Y";
				fileExt = filestr[i].substring(filestr[i].length() - 3, filestr[i].length());
			}
			fileExt = fileExt.toLowerCase();

			if( filestr[i].equals("") ) {
				fileChk = "Y";
				//fileExt1 = filestr[i].substring(filestr[i].length() - 4, filestr[i].length());
			} else {
				//fileChk = "Y";
				fileExt1 = filestr[i].substring(filestr[i].length() - 4, filestr[i].length());
			}
			fileExt1 = fileExt1.toLowerCase();
			
					
			if(amlUtil.check(fileExt,uploadfile)) {fileChk =  "Y";}
			if(amlUtil.check(fileExt1,uploadfile)) {fileChk =  "Y";}
			
			
			if(filestr[i].indexOf("\n")>=0 || filestr[i].indexOf("\r")>=0)
			{
				ERRCODE = "00099";
				ERRMSG  = MessageHelper.getInstance().getMessage("0053",LANG_CD,"첨부된 파일정보를 확인하십시요.") + uploadfile;
				WINMSG  = MessageHelper.getInstance().getMessage("0053",LANG_CD,"첨부된 파일정보를 확인하십시요.") + uploadfile;
				break;
			}			
			
			if(	!"Y".endsWith(fileChk)) 
			{
				ERRCODE = "00099";
				ERRMSG  = MessageHelper.getInstance().getMessage("0054",LANG_CD,"업로드 할 수  없는 타입의 파일입니다.") + uploadfile;
				WINMSG  = MessageHelper.getInstance().getMessage("0054",LANG_CD,"업로드 할 수  없는 타입의 파일입니다.") + uploadfile;
				break;
			}
						
						
		}	

		if("00000".equals(ERRCODE)  ) {
			
			output = new DataObj();
			

			output = AML_20_01_10_03.getInstance().dofileSave(req);  

			
			
			ERRCODE = Util.nvlTrim(output.getText("ERRCODE"),"");
			ERRMSG  = Util.nvlTrim(output.getText("ERRMSG"),"");
			WINMSG  = Util.nvlTrim(output.getText("WINMSG"),"");
		}		
		
	} catch(RuntimeException e){
		ERRCODE = "00099";		
		ERRMSG  = MessageHelper.getInstance().getMessage("0005",LANG_CD,"처리중 오류가 발생하였습니다.");  //20141030 hikim
		WINMSG  = MessageHelper.getInstance().getMessage("0005",LANG_CD,"처리중 오류가 발생하였습니다.");	
	} catch(Exception e){
		ERRCODE = "00099";		
		ERRMSG  = MessageHelper.getInstance().getMessage("0005",LANG_CD,"처리중 오류가 발생하였습니다.");  //20141030 hikim
		WINMSG  = MessageHelper.getInstance().getMessage("0005",LANG_CD,"처리중 오류가 발생하였습니다.");	
		
	}

	out.println("<script>");
	
	StringBuffer strMsg = new StringBuffer(126);
	strMsg.append("alert('");
	strMsg.append(WINMSG);
	strMsg.append("');");
	
	if("00000".equals(ERRCODE)) {
		if ("STR".equals(FILE_GUBUN)){
			out.println("parent.doSave();");
		}
		else if  ("CTR".equals(FILE_GUBUN)) {
			out.println(strMsg.toString());
			//out.println("alert('"+WINMSG+"');");
			out.println("parent.doSave_end();");
		}
	} else {
		out.println(strMsg.toString());
		//out.println("alert('"+WINMSG+"');");
	}
	out.println("</script>");

%>
<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 고객알기상세
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : ?
* Since           : ?
********************************************************************************************************************************************
* Modifier        : 민경진
* Update          : 2017. 5. 15.
* Alteration      : 1. 그디드에 devextreme 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 8.
* Alteration      : 1. 신규 레이아웃 적용, 코드 정리
*                   2. HTML5, Any Browser 적용
********************************************************************************************************************************************
--%>
<style>
.inquiry-table2 .table-cell .title {
    width: 130px; 
}
</style>
 
<!-- 고객알기상세  [ -->
<div style="width:100%">
	<div class="row">
       <h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_601','기본정보')}</h4>
    </div>
</div>
<!-- 고객알기상세  [ -->
    <div class="inquiry-table2 rowtype">
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_602", "고객명")}</div>
                <div class="content">${output.CS_NM}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_603", "영문고객명")}</div>
                <div class="content">${output.ENG_CS_NM}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_604", "실명구분")}</div>
                <div class="content">${output.RNM_CNFR_CCD}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_605", "실명번호")}</div>
                <div class="content">${output.CS_NO_VIEW} [${output.RNMCNO}]</div>
            </div>
        </div>
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg('AML_20_01_10_03_606', '소속국가')}</div>
                <div class="content">${output.NTN_CD}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_607", "거주국가")}</div>
                <div class="content">${output.RSDNC_PLC_NTN_CD}</div>
            </div>
       <%if(INDV_CORP_CCD.equals("1")) { %>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_608", "생년월일")}</div>
                <div class="content">${output.BRTDY}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_609", "성별")}</div>
                <div class="content">${output.GENDER}</div>
           </div>
       <%}else{ %>
       		<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_10_06_01_01_011", "법인구분")}</div>
                <div class="content">${output.INSN_SECT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_10_06_01_01_111", "설립일자")}</div>
                <div class="content">${output.FNDTN_DT}</div>
           </div>
       <%} %>
        </div>
        <!-- 3) -->
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_610", "당사고객여부")}</div>
                <div class="content">${output.SS_CLNT_YN}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg('AML_20_01_10_03_611', '고객상태')}</div>
                <div class="content">${output.CS_ST_CD}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg('AML_20_01_10_03_612', '고객등록일자')}</div>
                <div class="content">${output.CS_RGST_DT}</div>
            </div>
		<%if(INDV_CORP_CCD.equals("1")) { %>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_613", "연령")}</div>
                <div class="content">${output.AGE}</div>
           </div>
        <%}else{ %>
           <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_628", "사업체존속기간")}</div>
                <div class="content">${output.ENTY_AGE}</div>
           </div>
        <%} %>
        </div>
        <!-- 4) -->
        <div class="table-row">

            <div class="table-cell row2">
            <%if(INDV_CORP_CCD.equals("1")) { %>
                <div class="title">${msgel.getMsg("AML_20_01_10_03_614", "직업")}</div>
                <div class="content">${output.JOB_NAME}</div>
            <%}else{ %>
                <div class="title">${msgel.getMsg("AML_20_01_10_03_630", "업종")}</div>
                <div class="content">${output.STND_INDY_CLSN_NAME}</div>
            <%} %>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_629", "E-mail")}</div>
                <div class="content">
                <%
				String mailId = (output.getText("EMAIL_ID")).replace(" ", "");
               	String mailHN = (output.getText("EMAIL_HOST_NAME")).replace(" ", "");
               	if(!"".equals(mailId) && !"".equals(mailHN)){
               	%>
                	${output.EMAIL_ID}@${output.EMAIL_HOST_NAME}
				<%
               	}
               	%>
                </div>
            </div>
        </div>
<%if(INDV_CORP_CCD.equals("1")) { %>
        <div class="table-row">
            <div class="table-cell row3" >
                <div class="title">${msgel.getMsg("AML_20_01_10_03_615", "자택주소")}</div>
                <div class="content">
                <%
               	String adr10 = (output.getText("ADDR_PS_BSC")).replace(" ", "");
               	String adr11 = (output.getText("ADDR_PS_DTL")).replace(" ", "");
               	if(!"".equals(adr10) || !"".equals(adr11)){
               	%>
                	[${output.ADDR_PS_PST_NO}] ${output.ADDR_PS_BSC} ${output.ADDR_PS_DTL}
               	<%
               	}
               	%>
                </div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_616", "자택전화번호")}</div>
                <div class="content">
                <%
               	String tel10 = (output.getText("TEL1_0_CRYP")).replace(" ", "");
               	String tel11 = (output.getText("TEL1_1_CRYP")).replace(" ", "");
               	if(!"".equals(tel10) && !"".equals(tel11)){
               	%>
                	${output.TEL1_0_CRYP}-${output.TEL1_1_CRYP}-${output.TEL1_2_CRYP}-${output.TEL1_3_CRYP}
               	<%
               	}else if("".equals(tel10) && !"".equals(tel11)){
                %>
                	${output.TEL1_1_CRYP}-${output.TEL1_2_CRYP}-${output.TEL1_3_CRYP}
               	<%
               	}
               	%>
                </div>
            </div>

        </div>
        <!-- 6) -->
        <div class="table-row">
            <div class="table-cell row3">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_617", "직장주소")}</div>
                <div class="content">
                <%
               	String adr20 = (output.getText("ADDR_OF_BSC")).replace(" ", "");
               	String adr21 = (output.getText("ADDR_OF_DTL")).replace(" ", "");
               	if(!"".equals(adr20) || !"".equals(adr21)){
               	%>
                	[${output.ADDR_OF_PST_NO}] ${output.ADDR_OF_BSC} ${output.ADDR_OF_DTL}
               	<%
               	}
               	%>
                </div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_618", "직장전화번호")}</div>
                <div class="content">
                <%
               	String tel20 = (output.getText("TEL2_0_CRYP")).replace(" ", "");
               	String tel21 = (output.getText("TEL2_1_CRYP")).replace(" ", "");
               	if(!"".equals(tel20) && !"".equals(tel21)){
               	%>
                	${output.TEL2_0_CRYP}-${output.TEL2_1_CRYP}-${output.TEL2_2_CRYP}-${output.TEL2_3_CRYP}
               	<%
               	}else if("".equals(tel20) && !"".equals(tel21)){
                %>
                	${output.TEL2_1_CRYP}-${output.TEL2_2_CRYP}-${output.TEL2_3_CRYP}
               	<%
               	}
               	%>
                </div>
            </div>

        </div>
<% }else{ %>
		<div class="table-row">
            <div class="table-cell row3">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_631", "본점주소")}</div>
                <div class="content">
                <%
               	String adr30 = (output.getText("ADDR_PS_BSC")).replace(" ", "");
               	String adr31 = (output.getText("ADDR_PS_DTL")).replace(" ", "");
               	if(!"".equals(adr30) || !"".equals(adr31)){
               	%>
                	[${output.ADDR_PS_PST_NO}] ${output.ADDR_PS_BSC} ${output.ADDR_PS_DTL}
               	<%
               	}
               	%>
                </div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_632", "본점전화번호")}</div>
                <div class="content">
                <%
               	String tel30 = (output.getText("TEL1_0_CRYP")).replace(" ", "");
               	String tel31 = (output.getText("TEL1_1_CRYP")).replace(" ", "");
               	if(!"".equals(tel30) && !"".equals(tel31)){
               	%>
                	${output.TEL1_0_CRYP}-${output.TEL1_1_CRYP}-${output.TEL1_2_CRYP}-${output.TEL1_3_CRYP}
               	<%
               	}else if("".equals(tel30) && !"".equals(tel31)){
                %>
                	${output.TEL1_1_CRYP}-${output.TEL1_2_CRYP}-${output.TEL1_3_CRYP}
               	<%
               	}
               	%>
                </div>
            </div>

        </div>
        <div class="table-row">
            <div class="table-cell row3">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_633", "사업장주소")}</div>
                <div class="content">
                <%
               	String adr40 = (output.getText("ADDR_OF_BSC")).replace(" ", "");
               	String adr41 = (output.getText("ADDR_OF_DTL")).replace(" ", "");
               	if(!"".equals(adr40) || !"".equals(adr41)){
               	%>
                	[${output.ADDR_OF_PST_NO}] ${output.ADDR_OF_BSC} ${output.ADDR_OF_DTL}
               	<%
               	}
               	%>
                </div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_634", "사업장전화번호")}</div>
                <div class="content">
                <%
               	String tel40 = (output.getText("TEL2_0_CRYP")).replace(" ", "");
               	String tel41 = (output.getText("TEL2_1_CRYP")).replace(" ", "");
               	if(!"".equals(tel40) && !"".equals(tel41)){
               	%>
                	${output.TEL2_0_CRYP}-${output.TEL2_1_CRYP}-${output.TEL2_2_CRYP}-${output.TEL2_3_CRYP}
               	<%
               	}else if("".equals(tel40) && !"".equals(tel41)){
                %>
                	${output.TEL2_1_CRYP}-${output.TEL2_2_CRYP}-${output.TEL2_3_CRYP}
               	<%
               	}
               	%>
                </div>
            </div>

        </div>
<% } %>
		<!-- 7) -->
		<div class="table-row">
   				<div class="table-cell">
   					<div class="title">${msgel.getMsg('AML_20_01_10_03_636','계좌수(정상)')}</div>
   					<div class="content">${output.ACNT_AC_CNT}</div>
   				</div>
   				<div class="table-cell">
   					<div class="title" >${msgel.getMsg('AML_20_01_10_03_637','계좌수(전체)')}</div>
   					<div class="content">${output.ACNT_TOT}</div>
   				</div>
   				<div class="table-cell row2">
   					<div class="title" >${msgel.getMsg('AML_20_01_10_03_622','휴대전화번호')}</div>
   					<div class="content">
   					<%
               	String mob0 = (output.getText("MOB_0_CRYP")).replace(" ", "");
               	String mob1 = (output.getText("MOB_1_CRYP")).replace(" ", "");
               	if(!"".equals(mob0) && !"".equals(mob1)){
               	%>
                	${output.MOB_0_CRYP}-${output.MOB_1_CRYP}-${output.MOB_2_CRYP}-${output.MOB_3_CRYP}
               	<%
               	}else if("".equals(mob0) && !"".equals(mob1)){
                %>
                	${output.MOB_1_CRYP}-${output.MOB_2_CRYP}-${output.MOB_3_CRYP}
               	<%
               	}
               	%>
   					</div>
   				</div>
   		</div>
		<div class="table-row"> 
   				<div class="table-cell">
   					<div class="title" rowspan="2">${msgel.getMsg('AML_10_06_01_01_118','최초계좌개설')}일</div>
   					<div class="content">${output.FIRST_OPNG_DATE}</div> 
   					
   				</div>
   				<div class="table-cell" >
   					<div class="title"  rowspan="2">${msgel.getMsg('AML_10_06_01_01_119','최종계좌개설')}일</div>
   					<div class="content">${output.LAST_OPNG_DATE}</div>  
   					
   				</div>
   				<div class="table-cell row2">
   					<%if(INDV_CORP_CCD.equals("1")) { %>
   					<div class="title">${msgel.getMsg('AML_20_01_10_03_623','고액자산가여부')}</div>
   					<div class="content">${output.LG_AMT_ASTS_F}</div>
   					<%}else{ %>
   					<div class="title">${msgel.getMsg('AML_20_01_10_03_635','작성자')}</div>
   					<div class="content">${output.WRIT_NAME}</div>
   					<%} %>
				</div>
		</div>
		
		<div class="table-row"> 
   				<div class="table-cell"> 
   					<div class="title" rowspan="2">${msgel.getMsg('AML_10_06_01_01_118','최초계좌개설')}(지점)</div> 
   					<div class="content">${output.FIRST_DTBR_NAME}</div>
   				</div>
   				
   				<div class="table-cell"> 
   					<div class="title"  rowspan="2">${msgel.getMsg('AML_10_06_01_01_119','최종계좌개설')}(지점)</div> 
   					<div class="content">${output.LAST_DTBR_NAME}</div>
   				</div>
   				<div class="table-cell row2">
   					 
				</div>
		</div>
		<div class="table-row">
            <div class="table-cell row2">
                <div class="title" >${msgel.getMsg("AML_20_01_10_03_624", "고객관리점")}</div>
                <div class="content">${output.MGR_MD_DTBR}</div>
            </div>
            <div class="table-cell row2">
                <div class="title" >${msgel.getMsg("AML_20_01_10_03_625", "고객관리자")}</div>
                <div class="content">${output.MGR_MU_EMPY}</div>
            </div>

        </div>

    </div>


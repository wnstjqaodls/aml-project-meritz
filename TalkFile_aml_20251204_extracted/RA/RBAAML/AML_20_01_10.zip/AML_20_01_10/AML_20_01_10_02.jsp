<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 혐의점수 이력 조회
*                   嫌疑点数履歴照会
*                   Suspicious Score Hist. View
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 송지윤
* Update          : 2017. 9. 18.
* Alteration      : 1. 코드 정리
*                   2. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2018. 4. 23.
* Alteration      : AML() 함수제거, 코드정리
********************************************************************************************************************************************
--%>
<%
	String KYC_TMS_CCD     = request.getParameter("KYC_TMS_CCD"    );
	String SSPS_DL_CRT_DT  = request.getParameter("SSPS_DL_CRT_DT" );
	String SSPS_DL_ID      = request.getParameter("SSPS_DL_ID"     );
    String locAML_CUST_ID          = request.getParameter("locAML_CUST_ID"         );
    String CS_TYP_CD       = request.getParameter("CS_TYP_CD"      );
    request.setAttribute("KYC_TMS_CCD"      ,KYC_TMS_CCD    );
    request.setAttribute("SSPS_DL_CRT_DT"   ,SSPS_DL_CRT_DT );
    request.setAttribute("SSPS_DL_ID"       ,SSPS_DL_ID     );
    request.setAttribute("aml_cust_id"           ,locAML_CUST_ID         );
    request.setAttribute("CS_TYP_CD"        ,CS_TYP_CD      );
%>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" /> 
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %> 
<script>
    var GridObj1 = null;
    var GridObj2 = null;
    var GridObj3 = null;
    var overlay = new Overlay();
    var dataSource = [];
	var dataSource2 = [];
	var dataSource3 = [];
	
    $(document).ready( function() {
    	setupGrids();
    	setupGrids2();
    	doSearch();
    });
	
    function setupGrids(){
    	GridObj1 = $("#GTDataGrid0_Area").dxDataGrid({dataSource : dataSource3,gridId : "GTDataGrid0"}).dxDataGrid("instance");
    	GridObj2 = $("#GTDataGrid1_Area").dxDataGrid({
        	dataSource 					: dataSource,
        	gridId 						: "GTDataGrid1",	
        	height : 'calc(73vh - 250px)',
    	    "hoverStateEnabled"			: true,
    	    "wordWrapEnabled"			: false,
    	    "allowColumnResizing"		: true,
    	    "columnAutoWidth"			: true,
    	    "allowColumnReordering"		: true,
    	    "cacheEnabled"				: false,
    	    "cellHintEnabled"			: true,
    	    "showBorders"				: true,
    	    "showColumnLines"			: true,
    	    "showRowLines"				: true,
    	    "export"					: {"allowExportSelectedData": true,  "enabled": false, "excelFilterEnabled": true, "fileName": "gridExport"},
    	    "sorting"					: {"mode": "multiple"},
    	    remoteOperations 			: {filtering:false, grouping:false, paging:false, sorting:false, summary:false},
    	    editing						: { mode: 'batch', allowUpdating: false, allowAdding : false, "allowDeleting": false},
    	    "filterRow"					: {"visible": false},
    	    "rowAlternationEnabled"		: true,
    	    "columnFixing"				: {"enabled": true},
    	    pager: {
    	    	visible: true
    	    	,showNavigationButtons: true
    	    	,showInfo: true
    	    },
    	    paging: {
    	    	enabled : true
    	    	,pageSize : 20
    	    },
	 	   	scrolling : {
	            mode            : "standard"
	           ,preloadEnabled  : false
	        },
    	    "searchPanel"				: {"visible": false, "width": 250},
    	    "selection"					: {allowSelectAll : true, deferred : false, mode : 'single', selectAllMode : 'allPages', showCheckBoxesMode : 'onClick'},
//     	    "summary" :{totalItems: [{column: 'SCNR_MRK', summaryType: 'count', valueFormat: "fixedPoint"}],
// 				texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
    	    "columns": [
    	    	{"dataField": "SCNR_MRK", 			"caption": '${msgel.getMsg("AML_20_01_10_01_114","시나리오점수")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "SCNR_WGHTS", 		"caption": '${msgel.getMsg("AML_20_01_10_01_104","시나리오가중치")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
                {"dataField": "EXCH_MRK", 			"caption": '${msgel.getMsg("AML_20_01_10_01_105","시나리오최종점수")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
                {"dataField": "SCORE_MRK", 			"caption": '${msgel.getMsg("AML_20_01_10_01_106","스코링점수")}', 		"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "SCORE_WGHTS", 		"caption": '${msgel.getMsg("AML_20_01_10_01_107","스코링가중치")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
  	            {"dataField": "SCORE_EXCH_MRK", 	"caption": '${msgel.getMsg("AML_20_01_10_01_108","스코링최종점수")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "TOTAL_MRK", 			"caption": '${msgel.getMsg("AML_20_01_10_01_109","최종점수")}', 		"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "RSK_GRD_CD", 		"caption": 'RSK_GRD_CD', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true,"visible": false}
    	    ]
    	}).dxDataGrid("instance");

    }
    
    function setupGrids2(){
    	GridObj3 = $("#GTDataGrid2_Area").dxDataGrid({
        	dataSource 				: dataSource2,
        	gridId 					: "GTDataGrid2",	
        	height : 'calc(65vh - 250px)',
       	    "hoverStateEnabled"		: true,
       	    "wordWrapEnabled"		: false,
       	    "allowColumnResizing"	: true,
       	    "columnAutoWidth"		: true,
       	    "allowColumnReordering"	: true,
       	    "cacheEnabled"			: false,
       	    "cellHintEnabled"		: true,
       	    "showBorders"			: true,
       	    "showColumnLines"		: true,
       	    "showRowLines"			: true,
       	    "loadPanel" 			: { enabled: false },
       	    "export"				: {"allowExportSelectedData": true,  "enabled": false, "excelFilterEnabled": true, "fileName": "gridExport"},
       	    "sorting"				: {"mode": "multiple"},
       	 	"remoteOperations" 		: {filtering:false, grouping:false, paging:false, sorting:false, summary:false},
       	    "editing" 				: { mode: 'batch', allowUpdating: false, allowAdding : false, "allowDeleting": false},
       	    "filterRow"				: {"visible": false},
       	    "rowAlternationEnabled"	: true,
       	    "columnFixing"			: {"enabled": true},
	       	pager: {
	 	    	visible: true
	 	    	,showNavigationButtons: true
	 	    	,showInfo: true
	 	    },
	 	    paging: {
	 	    	enabled : true
	 	    	,pageSize : 20
	 	    },
	 	   	scrolling : {
	            mode            : "standard"
	           ,preloadEnabled  : false
	        },
       	    "searchPanel" 			: {"visible": false, "width": 250},
       	 	"selection"				: {allowSelectAll : true, deferred : false, mode : 'single', selectAllMode : 'allPages', showCheckBoxesMode : 'onClick'},
       	    "columns": [
       	    	{"dataField": "RSK_CCD", 		"caption": '${msgel.getMsg("AML_20_01_10_01_110","요소ID")}', 	"alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true, "width":"80px"},
       	        {"dataField": "RSK_NM", 		"caption": '${msgel.getMsg("AML_20_01_10_01_111","요소명")}', 	"alignment": "left", "allowResizing": true, "allowSearch": true, "allowSorting": true, "width":"150px"},
       	        {"dataField": "RSK_GRD_MRK", 	"caption": '${msgel.getMsg("AML_20_01_10_01_112","점수")}', 		"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true, "width":"120px"},
	            {"dataField": "WGHTS", 			"caption": '${msgel.getMsg("AML_20_01_10_01_113","가중치")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true, "width":"120px"},
       	        {"dataField": "EXCH_MRK", 		"caption": '${msgel.getMsg("AML_20_01_10_01_109","최종점수")}', 	"alignment": "right", "allowResizing": true, "allowSearch": true, "allowSorting": true}
       	    ],
//        	    "summary": {"totalItems": [{"column": "RSK_CCD", "summaryType": "count", valueFormat: "fixedPoint"}], texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
       	 	onInitialized : function(e) {
         		//doSearch();
         	}
       	}).dxDataGrid("instance");
   	}
        	
    function makeToolbarButton2(e){}//dummy

    function doSearch()
    {
        var pageID	 = "AML_10_04_01_04";	
    	var classID  = "AML_10_04_01_04";
    	
        var params = new Object();
		var methodID = "doSearch";
		overlay.show(true, true);
		params.pageID = pageID;
		params.AML_CUST_ID   =  $("#aml_cust_id").val().replaceAll("-","");
		params.KYC_TMS_CCD   =   $("#KYC_TMS_CCD").val();
		
		sendService(classID, methodID, params, doSearch_success, doSearch_fail);
    }
    
    function doSearch_success(gridData, data) { 
   	 	try {
   	 		console.log("gridData " + gridData);
   	    	GridObj1.refresh();
   	        GridObj1.option("dataSource3",gridData); 
   	        doSearch4();
   		} catch (e) {
   	        showAlert(e,"ERR");
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }
    function doSearch_fail() { 
   		overlay.hide();
    }

    function setClear()
    {
        $("#INDV_CORP_CCD"      ).html("");
        $("#CRDT_BAD_P_F"       ).html("");
        $("#NPRFT_GROUP_F"      ).html("");
        $("#AML_CRP_LTG_DIT_CD" ).html("");
        $("#LG_AMT_ASTS_F"      ).html("");
        $("#RSDNC_F"            ).html("");
        $("#AML_JOB_GUBN"       ).html("");
        $("#AML_JOB_GUBN_NM"    ).html("");
        $("#NTN_CD"             ).html("");
        $("#NTN_CD_NM"          ).html("");
        $("#INDST_RSK_DVD_CD"   ).html("");
        $("#INDST_RSK_DVD_CD_NM").html("");
    }
    
    function doSearch4()
    {
        var pageID	 = "AML_20_01_10_01";	
     	var classID  = "AML_20_01_10_01";
        var params = new Object();
 		var methodID = "doSearch";
 		overlay.show(true, true);
 		params.pageID = pageID;
 		params.AML_CUST_ID   =  $("#aml_cust_id").val();
 		params.KYC_TMS_CCD   =  $("#KYC_TMS_CCD").val();
 		params.SSPS_DL_CRT_DT   = "${SSPS_DL_CRT_DT}";
 		params.SSPS_DL_ID   = "${SSPS_DL_ID}";
 		
 		sendService(classID, methodID, params, doSearch4_success, doSearch_fail);
 		
    }   

    function doSearch4_success(gridData) { 
    	try {
   	    	GridObj2.refresh();
   	        GridObj2.option("dataSource",gridData);
   	     doSearch2();
   		} catch (e) {
   	        showAlert(e,"ERR");
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }   


    function doSearch2()
    {  
        var pageID	 = "AML_10_04_01_04";	
     	var classID  = "AML_10_04_01_04";
     	
         var params = new Object();
 		var methodID = "doSearch2";
 		overlay.show(true, true);
 		params.pageID = pageID;
 		params.AML_CUST_ID   =  $("#aml_cust_id").val().replaceAll("-","");
 		params.KYC_TMS_CCD   =   $("#KYC_TMS_CCD").val();
 		params.AML_CRT_DT   = "${SSPS_DL_CRT_DT}";
 		
 		sendService(classID, methodID, params, doSearch2_success, doSearch_fail);
    }
	
    function doSearch4_success(gridData) { 
    	try {
    		GridObj3.refresh();
    		GridObj3.option("dataSource2",gridData);
    		doSearch3();
   		} catch (e) {
   	        showAlert(e,"ERR");
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }   
    
    function doSearch3()
    {
        
        var pageID	 = "AML_10_04_01_04";	
     	var classID  = "AML_10_04_01_04";
     	
         var params = new Object();
 		var methodID = "doSearch3";
 		overlay.show(true, true);
 		params.pageID = pageID;
 		params.AML_CUST_ID   =  $("#aml_cust_id").val().replaceAll("-","");
 		params.KYC_TMS_CCD   =  $("#KYC_TMS_CCD").val();
 		params.AML_CRT_DT   = "${SSPS_DL_CRT_DT}";
 		
 		sendService(classID, methodID, params, reDrawInputData_success, doSearch_fail);
 		
    }   

    
    function reDrawInputData_success(gridData, data)
    {
        var tbl = $('#inputDataTbl')[0];
        while (tbl.rows.length>0) {
            tbl.deleteRow(0);
        }
        var row;
        for (var i in gridData) {
            if (i%2==0) row = tbl.insertRow();
            var cell = row.insertCell();
            cell.innerHTML  = gridData[i].RS11_2;
            cell.className  = "tbl_h";
            cell.width      = "25%";
            cell = row.insertCell();
            cell.innerHTML  = gridData[i].ITEM_VALUE;
            cell.className  = "tbl_info_w";
        }
    }
    
    function popimage(imagesrc,winwidth,winheight)
    {
        var look = 'width='+winwidth+',height='+winheight+',';
        popwin = window.open("","",look)
        popwin.document.open()
        popwin.document.write('<body topmargin=0 leftmargin=0 marginwidth=0 marginheight=0><img src="'+imagesrc+'"></body>')
        popwin.document.close()
    }
    
  
</script> 
<form name="form1">
    <input type="hidden" name="aml_cust_id" id="aml_cust_id"  value="<c:out value='${param.aml_cust_id}'/>">
    <input type="hidden" name="CS_TYP_CD"       value="${pstsm.CS_TYP_CD}"/>
    <input type="hidden" name="pageID"          value=""/>
    <input type="hidden" name="rsk_grd_rgst_dt" value=""/>
    <input type="hidden" name="sq"              value=""/>
    <input type="hidden" id="KYC_TMS_CCD" name="KYC_TMS_CCD" value="<c:out value='${param.KYC_TMS_CCD}'/>"/>

 	<div class="tab-content-bottom">
	    <div class="row">
    		<h4 class="tab-content-title">${msgel.getMsg('AML_20_02_10_02_010','상세점수')}</h4>
	    </div>
	    <div class="tab-content-bottom">
	        <div id="GTDataGrid1_Area"></div>
	    </div>
	      <div class="row">
    		<h4 class="tab-content-title">${msgel.getMsg('AML_10_04_01_04_002','요소 상세점수')}</h4>
	    </div>
           <div id="GTDataGrid2_Area"></div>
	    <div class="row">
	        <h4 class="tab-content-title">${msgel.getMsg('AML_10_04_01_04_003','요소 인자')}</h4>
	    </div>
	    <div class="panel-body">  
	          <table id="inputDataTbl" width="100%" border="1" class="tbl_info_no"></table>
		</div>
	</div>
	    <div class="button-area" style="display: flex;justify-content: flex-end; margin-top: 8px;">
	        ${btnel.getButton(outputAuth, '{btnID:"sbtn_02", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"self.close", cssClass:"btn-36"}')}
	    </div>  
        <div id="GTDataGrid0_Area" style="display: none;"></div>	<!-- ??? -->
</form>
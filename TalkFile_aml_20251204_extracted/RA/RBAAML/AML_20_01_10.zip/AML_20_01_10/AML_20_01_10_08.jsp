<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 결재회수팝업
*                   STR 決裁
*                   STR Approval Return
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 유성진
* Since           : 2019. 2. 20.
********************************************************************************************************************************************
********************************************************************************************************************************************
--%>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%@page import="com.gtone.webadmin.util.JSONUtil,com.gtone.webadmin.util.CodeUtil"%>

<%
    String stDate = Util.nvl(request.getParameter("stDate"));
    String edDate = Util.nvl(request.getParameter("edDate"));
    
    if(stDate.equals("")) stDate = DateUtil.addDays(DateUtil.getDateString(), -30, "yyyy-MM-dd");
	if(edDate.equals("")) edDate = DateUtil.addDays(DateUtil.getDateString(), 0, "yyyy-MM-dd");
	
    String branchCode = Util.nvl(request.getParameter("branchCode2"));
    String SSPS_TYP_CD = Util.nvl(request.getParameter("SSPS_TYP_CD"));
    String RNMCNO = Util.nvl(request.getParameter("rnmcno"));
    String CS_NM = Util.nvl(request.getParameter("cs_nm"));
    String SSPS_DL_DT_ALL = Util.nvl(request.getParameter("SSPS_DL_DT_ALL"));
    String lastApp = Util.nvl(request.getParameter("lastApp"));

    request.setAttribute("stDate",stDate);
    request.setAttribute("edDate",edDate);
    request.setAttribute("branchCode",branchCode);
    request.setAttribute("RNMCNO",RNMCNO);
    request.setAttribute("CS_NM",CS_NM);
    request.setAttribute("lastApp",lastApp);
    request.setAttribute("SSPS_TYP_CD",SSPS_TYP_CD);
%>
<style>
.summary1 {
    height:10px;
}
</style>
<script>
    // [ Attributes ]
    var GridObj1 = null;
    var overlay = new Overlay();
    var double_yn=null;
    var pageID	 = "AML_20_01_10_08";
	var classID  = "AML_20_01_10_08";
	var dataSource = [];

    $(document).ready(function(){

        setupConditions();
        setupGrids();
        setupFilter("init");
    });

    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid1_Area";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }

    function setupConditions()
    {
        try {
            var cbox1 = new GtCondBox("condBox1",1,true);
            cbox1.setItemWidths(320, 75, 0);
            cbox1.setItemWidths(220, 75, 1);
            cbox1.setItemWidths(220, 75, 2); 
             
            
            if ('<c:out value="<%=SSPS_DL_DT_ALL%>"/>' == "Y"){
            	document.form1.SSPS_DL_DT_ALL.checked = true;
            }
        } catch (e) {
            showAlert(e.message,"ERR");
        }
    }

    function makeToolbarButtonGrids(e){

        var cmpnt; cmpnt = e.component;
        var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
        var authC = "${outputAuth.C       }";  // 추가,수정 권한
        var authD = "${outputAuth.D       }";  // 삭제 권한
        if (useYN=="Y") {
            var gridID       = e.element.attr("id");    // 그리드 아이디
            var toolbarItems = e.toolbarOptions.items;
            toolbarItems.splice(0, 0, {
                "locateInMenu"  : "auto"
                ,"location"     : "after"
                ,"widget"       : "dxButton"
                ,"name"         : "filterButton"
                ,"showText"     : "inMenu"
                ,"options"      : {
                         "icon"      : ""
                       	,"elementAttr": { class: "btn-28 filter popupFilter" }
            			,"text"      : ""
                        ,"hint"      : '필터'
                        ,"disabled"  : false
                        ,"onClick"   : function(){
								setupFilter();
                        }
                 }
            });
        }
    }

    function setupGrids(){
        GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
        	dataSource 				: dataSource,
        	gridId 					: "GTDataGrid1",
        	"width" 				:"100%",
        	"height" 				:"calc(75vh - 100px)",
        	"elementAttr"           : { class: "grid-table-type" },
            hoverStateEnabled 		: true,
            wordWrapEnabled 		: false,
            allowColumnResizing 	: true,
            columnAutoWidth 		: true,
            allowColumnReordering 	: true,
            columnResizingMode 		: 'widget',
            cacheEnabled 			: false,
            cellHintEnabled 		: true,
            showBorders 			: true,
            showColumnLines 		: true,
            showRowLines 			: true,
            sorting					: { mode: "multiple"},
            loadPanel 				: { enabled: false },
            remoteOperations 		: {filtering:false, grouping:false, paging:false, sorting:false, summary:false},
            editing					: { mode: 'cell', allowUpdating: false, allowAdding : false},
            filterRow				: { visible: false },
            rowAlternationEnabled 	: true,
            columnFixing			: {	enabled: true},
            pager: {
    	    	visible: false
    	    	,showNavigationButtons: true
    	    	,showInfo: true
    	    },
    	    paging: {
    	    	enabled : false
    	    	,pageSize : 20
    	    },
	 	   	scrolling : {
	            mode            : "virtual" /*standard*/
	           ,preloadEnabled  : false
	        },
            searchPanel				: {visible: false, width: 250},
            selection				: {allowSelectAll : true, deferred : false, mode : 'multiple', selectAllMode : 'allPages', showCheckBoxesMode : 'always' },
            onToolbarPreparing		: makeToolbarButtonGrids,
            export 					: {allowExportSelectedData : true ,enabled : true ,excelFilterEnabled : true},
            columns: [
            	{dataField:'SSPS_DL_CRT_DT', 	caption:'${msgel.getMsg("AML_20_02_10_01_002","추출일자")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc",  fixed: true},
                {dataField:'SSPS_DL_ID', 		caption:'${msgel.getMsg("AML_20_01_11_01_124","일련번호")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc", cssClass:'link',fixed: true},
                {dataField:'SSPS_DL_CRT_DT_A', 	caption:'${msgel.getMsg("AML_20_02_10_01_002","추출일자")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc", cssClass:'link', visible:false },
                
                {dataField:'DL_P_NM', 			caption:'${msgel.getMsg("AML_20_01_11_01_102","고객명")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, allowFiltering: true ,fixed: true},
                
                {dataField:'OK_CCD', 			caption:'${msgel.getMsg("AML_20_02_10_02_005","보고구분")}', 		alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, width:"70px",
    				lookup: {dataSource: <%=JSONUtil.listToJson(CodeUtil.getCodes("AML_00_00_00_00_common_getComboData", "A301"))%>, displayExpr: "VALUE", valueExpr: "KEY"}},
   				{dataField:'INDV_CORP_CCD', caption:'개인/법인구분', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false,  
                       lookup: {
                                   dataSource: <%=JSONUtil.listToJson(CodeUtil.getCodes("AML_00_00_00_00_common_getComboData", "M006"))%>,
                                   displayExpr: "VALUE",
                                   valueExpr: "KEY"
                               }
                },
    			{dataField:'LGA_AST_YN',		caption:'${msgel.getMsg("AML_20_01_11_01_114","고액자산가여부")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false,width:"100px"},
    			{dataField:'STR_RPR_YN',		caption:'기보고', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, width:"100px"},
    			{dataField:'ACNT_NO', 			caption:'${msgel.getMsg("AML_20_01_11_01_105","계좌번호")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, "cssClass": "link",
    				cellTemplate: function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate_GTONE(cellInfo.text,"GNL_AC_NO")); }},
    			{dataField:'CS_NO', 			caption:'${msgel.getMsg("AML_20_01_10_03_301","실명번호")}',	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, "cssClass": "link"},
    			
                {dataField:'SSPS_TYP_NM', 		caption:'${msgel.getMsg("AML_20_01_11_01_108","시나리오명")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false},
    			{dataField:'SSPS_TYP_CD', 		caption:'${msgel.getMsg("AML_20_01_11_01_107","시나리오ID")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
    			{dataField:'CNT', 				caption:'${msgel.getMsg("AML_20_01_11_01_109","추출건수")}', 		dataType:'number', cssClass: 'link', alignment:'right', allowResizing:true, allowSorting:true, allowEditing:false, width:"60px", visible:false},
                {dataField:'XCL_RSN_CNTNT',  	caption:'${msgel.getMsg("AML_20_01_10_01_101","보고제외사유(본점)")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false},
                {dataField:'XCL_RSN_CNTNT2', 	caption:'${msgel.getMsg("AML_20_01_10_01_100","보고제외사유(지점)")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false , visible:false },
                
    			
    			{dataField:'DL_P_RNM_NO_CCD_NM', 	caption:'${msgel.getMsg("AML_20_01_11_01_104","실명확인구분")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible: false},
    			{dataField:'RSK_GRD_CD_NM', caption:'${msgel.getMsg("AML_20_01_11_01_113","KYC등급")}', 		alignment:'center', dataType:'text', allowResizing:true, allowSorting:true, allowEditing:false,  width:"60px", visible: false},
    	        {dataField:'TRIG_CTNT', 	caption:'혐의트리거', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, width:300, visible:false},
    	        {dataField:'MN_DL_DPRT_NM', caption:'계좌관리점', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
    	        {dataField:'PRFT_BRN_NM', 	caption:'계좌실적점', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
    	        {dataField:'ACT_NAME', 		caption:'${msgel.getMsg("AML_20_01_11_01_117","결재단계")}', 		alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, cssClass:'link', visible:false },
                {dataField:'GNL_AC_NO', 	caption:'계좌ID', alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
    	        {dataField:'DL_P_RNMCNO', 	caption:'고객번호', visible:false},
                
                {dataField:'DL_AMT', 			caption:'${msgel.getMsg("AML_20_01_11_01_106","거래금액")}',		alignment:'right', allowResizing:true, allowSorting:true, allowEditing:false, dataType:'number', format:'fixedPoint', visible:false     },
                {dataField:'RPR_DT', 			caption:'${msgel.getMsg("AML_20_01_11_01_110","최근보고거래일자")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, width:"120px", visible:false },
                {dataField:'RSK_GRD_MRK', 		caption:'${msgel.getMsg("AML_20_01_11_01_112","KYC점수")}', 		alignment:'right', allowResizing:true, allowSorting:true, allowEditing:false, cssClass:'link' , visible:true, width:"60px", visible:false ,
                								cellTemplate: function (cellElement, cellInfo) {if(cellInfo.data){cellElement.append($("<span class='"+setReskGrdColor1(cellInfo.data.RSK_GRD_CD)+"'>").text(cellInfo.displayValue));}} },
                {dataField:'MERGE_YN', 			caption:'병합여부', alignment:'center', allowResizing:true, 		allowSorting:true, allowEditing:true, visible:false},
                {dataField:'DNY_RSN_CNTNT',  	caption:'${msgel.getMsg("AML_20_01_10_01_102","반려사유")}', 			alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false},
                {
                    "dataField": "SPRN_KEEP_TAGT_YN",
                    "caption": '분리보관',
                    "alignment": "center",
                    "allowResizing": true,
                    "allowSearch": true,
                    "allowSorting": true,
                    "width":80
                },
                {dataField:"INST_ID",			caption: 'INST_ID', "alignment": "left", "allowResizing": true, "allowSearch": true, "allowSorting": true, "visible": false},
                {dataField:'WORK_ID', 			visible:false, allowSearch:false},
                {dataField:'ACT_ID', 			visible:false, allowSearch:false},
                {dataField:'RSK_GRD_CD', 		visible:false, allowSearch:false},
                {dataField:'RSK_GRD', 			visible:false, allowSearch:false}
            ],
            onExporting: function (e) {
    	    	var workbook = new ExcelJS.Workbook();
    	    	var worksheet = workbook.addWorksheet("Sheet1");
    		    DevExpress.excelExporter.exportDataGrid({
    		        component: e.component,
    		        worksheet: worksheet,
    		        autoFilterEnabled: true,
    		    }).then(function(){
    		        workbook.xlsx.writeBuffer().then(function(buffer){
    		            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${pageTitle}.xlsx");
    		        });
    		    });
    		    e.cancel = true;
            },
             summary:{
         		        totalItems: [{
         		            column      : 'SSPS_DL_CRT_DT_A',
         		            summaryType : 'count'
         		        }],
             			texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}
         		    },
            onCellClick: function(e){
                if(e.data ){
                	clickCellGrid1('gridId', e, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
                }
                /* if (e.component.isRowSelected(e.key)) {
                    if (e.column.dataField=="OK_CCD"){
                    	e.component.editCell(e.rowIndex,e.columnIndex);
                    } else if (e.column.dataField=="XCL_RSN_CNTNT") {
                        e.component.editCell(e.rowIndex,e.columnIndex);
                    }
                } */
            },
            onInitialized : function(e) {
            	doSearch();
            }
        }).dxDataGrid("instance");
    }

    function doSearch()
    {
    	var startDate = getDxDateVal("stDate", true);
        var endDate   = getDxDateVal("edDate"  , true);
        if (startDate == null) {
            showAlert('${msgel.getMsg("AML_60_02_02_01_005","시작일자를 입력해주세요.")}',"WARN");
            return;
        }
        if (endDate == null) {
            showAlert('${msgel.getMsg("AML_60_02_02_01_006","종료일을 입력해주세요.")}',"WARN");
            return;
        }
        if (startDate > endDate) {
            showAlert('${msgel.getMsg("AML_20_02_02_01_042","시작일이 종료일보다 늦을 수 없습니다.")}',"WARN");
            return;
        }

       /*  var vWfCodeSts = $("#wfCodeSts"            ,"form[name=form1]").val();
        if(vWfCodeSts == 'D'){
        	vWfCodeSts = '';
        } */
        var params = new Object();
		var methodID = "doSearch";
		overlay.show(true, true);
		params.pageID = form1.pageID.value;
		params.branchCode = $("input[name=branchCode]" ,"form[name=form1]").val()=="99999"?"":$("input[name=branchCode]","form[name=form1]").val();
        //params.wfCodeSts  = vWfCodeSts;
		params.stDate = getDxDateVal("stDate",true);
		params.edDate = getDxDateVal("edDate",true);
		params.CS_NM  = $("input[name=CS_NM]","form[name=form1]").val();
		params.CS_NO  = $("input[name=CS_NO]","form[name=form1]").val();
		params.SSPS_TYP_CD = $("#SSPS_TYP_CD", "form[name=form1]").val();
		params.lastApp = $("input[name=lastApp]","form[name=form1]").val();
		params.SSPS_DL_DT_ALL = ($("#SSPS_DL_DT_ALL"  ).is(":checked")==true ? "":"N");

		sendService(classID, methodID, params, doSearch_success, doSearch_fail);

    }

    function doSearch_success(gridData, data){
        try {
   	    	GridObj1.refresh();
   	        GridObj1.option("dataSource",gridData);
   		} catch (e) {
   	        showAlert(e,"ERR");
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }

    function doSearch_fail(){
    	overlay.hide();
    }

    function closeCancel() { self.close(); }

    /*회수 처리 : 결재중인 건에 대해 회수 처리함 [지점담당자, 지점책임자, 본점담당자 사용]*/
    function withdraw(){
    	var rowsData = GridObj1.getSelectedRowsData();
    	if (rowsData.length==0) {
            showAlert('${msgel.getMsg("AML_20_01_10_08_001","결재 회수할 건을 선택하세요.")}',"ERR");
            return;
        }

    	showConfirm('${msgel.getMsg("AML_20_01_10_08_002","회수처리 하시겠습니까?")}', "회수", function(){

    		var params = new Object();
      		var methodID = "withdrawProcess";
      		overlay.show(true, true);
      		params.pageID = form1.pageID.value;
      		params.gridData = rowsData;
      		params.typeCode = "STR";

      		sendService(classID, methodID, params, withdrawProcess_success, withdrawProcess_fail);

    	});

    }
    /*회수 처리 : 결재중인 건에 대해 회수 처리함 [지점담당자, 지점책임자, 본점담당자 사용]*/

    function withdrawProcess_success(gridData, data){
    	try {
	        doSearch();
	        opener.doSearch();
    	} catch (e) {
            showAlert(e,"ERR");
            overlay.hide();
        } finally {
            overlay.hide();
        }
    }

    function withdrawProcess_fail(data){
    	overlay.hide();
    }


    /*회수 처리 : 결재완료, 파일생성 된 건에 대해 회수처리 함 [본점책임자 사용]*/
    function lastAppWithdraw(){

    	var rowsData = GridObj1.getSelectedRowsData();
    	if (rowsData.length==0) {
            showAlert('${msgel.getMsg("AML_20_01_10_08_001","결재 회수할 건을 선택하세요.")}',"WARN");
            return;
        }

    	if (!confirm('${msgel.getMsg("AML_20_01_10_08_002","회수처리 하시겠습니까?")}')) {
              return;
          }

        var params = new Object();
  		var methodID = "lastAppWithdrawProcess";
  		overlay.show(true, true);
  		params.pageID = form1.pageID.value;
  		params.gridData = rowsData;

  		sendService(classID, methodID, params, withdrawProcess_success, withdrawProcess_fail);
    }
    /*회수 처리 : 결재완료, 파일생성 된 건에 대해 회수처리 함 [본점책임자 사용]*/
    
    /** click grid row */
    function clickCellGrid1(id, obj, data, rowIdx, colIdx, columnId)
    {
        if(columnId == "SSPS_DL_ID" ) {       // 일련번호
            form2.pageID.value = 'AML_20_01_10_03';
            window_popup_open(form2, 1370, 830, '');
            form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
            form2.SSPS_DL_ID.value = data.SSPS_DL_ID;
            form2.WORK_ID.value = data.WORK_ID;
            form2.ACNT_NO.value = data.ACNT_NO;
            form2.AML_CUST_ID.value = data.AML_CUST_ID.replaceAll("-","");
            form2.approval.value = 'true';
            form2.ctlBtn02.value = 'true';
        } else if (columnId == "RSK_GRD_CD_NM" ) {    // KYC등급
            form2.pageID.value = 'AML_10_04_01_04';
            window_popup_open(form2, 1000, 700, '', 'yes');
            form2.rnmcno.value = data.DL_P_RNMCNO;
            form2.KYC_TMS_CCD.value = 'K';
        } else if (columnId == "DL_P_NM" ) {			// 고객명 - 고객상세
            form2.rnmcno.value = data.DL_P_RNMCNO.replaceAll("-","");
            form2.dis_flag.value = "P";
            if(data.INDV_CORP_CCD == "2"){		// 법인
        		form2.pageID.value = "AML_10_07_01_01";
	          //window_popup_open(form2, 1000, 830, '','yes');
        		window_popup_open(form2, 1370, 830, 'yes','yes'); 
        	}else{
        		form2.pageID.value = "AML_10_06_01_01";	// 개인
	          //window_popup_open(form2, 1000, 650, '','yes');
        		window_popup_open(form2, 1370, 650, '','yes');
        	}
        } else if(columnId == "ACNT_NO" ) {		// 계좌번호 - 기간벌 거래내역
        	form2.pageID.value = 'AML_20_01_11_03';
        	form2.ACNT_NO.value = data.ACNT_NO;
        	form2.GNL_AC_NO.value = data.GNL_AC_NO;
        	form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
        	form2.STR_CTR_GB.value = 'S';
            window_popup_open(form2, 900, 600, '','yes');
        } else if(columnId == "CS_NO" ) {		// 실명번호 - STR 경보 History
        	form2.pageID.value = 'AML_20_01_11_04';
        	form2.DL_P_NM.value = data.DL_P_NM;
        	form2.GNL_AC_NO.value = data.GNL_AC_NO;
        	form2.DL_P_RNMCNO.value = data.DL_P_RNMCNO;
        	form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
        	form2.STR_CTR_GB.value = 'S';
            window_popup_open(form2, 900, 600, '','yes');
        } else {
            return;
        }
        form2.target = form2.pageID.value;
        form2.action = "<c:url value='/'/>0001.do";
        try {
            form2.submit();
        } catch (e) {
            alert(e.message);
        }
    }

</script>
<form name="form2" method="post" >
    <input type="hidden" name="pageID"          id="pageID"         />
    <input type="hidden" name="CCD"             id="CCD"            />
    <input type="hidden" name="clientID"        id="clientID"       />
    <input type="hidden" name="rnmcno"          id="rnmcno"         />
    <input type="hidden" name="rnmcno_view"     id="rnmcno_view"    />
    <input type="hidden" name="dis_flag"        id="dis_flag"       />    
    <input type="hidden" name="KYC_TMS_CCD"     id="KYC_TMS_CCD"    />
    <input type="hidden" name="SSPS_DL_CRT_DT"  id="SSPS_DL_CRT_DT" />
    <input type="hidden" name="SSPS_DL_ID"      id="SSPS_DL_ID"     />
    <input type="hidden" name="ACT_NAME_MASTER" id="ACT_NAME_MASTER"/>
    <input type="hidden" name="ctlBtn02"        id="ctlBtn02"       />
    <input type="hidden" name="cs_nm"           id="cs_nm"          />
    <input type="hidden" name="WORK_ID"         id="WORK_ID"        />
    <input type="hidden" name="approval"        id="approval"       />
    <input type="hidden" name="modify"          id="modify"         />
    <input type="hidden" name="ACNT_NO"         id="ACNT_NO"        />
    <input type="hidden" name="DL_P_NM"         id="DL_P_NM"        />
    <input type="hidden" name="GNL_AC_NO"       id="GNL_AC_NO"      />
    <input type="hidden" name="DL_P_RNMCNO"     id="DL_P_RNMCNO"    />
    <input type="hidden" name="STR_CTR_GB"      id="STR_CTR_GB"     />
    <input type="hidden" name="AML_CUST_ID"      id="AML_CUST_ID"     />
</form>
<form name="form1" method="post">
    <input type="hidden" name="pageID"  id="pageID" />
    <input type="hidden" name="ROLE_ID" id="ROLE_ID" value="<c:out value='${ROLE_ID}'/>" />
    <input type="hidden" name="lastApp" id="lastApp" value="<c:out value='${lastApp}'/>" />

<!-- Condition Box[ ----------------------------------------------------------------------------------------------------------------------->
<div class="inquiry-table">
    <div class="table-row">
        <div class="table-cell">
            ${condel.getInputDateDxPair('AML_20_01_11_01_002','추출일자','stDate',stDate,'edDate',edDate)}
           <div class="all">
               <input type="checkbox" id="SSPS_DL_DT_ALL" name="SSPS_DL_DT_ALL" value="Y" checked>
               <label for="SSPS_DL_DT_ALL">${msgel.getMsg('AML_10_05_01_01_009','전체')}</label>
           </div>
        </div>
        <div class="table-cell">
            ${condel.getInputCustomerNo('{msgID:"AML_20_01_01_01_048", devaultValue:"실명확인번호", name:"CS_NO", size:"51"}')}
        </div>
    </div>
    <div class="table-row">
    	<div class="table-cell">
            ${condel.getBranchSearch('{msgID:"AML_20_01_11_01_001", defaultValue:"거래지점", name:"branchCode", firstComboWord:"ALL"}')}
        </div>

        <div class="table-cell">
            ${condel.getInputCustomerNo('{msgID:"AML_20_01_01_03_008", devaultValue:"고객명", name:"CS_NM"}')}
        </div>
    </div>
    <div class="table-row">
        <div class="table-cell">
        	${condel.getSelect('{msgID:"AML_20_01_11_01_005", defaultValue:"혐의명", selectID:"SSPS_TYP_CD", width:"150", sqlID:"MDAO.AML_20_01_11_01_getSSPS_TYP_CDList", firstComboWord:"ALL"}')}
        </div>
        <div class="table-cell"></div>
    </div>
</div>
<div class="button-area" style="float:right;margin-top:5px;">
      ${btnel.getButton(outputAuth, '{btnID:"sbtn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}
      <% if ( !"5".equals(ROLE_ID)) { //본점책임자%>
      ${btnel.getButton(outputAuth, '{btnID:"sbtn_04", cdID:"withdrawBtn", defaultValue:"회수", mode:"U", function:"withdraw", cssClass:"btn-36"}')}
      <%}else{ %>
      <%-- ${btnel.getButton(outputAuth, '{btnID:"sbtn_04", cdID:"withdrawBtn", defaultValue:"회수", mode:"U", function:"lastAppWithdraw", cssClass:"btn-36"}')} --%>
      <%}%>
      ${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"closeCancel", cssClass:"btn-36"}')}
</div>

<!-- ]Condition Box, Grid1[ --------------------------------------------------------------------------------------------------------------->
<div class="tab-content-bottom">
<div class="row"></div>
   <div id="GTDataGrid1_Area"></div>
</div>
<!-- ]Grid1 ------------------------------------------------------------------------------------------------------------------------------->
</form>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" />
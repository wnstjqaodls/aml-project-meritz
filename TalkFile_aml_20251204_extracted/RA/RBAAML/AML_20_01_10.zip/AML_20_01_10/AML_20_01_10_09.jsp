<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR수탁거부현황
********************************************************************************************************************************************
--%>

<%@ include file="/WEB-INF/Package/AML/common/notitle_common_top.jsp" %>
<%@ page import="com.gtone.webadmin.util.JSONUtil,com.gtone.webadmin.util.CodeUtil"%>


<%
    String CS_NO_VIEW     = Util.nvl(request.getParameter("CS_NO_VIEW"    ));
    request.setAttribute("CS_NO_VIEW",CS_NO_VIEW);
%>
<!-- [2] init ${msgel.getMsg('AML_20_02_10_02_010')} JavaScript -->
<script language="JavaScript">
	var GridObj = null;
    var GridObj1 = null;
    var new_obj;
    var pageID = "AML_20_01_10_09";

    $(document).ready(function(){
    	setupGrids();
    	doSearchDeal();
    	setupFilter("init");
    });

    function setupGrids(){
    	GridObj = $("#GTDataGrid_Area").dxDataGrid({
			gridId 					: "GTDataGrid"
			,height 					: "479"
			,elementAttr: { class: "grid-table-type" }
	 	   ,allowColumnReordering : true
	 	   ,allowColumnResizing : true
	 	   ,cacheEnabled : false
	 	   ,cellHintEnabled : true
	 	   ,columnAutoWidth : true
	 	   ,columnFixing : { enabled : true }
	 	   ,editing : {
	 	        mode : "batch"
	 	       ,allowUpdating : false
	 	       ,allowAdding : false
	 	       ,allowDeleting : false
	 	    }
	 	   ,export : {
	 	        allowExportSelectedData : false
	 	       ,excelFilterEnabled : false
	 	       ,fileName : "gridExport"
	 	       ,enabled : false
	 	    }
	 	   ,filterRow : { visible : false }
	 	   ,onToolbarPreparing   : makeToolbarButtonGrids
	 	   ,hoverStateEnabled : true
	 	   ,loadPanel : { enabled : false }
	 	   ,remoteOperations : {
	 	        filtering : false
	 	       ,grouping  : false
	 	       ,paging    : false
	 	       ,sorting   : false
	 	       ,summary   : false
	 	    }
	 	   ,rowAlternationEnabled : true
	 	   ,searchPanel : {
	 	        visible : false
	 	       ,width   : 250
	 	    }
	 	   ,selection : {
	 	        allowSelectAll     : true
	 	       ,deferred           : false
	 	       ,mode               : "single"
	 	       ,selectAllMode      : "allPages"
	 	       ,showCheckBoxesMode : "onClick"
	 	    }
	 	   ,showBorders            : true
	 	   ,showColumnLines        : true
	 	   ,showRowLines           : true
	 	   ,sorting                : { mode : "multiple" }
	 	   ,wordWrapEnabled        : false
//  	   ,scrolling              : {
//  	   		mode: "virtual"
//  	   	   ,preloadEnabled  : false
//  	   	}
	 	   ,onCellPrepared        : function(e){

	 	    }
	 	   ,columns : [
	 		  {
	              dataField: "RGSN_DATE",
	              caption: '등록일',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 80,
	              allowSorting: true
	          },
	                               {
	              dataField: "RGSN_STAT",
	              caption: '등록상태',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 70,
	              allowSorting: true
	          },
	                               {
	              dataField: "RGSN_GBN",
	              caption: '등록구분',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 70,
	              allowSorting: true
	          },
	                               {
	              dataField: "CNGR_SECT_NAME",
	              caption: '위탁자구분',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 90,
	              allowSorting: true
	          },
	                               {
	              dataField: "CS_NM",
	              caption: '성명',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 100,
	              allowSorting: true
	          },
	                               {
	              dataField: "CS_NO",
	              caption: '고객번호',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 110,
	              allowSorting: true
	          },
	                               {
	              dataField: "TSUS_RJCT_RESN_NAME",
	              caption: '거부사유',
	              alignment: "left",
	              allowResizing: true,
	              allowSearch: true,
	              allowSorting: true
	          },
	                               {
	              dataField: "TSUS_RJCT_STRT_DATE",
	              caption: '수탁거부시작일',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 110,
	              allowSorting: true
	          },
	                               {
	              dataField: "TSUS_RJCT_END_DATE",
	              caption: '수탁거부종료일',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 110,
	              allowSorting: true
	          },
	                               {
	              dataField: "TSUS_RJCT_ACTN_DATE",
	              caption: '조치일',
	              alignment: "center",
	              allowResizing: true,
	              allowSearch: true,
	              width: 80,
	              allowSorting: true
	          }
	 	    ]
	 	   ,onCellClick : function(e) {
	 	        if (e.data) {
	 	            clickGrid1Cell('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
	 	        }
	 	    }


    	}).dxDataGrid("instance");
    }

    /**
     * Search
     */

    function doSearchDeal(){
		console.log("doSearchDeal ----------------");
    	var classID = "AML_20_01_01_07";
    	var methodID = "searchTsusRjctHistory";
    	var params = new Object();

    	var CS_NO_VIEW = "${CS_NO_VIEW}";
    	CS_NO_VIEW = CS_NO_VIEW.replaceAll(" ","");
    	params.CS_NO = CS_NO_VIEW;

    	sendService(classID, methodID, params, doSearchDeal_success, doSearchDeal_fail);

    }
    function doSearchDeal_success(data)
    {


    }

    function doSearchDeal_fail()
    {
    	console.log("doSearchDeal_fail");
    }


    function clickGrid1Cell(id, obj, data, rowIdx, colIdx, columnId)
    {

    } 

    function makeToolbarButtonGrids(e){

	    var cmpnt; cmpnt = e.component;
	    var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
	    var authC = "${outputAuth.C       }";  // 추가,수정 권한
	    var authD = "${outputAuth.D       }";  // 삭제 권한
	    if (useYN=="Y") {
	        var gridID       = e.element.attr("id");    // 그리드 아이디
	        var toolbarItems = e.toolbarOptions.items;
	        toolbarItems.splice(0, 0, {
	            "locateInMenu"  : "auto"
	            ,"location"     : "after"
	            ,"widget"       : "dxButton"
	            ,"name"         : "filterButton"
	            ,"width" :"100%"
	            ,"showText"     : "inMenu"
	            ,"options"      : {
	                     "icon"      : ""
	                   	,"elementAttr": { class: "btn-28 filter popupFilter" }
	        			,"text"      : ""
	                    ,"hint"      : '필터'
	                    ,"disabled"  : false
	                    ,"onClick"   : function(){
								setupFilter();
	                    }
	             }
	        });
	    }
	}


    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid_Area";
    	gridObj.title = "";
    	gridArrs[0] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }



</script>
<style>
	textarea[readonly=readOnly]{
		background-color: #faf9f8;
	}
	.dx-datagrid-content .dx-datagrid-table .dx-row > td, .dx-datagrid-content .dx-datagrid-table .dx-row > tr > td {
	  vertical-align: middle;
	}

	td > .dx-visibility-change-handler{
		display: flex;
    	justify-content: center;
	}

</style>
<form name="form1"  method="post">
    <input type="hidden" name="pageID"  />
    <input type="hidden" name="classID" />
    <input type="hidden" name="methodID" />
    <input type="hidden" name="SSPS_DL_ID" value="${SSPS_DL_ID}"/>
    <input type="hidden" name="DL_P_AML_CUST_ID" value="${DL_P_AML_CUST_ID}"/>

<div class="tab-content-bottom">
    <div class="row" style="padding-top:8px;">
	</div>
	<div id="GTDataGrid_Area"></div>
</div>

</form>
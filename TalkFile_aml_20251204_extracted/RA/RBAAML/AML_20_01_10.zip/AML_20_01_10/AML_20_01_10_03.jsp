<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 결재 상세
*                   STR決裁の詳細
*                   STR Approval Details
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 7. 28.
* Alteration      : 1. 신규 레이아웃 적용, 코드 정리
*                   2. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2018. 4. 23.
* Alteration      : AML() 함수제거, 코드정리
********************************************************************************************************************************************
--%>
<%@page import="java.util.*"                                                        %>
<%@ page import="java.math.BigDecimal"                                              %>
<%@page import="com.gtone.aml.basic.jspeed.base.el.MsgEL"                           %>
<%@page import="com.gtone.aml.dao.common.MDaoUtilSingle"                            %>
<%@page import="com.gtone.aml.workflow.AMLWF4Interface"                             %>
<%@page import="com.gtone.aml.admin.MMA040Handler"                                  %>
<%@page import="com.gtone.aml.admin.StdValHandler"                                  %>
<%@page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01.AML_20_01_01_03" %>
<%@page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03" %>
<%@page import="java.text.ParseException"                                  			%>
<%@page import="com.gtone.aml.basic.common.log.Log"								    %>
<%@page import="com.gtone.aml.admin.AMLException" 									%>
<%@page import="java.text.DateFormat" 											    %>
<%@page import="com.ss.common.util.security.damo.damoManager" 					    %>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%
	try{
		String uploadFile = PropertyService.getInstance().getProperty("aml.config","upload.file");
		request.setAttribute("uploadFile",uploadFile);
	
		AMLWF4Interface wfif = new AMLWF4Interface(request, response, "ko-KR", 0);
	    String useBRMiner = PropertyService.getInstance().getProperty("aml.config", "useBRMiner", "N");
	    ArrayList btnActs, btnActs2;
	    if ("Y".equals(useBRMiner)) {
	        btnActs = wfif.denyBtnActivities(MMA040Handler.getInstance().getIntValue("101")); // STR
	        btnActs2 = wfif.denyBtnActivities(MMA040Handler.getInstance().getIntValue("105")); // STR 임의보고
	    } else {
	        btnActs = wfif.denyBtnActivities(StdValHandler.getInstance().getIntValue("101")); // STR
	        btnActs2 = wfif.denyBtnActivities(StdValHandler.getInstance().getIntValue("105")); // STR 임의보고
	    }
	
		request.setAttribute("btnActs",btnActs);
		request.setAttribute("btnActs2",btnActs2);
	}catch(RuntimeException e){
		Log.logAML(Log.ERROR, e);
	}catch(Exception e){
		Log.logAML(Log.ERROR, e);
	}

	String AML_ROLE_ID = sessionAML.getsAML_ROLE_ID();

    // MASTER_BRANCH  [Y] [N]
    // BDPT_CD
    String SSPS_DL_CRT_DT   = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_CRT_DT")));
    String SSPS_DL_ID       = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_ID"    )));
    String WORK_ID          = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("WORK_ID"       )));
    String ACT_ID           = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("ACT_ID"        )));
    String ctlBtn02         = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("ctlBtn02")), ""     );
    String approval         = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("approval")), "false");
    String dvTabID          = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("dvTabID" )), "4"     );
    String GNL_AC_NO        = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("GNL_AC_NO" )), ""     );
    String parentPage       = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("parentPage" )), "");
    String ACNT_NO       	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("ACNT_NO" )), ""     );
    String AML_CUST_ID     	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("AML_CUST_ID" )), ""     );
    

    DataObj in1  = new DataObj();
    in1.add("SSPS_DL_ID"    ,SSPS_DL_ID     );
    in1.add("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);

    DataObj out1 = AML_20_01_10_03.getInstance().getCustInfo(in1);
 
    String Search_Code          = SSPS_DL_CRT_DT +","+ SSPS_DL_ID +","+ SSPS_DL_CRT_DT +","+ SSPS_DL_ID;
    String RPR_PRGRS_CCD        = out1.getText("RPR_PRGRS_CCD"      );
    String SSPS_TYP_CD          = out1.getText("SSPS_TYP_CD"        );
    String SSPS_TYP_NM          = out1.getText("SSPS_TYP_NM"        );
    String INDV_CORP_CCD        = out1.getText("INDV_CORP_CCD"      );
    String DL_P_RNM_NO_CCD      = out1.getText("DL_P_RNM_NO_CCD"    );
    String DL_P_RNM_NO_CCD_NM   = out1.getText("DL_P_RNM_NO_CCD_NM" );
    String DL_P_RNMCNO          = out1.getText("DL_P_RNMCNO"        );
    String CS_NO_VIEW           = out1.getText("CS_NO_VIEW"         );
    String DL_P_NM              = out1.getText("DL_P_NM"            );
    String INST_ID              = out1.getText("INST_ID"            );

    // 20170228 추가KEOL
    String OK_CCD               = out1.getText("OK_CCD");
    String OK_CCD_CODE          = out1.getText("OK_CCD");
    MsgEL msgel = (MsgEL)request.getAttribute("msgel");
    if      ("1".equals(OK_CCD)) {
    	OK_CCD = msgel.getMsg("AML_20_02_03_01_002", "보고대상"   );
    }
    else if ("2".equals(OK_CCD)){
    	OK_CCD = msgel.getMsg("AML_20_01_01_01_031", "보고제외");
    }
    else                        {
    	OK_CCD = msgel.getMsg("AML_20_01_10_03_118", "선택"   );
    }

    // 20170309 추가
    String stDate = "";
    String edDate = "";

    try{

    if("".equals(stDate)) {
    	stDate = DateUtil.addDays(DateUtil.getDateString(), -90, "yyyy-MM-dd");
    }
    if("".equals(edDate)) {
    	edDate = DateUtil.addDays(DateUtil.getDateString(),   0, "yyyy-MM-dd");
    }
    }catch (ParseException e){
    	Log.logAML(Log.ERROR, e);
    }

    stDate = stDate.replaceAll("-","");
    edDate = edDate.replaceAll("-","");

    // =====================================================================================================================================
    DataObj output      = null;
    DataObj output_temp = null;

    DataObj input  = new DataObj();
    input.add("SSPS_DL_ID"      ,SSPS_DL_ID                    );
    input.add("SSPS_DL_CRT_DT"  ,SSPS_DL_CRT_DT                );
    input.add("BDPT_CD"         ,BDPT_CD                       );
    input.add("RNMCNO"          ,DL_P_RNMCNO.replaceAll("-",""));
    input.add("RNMCNO_HIDDEN"   ,DL_P_RNMCNO.replaceAll("-","")            );
    input.add("CS_NO"           ,"");
    input.add("AML_CUST_ID", AML_CUST_ID);
    input.add("INDV_CORP_CCD"   ,INDV_CORP_CCD);
    

    AML_20_01_01_03 AML_20_01_01_03_I =  AML_20_01_01_03.getInstance();

    // =====================================================================================================================================
    // [1] ST Type List (NIC69B)
    DataObj GROUP   = new DataObj();
    DataObj ELEMENT = new DataObj();
    GROUP = AML_20_01_01_03_I.getSuspication_List(input);
    // =====================================================================================================================================

    // =====================================================================================================================================
    // [2] Basic information
    try{
    	DataObj input_p = new DataObj();
    	input_p.add("RNMCNO", "");
    	input_p.add("CS_NO", "");
    	input_p.add("AML_CUST_ID", AML_CUST_ID);
    	input_p.add("INDV_CORP_CCD"   ,INDV_CORP_CCD); 
    	output = MDaoUtilSingle.getData("AML_10_06_01_01_getSearch_01_SS",input_p);
    }catch(AMLException e){
    	Log.logAML(Log.ERROR, e);
    }
    // =====================================================================================================================================

    String J_BDPT_CD = "N".equals(MASTER_BRANCH) ? BDPT_CD : "";
   // String gubun = "N".equals(MASTER_BRANCH) ? "B" : "J";

    request.setAttribute("INST_ID"              ,INST_ID            );
    request.setAttribute("INDV_CORP_CCD"        ,INDV_CORP_CCD      );
    request.setAttribute("RPR_PRGRS_CCD"        ,RPR_PRGRS_CCD      );
    request.setAttribute("SSPS_DL_ID"           ,SSPS_DL_ID         );
    request.setAttribute("SSPS_DL_CRT_DT"       ,SSPS_DL_CRT_DT     );
    request.setAttribute("SSPS_TYP_CD"          ,SSPS_TYP_CD        );
    request.setAttribute("SSPS_TYP_NM"          ,SSPS_TYP_NM        );
    request.setAttribute("DL_P_RNM_NO_CCD"      ,DL_P_RNM_NO_CCD    );
    request.setAttribute("DL_P_RNM_NO_CCD_NM"   ,DL_P_RNM_NO_CCD_NM );
    request.setAttribute("DL_P_RNMCNO"          ,DL_P_RNMCNO        );
    request.setAttribute("CS_NO_VIEW"           ,CS_NO_VIEW         );
    request.setAttribute("DL_P_NM"              ,DL_P_NM            );
    request.setAttribute("Search_Code"          ,Search_Code        );
    request.setAttribute("J_BDPT_CD"            ,J_BDPT_CD          );
    request.setAttribute("dvTabID"              ,dvTabID            );
    request.setAttribute("OK_CCD"               ,OK_CCD             );  // 20170228 추가 KEOL
    request.setAttribute("OK_CCD_CODE"          ,OK_CCD_CODE        );  // 20170228 추가 KEOL
    request.setAttribute("WORK_ID"              ,WORK_ID            );  // 20170302 추가 KEOL
    request.setAttribute("approval"             ,approval           );  // 20170307 추가 KEOL
    request.setAttribute("stDate"               ,stDate             );
    request.setAttribute("edDate"               ,edDate             );
    request.setAttribute("output"               ,output             );
    request.setAttribute("ACT_ID"               ,ACT_ID             );
    request.setAttribute("ctlBtn02"             ,ctlBtn02           );
    //request.setAttribute("GNL_AC_NO"            ,GNL_AC_NO          );
    request.setAttribute("parentPage"           ,parentPage         );
    request.setAttribute("parentViewId"         ,request.getParameter("parentViewId"));
    request.setAttribute("parentViewName"       ,request.getParameter("parentViewName"));
    request.setAttribute("ACNT_NO"              ,ACNT_NO             );
    // =====================================================================================================================================
%>
<style type="text/css">
.textarea-box:disabled{
	padding: 6px 8px;
	background-color: #c7c1c1;
	border: 1px solid #ccc;
	width: 100%;
}
.table-box:disabled{ 
	background-color: #efe9e9;
	border: 1px solid #ccc;
	width: 100%;	
}
</style>

<script>
    var GridObj1    = null;
    var GridObj2    = null;
    var modify      = false;
    var tabID       = null;
    var tabPanelID  = null;
    var onFileCheck = false;
    var overlay = null;
    var actId;
    var denyBtnActs = new Array();
    var vInit = "Y";
    /** Initial function */
    $(document).ready( function() {

    	actId = $("#ACT_ID").val();
        gubun = $("#MASTER_BRANCH").val()=="Y"?"0":"1"; // "0":Head office, "1":branch

        set_Suspication_able();
        ccdChange();
        $("button[name=custInfoDiv]").text("${INDV_CORP_CCD}"=="1"?"${msgel.getMsg('AML_20_01_01_03_114','고객상세(개인)')}":"${msgel.getMsg('AML_20_01_01_03_115','고객상세(법인)')}");

        // 텝 클릭 이벤트
        $(".tab-item").click(function(e){
        	setupTabPanel($(this).index());
        });

        //탭 오픈
        setupTabPanel("${dvTabID}");

        doSearch(gubun);
        var tabtext = $(".dx-tab-text");
        tabtext.css("font-weight","bolder");
        if("${dvTabID}"=="4"){
        	$("#btn_02" ).show();
        	$("#sbtn_02" ).show();
            $("#sbtn_03" ).show();

            if("${ROLE_ID}"=="4" && $.inArray(actId, denyBtnActs) > -1) {
                $("#sbtn_04" ).hide();
                $("#DNY_CHECK").hide();
            } else {
            	$("#sbtn_04" ).show();
            	$("#DNY_CHECK").show();
            }

            if("${ROLE_ID}"=="3"){
            	$("#sbtn_04" ).hide();
            	$("#DNY_CHECK").hide();
            }
        }

       	if("${AML_ROLE_ID}" == "3" || "${AML_ROLE_ID}" == "6" ){
       		  if("${dvTabID}"=="6"){
	        	var tabBg =	$(".dx-tabpanel");
	        	tabBg.css("background-color", "gray");

       		}
       	}

        //STR 3개월 거래내역을 추출하여 XLS 파일 생성한다. 현재 사용 x 버튼이벤트로 변경 필요시 주석해제
		if($("#MASTER_BRANCH").val()=="Y" && $("#approval").val() == "true") {
            //doSearchStrXlsFile("0");
        }

        //init때 탭 클릭 이벤트 class 추가
		$("#tabPane_tabCont1").addClass("dx-state-focused");

        // STR 검색 화면에서 호출 시 input disable 처리
        if ($("#approval").val() == "false") {
            setInputDisable();
        }

        // 3개월 거래내역 파일 자동으로 생성
    	/* if ($("#approval").val() == "true") {
    		addStrXlsFileTab5Action(0)
        } */
    });

    //init때 탭 이외에 부분을 클릭하면 class 삭제
	$(document).click(function(e){
     	if(vInit == "Y" &&!$(e.target).is('.dx-item, .dx-tab, .dx-state-focused, .dx-state-hover, .dx-state-active, .dx-tab-text')){
        	$("#tabPane_tabCont1").removeClass("dx-state-focused");
        	vInit = "N";
        }
	});

	/** 탭 셋업 */

    function setupTabPanel(defTabIdx)
    {
        var indx = defTabIdx || 0;
        var tabItm = $(".tab-item");
        var tabCon = $(".tab-content");

        //탭 헤드 활성 클래스 제거
        tabItm.each(function (idx,item) {
       	    $(item).removeClass("active");
        });
        //탭 영역 활성 클래스 제거 및 숨김처리
        tabCon.each(function (idx,item) {
    		$(item).removeClass("active");
    	    $(item).css("display","none");
    	});

        //선택한 index영역만 활성 처리
        $(tabItm[indx]).addClass("active");
        $(tabCon[indx]).addClass("active");
        $(tabCon[indx]).css("display","block");

        dvTab(indx);
    }
 
    function _dvTab(pageNum) {  setupTabPanel(pageNum); }

    function dvTab(pageNum)
    {
 
        tabID = pageNum;
        if (pageNum == 0) {    //basic information
        	$("#btn_02").hide();
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
        } else if(pageNum == 1) {    //Cust Details
        	$("#btn_02").hide();
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
        }else if(pageNum == 2){    //Account Details
        	$("#btn_02").hide();
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
            document.form1.pageID.value = "AML_20_01_01_07";
            document.form1.target = "AML_20_01_01_01_POP02";
            document.form1.action = "${path}/0001.do";
            document.form1.submit();
        }else if(pageNum == 3){    //Transaction Details
        	//$("#btn_02").hide();  //2025.10.20 JSW
        	$("#btn_02").show();  //2025.10.20 JSW
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
            
            document.form1.pageID.value = "AML_20_01_01_08";
            document.form1.target = "AML_20_01_01_01_POP03";
            document.form1.action = "${path}/0001.do";
            setTimeout(function(){document.form1.submit();},200);
            
            $(".dx-scrollable-scrollbar, .dx-scrollbar-vertical").remove();
            $(".dx-scrollable-container").css("overflow-y","scroll");

      /*   }else if(pageNum == 4){//AI Prediction
           	$("#sbtn_05" ).show();
        	document.form1.pageID.value = "AML_20_01_10_09";
            document.form1.target = "AML_20_01_01_01_POP05";
            document.form1.action = "<c:url value='/'/>0001.do"
            document.form1.submit(); 
        }
        else if(pageNum == 4){    //Suspicious Transaction Type-Branch
        	$("#sbtn_05" ).hide();
        	doSearch(1);
        	if($("#MASTER_BRANCH").val() == "N" && $("#approval").val() == "true") {
                if ($("#OK_CCD_CODE").val() == '' || $("#OK_CCD_CODE").val() == '0') $("#sbtn_02").hide();
                else $("#sbtn_02").show();
                $("#btn_02").show();
                $("#sbtn_03").show();
                $("#DNY_CHECK").show();

                if("${ROLE_ID}"=="3"){
                	$("#sbtn_04" ).hide();
                	$("#DNY_CHECK").hide();
                } else {
                	$("#sbtn_04" ).show();
                	$("#DNY_CHECK").show();
                }
            } else {
            	$("#btn_02").hide();
                $("#sbtn_02").hide();
                $("#sbtn_03").hide();
                $("#sbtn_04").hide();
                $("#DNY_CHECK").hide();
            }
              if("${ROLE_ID}"=="3"){
            	$("#sbtn_04" ).hide();
            	$("#DNY_CHECK").hide();
            }
           // $("#sbtn_04").hide(); */
        }else if(pageNum == 4){    //Suspicious Transaction Type(HO)
        	if("${AML_ROLE_ID}" == "3" || "${AML_ROLE_ID}" =="6"){
     		   showAlert("${msgel.getMsg('AML_20_01_10_03_120','본점담당자/본점책임자만 내용을 확인 하실 수 있습니다.')}", 'WARN');
     		   return;
     	   }else{
     		  doSearch(0);
        	$("#sbtn_05" ).hide();
            if($("#MASTER_BRANCH").val()== "Y" && $("#approval").val() == "true") {
            	if ($("#OK_CCD_CODE").val() == '' || $("#OK_CCD_CODE").val() == '0') $("#sbtn_02").hide();
                else $("#sbtn_02").show();
            	$("#btn_02").show();
                $("#sbtn_03" ).show();

                if("${ROLE_ID}"=="4" && $.inArray(actId, denyBtnActs) > -1) {
	                $("#sbtn_04" ).hide();
	                $("#DNY_CHECK").hide();
                } else {
                	$("#sbtn_04" ).show();
                	$("#DNY_CHECK").show();
                }

                $("#btn_file").show();
                //$("#DNY_CHECK").show();
            } else {
            	//$("#btn_02").hide();  //2025.10.20 JSW
            	$("#btn_02").show();  //2025.10.20 JSW
                $("#sbtn_02" ).hide();
                $("#sbtn_03" ).hide();
                $("#sbtn_04" ).hide();
                $("#btn_file").hide();
                $("#DNY_CHECK").hide();
            }
     	   }
        }else if(pageNum == 5){    //Approval History 6.협의거래 결재 진행
        	$("#btn_02").hide();
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
            document.form1.pageID.value = "AML_20_01_10_04";
            document.form1.target = "AML_20_01_01_01_POP04";
            document.form1.action = "<c:url value='/'/>0001.do"
            document.form1.submit();
            
        }else if(pageNum == 6){    // 7.수탹거부현황
        	$("#btn_02").hide();
            $("#sbtn_02").hide();
            $("#sbtn_03").hide();
            $("#sbtn_04").hide();
            $("#sbtn_05" ).hide();
            $("#DNY_CHECK").hide();
            document.form1.pageID.value = "AML_20_01_10_09";
            document.form1.target = "AML_20_01_01_01_POP09";
            document.form1.action = "<c:url value='/'/>0001.do"
            document.form1.submit();
            $(".dx-scrollable-scrollbar, .dx-scrollbar-vertical").remove();
            $(".dx-scrollable-container").css("overflow-y","scroll");
        }
    }

    /** disabled */
    function set_Suspication_able()
    {
        var temp ;
        var tempArray ;

        for (var tempi in tempArray) {
            temp = tempArray[tempi];
            var obj = document.all[temp+"_DOBT_TYP_KND_CD"];
            for (var i in obj) obj[i].disabled = true;
            var obj_Array = new Array( "ITEM_CNTNT1","ITEM_CNTNT2","ITEM_CNTNT3","ITEM_CNTNT4","ITEM_CNTNT5","ITEM_CNTNT6","XCL_RSN_CNTNT","DNY_RSN_CNTNT","RPR_RSN_CNTNT","ATT_FILE_NM","DOBT_DL_GRD_CD","SEND_DOC_NM","RE_DOC" , "DOBT_TYP_KND_CD_501","EXE_CODE");
            for (var i in obj_Array) {
                var obj2 = document.all[temp+"_"+obj_Array[i]];
                if (obj_Array[i] == "DOBT_DL_GRD_CD") {
                    for (var j in obj2) try { obj2[j].disabled = true; } catch(e) {showAlert(e,'ERR');}
                } else {
                    try { if (obj2) obj2.readOnly = true; } catch(e) {showAlert(e,'ERR');}
                }
            }
        }
    }

    // 20170307 KEOL
    function ccdChange()
    {
    	var OK_CCD = $("#OK_CCD1")[0].options[$("#OK_CCD1")[0].selectedIndex].value;

        if ("ALL"==OK_CCD) {    //셀렉트박스 선택없이 기존값 그대로 사용시 값이 'ALL'로 넘어옴
            OK_CCD = $("#OK_CCD_CODE").val();
        }

        if(form1.DNY_CHECK_VALUE.checked == true){
        	if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")){
        		form1.B_DNY_RSN_CNTNT.disabled = false;
        	}else{
       			//form1.J_DNY_RSN_CNTNT.disabled = false;
        	}
       	}else{
       		if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")) {
       			form1.B_DNY_RSN_CNTNT.disabled = true;
       			form1.B_DNY_RSN_CNTNT.value = "";
       		} else {
       			//form1.J_DNY_RSN_CNTNT.disabled = true;
       			//form1.J_DNY_RSN_CNTNT.value = "";
       		}
       	}

        if (OK_CCD == 2){
        	//보고제외인경우 보고제외 사유 입력 가능
        	 if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")){
        		 form1.B_XCL_RSN_CNTNT.disabled = false;
        		 //form1.J_XCL_RSN_CNTNT.disabled = true;
        	 }else{
        		 //form1.B_XCL_RSN_CNTNT.disabled = true;
        		 //form1.J_XCL_RSN_CNTNT.disabled = false;
        	 }
        	//form1.J_ITEM_CNTNT1.disabled = true;
        	//form1.J_ITEM_CNTNT2.disabled = true;
        	//form1.J_ITEM_CNTNT3.disabled = true;
        	//form1.J_ITEM_CNTNT4.disabled = true;
        	//form1.J_ITEM_CNTNT5.disabled = true;
        	//form1.J_ITEM_CNTNT6.disabled = true;
        	//form1.J_RPR_RSN_CNTNT.disabled = true;

        	if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")){
        	form1.B_ITEM_CNTNT1.disabled = true;
        	form1.B_ITEM_CNTNT2.disabled = true;
        	form1.B_ITEM_CNTNT3.disabled = true;
        	form1.B_ITEM_CNTNT4.disabled = true;
        	form1.B_ITEM_CNTNT5.disabled = true;
        	form1.B_ITEM_CNTNT6.disabled = true;
        	form1.B_RPR_RSN_CNTNT.disabled = true;
        	}
        }else if (OK_CCD == 0){
        	if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")){
            	form1.B_XCL_RSN_CNTNT.disabled = false;
            	form1.B_ITEM_CNTNT1.disabled = false;
            	form1.B_ITEM_CNTNT2.disabled = false;
            	form1.B_ITEM_CNTNT3.disabled = false;
            	form1.B_ITEM_CNTNT4.disabled = false;
            	form1.B_ITEM_CNTNT5.disabled = false;
            	form1.B_ITEM_CNTNT6.disabled = false;
            	form1.B_RPR_RSN_CNTNT.disabled = false;
            	} 
    	}else{
        	//보고인경우 보고제외 사유 입력 불가능
        	//form1.J_XCL_RSN_CNTNT.disabled = true;
        	//form1.J_ITEM_CNTNT1.disabled = false;
        	//form1.J_ITEM_CNTNT2.disabled = false;
        	//form1.J_ITEM_CNTNT3.disabled = false;
        	//form1.J_ITEM_CNTNT4.disabled = false;
        	//form1.J_ITEM_CNTNT5.disabled = false;
        	//form1.J_ITEM_CNTNT6.disabled = false;
        	//form1.J_RPR_RSN_CNTNT.disabled = false;
        	if($("#MASTER_BRANCH").val()== "Y" && ("${AML_ROLE_ID}" =="4" ||  "${AML_ROLE_ID}" =="5")){
        	form1.B_XCL_RSN_CNTNT.disabled = true;
        	form1.B_ITEM_CNTNT1.disabled = false;
        	form1.B_ITEM_CNTNT2.disabled = false;
        	form1.B_ITEM_CNTNT3.disabled = false;
        	form1.B_ITEM_CNTNT4.disabled = false;
        	form1.B_ITEM_CNTNT5.disabled = false;
        	form1.B_ITEM_CNTNT6.disabled = false;
        	form1.B_RPR_RSN_CNTNT.disabled = false;
        	}
        }
    }

    /* check */

    /** Input Validation */
    function checkValue( obj_name , msg )
    {

        var obj = document.form1[obj_name];
        if (obj.value == null || obj.value == "") {
            showAlert(msg+"${msgel.getMsg('AML_20_01_01_03_101','항목을 입력하십시오.')}", 'WARN');
            return false;
        }
        return true;
    }

    function chkValidat(gubun, status)
    {
    	// 20170228 추가KEOL
        var OK_CCD = $("#OK_CCD1")[0].options[$("#OK_CCD1")[0].selectedIndex].value;

    	if ("ALL"==OK_CCD) {    //셀렉트박스 선택없이 기존값 그대로 사용시 값이 'ALL'로 넘어옴
            OK_CCD = $("#OK_CCD_CODE").val();
        }

        if($("#OK_CCD_CODE").val()=="3" &&(OK_CCD == '' || OK_CCD == '0')){
       		showAlert("${msgel.getMsg('AML_20_01_01_01_064','회수 건은 결재 상태값을 다시 선택하셔야 합니다.')}", 'WARN');
       		return;
        }else if(OK_CCD == '' || OK_CCD == '0') {
            //showAlert("${msgel.getMsg('AML_20_01_10_01_003','미확인 건이 있습니다.')}", 'WARN');
            //return;
        }else if(OK_CCD == '2') {
        	if (document.form1[gubun + "_XCL_RSN_CNTNT"].value == ""){
           	    showAlert("${msgel.getMsg('AML_20_01_10_01_004','보고제외 사유를 입력하십시오.')}", 'WARN');
           	 	document.form1[gubun + "_XCL_RSN_CNTNT"].focus();
           		return false;
       		}

        	if ($("#MASTER_BRANCH").val() == "Y") {
	            var fileBoxNode =  $("#fileBox").children();
				var fileNode = "";
				var transGubn ="";
	            for (i=0; i<fileBoxNode.length; i++){
	                fileNode=$(fileBoxNode[i]).children().children();
	                transGubn=$(fileNode[4]).val();
	                if(transGubn=="Y"){
	                	showAlert("${msgel.getMsg('AML_20_01_10_03_011', '3개월 거래내역이 생성되어 있습니다. 삭제 후 진행하시기 바랍니다.')}", 'WARN');
	                    return;
	//                 	$(fileBoxNode[i]).remove();
					}
	            }
        	}
// 			return;
        }else{
        	//보고일 경우,
        	if (document.form1[gubun+"_XCL_RSN_CNTNT"].value != ""){
        		showAlert("${msgel.getMsg('AML_20_01_01_01_065', '보고제외사유를 초기화합니다.')}", 'WARN');
        		document.form1[gubun+"_XCL_RSN_CNTNT"].value = "";
        	}

        	if ($("#MASTER_BRANCH").val() == "Y" && status != 'RETURN') { // 보고일 경우 본점담당자 반려시 미체크
	            var fileBoxNode =  $("#fileBox").children();
				var fileNode = "";
				var transGubn ="";
				if(fileBoxNode.length == 0){
	               	showAlert("${msgel.getMsg('AML_20_01_10_03_010','3개월 거래내역이 생성되지 않았습니다.')}", 'WARN');
		        	return;
				}
	            for (i=0; i<fileBoxNode.length; i++){
	                fileNode=$(fileBoxNode[i]).children().children();
	                transGubn=$(fileNode[4]).val();
	                if(transGubn=="Y"){
						break;
					}
	            }
	            if (transGubn==""||transGubn=="N"){
	            	showAlert("${msgel.getMsg('AML_20_01_10_03_010','3개월 거래내역이 생성되지 않았습니다.')}", 'WARN');
		        	return;
				}
        	}
        }

        $("#OK_CCD_CODE").val(OK_CCD);

        // Input Validation
        var obj_Array = [
            [ "ITEM_CNTNT1"     , "${msgel.getMsg('AML_20_01_01_03_090','의심스러운 거래자')}"      ,true ]
           ,[ "ITEM_CNTNT2"     , "${msgel.getMsg('AML_20_01_01_03_091','거래 발생일자')}"        ,true ]
           ,[ "ITEM_CNTNT3"     , "${msgel.getMsg('AML_20_01_01_03_092','거래 발생장소(영업점)')}"   ,true ]
           ,[ "ITEM_CNTNT4"     , "${msgel.getMsg('AML_20_01_01_03_093','금융거래 수단(상품)')}"    ,true ]
           ,[ "ITEM_CNTNT5"     , "${msgel.getMsg('AML_20_01_01_03_094','금융거래 방법(특이거래)')}" ,true ]
           ,[ "ITEM_CNTNT6"     , "${msgel.getMsg('AML_20_01_01_03_095','혐의거래로 판단한 사유')}"   ,true ]
           ,[ "XCL_RSN_CNTNT"   , "${msgel.getMsg('AML_20_01_01_03_116','보고제외 또는 반려 사유')}"  ,false]
           ,[ "RPR_RSN_CNTNT"   , "${msgel.getMsg('AML_20_01_01_03_096','종합의견')}"           ,true ]
           ,[ "ATT_FILE_NM"     , "${msgel.getMsg('AML_20_01_01_03_097','첨부파일명 작성')}"       ,false]
           ,[ "DOBT_DL_GRD_CD"  , "${msgel.getMsg('AML_20_01_01_03_098','의심스러운 거래의 등급 설정')}",false]  //[radio Button]
           ,[ "SEND_DOC_NM"     , "${msgel.getMsg('AML_20_01_01_03_099','별도송부 문서명 작성')}"    ,false]
        ];
        // OK_CCD가 보고제외일 경우 RPR_RSN_CNTNT 종합의견 데이터가 없어도 저장가능하게 20170307 KEOL
        if ($("#OK_CCD_CODE").val() == 2) obj_Array[7][2] = false;
        
        // OK_CCD 미확인경우 종합의견 없어도 데이터 저장 가능하게 2025.09.29 jsw 
        if ($("#OK_CCD_CODE").val() == 0) obj_Array[7][2] = false;
        
       if($("#OK_CCD_CODE").val() == 1){
      	//금칙어체크
	 	////who, when, where, what, how, why
	 	for (i=1; i<7; i++){
			if(document.form1[gubun+"_ITEM_CNTNT"+i].value != '' ){
				if(!chkContens(document.form1[gubun+"_ITEM_CNTNT"+i],2,1000)) return false;
			}
		}

      	////종합의견
		var obj_rprRsnCntnt = document.form1[gubun+"_RPR_RSN_CNTNT"];

		if(obj_rprRsnCntnt.value != ''){
			if(obj_rprRsnCntnt.name == 'J_RPR_RSN_CNTNT' || obj_rprRsnCntnt.name == 'B_RPR_RSN_CNTNT'){
				if(!chkContens(obj_rprRsnCntnt,20,4000)) return false;
			}
		}

        for (i=0; i<obj_Array.length; i++) {
            if(obj_Array[i][2]) if(!checkValue( gubun+"_"+ obj_Array[i][0] , obj_Array[i][1] )) return false;
        }
       }

       if($("#OK_CCD_CODE").val() != 0){
    	   var obj = document.form1[gubun+"_DOBT_TYP_KND_CD"];
           try {
               var temp_check = true;
               var check_501  = false;
               var cnt = 0;
               for (var i=0; i<obj.length; i++) {
                   if (obj[i].value != "501") {
                       if (obj[i].checked) {
                       	temp_check = false;
                       	cnt++;
                       }
                   } else {
                       check_501 = obj[i].checked;
                   }
               }

               if($("#OK_CCD_CODE").val() == 1){
                   //의심스러운 거래유형 체크
                   if(cnt == 0){
                   	showAlert("${msgel.getMsg('AML_20_01_10_03_121','의심스러운 거래유형을 한개 이상 선택하셔야 합니다.')}", 'WARN');
                   	 return;
                   }
               }

               var tmp_501 = document.form1[gubun+"_DOBT_TYP_KND_CD_501"].value;
               if (tmp_501 != "") {
               	for (var i=0; i<obj.length; i++) {if (obj[i].value == "501") obj[i].checked=true; }
               } else {
                   if (!check_501) document.form1[gubun+"_DOBT_TYP_KND_CD_501"].value = "";
                   else {
                   	if ($("#OK_CCD_CODE").val() != '2') {
                   		if(!checkValue( gubun+"_DOBT_TYP_KND_CD_501" , "${msgel.getMsg('AML_20_01_01_03_100','특징 및 유형을 별도 기술하여 주시기 바랍니다.')}" )) return false;
                   	}
                   }
               }
               if (temp_check) {
               	for (var i=0; i<obj.length; i++) { if (obj[i].value == "501") obj[i].checked=true; }
               	if ($("#OK_CCD_CODE").val() != '2') {
               		if (!checkValue( gubun+"_DOBT_TYP_KND_CD_501", "${msgel.getMsg('AML_20_01_01_03_100','특징 및 유형을 별도 기술하여 주시기 바랍니다.')}" )) return false;
               	}
               }
           } catch(e) {return false;}
       }
    
        
        return true;
    }

    // 20170308 추가
    function doRprstUpdate()
    {
        window_popup_open(form2, 620, 450, '','no','no');
        form2.pageID.value          = 'AML_20_01_01_20';
        form2.AML_CUST_ID.value          = form1.DL_P_AML_CUST_ID.value;
        form2.RNM_NO_CCD_NM.value   = form1.DL_P_RNM_NO_CCD_NM.value;
        form2.CS_NM.value           = form1.DL_P_NM.value;
        form2.target                = 'AML_20_01_01_20';
        form2.action                = "${path}/0001.do";
        form2.submit();
    }

    /** Report */
    function doReport()
    {
        document.form1.pageID.value = 'AML_20_01_01_03';
        var par_SSPS_DL_CRT_DT = form1.SSPS_DL_CRT_DT.value;
        var par_SSPS_DL_ID     = form1.SSPS_DL_ID.value;
        var par_LANG_CD        = "${LANG_CD}";
        if (par_LANG_CD == "") {
            return;
        } else if ( par_LANG_CD == "ko-KR" || par_LANG_CD == "ko_KR" ) {
            par_LANG_CD = "ko_KR";
        } else if ( par_LANG_CD == "ja-JP" || par_LANG_CD == "ja_JP" ) {
            par_LANG_CD = "ja_JP";
        } else if ( par_LANG_CD == "en-US" || par_LANG_CD == "en_US" ) {
            par_LANG_CD = "en_US";
        } else if ( par_LANG_CD == "zh-CN" || par_LANG_CD == "zh_CN" ) {
            par_LANG_CD = "zh_CN";
        } else {
            par_LANG_CD = "ko_KR";
        }
        var fileName = "AML_REPORT_STR_001_" + par_LANG_CD.substring(0,2) + ".rptdesign";
        var frm = document.form1;
        var url  = "/RCServer/frameset";
            url += "?par_SSPS_DL_CRT_DT="   + par_SSPS_DL_CRT_DT;
            url += "&par_SSPS_DL_ID="       + par_SSPS_DL_ID    ;
            url += "&__report="             + "rcreport/report/" + fileName;
            url += "&__format="             + "pdf";        //[pdf][html]
            url += "&__locale="             + par_LANG_CD;  //ja_JP, ko_KR
            url += "&__showtitle="          + "false";
            url += "&__title="              + "STR Report";
        window_popup_open('AML_20_01_01_POP', 1000, 700, url);
    }


    function doClose()
    {
        doParentReload();
        window.close();
    }

    function doParentReload()
    {
        //AML_20_01_10_01.jsp(STR결재에서 넘어온 팝입일 경우 + 결재 또는 반려를 했을경우에만 부모창새로고침 하도록 수정) 20170404 KEOL
       if($('#parentViewId').val().trim() == ""){
	        if ($("#approval").val() && modify) {
	            //window.opener.location.href = window.opener.document.URL;    // 부모창 새로고침
	            try{
		        	window.opener.doSearch();
	            }catch(e){
	            	showAlert(e, 'WARN');
	            }
	        }
       } else{
    	   if($('#parentViewName').val().indexOf("결재") >-1){
	    	   window.opener.openerView.refreshPage();
    	   }
       }
    }

    /** Save */
    function doSave()
    {
    	var frm = document.form1;
        if ($("#MASTER_BRANCH").val() == "Y") {
            //_dvTab(6);
            gubun = "B";  // Head office
        } else {
            //_dvTab(5);
            gubun = "J";  // branch
        }

        var obj_Array = [
            [ "ITEM_CNTNT1"     , "${msgel.getMsg('AML_20_01_01_03_090','의심스러운 거래자')}"      ,true ]
           ,[ "ITEM_CNTNT2"     , "${msgel.getMsg('AML_20_01_01_03_091','거래 발생일자')}"        ,true ]
           ,[ "ITEM_CNTNT3"     , "${msgel.getMsg('AML_20_01_01_03_092','거래 발생장소(영업점)')}"   ,true ]
           ,[ "ITEM_CNTNT4"     , "${msgel.getMsg('AML_20_01_01_03_093','금융거래 수단(상품)')}"    ,true ]
           ,[ "ITEM_CNTNT5"     , "${msgel.getMsg('AML_20_01_01_03_094','금융거래 방법(특이거래)')}" ,true ]
           ,[ "ITEM_CNTNT6"     , "${msgel.getMsg('AML_20_01_01_03_095','혐의거래로 판단한 사유')}"   ,true ]
           ,[ "XCL_RSN_CNTNT"   , "${msgel.getMsg('AML_20_01_01_03_116','보고제외 또는 반려 사유')}"  ,true ]
           ,[ "RPR_RSN_CNTNT"   , "${msgel.getMsg('AML_20_01_01_03_096','종합의견')}"           ,true ]
           ,[ "ATT_FILE_NM"     , "${msgel.getMsg('AML_20_01_01_03_097','첨부파일명 작성')}"       ,false]
           ,[ "DOBT_DL_GRD_CD"  , "${msgel.getMsg('AML_20_01_01_03_098','의심스러운 거래의 등급 설정')}",false]  //[radio Button]
           ,[ "SEND_DOC_NM"     , "${msgel.getMsg('AML_20_01_01_03_099','별도송부 문서명 작성')}"    ,false]
        ];
        var obj = document.form1[gubun + "_DOBT_TYP_KND_CD"];

        var OK_CCD = $("#OK_CCD1")[0].options[$("#OK_CCD1")[0].selectedIndex].value;


	    if (!chkValidat(gubun)) return;

	    var userGridData = new Array();
        for (var i in obj_Array) {
            var obj_param = new Object();
            obj_param.GUBUN = gubun;
            obj_param.TYPE  = "TEXT";
            obj_param.NAME  = obj_Array[i][0];
            obj_param.CODE  = "";
            if(obj_Array[i][0] == "DOBT_DL_GRD_CD") /* radio */ obj_param.VALUE = getCheckedRadio( gubun+"_"+obj_Array[i][0] );
            else if (obj_Array[i][0] == "ATT_FILE_NM") {}
            else {
            	try{
            	obj_param.VALUE = $("#"+gubun+"_"+obj_Array[i][0]).val();
            	} catch (e){
            		showAlert(gubun+"_"+obj_Array[i][0] + " " + e,"WARN");
            	}
            }
            obj_param.ETC = "";
            userGridData.push(obj_param);
        }
        for(i=0; i<obj.length; i++){
           if (obj[i].checked) {
                var obj_param = new Object();
                obj_param.GUBUN = gubun;
                obj_param.TYPE  = "CHECK";
                obj_param.NAME  = "DOBT_TYP_KND_CD";
                obj_param.CODE  = obj[i].value;
                obj_param.VALUE = "Y";
                if( obj[i].value == "501" ) {
                    obj_param.ETC = document.form1[gubun + "_DOBT_TYP_KND_CD_501"].value ;
                } else {
                    obj_param.ETC = "";
                }
                userGridData.push(obj_param);
            }
        }

        //보고인경우 보고제외 사유 공백 처리
        if(OK_CCD == 1){
        	$("#B_XCL_RSN_CNTNT").val() == "";
        	$("#J_XCL_RSN_CNTNT").val() == "";
        }
		//~~~~~~~~~~~~ 첨부파일 담기 START ~~~~~~~~~~~~
		var fileCnt = $("input[name='origFileNms']").length;

		for(var i=0; i<fileCnt; i++) {
			var obj_param = new Object();
			obj_param.TYPE  			= "FILE";
			obj_param.FILE_SIZE 		= $("input[name='fileSizes']")[i].value;
			obj_param.ORIG_FILE_NM 		= $("input[name='origFileNms']")[i].value;
			obj_param.STORED_FILE_NM 	= $("input[name='storedFileNms']")[i].value;
			obj_param.FILE_PATH 		= $("input[name='filePaths']")[i].value;

			userGridData.push(obj_param);
		}
		//~~~~~~~~~~~~ 첨부파일 담기 END ~~~~~~~~~~~~
		 showConfirm("${msgel.getMsg('AML_20_01_10_01_008','저장 처리를 하시겠습니까?')}", "저장", function(){doSaveAction(userGridData)});
    }

    function doSaveAction(userGridData) {
    	var actionParam     = {
            pageID          : form1.pageID.value
           ,classID         : "AML_20_01_10_03"
           ,methodID        : "doSave"
           ,SSPS_DL_ID      	: $("#SSPS_DL_ID"      	  ).val()    // 혐의거래ID
           ,SSPS_DL_CRT_DT	: $("#SSPS_DL_CRT_DT" ).val()    // 혐의거래일
           ,MN_DL_BRN_CD	: $("#MN_DL_BRN_CD"    ).val()    // 선택지점 코드
           ,MASTER_BRANCH	: $("#MASTER_BRANCH"  ).val()    // 본사구분
           ,OK_CCD          : $("#OK_CCD_CODE"     ).val()
           ,XCL_RSN_CNTNT	: $("#MASTER_BRANCH").val()=="Y"?$("#B_XCL_RSN_CNTNT" ).val():$("#J_XCL_RSN_CNTNT").val()		// 보고제외 사유
           ,RPR_RSN_CNTNT	: $("#MASTER_BRANCH").val()=="Y"?$("#B_RPR_RSN_CNTNT" ).val():$("#J_RPR_RSN_CNTNT").val()		// 종합의견
           ,gridData        : userGridData
        }
    	sendService(actionParam.classID, actionParam.methodID, actionParam, doSave_end, doSearch_fail);
    }

    function doSave_end(actionParam, jsonResultData)
    {
   		window.opener.doSearch();
		location.reload();
    }

    // 팝업에서 바로 결재처리 20170301 KEOL
    function doSave1()
    {
        gubun = $("#MASTER_BRANCH").val()=="Y"?"B":"J"; // "B":Head office, "J":branch
        if (chkValidat(gubun)) {
        	showConfirm("${msgel.getMsg('AML_20_01_10_01_002','결재 처리를 하시겠습니까?')}", "결재", doSave1Action);
        	document.form1[gubun + "_DNY_RSN_CNTNT"].value = "";
        }
    }

    function doSave1Action(){
   
    	 var actionParam = {
             pageID          : form1.pageID.value
            ,classID         : "AML_20_01_10_03"
            ,methodID        : "doSave1"
            ,SSPS_DL_CRT_DT  : $("#SSPS_DL_CRT_DT"  ).val()
            ,SSPS_DL_ID      : $("#SSPS_DL_ID"      ).val()
            ,OK_CCD          : $("#OK_CCD_CODE"     ).val()
            ,MN_DL_BRN_CD    : $("#MN_DL_BRN_CD"    ).val()
            ,XCL_RSN_CNTNT   : $("#MASTER_BRANCH").val()=="Y"?$("#B_XCL_RSN_CNTNT" ).val():$("#J_XCL_RSN_CNTNT").val()
            ,RPR_RSN_CNTNT   : $("#MASTER_BRANCH").val()=="Y"?$("#B_RPR_RSN_CNTNT").val():$("#J_RPR_RSN_CNTNT").val()
            ,INST_ID         : $("#INST_ID").val()
            ,WORK_ID         : $("#WORK_ID").val()
         }
    	 sendService(actionParam.classID, actionParam.methodID, actionParam, doSave1Action_success, doSearch_fail);
    }

    function doSave2()
    {
        gubun = $("#MASTER_BRANCH").val()=="Y"?"B":"J"; // "B":Head office, "J":branch
        if (!chkValidat(gubun, 'RETURN') ) return;

        if (document.form1["DNY_CHECK_VALUE"].checked == false || document.form1[gubun + "_DNY_RSN_CNTNT"].value.length == 0) {
            showAlert("${msgel.getMsg('AML_20_01_10_03_117','반려 사유를 입력하십시오.')}", 'WARN');
            document.form1[gubun + "_DNY_RSN_CNTNT"].value = "";
            document.form1[gubun + "_DNY_RSN_CNTNT"].disabled = false;
            document.form1["DNY_CHECK_VALUE"].checked = true;
            return;
        }
        showConfirm("${msgel.getMsg('AML_20_01_10_01_005','반려 처리를 하시겠습니까?')}", "반려", doSave2Action);
    }

    function doSave2Action(){
    
        var obj = new Object();
        obj.pageID          = document.form1.pageID.value;
        obj.classID         = "AML_20_01_10_03";
        obj.methodID        = "doSave2";
        obj.SSPS_DL_CRT_DT  = $("#SSPS_DL_CRT_DT"  ).val()
        obj.SSPS_DL_ID      = $("#SSPS_DL_ID"      ).val()
        obj.OK_CCD          = $("#OK_CCD_CODE"     ).val()
        if($("#MASTER_BRANCH").val()=="Y") {
            obj.DNY_RSN_CNTNT = $("#B_DNY_RSN_CNTNT").val()
        } else {
            obj.DNY_RSN_CNTNT = $("#J_DNY_RSN_CNTNT").val()
        }
        obj.INST_ID = $("#INST_ID").val()
        obj.WORK_ID = $("#WORK_ID").val()
   	   sendService(obj.classID, obj.methodID, obj, doSave1Action_success, doSearch_fail);
   }

    function doSave1Action_success(actionParam, jsonResultData)
    {
    	 
    	refreshApprovalCount();
        modify = true;
        doClose();
    }

    /** Search */
    var gubn = "";
    function doSearch(gubun)
    {
    	//overlay.show(true, true);
    	gubn = gubun;
    	var params = new Object();
		var methodID = "getSuspication";
		params.pageID = pageID;
		params.GUBUN = gubun==0?"B":"J";
		params.MASTER_BRANCH  = $("#MASTER_BRANCH"      ).val();
		params.SSPS_DL_CRT_DT =  $("#SSPS_DL_CRT_DT"      ).val();
		params.SSPS_DL_ID =  $("#SSPS_DL_ID"      ).val();
		params.SSPS_TYP_CD  =  $("#SSPS_TYP_CD"      ).val();
		params.MN_DL_BRN_CD  = $("#MN_DL_BRN_CD"      ).val();
		params.DL_P_NM = $("#DL_P_NM"      ).val();
		params.AML_CUST_ID =  $("#AML_CUST_ID"      ).val();
		params.MN_DL_BRN_CD_NM = $("#MN_DL_BRN_CD_NM option:selected").text();
		sendService("AML_20_01_01_03", methodID, params, doSearch_success, doSearch_fail);
    }

    function doSearch_success(gridData, data)
    {
    	var temp1 = gubn==0?"B":"J";
        var obj_OBT_TYP_KND = document.all[temp1 + "_DOBT_TYP_KND_CD"];
        for (var i in gridData) {
            var obj     = gridData[i];
            var v_GUBUN = obj.GUBUN;
            var v_TYPE  = obj.TYPE;
            var v_NAME  = obj.NAME;
            var v_CODE  = obj.CODE;
            var v_VALUE = obj.VALUE;
            var v_ETC   = obj.ETC;
            try {
            	if (v_TYPE == "TEXT" && v_NAME == "B_TRIG_CTNT") {
            		$("textarea[name=B_RPR_RSN_CNTNT").val(v_VALUE);
                }else if (v_TYPE == "TEXT") {
                	$("#"+v_NAME).val(v_VALUE);
                    $("*[name="+v_NAME+"]").val(v_VALUE);
                } else if (v_TYPE == "RADIO") {
                    setCheckedRadio( v_NAME , v_VALUE , true);
                } else if (v_TYPE == "CHECK") {
                    // (code(501)) Exception
                    if (v_CODE == "501") {
                        $("#"+v_NAME+"_501").val(v_ETC);
                        $("input[name="+v_NAME+"_501]").val(v_ETC);
                    }
                    for (j=0; obj_OBT_TYP_KND&&j<obj_OBT_TYP_KND.length; j++) {
                        if (obj_OBT_TYP_KND[j].value == v_CODE) {
                            if(v_VALUE =="Y") {
                                obj_OBT_TYP_KND[j].checked = true;
                                break;
                            }
                        }
                    }
                }
            } catch(e) {
                showAlert(e, 'ERR');
            }
        }

        calcBytes(temp1);
        //overlay.hide();
    }

    function doSearch_fail(data){
    	overlay.hide();
    }

    function setValueCompany(obj)
    {
        $("#company_COL0").val() = obj.company_COL0; // Representative Owner Name
        $("#company_COL1").val() = obj.company_COL1; // Representative Owner SSN Type
        $("#company_COL2").val() = obj.company_COL2; // Representative Owner SSN
        $("#company_COL3").val() = obj.company_COL3; // Representative Owner Nationality
        $("#company_COL5").val() = obj.company_COL5; // Representative Owner Phone Number
        $("#company_COL6").val() = obj.company_COL6; // Representative Owner House Postal Number/Address
    }

	//~~~~~~~~~ 첨부파일 START ~~~~~~~~~
	function downloadFile( dFileNm, oFileNm, fPath, FILE_SEQ)
    { 
	    try {

        	$("#BOARD_ID"           ,"form[name=form1]").val($("#SSPS_DL_CRT_DT","form[name=form1]").val());
            $("#BOARD_SEQ"          ,"form[name=form1]").val($("#SSPS_DL_ID"    ,"form[name=form1]").val());
            $("input[name=FILE_NO]" ,"form[name=form1]").val(FILE_SEQ);
            $("#FILE_TYPE"          ,"form[name=form1]").val("AML_20");

            form1.target = "_self";
            form1.action =  "<c:url value='/'/>0001.do?pageID=fileDownloadAML" ;
            form1.method = "post";
            form1.submit();
        } catch (e) {
            showAlert(e, 'WARN');
        }
    }
	
    /* function downloadFile( dFileNm, oFileNm, fPath, temp)
    {
	    try {
        	$("[name=pageID]"     ,"form[name=fileFrm]").val(pageID);
        	$("#downType"        ,"form[name=fileFrm]").val();		//파일타입
        	$("#downFileName"     ,"form[name=fileFrm]").val(dFileNm);		//파일물리이름
        	$("#orgFileName"        ,"form[name=fileFrm]").val(oFileNm);		//파일논리이름
        	$("#downFilePath"        ,"form[name=fileFrm]").val(fPath);		//파일경로

        	fileFrm.target = "_self";
        	fileFrm.action = "${ctx}/common/fileDownload.do";
        	fileFrm.method = "post";
        	fileFrm.submit();
        } catch (e) {
            showAlert(e, 'WARN');
        }
    } */

  //입력한 내용 금칙어 및 제한글자수 체크
    function chkContens(obj,limitLen,limitLen2){

        if(obj.value == ''){
            return false;
        }

        var vContens = obj.value.trim();
        var valLen = vContens.length;
        var valBytes = strByteLength(vContens);

        //금칙어체크
        if(isNotGoodWord(vContens)){
            // ', " 는 제외 
        	showAlert("${msgel.getMsg('AML_20_01_10_03_006','내용에 금칙어가 포함되어있습니다.')}"+"( < > &  "+" ; \\ )", 'WARN');
            return false;
        }

        //최소글자수
        if(obj.name == 'J_RPR_RSN_CNTNT' || obj.name == 'B_RPR_RSN_CNTNT'){
	        if(valBytes < limitLen){
	        	 showAlert("${msgel.getMsg('AML_20_01_10_03_004','종합의견 내용은 20자 이상 입력하십시오.')}", 'WARN');
	            return false;
	        }
        }

        //최대글자수
        if(limitLen2 == 6000){
        	if(valLen > 3000){
            	showAlert("${msgel.getMsg('AML_20_01_10_03_005','종합의견 내용의 길이가 초과되었습니다.')}"+" (3,000 자 초과)", 'WARN');
                return false;
            }
        }else{
        	if(valBytes > limitLen2){
            	showAlert("${msgel.getMsg('AML_20_01_10_03_007','의심내역 중  길이가 초과된 항목이 있습니다.')}"+" (1,000 바이트 초과)", 'WARN');
                return false;
            }
        }

        return true;
    }

  	//금칙어 체크(<,>,&,',\,",;)
    function isNotGoodWord (val)
    {
        if (isEmpty(val)) return false;

        var chkVal = "<>&;\\";

        for (var i = 0; i < chkVal.length; i++)
        {
            for (var j = 0; j < val.length; j++){
                if (chkVal.charAt(i).indexOf( val.charAt(j) ) > -1) return true;
            }
        }

        return false;
    }

    function calcBytes(gubun){
        var obj = document.form1[gubun + "_RPR_RSN_CNTNT"];
        var obj_bytes = document.form1[gubun + "_RPR_RSN_CNTNT_BYTES"];

        if(obj.value == ''){
        	obj_bytes.value = '0/3000 자';
        	return;
        }

        var vContens = obj.value.trim();
        var valBytes = strByteLength(vContens);
        var end_val = "/3000 자";
        obj_bytes.value = valBytes+end_val;
        document.form1[gubun + "_RPR_RSN_CNTNT_BYTES"].value = obj_bytes.value  ;
    }
    
    function strByteLength(s) {
    	var str = s;
    	var returnByte = 0;
    	var tmp = 0;
    	
    	for(var i=0; i<str.length; i++) {
    		if(str.charCodeAt(i) > 128)
    			tmp = 1;  // 2byte 문자로 1글자로 계산
    		else
    			tmp = 1; 
    		
    		returnByte = returnByte + tmp;
    	}

    	return returnByte;
    }

    function doSearchStrXlsFile(gb) {
		overlay.show(true, true);

    	if(gb == null) gb = "1";

		new GTActionRun().run({
			actionParam     : {
	                "pageID"        : "AML_20_01_10_03"
	               ,"classID"       : "AML_20_01_10_03"
	               ,"methodID"      : "doSearchFileTrList"
	               ,"stDate"        : $("#stDate"        ).val()
	               ,"edDate"        : $("#edDate"        ).val()
	               ,"SSPS_DL_CRT_DT": $("#SSPS_DL_CRT_DT").val()
	               ,"SSPS_DL_ID"    : $("#SSPS_DL_ID"    ).val()
			}
			,completedEvent : function(actionParam, jsonResultData){

				var strFileNm = jsonResultData.GRID_DATA[0].STR_FILE_NM;
				var strFileFlag = jsonResultData.GRID_DATA[0].STR_FILE_FLAG;

				$("#STR_FILE_FLAG").val(strFileFlag);
				if(strFileFlag == "N") {
					//STR 3개월 거래내역을 추출하여 XLS 파일 생성후 화면에 파일정보를 보여준다.
					new GTActionRun().run({
						actionParam     : {
							"pageID"		 : "AML_20_01_10_03"
						   ,"stDate"         : $("#stDate"                ).val()
	                       ,"edDate"         : $("#edDate"                ).val()
	                       ,"SSPS_DL_CRT_DT" : $("#SSPS_DL_CRT_DT"        ).val()
	                       ,"SSPS_DL_ID"     : $("#SSPS_DL_ID"            ).val()
	                       ,"DL_P_RNMCNO"    : $("input[name=DL_P_RNMCNO]").val()
						}
	                   ,runAction       : "com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03_Kofiu_Action"
	                   ,completedEvent  : function(paramdata,jsonData){
							var arrValue = jsonData.fileContent;

							if(arrValue != undefined) {
								for(var j=0; j<arrValue.length; j++){
									var addLine;
								    var divId = arrValue[j].storedFileNms.substring(0,arrValue[j].storedFileNms.lastIndexOf("."));

						      		addLine	= "<div id='"+divId+"'  style='height:30px;text-align:left;background-color:#FFFFFF;'>"
						      			+"<i class='fa fa-floppy-o' style='font-size: 14px;padding:6px 5px;' aria-hidden='true'></i>&nbsp;&nbsp;"
										+ arrValue[j].origFileNms
										//+" <a onclick=\"tempFileDel('"+divId+"','/upload/attachTmp/','"+arrValue[j].storedFileNms+"');\" >"
										+"<input type='hidden' name='fileSizes' id='fileSizes' value='"+arrValue[j].fileSizes+"' />"
										+"<input type='hidden' name='origFileNms' id='origFileNms' value='"+arrValue[j].origFileNms+"' />"
										+"<input type='hidden' name='storedFileNms' id='storedFileNms' value='"+arrValue[j].storedFileNms+"' />"
										+"<input type='hidden' name='filePaths' id='filePaths' value='"+arrValue[j].filePaths+"' />"
										//+"<div class='dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon' style='margin-left: 10px; margin-top:0.2em;'  role='button' aria-hidden='true' aria-label='close'>"
										//+"	<div class='dx-button-content'>&nbsp;<i class='dx-icon dx-icon-close'></i></div>"
										//+"</div>"
										//+"</a>"
										+"</div>";
					      			$("#fileBox").append(addLine);
								}
							}
						}
					});
				} else {
					var origFilenmLng = $("input[name='origFileNms']").length;

					for(var i=0; i<origFilenmLng; i++) {
						var fileTemp = $("input[name='origFileNms']")[i].value;
						if(fileTemp == strFileNm) {
							$(".strFlag"+i).hide();
						} else {
							$(".strFlag"+i).show();
						}
					}

				}
			}
		});
    }

    function doOpenerSwitch(){
    	if (opener) {
            try {
            	var st_dt = document.form1.ST_DT.value;
            	var ed_dt = document.form1.ED_DT.value;
            	var gnl_ac_no = "${GNL_AC_NO}";
            	var gds_no = document.form1.GDS_NO.value;
            	var dl_sq = document.form1.DL_SQ.value;
            	var DL_P_AML_CUST_ID = "${DL_P_AML_CUST_ID}";
            	var ssps_dl_id = $("#SSPS_DL_ID"    ).val();
            	opener.goAIResult(st_dt, ed_dt, gnl_ac_no, gds_no, dl_sq, DL_P_AML_CUST_ID, ssps_dl_id);
            } catch (e) {
                showAlert(e, 'ERR');
            } finally {
//                 setTimeout(function(){self.close();},500);
            }
        }
    }

    function setInputDisable() {
        // 지점의심내역 disable
        for (element of document.getElementsByName("J_DOBT_TYP_KND_CD")) {
            element.disabled = true;
        }
        for (element of document.getElementsByName("J_DOBT_DL_GRD_CD")) {
            element.disabled = true;
        }
        for (element of document.getElementsByName("J_DOBT_TYP_KND_CD_501")) {
            element.disabled = true;
        }
        for (var i = 1; i < 7; i++) {
            document.getElementById("J_ITEM_CNTNT" + i).disabled = true;
        }
        document.getElementById("J_SEND_DOC_NM").disabled = true;
        document.getElementById("J_RPR_RSN_CNTNT").disabled = true;
        document.getElementById("J_AI_RPR_RSN_CNTNT_BATCH").disabled = true;
        document.getElementById("J_AI_RPR_RSN_CNTNT").disabled = true;
        document.getElementById("J_applyAIopiBtn_Batch").disabled = "disabled";
        document.getElementById("J_createAIopiBtn").disabled = "disabled";

        // 본점의심내역 disable
        for (element of document.getElementsByName("B_DOBT_TYP_KND_CD")) {
            element.disabled = true;
        }
        for (element of document.getElementsByName("B_DOBT_DL_GRD_CD")) {
            element.disabled = true;
        }
        for (element of document.getElementsByName("B_DOBT_TYP_KND_CD_501")) {
            element.disabled = true;
        }
        for (var i = 1; i < 7; i++) {
            document.getElementById("B_ITEM_CNTNT" + i).disabled = true;
        }
        document.getElementById("B_SEND_DOC_NM").disabled = true;
        document.getElementById("B_RPR_RSN_CNTNT").disabled = true;
        document.getElementById("B_AI_RPR_RSN_CNTNT_BATCH").disabled = true;
        document.getElementById("B_AI_RPR_RSN_CNTNT").disabled = true;
        document.getElementById("B_applyAIopiBtn_Batch").disabled = "disabled";
        document.getElementById("B_createAIopiBtn").disabled = "disabled";

    }


	function refreshApprovalCount()
	{
	    if (opener) {
	        if (opener.opener) {
	            if (opener.opener.parent.getApprovalCount) opener.opener.parent.getApprovalCount();
	        } else if (opener.parent.getApprovalCount) opener.parent.getApprovalCount();
	    } else if (parent.getApprovalCount) parent.getApprovalCount();
	}

</script>

<!-- 파일 삭제, 다운로드 -->
<form name="fileFrm" id="fileFrm" method="POST">
<input type="hidden" name="pageID" />
<input type="hidden" name="downFileName" id="downFileName" value="" />
<input type="hidden" name="orgFileName" id="orgFileName" value="" />
<input type="hidden" name="downFilePath" id="downFilePath" value="" />
<input type="hidden" name="downType" id="downType" value="STR" />
</form>

<form name="form2" method="post">
    <input type="hidden" name="pageID"          />
    <input type="hidden" name="RNMCNO"          />
    <input type="hidden" name="RNM_NO_CCD_NM"   />
    <input type="hidden" name="CS_NM"           />
</form>

<form name="form1" id="form1" method="post">
    <input type="hidden" name="pageID"          id="pageID"         />
    <input type="hidden" name="classID"         id="classID"        />
    <input type="hidden" name="methodID"        id="methodID"       />
    <input type="hidden" name="INST_ID"         id="INST_ID" value="${INST_ID}"/>
    <input type="hidden" name="FILE_POS"        id="FILE_POS"       />
    <input type="hidden" name="USER_FILE_NM"    id="USER_FILE_NM"   />
    <input type="hidden" name="BOARD_ID"        id="BOARD_ID"       />
    <input type="hidden" name="BOARD_SEQ"       id="BOARD_SEQ"      />
    <input type="hidden" name="FILE_TYPE"       id="FILE_TYPE"      />
    <input type="hidden" name="FILE_POS_M"                          />
    <input type="hidden" name="FILE_NO"                             />
    <input type="hidden" name="STR_FILE_FLAG"  id="STR_FILE_FLAG" />
<!-- ${msgel.getMsg('AML_20_01_01_03_102','개인법인구분코드')}_A040 [1] ${msgel.getMsg('AML_20_01_01_03_103','개인')} [2] ${msgel.getMsg('AML_20_01_01_03_104','법인')} -->
    <input type="hidden" name="INDV_CORP_CCD"   id="INDV_CORP_CCD"  value="${INDV_CORP_CCD}"/>
    <input type="hidden" name="DL_P_RNMCNO"     id="DL_P_RNMCNO"    value="${DL_P_RNMCNO}"  />
    <input type="hidden" name="GNL_AC_NO"       id="GNL_AC_NO"      value="${GNL_AC_NO}"    />
<!-- MASTER_BRANCH ${msgel.getMsg('AML_20_01_01_03_105','본점지점 여부')} [Y] [N] -->
    <input type="hidden" name="MASTER_BRANCH"   id="MASTER_BRANCH"  value="${MASTER_BRANCH}"/>
    <input type="hidden" name="BDPT_CD"         id="BDPT_CD"        value="${BDPT_CD}"      />
<!-- ${msgel.getMsg('AML_20_01_01_03_106','진행상태')} -->
    <input type="hidden" name="RPR_PRGRS_CCD"   id="RPR_PRGRS_CCD"  value="${RPR_PRGRS_CCD}"/>
    <input type="hidden" name="AML_ROLE_ID"     id="AML_ROLE_ID"    value="${ROLE_ID}"      />
    <input type="hidden" name="OK_CCD_CODE"     id="OK_CCD_CODE"    value="${OK_CCD_CODE}"  />
    <input type="hidden" name="WORK_ID"         id="WORK_ID"        value="${WORK_ID}"      />
    <input type="hidden" name="ACT_ID"          id="ACT_ID"         value="${ACT_ID}"       />
    <input type="hidden" name="approval"        id="approval"       value="${approval}"     />
    <input type="hidden" name="stDate"          id="stDate"         value=" ${stDate}"      />
    <input type="hidden" name="edDate"          id="edDate"         value=" ${edDate}"      />
    <input type="hidden" name="CS_NO_VIEW"      id="CS_NO_VIEW"     value=" ${CS_NO_VIEW}"  />
    <input type="hidden" name="ctlBtn02"        id="ctlBtn02"       value=" ${ctlBtn02}"    />
    <input type="hidden" name="FILE_SEQ_A"      id="FILE_SEQ_A"                             />
    <input type="hidden" name="DL_DT"           id="DL_DT"          value=""                />
    <input type="hidden" name="ST_DT"           id="ST_DT"          value=""                />
    <input type="hidden" name="ED_DT"           id="ED_DT"          value=""                />
    <input type="hidden" name="GDS_NO"          id="GDS_NO"         value=""                />
    <input type="hidden" name="DL_SQ"           id="DL_SQ"          value=""                />
    <input type="hidden" name="parentViewId"    id="parentViewId"  value=" ${parentViewId}"  />
    <input type="hidden" name="parentViewName"  id="parentViewName"  value=" ${parentViewName}"  />
    <div class="inquiry-table2 rowtype">
        <div class="table-row">
          <div class="table-cell">
            <div class="title">
            ${msgel.getMsg('AML_20_01_01_03_003','혐의거래ID')}
            </div>
            <div class="content">
              <input name="SSPS_DL_ID"     id="SSPS_DL_ID"     type="text"   value="${SSPS_DL_ID}" size="20" readonly="readonly" />
                <input name="SSPS_DL_CRT_DT" id="SSPS_DL_CRT_DT" type="hidden" value="${SSPS_DL_CRT_DT}" />
            </div>
          </div>
        <div class="table-cell">
            <div class="title">
              ${msgel.getMsg('AML_20_01_01_03_004','혐의코드')}
            </div>
            <div class="content">
              <input name="SSPS_TYP_CD" id="SSPS_TYP_CD" type="text" value="${SSPS_TYP_CD}" size="20" readonly="readonly">
            </div>
          </div>
          <div class="table-cell row2">
            <div class="title">
              ${msgel.getMsg('AML_20_01_01_03_005','혐의명')}
            </div>
            <div class="content">
              <input name="SSPS_TYP_NM" id="SSPS_TYP_NM" type="text" value="${SSPS_TYP_NM}" size="70" readonly="readonly">
            </div>
          </div>
        </div>
        <div class="table-row">
           <div class="table-cell">
            <div class="title">
              ${msgel.getMsg('AML_20_01_01_03_006','실명확인구분')}
            </div>
            <div class="content">
               <input name="DL_P_RNM_NO_CCD" type="hidden" value="${DL_P_RNM_NO_CCD}">
                <input name="DL_P_RNM_NO_CCD_NM" id="DL_P_RNM_NO_CCD_NM" type="text" class="" value="${DL_P_RNM_NO_CCD_NM}" size="20" readonly="readonly">
            </div>
          </div>
           <div class="table-cell">
            <div class="title">
               ${msgel.getMsg('AML_20_01_10_03_301','실명번호')}
            </div>
            <div class="content">
               <input name="CS_NO" id="CS_NO" type="text" value="${CS_NO_VIEW}" size="20" readonly="readonly">
            </div>
          </div>
            <div class="table-cell">
              <div class="title">
                 ${msgel.getMsg('AML_20_01_01_03_008','고객명')}
              </div>
              <div class="content">
                 <input name="DL_P_NM" id="DL_P_NM" type="text" value="${DL_P_NM}" size="20" readonly="readonly">
              </div>
                </div>
              <div class="table-cell">
	              <div class="title">
	                 ${msgel.getMsg('AML_20_01_01_03_009','계좌번호')}
	              </div>
	              <div class="content">
	                 <input name="ACNT_NO" id="ACNT_NO" type="text" value="<c:out value='${ACNT_NO}'/>" size="20" readonly="readonly">
	              </div>
              </div>
        </div>
     </div>
            <ul class="tab-list" style="margin-top:5px">
              <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_20_01_01_03_010','고객알기상세')}</button>
              </li>
              <li class="tab-item">
                <button name="custInfoDiv" type="button"></button>
              </li>
              <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_20_01_01_03_013','계좌상세')}</button>
              </li>
              <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_20_01_01_03_014','거래상세')}</button>
              </li>
              <%-- <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_21_01_01_01_004','AI 예측 위험도')}</button>
              </li> --%>
              <%-- <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_20_01_01_03_015','지점의심내역')}</button>
              </li> --%>
              <li class="tab-item">
		        <button type="button">${msgel.getMsg('AML_20_01_01_03_016','본점의심내역')}</button>
              </li>
              <li class="tab-item">
                <button type="button">${msgel.getMsg('AML_20_01_01_03_067','혐의거래 결재진행')}</button>
              </li>
              <li class="tab-item">
                <button type="button">수탁거부현황</button>
              </li>
            </ul>
            <div class="tab-area" style="height:68vh;overflow-y: auto;padding-top:5px;">
	          <div>
	                  <div class="tab-content" style="display:none"><%@ include file="_AML_20_01_10_03_tab1.jsp"%></div>
	                  <div class="tab-content" style="display:none"><%@ include file="_AML_20_01_10_03_tab2.jsp"%></div>
	                  <div class="tab-content" style="display:none"><iframe name="AML_20_01_01_01_POP02" id="AML_20_01_01_01_POP02" style="width:100%;height:calc(100vh - 1px);border:0;"></iframe></div>
	                  <div class="tab-content" style="display:none"><iframe name="AML_20_01_01_01_POP03" id="AML_20_01_01_01_POP03" style="width:100%;height:calc(100vh - 1px);border:0;"></iframe></div>
	                  <!-- <div class="tab-content" style="display:none"><iframe name="AML_20_01_01_01_POP05" id="AML_20_01_01_01_POP05" style="width:100%;height:calc(100vh - 200px);border:0;"></iframe></div> -->
	                  <%-- <div class="tab-content" style="display:none"><%@ include file="_AML_20_01_10_03_tab4.jsp"%></div> --%>
	                  <div class="tab-content" style="display:none">
	                  <%if("3".equals(AML_ROLE_ID) || "6".equals(AML_ROLE_ID)){ %>
						  <div title="${msgel.getMsg('AML_20_01_01_03_016','본점의심내역')}">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${msgel.getMsg('AML_20_01_10_03_120','본점담당자/본점책임자만 내용을 확인 하실 수 있습니다.')}</div>
					  <%}else{ %>
	                       <%@ include file="_AML_20_01_10_03_tab5.jsp"%>
	                  <%} %>
	                  </div>
	                  <div class="tab-content" style="display:none"><iframe name="AML_20_01_01_01_POP04" id="AML_20_01_01_01_POP04" style="width:100%;height:calc(100vh - 1px);border:0;"></iframe></div>
	                  <div class="tab-content" style="display:none"><iframe name="AML_20_01_01_01_POP09" id="AML_20_01_01_01_POP09" style="width:100%;height:calc(60vh - 10px);border:0;"></iframe></div>
	         </div>
         </div>
      <div class="button-area" style="display:flex;justify-content:flex-end;margin-top:10px;margin-right: 30px;">
    	<span id ="DNY_CHECK" style="margin-right:8px;">
    	<input type="checkbox" name="DNY_CHECK_VALUE" id="DNY_CHECK_VALUE" onChange='ccdChange()' >
    	 <label for="DNY_CHECK_VALUE" style="padding-left:23px;top:4px;font-family: SpoqR;font-size:16px;">${msgel.getMsg('AML_20_01_10_03_200','반려체크')}</label>
    	</span>
        <span id ="sbtn_03" style="margin-right:8px;">
	        <select name="OK_CCD1" id="OK_CCD1" onChange='ccdChange()' class="dropdown" >
	            ${condel.getSelectOption('{code:"A301",initValue:"${OK_CCD_CODE}"}')}
	        </select>
        </span>
        <%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
        ${btnel.getButton(outputAuth, '{btnID:"btn_02", cdID:"saveBtn", defaultValue:"저장", mode:"U", function:"doSave", cssClass:"btn-36"}')}
        <%}%>
        ${btnel.getButton(outputAuth, '{btnID:"sbtn_02", defaultValue:"결재", mode:"U", function:"doSave1", cssClass:"btn-36", show:"N"}')}
        <% if(!"3".equals(AML_ROLE_ID)) { %>
        ${btnel.getButton(outputAuth, '{btnID:"sbtn_04", defaultValue:"반려", mode:"U", function:"doSave2", cssClass:"btn-36", show:"N"}')}
        <% } %>
        ${btnel.getButton(outputAuth, '{btnID:"sbtn_05", cdID:"dataDetailSearch", defaultValue:"상세보기", mode:"R", function:"doOpenerSwitch", cssClass:"btn-36 filled", show:"Y"}')}
        ${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"doClose", cssClass:"btn-36", show:"N"}')}
    </div>
</form>
<!------------------------------------------------------------------------------>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" />
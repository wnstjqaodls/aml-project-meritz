<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%> 
<%--
- File Name  : AML_20_01_10_32.jsp
- Comment    : 수표정보 추가                          
- Version    : 1.0
- history    : 1.0 2017-02-03
--%>
<%@ page import="java.util.*" %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_32" %>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>

<%
    String SSPS_DL_ID       = Util.nvl(request.getParameter("SSPS_DL_ID"));         
    String SSPS_DL_CRT_DT   = Util.nvl(request.getParameter("SSPS_DL_CRT_DT")); 
    String GNL_AC_NO   = Util.nvl(request.getParameter("GNL_AC_NO"));
    String GDS_NO   = Util.nvl(request.getParameter("GDS_NO"));
    String GDS_NO_VIEW   = Util.nvl(request.getParameter("GDS_NO_VIEW"));    
    String DL_DT   = Util.nvl(request.getParameter("DL_DT"));
    String DL_DT_VIEW = DateUtil.dashDate(DL_DT);
    String DL_SQ   = Util.nvl(request.getParameter("DL_SQ"));      
    String RNM_CNFR_CCD   = Util.nvl(request.getParameter("RNM_CNFR_CCD")); //실명구분코드  
    String RNMCNO   = Util.nvl(request.getParameter("RNMCNO")); //실명확인번호
    String SSPS_DL_CRT_DT_VIEW   = DateUtil.dashDate(SSPS_DL_CRT_DT);
    String ENDRS_P_NM   = Util.nvl(request.getParameter("ENDRS_P_NM"));
    String CHCK_STRT_NO   = Util.nvl(request.getParameter("CHCK_STRT_NO"));
    String BTN_SAVE_F = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("BTN_SAVE_F")), "");    
    String SCH_GUBN   = Util.nvl(request.getParameter("SCH_GUBN"));
    if(("").equals(CHCK_STRT_NO)){
    	SCH_GUBN = "new";
    }
    
    DataObj output = null;
    DataObj in1  = new DataObj();	
	in1.add("SSPS_DL_ID",SSPS_DL_ID);
	in1.add("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	in1.add("GNL_AC_NO",GNL_AC_NO);
	in1.add("GDS_NO",GDS_NO);
	in1.add("DL_DT",DL_DT);
	in1.add("DL_SQ",DL_SQ);
	in1.add("CHCK_STRT_NO",CHCK_STRT_NO);
	
	
	if(!("new").equals(SCH_GUBN))	{
		output = AML_20_01_10_32.getInstance().getSearch(in1);
	}
    
    request.setAttribute("SSPS_DL_ID",SSPS_DL_ID);
    request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
    request.setAttribute("GNL_AC_NO",GNL_AC_NO);
    request.setAttribute("GDS_NO",GDS_NO);
    request.setAttribute("RNM_CNFR_CCD",RNM_CNFR_CCD);
    request.setAttribute("RNMCNO",RNMCNO);
    request.setAttribute("SCH_GUBN",SCH_GUBN);    
    request.setAttribute("GDS_NO_VIEW",GDS_NO_VIEW);
    request.setAttribute("DL_DT",DL_DT);
    request.setAttribute("DL_DT_VIEW",DL_DT_VIEW);
    request.setAttribute("DL_SQ",DL_SQ);
    request.setAttribute("BTN_SAVE_F",BTN_SAVE_F);
    request.setAttribute("SSPS_DL_CRT_DT_VIEW",SSPS_DL_CRT_DT_VIEW);
    request.setAttribute("ENDRS_P_NM",ENDRS_P_NM);
    request.setAttribute("output",output);
    
    
%>

<script>
   
    $(document).ready(function(){
    	setupEvents();
    	
    	if($("#CHCK_STRT_NO").val() != ''){
    		form1.CHCK_STRT_NO.readOnly = true;
    		form1.CHCK_STRT_NO.className = "input_t_dis";
    	}
    	$("input[name=CHCK_AMT]").keyup();
    });
    
	//상세조회
	function doSearchInfo(){
        
        _url = "?pageID=AML_20_01_10_32" + "&SSPS_DL_CRT_DT=" + "${SSPS_DL_CRT_DT}" + "&SSPS_DL_ID=" + "${SSPS_DL_ID}"
		 + "&GNL_AC_NO=" + "${GNL_AC_NO}"+ "&GDS_NO=" + "${GDS_NO}"+ "&DL_DT=" + "${DL_DT}"
		 + "&DL_SQ=" + "${DL_SQ}" + "&CHCK_STRT_NO=" + "${CHCK_STRT_NO}";	
		//showAlert(_url);			
		form1.methodID.value = "";
	   	form1.target = "_self";
		form1.action = "<c:url value='/'/>0001.do" + _url;
			
		form1.submit();
         
    }           
  

    function doSave(){
        var form1 = document.form1;        
        if(!checkValue()) return;
        
        //if(!confirm('<fmt:message key="AML_20_01_01_20_014"/>')) return;    
        showConfirm('<fmt:message key="AML_20_01_01_20_014"/>', "저장", doSaveAction);
    }

    function doSaveAction () {
    	form1.pageID.value = "AML_20_01_10_99";
        form1.classID.value = "AML_20_01_10_32";
        form1.methodID.value = "doSave";  
        form1.CHCK_STRT_NO.disabled = false;
        form1.CHCK_ISNG_DT.value = getDxDateVal("CHCK_ISNG_DT_VIEW",true);
        form1.CHCK_AMT.value = form1.CHCK_AMT.value.replaceAll(",","");        
		
        form1.target = "hidden_iframe";
        form1.action = "<c:url value='/'/>0001.do";
        form1.submit(); 
    }
    
    function doSave_end(){
    	//opener.parent.document.form1.DIV_21.value = "";	
		opener.doSearch(); 
		
    }
    
    function doSubmit_end(){        
        setTimeout(function(){        	
            if(form1.methodID.value == 'doSave') doSave_end();  

            if("${SCH_GUBN}" != 'new'){                
            	form1.CHCK_STRT_NO.disabled = true;                
            }else{
            	
            	
            }            
            
        },300);
    }

    function checkValue(){        
      
        if($("#SSPS_DL_CRT_DT").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_020','확인요망! 혐의거래ID 미존재.')}","WARN");         
            return false;
        }

        if($("#SSPS_DL_ID").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_021','확인요망! 혐의일자 미존재.')}","WARN");           
            return false;
        }  
        
        if($("#GNL_AC_NO").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_022','확인요망! 혐의거래계좌번호 미존재.')}","WARN");         
            return false;
        }

        if($("#GDS_NO").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_023','확인요망! 혐의거래계좌 상품번호  미존재.')}","WARN");           
            return false;
        }     
        
        if($("#DL_DT").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_024','확인요망! 혐의거래 거래일자  미존재.')}","WARN");           
            return false;
        }
        
        if($("#DL_SQ").val().trim() == ''){
            showAlert("${msgel.getMsg('AML_20_01_10_32_025','확인요망! 혐의거래 거래일련번호  미존재.')}","WARN");           
            return false;
        }
  
        if(jQuery("#CHCK_KND_CD option:selected").val() == '' || jQuery("#CHCK_KND_CD option:selected").val() == 'ALL'){
            showAlert('${msgel.getMsg("AML_20_01_10_32_011","유가증권종류를 선택하십시오.")}',"WARN");
            $("#CHCK_KND_CD").focus();
            return false;
        }
                
        if($("#CHCK_STRT_NO").val() == ''){
            showAlert('${msgel.getMsg("AML_20_01_10_32_012","유가증권번호를 입력하십시오.")}',"WARN");
            $("#CHCK_STRT_NO").focus();
            return false;
        }

        if(jQuery("#ISNG_BNK_CD option:selected").val() == '' || jQuery("#ISNG_BNK_CD option:selected").val() == 'ALL'){
            showAlert('${msgel.getMsg("AML_20_01_10_32_013","발행금융기관를 선택하십시오.")}',"WARN");
            $("#ISNG_BNK_CD").focus();
            return false;
        }   

        if($("#CHCK_AMT").val() == ''){
            showAlert('${msgel.getMsg("AML_20_01_10_32_014","금액을 입력하십시오.")}',"WARN");
            $("#CHCK_AMT").focus();
            return false;
        }
        
    	if(parseInt($("#CHCK_AMT").val()) <= 0){
            showAlert('${msgel.getMsg("AML_20_01_10_32_026","금액은 0이상이여야 합니다.")}',"WARN");
            $("#CHCK_AMT").focus();
            return false;
        }
    
        

        if(getDxDateVal("CHCK_ISNG_DT_VIEW",true) == ''){    
            showAlert('${msgel.getMsg("AML_20_01_10_32_015","발행일을 입력하십시오.")}',"WARN");
            $("#CHCK_ISNG_DT_VIEW").focus();
            return false;
        }
 
        if(jQuery("#ENDRS_P_KND_CD option:selected").val() == '' || jQuery("#ENDRS_P_KND_CD option:selected").val() == 'ALL'){ 
            showAlert('${msgel.getMsg("AML_20_01_10_32_016","발행인/최종소지인 구분를 선택하십시오.")}',"WARN");
            $("#ENDRS_P_KND_CD").focus();
            return false;
        }
        
        if($("#ENDRS_P_NM").val() == ''){
            showAlert('${msgel.getMsg("AML_20_01_10_32_017","발행인/최종소지인명을 입력하십시오.")}',"WARN");
            $("#ENDRS_P_NM").focus();
            return false;
        }
        
        if($("#ENDRS_P_RNM_NO").val() == ''){
            showAlert('${msgel.getMsg("AML_20_01_10_32_018","발행인/최종소지인 실명확인번호를 입력하십시오.")}',"WARN");
            $("#ENDRS_P_RNM_NO").focus();
            return false;
        }
        
        return true;
        
    }           

    function doClose(){
        window.close(); 
    }
    
    function setupEvents()
    {
    	//금액
    	$("input[name=CHCK_AMT]").blur( function() {
			$(this).val( $(this).val().replace(/[^0-9|.]/gi,"") ); //0~9|. 외 입력불가
			
			//입력값에 값을 입력중일때 실시간으로 천단위로 콤마를 찍는다. 20190219
			$(this).val( $(this).val().replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,') );
		});
    	
    	//금액
    	$("input[name=CHCK_AMT]").keyup(function(e){
    		var IN_V = $(this).val().replace(/[가-힣|ㄱ-ㅎ|ㅏ-ㅣ|,|.]/gi,"");
    		$(this).val( IN_V.replace(/[^0-9|.]/gi,"") ); //0~9|. 외 입력불가
    		
			//기존 저장버튼 클릭시 doSave에서 하던 입력값 유효값체크를 실시간으로 하도록 변경. 20190222
			IN_V = $(this).val();
			var IN_V_length = IN_V.length - 1;
			var _pattern; _pattern = /^(\d{1,10}([.]\d{0,2})?)?$/;
			if ( !_pattern.test(IN_V) ) {	// 10억미만, 소수점 2째자리인지 체크정규식
				var preMsg = "${msgel.getMsg('AML_50_01_01_02_004','입력값')}" + "(";
				var msg = preMsg + IN_V + ")" + "${msgel.getMsg('AML_20_01_10_32_027','은 저장할 수 없습니다.')}" + "\n";
				if (IN_V == '.') {
					msg += "${msgel.getMsg('AML_20_01_10_32_029','숫자를 입력하세요.')}"
				    showAlert(msg,"WARN");
				} else {
					msg += "${msgel.getMsg('AML_20_01_10_32_030','입력값은 10,000,000,000(10억)미만의 숫자로 입력가능합니다.')}"
					showAlert(msg,"WARN");
				}
		    	$(this).val( IN_V.substring(0, IN_V_length) );
			}
			
			//입력값에 값을 입력중일때 실시간으로 천단위로 콤마를 찍는다. 20190219
			$(this).val( $(this).val().replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,') );
        });
    	
    	//실명확인번호
    	$("input[name=ENDRS_P_RNM_NO]").blur( function() {
			$(this).val( $(this).val().replace(/[^0-9|.]/gi,"") ); //0~9|. 외 입력불가
		});
    	//실명확인번호
    	$("input[name=ENDRS_P_RNM_NO]").keyup(function(e){
    		var IN_V = $(this).val().replace(/[가-힣|ㄱ-ㅎ|ㅏ-ㅣ|,|.]/gi,"");
    		$(this).val( IN_V.replace(/[^0-9|.]/gi,"") ); //0~9|. 외 입력불가			
        });
    }
    
    
    
    

</script> 
<form name="form1">
<input type="hidden" name="pageID" id="pageID">
<input type="hidden" name="classID" id="classID"> 
<input type="hidden" name="methodID" id="methodID">
<input type="hidden" name="SCH_GUBN" id="SCH_GUBN" value="<c:out value='${SCH_GUBN}'/>">
<input type="hidden" name="SSPS_DL_CRT_DT" id="SSPS_DL_CRT_DT" value="<c:out value='${SSPS_DL_CRT_DT}'/>">
<input type="hidden" name="GDS_NO" id="GDS_NO" value="<c:out value='${GDS_NO}'/>">
<input type="hidden" name="DL_DT" id="DL_DT" value="<c:out value='${DL_DT}'/>">

<div style="margin-top:1px;margin-left:10px;margin-right:10px;">
        <table class="basic-table">
	        <tr>
	            <th class="title" width="150px">${msgel.getMsg('AML_20_01_01_01_011','추출일자')}</th>
	            <td>                
	                <input name="SSPS_DL_CRT_DT_VIEW" id="SSPS_DL_CRT_DT_VIEW" type="text" class="input_t_dis" value="${SSPS_DL_CRT_DT_VIEW}" style="width:100%" readonly>
	            </td>
	            <th class="title" width="150px">${msgel.getMsg('AML_20_01_01_03_003','혐의거래ID')}</th>
	            <td><input name="SSPS_DL_ID" id="SSPS_DL_ID" type="text" class="input_t_dis" value="${SSPS_DL_ID}" style="width:100%" readonly></td>            
	        </tr>
	        <tr>
	        	<th class="title">${msgel.getMsg('AML_20_01_01_03_009','계좌번호')}</th>
	            <td>
	                <input name="GNL_AC_NO" id="GNL_AC_NO" type="text" class="input_t_dis" value="${GNL_AC_NO}" size="20" readonly>
	            </td>
	            <th class="title">${msgel.getMsg('AML_10_07_01_01_024','거래상품')}</th>
	            <td><input name="GDS_NO_VIEW" id="GDS_NO_VIEW" type="text" class="input_t_dis" value="${GDS_NO_VIEW}" size="20" readonly></td>
	        </tr> 
	        <tr>
	        	<th class="title">${msgel.getMsg('AML_20_01_02_01_004','거래일자')}</th>
	            <td>
	                <input name="DL_DT_VIEW" id="DL_DT_VIEW" type="text" class="input_t_dis" value="${DL_DT_VIEW}" size="20" readonly>
	            </td>
	            <th class="title">${msgel.getMsg('AML_20_01_01_15_003','거래일련번호')}</th>
	            <td><input name="DL_SQ" id="DL_SQ" type="text" class="input_t_dis" value="${DL_SQ}" size="20" readonly></td>
	        </tr>        
        </table>

	<table class="basic-table">										
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_001','유가증권종류')}</th>
			<td>				
				<select name="CHCK_KND_CD" id="CHCK_KND_CD" class="dropdown" style="width: 50%;">                
                	<AMLTag:combobox_option	code="M052"	 initValue="${output.CHCK_KND_CD}" firstComboWord="CHOICE"/>
            	</select>
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_002','유가증권번호')}</th>
			<td>				
				<input type="text" class="input_text01" name="CHCK_STRT_NO" id="CHCK_STRT_NO" maxlength="20" value="${output.CHCK_STRT_NO}"/>
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_005','발행금융기관')}</th>
			<td>				
				<select name="ISNG_BNK_CD" id="ISNG_BNK_CD" class="dropdown" style="width: 50%;">                
                	<AMLTag:combobox_option	code="M050"	 initValue="${output.ISNG_BNK_CD}" firstComboWord="CHOICE"/>
            	</select>
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_007','금액')}</th>
			<td>				
				<input type="text" class="input_text01" name="CHCK_AMT" id="CHCK_AMT" maxlength="15" value="${output.CHCK_AMT}"/>
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_008','발행일자')}</th>
			<td class="content" >								
				${condel.getInputDateDx('CHCK_ISNG_DT_VIEW',output.CHCK_ISNG_DT_VIEW)}
				<input type="hidden" name="CHCK_ISNG_DT" id="CHCK_ISNG_DT" style="width: 50%;">
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_009','발행인/최종소지인 구분코드')}</th>
			<td>				
				<select name="ENDRS_P_KND_CD" id="ENDRS_P_KND_CD" class="dropdown"  style="width: 50%;">                
                	<AMLTag:combobox_option	code="M055"	 initValue="${output.ENDRS_P_KND_CD}" firstComboWord="CHOICE"/>
            	</select>
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_010','발행인/최종소지인')}</th>
			<td >				
				<input type="text" class="input_text01" name="ENDRS_P_NM" id="ENDRS_P_NM" value="${SCH_GUBN=='new'?ENDRS_P_NM:output.ENDRS_P_NM}" style="width: 50%;" />
			</td>
		</tr>
		<tr>
			<th class="title" style="width: 50%;">${msgel.getMsg('AML_20_01_10_32_019','실명확인번호')}</th>
			<td>				
				<input type="text" class="input_text01" name="ENDRS_P_RNM_NO" id="ENDRS_P_RNM_NO" value="${SCH_GUBN=='new'?RNMCNO:output.ENDRS_P_RNM_NO}" maxlength="13" />
			</td>
		</tr>		
	</table>
	<div class="button-area" style="display: flex;justify-content: flex-end; padding-top:8px;">  
        	<%if("Y".equals(BTN_SAVE_F)) {%>
    		${btnel.getButton(outputAuth, '{btnID:"btn_02", cdID:"saveBtn", defaultValue:"저장", mode:"U", function:"doSave", cssClass:"btn-36"}')}
    		<%}%>
    		${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"doClose", cssClass:"btn-36", show:"N"}')}
    </div>
</div>

<!-- 저장용 iframe -->
<table style="border:0;cellspacing:0;cellpadding:0">
     <tr>
        <td valign="top">
            <iframe name="hidden_iframe" name="hidden_iframe" style="width:0;height:0;marginwidth:0;marginheight:0;frameborder:0;scrolling:no"></iframe>
        </td>
    </tr>
</table>

</form>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" />
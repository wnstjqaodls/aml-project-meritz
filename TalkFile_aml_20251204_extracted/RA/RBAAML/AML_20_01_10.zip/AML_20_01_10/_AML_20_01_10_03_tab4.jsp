<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 지점의심내역
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : ?
* Since           : ?
********************************************************************************************************************************************
* Modifier        : 민경진
* Update          : 2017. 5. 15.
* Alteration      : 1. 그리드에 devextreme 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 8.
* Alteration      : 1. 신규 레이아웃 적용, 코드 정리
*                   2. HTML5, Any Browser 적용
* Breakdown       : 1. 서버로부터 조회 된 항목값 표시 안되는 오류 수정
********************************************************************************************************************************************
* Modifier        : 송지윤
* Update          : 2017. 11. 20.
* Alteration      : 그리드 수정
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 12. 14.
* Breakdown       : WebSphere의 EL Parser에서 BtnEL의 function 파라미터를 인식 못하는 문제 해결, 파라미터 별로 JAVASCRIPT function을 작성해줌
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2018. 4. 23.
* Alteration      : AML() 함수제거, 코드정리
********************************************************************************************************************************************
--%>
<!-- [${msgel.getMsg('AML_20_01_01_03_107')}] 의심스러운 거래유형 및 정도와 의심스러운 거래서술 ${msgel.getMsg('AML_20_01_01_03_107')}작(지점) -->
    <div class="row" style="margin-bottom:5px;">
        <h4 class="tab-content-title">
            ${msgel.getMsg('AML_20_01_01_03_068','의심스러운 거래유형 등록(지점)')}
        </h4>
        ${condel.getSelect('{selectID:"MN_DL_BRN_CD", width:"150", sqlID:"MDAO.AML_20_01_01_03_NIC73B_doSelectSearch", code:"${Search_Code}", initValue:"${J_BDPT_CD}", firstComboWord:""}')}
    </div>
    <div class="info-area2" style="overflow-y:initial;">
      <div class="info-left" style="width:50%">
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",0)%>
            </h5>
            <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",0);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
            <li>
                <input type="checkbox" id="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="J_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div>
                <textarea name='J_DOBT_TYP_KND_CD_501' rows='5' class='textarea-box' style='width:100%;'></textarea>
            </div>
    <%
            }
        }
    %>
          </ul>
        </div>
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",2)%>
            </h5>
            <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",2);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
             <li>
                <input type="checkbox" id="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="J_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div>
                <textarea name='J_DOBT_TYP_KND_CD_501' rows='4' class='textarea-box' style='width:100%;'></textarea>
            </div>
    <%
            }
        }
    %>
          </ul>
        </div>
         <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",4)%>
            </h5>
            <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",4);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
             <li>
                <input type="checkbox" id="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="J_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div style="margin:5px">
                <textarea name='J_DOBT_TYP_KND_CD_501' id='J_DOBT_TYP_KND_CD_501' rows='4' class='textarea-box' style='width:100%;'></textarea>
            </div>
    <%
            }
        }
    %>
           </ul>
        </div>
          <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_070','의심스러운 거래의 개요 및 보고 이유')}
            </h5>
               <table class="basic-table" style="width:100%;">
                <tr>
                    <th class="title" >${msgel.getMsg('AML_20_01_01_03_071')} </th>
                    <td><textarea name="J_ITEM_CNTNT1" id="J_ITEM_CNTNT1" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_072')} </th>
                    <td><textarea name="J_ITEM_CNTNT2" id="J_ITEM_CNTNT2" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_073')}</th>
                    <td><textarea name="J_ITEM_CNTNT3" id="J_ITEM_CNTNT3" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_074')} </th>
                    <td><textarea name="J_ITEM_CNTNT4" id="J_ITEM_CNTNT4" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_075')} </th>
                    <td><textarea name="J_ITEM_CNTNT5" id="J_ITEM_CNTNT5" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_076')} </th>
                    <td><textarea name="J_ITEM_CNTNT6" id="J_ITEM_CNTNT6" class='textarea-box' rows="1"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_116')}</th>
                    <td><textarea name="J_XCL_RSN_CNTNT" id="J_XCL_RSN_CNTNT" class='textarea-box' rows="3"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_10_03_119')}</th>
                    <td><textarea name="J_DNY_RSN_CNTNT" id="J_DNY_RSN_CNTNT" class='textarea-box' rows="2" disabled></textarea></td>
                </tr>
                <tr>
                    <th class="title">
                        ${msgel.getMsg('AML_20_01_01_03_077')}
                    	<input name="J_RPR_RSN_CNTNT_BYTES" type="text" class="table-box" size="15" style="text-align:right" disabled>
                    </th>
                    <td>
	                    <textarea name="J_RPR_RSN_CNTNT" id="J_RPR_RSN_CNTNT" rows="25" class='textarea-box' onKeyUp="calcBytes('J');"></textarea>
	                    <div style="color:blue">※${msgel.getMsg('AML_20_01_10_03_208','금칙어를')}( < > & ' " ; \ ) ${msgel.getMsg('AML_20_01_10_03_209','참조해서 작성해주세요.')}</div>
                    </td>
                </tr>
              </table>
    </div>
    <div class="info-right" style="width:50%">
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",1)%>
            </h5>
            <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",1);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
           <li>
             <input type="checkbox" id="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="J_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
             <label for="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
           </li>
    <%
        }
    %>
          </ul>
         </div>
         <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",3)%>
            </h5>
         <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",3);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
            <li>
             <input type="checkbox" id="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="J_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
             <label for="J_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
           </li>
    <%
        }
    %>
         </ul>
        </div>
             <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_078','의심스러운 거래의 등급 설정')}
            </h5>
            <div style="line-height:20px;margin-bottom:10px;margin-left: 20px;font-family:SpoqB; font-size:13px;">
                ${msgel.getMsg('AML_20_01_01_03_079')}
            </div>
            <div class="content">
	            <div class="radio-item" style="line-height:20px;margin-left: 20px;">
	                <input name="J_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="1" checked>
	                <label for='J_DOBT_DL_GRD_CD'>1. ${msgel.getMsg('AML_20_01_01_03_080')}</label>
	            </div>
	            <div class="radio-item" style="line-height:20px;">
	                <input name="J_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="2" checked>
	                <label for='J_DOBT_DL_GRD_CD'>2. ${msgel.getMsg('AML_20_01_01_03_081')}</label>
	            </div>
	            <div class="radio-item" style="line-height:20px;">
	                <input name="J_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="3" checked>
	                <label for='J_DOBT_DL_GRD_CD'>3. ${msgel.getMsg('AML_20_01_01_03_082')}</label>
	            </div>
	            <div class="radio-item" style="line-height:20px;">
	                <input name="J_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="4" checked>
	                <label for='J_DOBT_DL_GRD_CD'>4. ${msgel.getMsg('AML_20_01_01_03_083')}</label>
	            </div>
	            <div class="radio-item" style="line-height:20px;">
	                <input name="J_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="5" checked>
	                <label for='J_DOBT_DL_GRD_CD'>5. ${msgel.getMsg('AML_20_01_01_03_084')}</label>
	            </div>
            </div>
            <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_085','별도송부 문서명 작성')}
            </h5>
            <div style="margin:5px">
                <textarea name="J_SEND_DOC_NM" id="J_SEND_DOC_NM" class='textarea-box' rows="6"></textarea>
            </div>
            <div style="margin-top:5px;"></div>
            <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_086','첨부파일명 작성')}
            </h5>
            <div style="padding:5px">
    <%

        HashMap inputParam = new HashMap();
		inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
		inputParam.put("SSPS_DL_ID",SSPS_DL_ID);

        if( "N".equals(MASTER_BRANCH)) {
    %>
                <div style="width:100%;border:0px;margin-bottom:5px;text-align:right;">
                <%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
                	${btnel.getButton(outputAuth, '{btnID:"fileAdd", cdID:"addFileBtn", defaultValue:"파일추가", mode:"C", function:"addFileTab4", cssClass:"btn-36"}')}
                <%}%>
                	<div id="uploaderTab4" style="display:none;"></div>
                </div>
                <table class="data-table" style="width:100%; border:1px solid #ddd;">
	               <tr style="background-color:#F5F5F5">
	                	<td height="25px" align="center">${msgel.getMsg('AML_90_01_03_04_001','업로드 된 파일')}</td>
	                </tr>
	                <tr>
	                	<td valign="middle">
		    				<div class="content" id="selected-files">
		    					<div id="fileBox" >
    <%
            output = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam);
            if(output.getCount("FILE_SEQ") != 0) {
                String FILE_SEQ         		= "";
                String FILE_POS         		= "";
                String USER_FILE_NM     	= "";
                String PHSC_FILE_NM     	= "";
                String FILE_SIZE        		= "";
                String DOWNLOAD_COUNT	= "";

                for(int i=0; i<output.getCount("FILE_SEQ"); i++) {
                    FILE_SEQ        		= output.getText("FILE_SEQ"      ,i);
                    FILE_POS        		= output.getText("FILE_POS"      ,i);
                    USER_FILE_NM    		= output.getText("USER_FILE_NM"  ,i);
                    PHSC_FILE_NM    		= output.getText("PHSC_FILE_NM"  ,i);
                    FILE_SIZE       		= output.getText("FILE_SIZE"     ,i);
                    DOWNLOAD_COUNT	= output.getText("DOWNLOAD_COUNT",i);

                    request.setAttribute("FILE_SEQ"         ,FILE_SEQ       );
                    request.setAttribute("FILE_POS"         ,FILE_POS       );
                    request.setAttribute("USER_FILE_NM"     ,USER_FILE_NM   );
                    request.setAttribute("PHSC_FILE_NM"     ,PHSC_FILE_NM   );
                    request.setAttribute("FILE_SIZE"        ,FILE_SIZE      );
                    request.setAttribute("DOWNLOAD_COUNT"   ,DOWNLOAD_COUNT );
    %>
	                <div id="file<%=i%>" class="tx" style="height:30px;text-align:left;background-color:#FFFFFF;">
                        <i class="fa fa-floppy-o" style="font-size:14px;padding:6px 5px;" aria-hidden="true"></i>&nbsp;
                        <a class="filedown" href="javascript:downloadFile('${PHSC_FILE_NM}','${USER_FILE_NM}','${FILE_POS}');">${USER_FILE_NM}</a>
                        <a onclick="viewDelete(this);" >
	                        <input name="fileSizes" id="fileSizes" type="hidden" value="${FILE_SIZE}"/>
				    		<input name="origFileNms" id="origFileNms" type="hidden" value="${USER_FILE_NM}"/>
				    		<input name="storedFileNms" id="storedFileNms" type="hidden" value="${PHSC_FILE_NM}"/>
				    		<input name="filePaths" id="filePaths" type="hidden" value="${FILE_POS}"/>
				    		<%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
	                    	<div class="dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon" style="margin-left: 10px; margin-top:0.2em;"  role="button" aria-hidden="true" aria-label="close">
								<div class="dx-button-content" style="padding-left: 0.2em;">&nbsp;<i class="dx-icon dx-icon-close" ></i></div>
							</div>
							<%}%>
						</a>
					</div>
    <%
                }
            }
    %>
    							</div>
    						</div>
	                    </td>
	                </tr>
                </table>
    <%
        } else {
   %>
                <table class="grid-table-type" style="width:100%">
                  <thead>
	                <tr style="background-color:#F5F5F5">
	                	<th height="25px" align="center">${msgel.getMsg('AML_90_01_03_04_001','업로드 된 파일')}</th>
	                </tr>
	              </thead>
	              <tbody>
	                <tr>
	                	<td valign="middle">
		    				<div class="content" id="selected-files">
   <%
            output = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam);
            if(output.getCount("FILE_SEQ") != 0) {
            	String FILE_SEQ_M1 			= "";
                String FILE_POS_M1 			= "";
                String USER_FILE_NM_M1 	= "";
                String PHSC_FILE_NM_M1 	= "";
                String FILE_SIZE_M1 		= "";

                for(int i=0; i<output.getCount("FILE_SEQ"); i++) {
                	FILE_SEQ_M1 			= output.getText("FILE_SEQ"    ,i);
                    FILE_POS_M1 			= output.getText("FILE_POS",i);
                    USER_FILE_NM_M1 	= output.getText("USER_FILE_NM",i);
                    PHSC_FILE_NM_M1 	= output.getText("PHSC_FILE_NM",i);
                    FILE_SIZE_M1 			= output.getText("FILE_SIZE",i);

                    request.setAttribute("FILE_SEQ_M1"    ,FILE_SEQ_M1    );
                    request.setAttribute("FILE_POS_M1",FILE_POS_M1);
                    request.setAttribute("USER_FILE_NM_M1"    ,USER_FILE_NM_M1    );
                    request.setAttribute("PHSC_FILE_NM_M1",PHSC_FILE_NM_M1);
    %>
	                <div id="file<%=i%>" style="height:30px;text-align:left;background-color:#FFFFFF;">
                        <i class="fa fa-floppy-o" style="font-size:14px;margin-left:3px" aria-hidden="true"></i>&nbsp;
                        <a class="filedown" href="javascript:downloadFile('${PHSC_FILE_NM_M1}','${USER_FILE_NM_M1}','${FILE_POS_M1}');">${USER_FILE_NM_M1}</a>
					</div>
    <%
                }
            }
    %>
    						</div>
	                    </td>
	                </tr>
	                 </tbody>
                </table>
    <%
         }
    %>
             </div>
             <table class="basic-table">
                <tr>
	             <th class="title" style="border-bottom:0px;">
	                <i class="fa fa-chevron-circle-right"></i>${msgel.getMsg('AML_20_01_01_03_087','관련문서번호')}
	            </th>
	            <td><input name="J_RE_DOC" type="text" class="" style="display:inline-block;margin-left:5px;padding-left:5px;width:200px" value="" disabled/></td>
	            </tr>
            </table>

            <h5 class="info-title" style="margin-top:138px;display: flex;padding-left: 16px;justify-content: space-between;align-items: center;">
            	${msgel.getMsg('AML_20_01_10_03_206','AI 참조')}
            </h5>
            <table class="basic-table">
	            <tr>
	            <th class="title" style="width:25%;border-bottom:0px;">
	            	<div style="display:flex;align-items: center;justify-content: space-between;">
	                ${msgel.getMsg('AML_20_01_10_03_205','AI 종합의견(직전)')}
	                <div class="button-area" style="display:inline-block;float:right;">
	               		<button type="button" onclick="applyAIopi('batch')" id="J_applyAIopiBtn_Batch" class="btn-28" mode="R">${msgel.getMsg('AML_20_01_10_03_204','적용')}</button>
	            	</div>
	            	</div>
	            </th>
	            <td>
	            	<div style="color:blue;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_201','적용 시 종합의견에 삽입됩니다.')}</div>
	            	<div style="color:blue;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_202','최초에는 배치 수행 시 생성된 AI 종합의견입니다.')}</div>
<!-- 	            	<div class="button-area" style="display:inline-block;float:right;"> -->
<!-- 	            		<button type="button" onclick="createAIopi()" id="J_createAIopiBtn" class="btn-28" mode="R">생성</button> -->
<!-- 	               		<button type="button" onclick="applyAIopi()" id="J_applyAIopiBtn" class="btn-28" mode="R" disabled>적용</button> -->
<!-- 	            	</div> -->
	            	<textarea name="J_AI_RPR_RSN_CNTNT_BATCH" id="J_AI_RPR_RSN_CNTNT_BATCH" rows="9" class='textarea-box' style="margin-top:10px;"></textarea>
	            </td>
	            </tr>
	            <tr>
	            <th class="title" style="width:25%;border-bottom:0px;">
	            	<div style="display:flex;align-items: center;justify-content: space-between;">
	                ${msgel.getMsg('AML_20_01_10_03_207','AI 종합의견')}
	                <div class="button-area" style="display:inline-block;float:right;">
	               		<button type="button" onclick="applyAIopi('base')" id="J_applyAIopiBtn" class="btn-28" mode="R" disabled>${msgel.getMsg('AML_20_01_10_03_204','적용')}</button>
	            	</div>
	            	</div>
	            </th>
	            <td>
	            	<div style="display:flex;align-items: center;justify-content: space-between;">
		            	<div style="color:blue;display:inline-block;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_201','적용 시 종합의견에 삽입됩니다.')}</div>
		            	<div class="button-area" style="display:inline-block;float:right;">
		            		<button type="button" onclick="createAIopi()" id="J_createAIopiBtn" class="btn-28" mode="R">${msgel.getMsg('AML_20_01_10_03_203','신규생성')}</button>
		            	</div>
		            </div>
	            	<textarea name="J_AI_RPR_RSN_CNTNT" id="J_AI_RPR_RSN_CNTNT" rows="9" class='textarea-box' style="margin-top:10px;"></textarea>
	            </td>
	            </tr>
            </table>
    </div>
 </div>
<%--   <div class="row" style="margin-bottom:5px;">
        <h4 class="tab-content-title">
        ${msgel.getMsg('AML_20_01_01_03_069','의심스러운 거래등급 등록')}
        </h4>
    </div> --%>

      <!-- <div class="info-left" style="width:50%">
        </div> -->
   <!--   <div class="info-right" style="width:50%">

            </div> -->
<script>


	function createAIopi()
    {
		overlay.show(true, true);
		var selectObj = {};
		var form1 = document.form1;
        if (form1.GNL_AC_NO.value != '') {
            selectObj.classID             = "AML_20_01_01_08";
            selectObj.methodID            = "setStrSubPopMain08";
            selectObj.SSPS_DL_CRT_DT      = "${SSPS_DL_CRT_DT}";
            selectObj.SSPS_DL_ID          = "${SSPS_DL_ID}";
            selectObj.AML_ID              = "${ID}";
            selectObj.AML_USER_NAME       = "${USER_NAME}";
            selectObj.AML_ROLE_ID         = "${ROLE_ID}";
            selectObj.AML_MASTER_BRANCH   = "${MASTER_BRANCH}";
            selectObj.AML_BDPT_CD         = "${BDPT_CD}";
            selectObj.AML_TEAM_LEADER_YN  = "${TEAM_LEADER_YN}";
            selectObj.AML_TEL_NO          = "${sessionAML.sAML_TEL_NO}";
            selectObj.GNL_AC_NO           = form1.GNL_AC_NO.value;
            sendService(selectObj.classID, selectObj.methodID, selectObj, createAIopi_success, createAIopi_fail);
        }
    }

	function createAIopi_success(data){

		var dealList = [];

		for (var i=0; i < data.length; i++){
			var dealDetail = "" + (i+1) + ". ";
			dealDetail += '${msgel.getMsg("AML_21_01_01_01_001","거래일자")}' + " : " + data[i].DL_DT + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_100","거래시간")}' + " : " + data[i].DL_TM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_11_01_105","계좌번호")}' + " : " + data[i].GNL_AC_NO + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_07_101","상품")}' + " : " + data[i].GDS_NO_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_101","번호")}' + " : " + data[i].DL_SQ + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_102","거래유형")}' + " : " + data[i].DL_TYP_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_024","거래방법")}' + " : " + data[i].DL_WY_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_026","거래채널")}' + " : " + data[i].DL_CHNNL_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_11_01_106","거래금액")}' + " : " + data[i].DL_AMT + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_104","현금")}' + " : " + data[i].CSH + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_025","수표금액")}' + " : " + data[i].CHCK_AMT + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_027","예수금잔액")}' + " : " + data[i].TFND_RA + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_106","대출원금상환금액")}' + " : " + data[i].LN_AMT + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_108","상대대체계좌")}' + " : " + data[i].CPRTY_TRSNS_AC_NO + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_109","상대대체기관")}' + " : " + data[i].CPRTY_TRSNS_OGN_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_110","상대대체금융기관")}' + " : " + data[i].CPRTY_TRSNS_FOGN_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_07_01_01_050","취급지점")}' + " : " + data[i].HANDLNG_BRN_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_15_007","처리자")}' + " : " + data[i].HNDL_P_ENO_NM + "\n";
			dealDetail += '${msgel.getMsg("AML_20_01_01_08_118","거래적요")}' + " : " + data[i].DL_SMRY + "\n";

			dealList.push(dealDetail);
		}


		var temp1 = gubn==0?"B":"J";
		var obj_OBT_TYP_KND = document.all[temp1 + "_DOBT_TYP_KND_CD"];
		var dealFeature = [$("#"+temp1+"_RPR_RSN_CNTNT")[0].value];

		dealFeature.push()

		for (var i=0; i < obj_OBT_TYP_KND.length; i++){
			if(obj_OBT_TYP_KND[i].checked == true){
				if(obj_OBT_TYP_KND[i].id.indexOf('501') != -1){ //기타 특징 및 유형
					dealFeature.push($("#"+temp1+"_DOBT_TYP_KND_CD_501")[0].value);
				}
				else{
					dealFeature.push($("#"+obj_OBT_TYP_KND[i].id).next()[0].innerHTML);
				}
			}
		}

		var classID = "AML_20_01_10_09";
		var methodID = "createAIopi";
		var params = new Object();
		params.DL_F = dealFeature;
		params.DL_L = dealList;

		sendService(classID, methodID, params, createAIopi_success2, createAIopi_fail);
	}

	function createAIopi_success2(tmp,data){
		var temp_gubn = gubn==0?"B":"J";
		overlay.hide();
		if($("#"+temp_gubn+"_AI_RPR_RSN_CNTNT").val() == ""){
			$("#"+temp_gubn+"_AI_RPR_RSN_CNTNT").val(data.PARAM_DATA[0].VALUE);
		} else{
			$("#"+temp_gubn+"_AI_RPR_RSN_CNTNT_BATCH").val($("#"+temp_gubn+"_AI_RPR_RSN_CNTNT").val());
			$("#"+temp_gubn+"_AI_RPR_RSN_CNTNT").val(data.PARAM_DATA[0].VALUE);
		}

		$("#"+temp_gubn+"_applyAIopiBtn").attr("disabled", false);
	}

	function createAIopi_fail(){
		overlay.hide();
	}

	function applyAIopi(flag){
		var temp_gubn = gubn==0?"B":"J";

		var aiopi = "";
		if(flag == "base"){
			aiopi = $("#"+temp_gubn+"_AI_RPR_RSN_CNTNT").val();
		} else { //flag == "batch"
			aiopi = $("#"+temp_gubn+"_AI_RPR_RSN_CNTNT_BATCH").val();
		}

		var before = $("#"+temp_gubn+"_RPR_RSN_CNTNT")[0].value;
		var front = before.substring(0, before.indexOf("3."));
		var tmp = before.substring(before.indexOf("3."), before.length);
		var middle = tmp.substring(tmp.indexOf("3."), tmp.indexOf("\n"));
		var end = before.substring(before.indexOf("4."), before.length);
		var result = front + middle + "\n" + aiopi + "\n\n" + end;
		$("#"+temp_gubn+"_RPR_RSN_CNTNT").val(result);
		toByteCalc(temp_gubn);
	}

	function toByteCalc(gubun){
		calcBytes(gubun);
	}

  //공통 첨부파일
	function addFileTab4() {
		//var allowedFileExtensions = [".jpg", ".jpeg", ".gif", ".png", ".xlsx", ".xls", ".csv", ".ppt", ".doc", ".docx", ".xml", ".txt", ".zip"];
		var allowedFileExtensions = "${uploadFile}";
		var fileUploader = gtFileUploader("uploaderTab4",allowedFileExtensions,doSubmitTab4_end);
	}

	//선택한 첨부파일을 화면에 보여주기
	//임시첨부파일은 upload/attachTmp에 등록된다.
	function doSubmitTab4_end(fileData) {
		var addLine;
	    var divId = fileData.storedFileNm.substring(0,fileData.storedFileNm.lastIndexOf("."));

		if(fileData != undefined) {
      		addLine	= "<div id='"+divId+"'  style='height:30px;text-align:left;background-color:#FFFFFF;'>"
      			+"<i class='fa fa-floppy-o' style='font-size: 14px;padding:6px 5px;' aria-hidden='true'></i>&nbsp;&nbsp;"
				+ fileData.origFileNm
				+" <a onclick=\"tempFileDel('"+divId+"','/upload/attachTmp/','"+fileData.storedFileNm+"');\" >"
				+"<input type='hidden' name='fileSizes' id='fileSizes' value='"+fileData.fileSize+"' />"
				+"<input type='hidden' name='origFileNms' id='origFileNms' value='"+fileData.origFileNm+"' />"
				+"<input type='hidden' name='storedFileNms' id='storedFileNms' value='"+fileData.storedFileNm+"' />"
				+"<input type='hidden' name='filePaths' id='filePaths' value='"+fileData.filePath+"' />"
				+"<div class='dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon' style='margin-left: 10px; margin-top:0.2em;'  role='button' aria-hidden='true' aria-label='close'>"
				+"	<div class='dx-button-content'>&nbsp;<i class='dx-icon dx-icon-close'></i></div>"
				+"</div>"
				+"</a>"
				+"</div>";
      		$("#fileBox").append(addLine);
		}
	}
</script>

<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 결재
*                   STR 決裁
*                   STR Approval
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 민경진
* Update          : ?
* Alteration      : 그리드 교체
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
*                   2. 코드정리
*                   3. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2018. 4. 23.
* Alteration      : AML() 함수제거, 코드정리
********************************************************************************************************************************************
--%>
<%@ page import="java.math.BigDecimal"                   %>
<%@ page import="java.text.ParseException"                   %>
<%@ page import="com.gtone.aml.basic.common.log.Log"	%>
<%@page import="com.gtone.webadmin.util.JSONUtil,com.gtone.webadmin.util.CodeUtil"%>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%
	try{
	    String stDate = Util.nvl(request.getParameter("stDate"));
	    String edDate = Util.nvl(request.getParameter("edDate"));

	    if(("").equals(stDate)) {
	    	stDate = DateUtil.addDays(DateUtil.getDateString(), -1, "yyyy-MM-dd");
	    }
	    if(("").equals(edDate)) {
	    	edDate = DateUtil.addDays(DateUtil.getDateString(), 0, "yyyy-MM-dd");
	    }

	    request.setAttribute("stDate",stDate);
	    request.setAttribute("edDate",edDate);
	}catch(ParseException e){
		Log.logAML(Log.ERROR, e);
	}catch(Exception e){
		Log.logAML(Log.ERROR, e);
	}

	//세션결재자정보
	String ROLEID = sessionAML.getsAML_ROLE_ID();//Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("ROLE_ID"         )));
	request.setAttribute("ROLEID",ROLEID);

	// 업권
	String amlType = jspeed.base.property.PropertyService.getInstance().getProperty("aml.config", "amlType");
	request.setAttribute("amlType", amlType);
	
	//부서
	String AML_BDPT_CD = sessionAML.getsAML_BDPT_CD();
	request.setAttribute("AML_BDPT_CD",AML_BDPT_CD);
	
%>
<script>
    // [ Attributes ]
    var GridObj1 = null;
    var overlay = new Overlay();
    var pageID	 = "AML_20_01_10_01";
	var classID  = "AML_20_01_10_01";
	var dataSource = [];

	// [ Initialize ]
    $(document).ready(function(){
        $('#sbtn_03').hide();
        if ($('#ROLE_ID').val() == 4 || $('#ROLE_ID').val() == 3 || $('#ROLE_ID').val() == 6 || $('#ROLE_ID').val() == 7){
        	$('#sbtn_04').show();
        }else{
        	$('#sbtn_04').hide();
        }
        
        setupGrids();
        setupFilter("init");
        
        $("#GTDataGrid1_Area").parents("div").parents("div").css("visibility","visible");
        if ($('#ROLE_ID').val() == 4|| $('#ROLE_ID').val() == 5|| $('#ROLE_ID').val() == 7 || $('#ROLE_ID').val() == 104){
        	$('#sbtn_05').show();
        	GridObj1.columnOption("XCL_RSN_CNTNT", "visible", true);
        } else {
        	$('#sbtn_05').hide();
        	GridObj1.columnOption("XCL_RSN_CNTNT", "visible", false);
        }
    });

    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid1_Area";
    	//gridObj.title = "STR결재";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }

    /** click grid row */
    var double_yn=null;
    function clickCellGrid1(id, obj, data, rowIdx, colIdx, columnId) {
        fnVisibleBtnDenyGrdAll();

        if(columnId == "SSPS_DL_ID" ) {       // 혐의거래ID
            form2.pageID.value = 'AML_20_01_10_03';
            window_popup_open(form2.pageID.value, 1500, 860, '');
            form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
            form2.SSPS_DL_ID.value     = data.SSPS_DL_ID;
            form2.WORK_ID.value        = data.WORK_ID;
            form2.ACT_ID.value         = data.ACT_ID;
            form2.GNL_AC_NO.value      = data.GNL_AC_NO;
            form2.ACNT_NO.value        = data.ACNT_NO;
            form2.AML_CUST_ID.value    = data.AML_CUST_ID.replaceAll("-","");
            form2.approval.value       = 'true';
            form2.ctlBtn02.value       = 'true';
            
        } else if (columnId == "RSK_GRD_CD_NM" ) {    // KYC점수
            form2.pageID.value = 'AML_10_04_01_04';
            window_popup_open(form2.pageID.value, 1000, 950, '', 'yes');
            var locDL_P_RNMCNO = data.DL_P_RNMCNO;
            locDL_P_RNMCNO = locDL_P_RNMCNO.replaceAll("+","$");
            form2.rnmcno.value      =locDL_P_RNMCNO;
            form2.KYC_TMS_CCD.value = 'K';

        } else if (columnId == "CNT" ) {	// 적출건수
            form2.pageID.value = 'AML_20_01_11_03';
            window_popup_open('AML_20_01_11_03', 1100, 600, '','yes');
            var locDL_P_RNMCNO = data.DL_P_RNMCNO;
            form2.rnmcno.value          = locDL_P_RNMCNO;
            form2.SSPS_DL_CRT_DT.value  = data.SSPS_DL_CRT_DT;
            form2.KYC_TMS_CCD.value     = 'T';
            form2.dis_flag.value     = 'P';
            form2.target = form2.pageID.value;
            form2.action = "<c:url value='/'/>0001.do";
            form2.submit();
        
        } else if (columnId == "DL_P_NM" ) {			// 고객명 - 고객상세
           form2.rnmcno.value = "";
           form2.AML_CUST_ID.value = data.AML_CUST_ID.replaceAll("-","");
           form2.dis_flag.value = "P";
           if(data.INDV_CORP_CCD == "2"){		// 법인
	       		form2.pageID.value = "AML_10_07_01_01";
	         	//window_popup_open(form2, 1000, 830, '','yes');
	       		window_popup_open("AML_10_07_01_01", 1370, 830, 'yes','yes'); 
	       	}else{
	       		form2.pageID.value = "AML_10_06_01_01";	// 개인
	          	//window_popup_open(form2, 1000, 650, '','yes');
	       		window_popup_open("AML_10_06_01_01", 1370, 650, '','yes');
	       	} 
        
        } else if(columnId == "ACNT_NO" ) {		// 계좌번호 - 기간벌 거래내역
        	form2.pageID.value = 'AML_20_01_11_03';
        	form2.ACNT_NO.value = data.ACNT_NO;
        	form2.GNL_AC_NO.value = data.GNL_AC_NO;
        	form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
        	form2.STR_CTR_GB.value = 'S';
            window_popup_open('AML_20_01_11_03', 900, 600, '','yes');
        
        } else if(columnId == "CS_NO" ) {		// 실명번호 - STR 경보 History
        	form2.pageID.value = 'AML_20_01_11_04';
        	form2.DL_P_NM.value = data.DL_P_NM;
        	form2.GNL_AC_NO.value = data.GNL_AC_NO;
        	form2.DL_P_RNMCNO.value = data.DL_P_RNMCNO;
        	form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
        	form2.STR_CTR_GB.value = "S";
            window_popup_open('AML_20_01_11_04', 1600, 800, '','yes');
            
        } else if (columnId == "ACT_NAME" && data.INST_ID != "") {	//결재단계
            form2.pageID.value = 'AML_20_01_11_02';
            window_popup_open(form2, 800, 700, '');
            form2.INST_ID.value = data.INST_ID;
            
        } else if (columnId == "XCL_RSN_CNTNT") {
        	obj.component.editCell(obj.rowIndex,obj.columnIndex);
        	return;
        	
        } else if (columnId == "XCL_RSN_CNTNT2") {
        	if ($('#ROLE_ID').val() == 3|| $('#ROLE_ID').val() == 6){
        		obj.component.editCell(obj.rowIndex,obj.columnIndex);
        	}
        	return;
        } else {
        	if(columnId == '' || columnId == null){
				return;
			}

   			if(double_yn == null){
   				//최초클릭
   				double_yn = obj.SSPS_DL_CRT_DT_A;
   				return;
   			}

   			if(double_yn == obj.SSPS_DL_CRT_DT_A){
   				//더블클릭
   				GridObj1.selectRow();
   				double_yn = null;

   				form2.pageID.value = 'AML_20_01_10_03';
   	            window_popup_open(form2.pageID.value, 1200, 720, '');
   	            form2.SSPS_DL_CRT_DT.value = data.SSPS_DL_CRT_DT;
   	            form2.SSPS_DL_ID.value     = data.SSPS_DL_ID;
   	            form2.WORK_ID.value        = data.WORK_ID;
   	            form2.approval.value       = 'true';
   	            form2.ctlBtn02.value       = 'true';
   	            form2.target = form2.pageID.value;
   	            form2.action = "<c:url value='/'/>0001.do";
   	            form2.submit();

   			}else{
   				//다른것을 클릭했을때
   				double_yn = obj.SSPS_DL_CRT_DT_A;
   				return;
   			}
        }
        form2.target = form2.pageID.value;
        form2.action = "<c:url value='/'/>0001.do";
        try {
            form2.submit();
        } catch (e) {
            showAlert(e.message,"ERR");
        }
    }

	function fnVisibleBtnDenyGrdAll(){

		var i, rowData, sel, proc, cmt, count, row, wfActFlag, cntJun = 0, cntNoJun = 0;
        var oldACT_ID;
        var selectedRowData = GridObj1.getSelectedRowsData();
        row = selectedRowData.length;
        for(i = 0, count = 0; i < row; i++) {
            rowData = selectedRowData[i];
            wfActFlag = rowData.WF_ACT_FLAG;

            if (wfActFlag == "4" && $('#ROLE_ID').val() == "3"){
				cntJun++;
			}else if (wfActFlag == "2" && $('#ROLE_ID').val() == "4"){
				cntNoJun++;
			}
        }

		if (cntNoJun > 0){
			fnVisibleBtnDeny("2");
		} else{
			fnVisibleBtnDeny("4");
		}
	}

	 function fnVisibleBtnDeny(wfActFlag){
		if (wfActFlag == "4" && $('#ROLE_ID').val() == "3"){
			$('#sbtn_03').hide();
		}else if (wfActFlag == "2" && $('#ROLE_ID').val() == "4"){
			$('#sbtn_03').hide();
		}else if (wfActFlag != ""){
			$('#sbtn_03').show();
		}
	}


    function doSearch(){
    	var SSPS_DL_DT_ALL = $("#DT_ALL"  ).is(":checked")==true ? "":"N"

    	if(DT_ALL == "N"){
    		if(!fromToDateChechk("stDate", "edDate"))return;
    	}

        var params = new Object();
		var methodID = "doSearch";
		overlay.show(true, true);
		params.pageID = form1.pageID.value;
		if ( "${ROLEID}" =="4"  || "${ROLEID}" == "5" || "${ROLEID}" == "7" || "${ROLEID}" == "104" || "${ROLEID}" == "105") {
			params.branchCode = $("input[name=branchCode]" ,"form[name=form1]").val()=="99999"?"":$("input[name=branchCode]","form[name=form1]").val();
    	} else {
    		params.branchCode =  "${AML_BDPT_CD}" ;
		}
		params.stDate = getDxDateVal("stDate",true);
		params.edDate = getDxDateVal("edDate",true);
		params.SSPS_DL_CRT_CCD = $("#SSPS_DL_CRT_CCD","form[name=form1]").val()=="ALL"?"":$("#SSPS_DL_CRT_CCD","form[name=form1]").val();
		params.CS_NM  = $("input[name=CS_NM]","form[name=form1]").val();
		params.CS_NO  = $("input[name=CS_NO]","form[name=form1]").val();
		params.ACNT_NO  = $("input[name=ACNT_NO1]","form[name=form1]").val().replace('-', '');
		params.SSPS_TYP_CD = $("#SSPS_TYP_CD", "form[name=form1]").val();
		params.DT_ALL = ($("#DT_ALL").is(":checked")==true ? 1:0);

		sendService(classID, methodID, params, doSearch_success, doSearch_fail);
    }

    function doSearch_success(gridData, data){
        try {
   	    	GridObj1.refresh();
   	        GridObj1.option("dataSource",gridData);

   		} catch (e) {
   	        showAlert(e,'ERR');
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }

    function doSearch_fail(){
    	overlay.hide();
    }
    
    function doSave12()
    {
    	
            var params = new Object();
    		var methodID = "doSearch_code";
    		overlay.show(true, true);
    		params.pageID = form1.pageID.value;
    		params.CD = "S064";

    		sendService(classID, methodID, params, doSave1, doSearch_fail);
    }
 

    function doSave1(gridData, data){
    	
    	overlay.hide();
    	
    	if ("${ROLE_ID}" == "104" && gridData[0].CODE != "Y") {
    		alert("결재 불가 시간입니다.");
    		return;
    	}
    	
        GridObj1.saveEditData();

        var row = GridObj1.totalCount()
        var rowData = GridObj1.getSelectedRowsData();

        for(var i = 0; i < rowData.length; i++) {
            var obj = rowData[i];
            proc = obj.OK_CCD;
            var cmt = "";
            if($("#MASTER_BRANCH").val() == "N"){
            	cmt = obj.XCL_RSN_CNTNT2;
            }else{
            	cmt = obj.XCL_RSN_CNTNT;
            }
            var msgMemo = '('+(i+1)+'번째:'+obj.SSPS_DL_CRT_DT_A + ','+ obj.DL_P_NM+')';

            if (proc == '' || proc == '0') {
                showAlert("${msgel.getMsg('AML_20_01_10_01_003','미확인 건이 있습니다.')}"+msgMemo,"WARN");
                return;
            } else if(proc == '3'){
           		showAlert("${msgel.getMsg('AML_20_01_01_01_064','회수 건은 결재 상태값을 다시 선택하셔야 합니다.')}","WARN");
           		return;
            } else if(proc == '2') {
                if(cmt == '') {
                    showAlert("${msgel.getMsg('AML_20_01_10_01_004','보고제외 사유를 입력하십시오.')}"+msgMemo,"WARN");
                    return;
                }
            }
            delete rowData[i].SSPS_TYP_NM;
        }

        if(rowData.length < 1) {
            showAlert("${msgel.getMsg('AML_20_01_10_01_001','대상건이 존재하지 않습니다.')}","WARN");
            return;
        }

        showConfirm('${msgel.getMsg("AML_20_01_10_01_002","결재 처리를 하시겠습니까?")}', "${msgel.getMsg('AML_00_00_01_01_074','결재')}", function(){doSave1Action(rowData)});
    }



    function doSave1Action(rowData) {
    	var params = new Object();
		var methodID = "doSave1";
		overlay.show(true, true);
		params.pageID = form1.pageID.value;
		params.gridData = rowData;
		sendService(classID, methodID, params, doSave1_success, doSave1_fail);
    }

    function doSave1_success(gridData, data){
    	try {
	    	refreshApprovalCount();
	        doSearch();
    	} catch (e) {
            showAlert(e,"ERR");
            overlay.hide();
        } finally {
            overlay.hide();
        }
    }

    function doSave1_fail(data){
    	overlay.hide();
    }

    //반려
    function deny_popup() {
    	var grid1 = $('#GTDataGrid1_Area').dxDataGrid('instance');
        grid1.saveEditData();
        var i, rowData, sel, proc, cmt, count, row;
        var oldACT_ID;
        var selectedRowData = GridObj1.getSelectedRowsData();
        row = selectedRowData.length;
        
        for(i = 0, count = 0; i < row; i++) {
            rowData = selectedRowData[i];
            proc = rowData.OK_CCD;
            cmt = rowData.DNY_RSN_CNTNT;
            
            form2.DNY_RSN_CNTNT.value = rowData.DNY_RSN_CNTNT;
            form2.DNY_RSN_CNTNT_READONLY_YN.value = "";
             
            if (count != 0) {
                if (oldACT_ID != rowData.ACT_ID) {
                    showAlert("${msgel.getMsg('AML_20_01_10_01_006','동일한 결재 단계만 동시에 반려하실 수 있습니다.')}","WARN");
                    return;
                }
            }
            oldACT_ID = rowData.ACT_ID;
            count++;
            delete rowData.SSPS_TYP_NM;
        }
        if (row < 1 || count < 1) {
            showAlert("${msgel.getMsg('AML_20_01_10_01_001','대상건이 존재하지 않습니다.')}","WARN");
            return;
        }

    	form2.pageID.value = 'AML_20_01_10_07';
        window_popup_open(form2.pageID.value, 550, 330, ''); // 230 -> 330
		form2.target = form2.pageID.value;
	    form2.action = "<c:url value='/'/>0001.do";
        form2.submit();
    }



    function doSave2(DNY_RSN_CNTNT){
        var rowData = GridObj1.getSelectedRowsData();
        var params = new Object();
		var methodID = "doSave2";
		overlay.show(true, true);
		params.pageID = form1.pageID.value;
		params.gridData = rowData;
		params.DNY_RSN_CNTNT = DNY_RSN_CNTNT ;

		sendService(classID, methodID, params, doSave1_success, doSave1_fail);
    }

	function showBackRsn(){
    	$('#div_BACK_RSN_CNTNT').show();
    	if(backflag == 0){
    		backflag = 1;
    		showAlert("${msgel.getMsg('AML_20_01_01_01_062','반려사유를 입력해주십시오.')}","WARN");
    		document.form1.BACK_RSN_CNTNT.focus();
    		return false;
    	}
    	return true;
    }

    function hideBackRsn(){
    	$('#div_BACK_RSN_CNTNT').hide();
    	backflag = 0;
    	document.form1.BACK_RSN_CNTNT.value = "";
    }
    function doMerge(){
        var selectedRowData = GridObj1.getSelectedRowsData();

        if (selectedRowData.length != 1) {  // 20211108 : 병합건을 선택하지 않는 경우에 대한 예외 처리 포함
            showAlert("${msgel.getMsg('AML_20_01_10_01_007','병합/해제는 한건씩만 선택할 수 있습니다.')}","WARN");
            return;
        }
        
        if(selectedRowData[0].OK_CCD != '0'){
            alert("${msgel.getMsg('AML_20_01_10_06_005','병합/해제는 미확인 혐의거래만 가능합니다.')}");
            return;       	
        }

        SSPS_DL_CRT_DT = selectedRowData[0].SSPS_DL_CRT_DT;
        SSPS_DL_ID     = selectedRowData[0].SSPS_DL_ID;
        ACT_NAME       = selectedRowData[0].ACT_NAME;

        form2.pageID.value = 'AML_20_01_10_06';
        window_popup_open(form2.pageID.value, 980, 600, '');
        form2.SSPS_DL_CRT_DT.value  = SSPS_DL_CRT_DT;
        form2.SSPS_DL_ID.value      = SSPS_DL_ID;
        form2.ACT_NAME_MASTER.value = ACT_NAME;
        form2.approval.value        = 'true';
        form2.modify.value          = 'false';
        form2.target = form2.pageID.value;
        form2.action = "<c:url value='/'/>0001.do";
        form2.submit();
    }

    function setupGrids(){
    	GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
    	elementAttr: { class: "grid-table-type" },
    	dataSource				: dataSource,
    	gridId          		: "GTDataGrid1",
    	onToolbarPreparing		: makeToolbarButtonGrids,
    	width					:"100%",
    	height					:"calc(-150px + 85vh)",
        hoverStateEnabled 		: true,
        wordWrapEnabled 		: false,
        allowColumnResizing 	: true,
        columnAutoWidth 		: true,
        allowColumnReordering 	: true,
        columnResizingMode 		: 'widget',
        cacheEnabled 			: false,
        cellHintEnabled 		: true,
        showBorders 			: true,
        showColumnLines 		: true,
        showRowLines 			: true,
        sorting					: { mode: "multiple"},
        loadPanel 				: { enabled: false },
        remoteOperations 		: {filtering:false, grouping:false, paging:false, sorting:false, summary:false},
        editing					: { mode: 'cell', allowUpdating: false, allowAdding : false},
        filterRow				: { visible: false },
        rowAlternationEnabled 	: true,
        columnFixing			: {	enabled: true},
        pager: {
   	    	visible: true
   	    	,showNavigationButtons: true
   	    	,showInfo: true
   	    },
   	    paging: {
   	    	enabled : false
   	    	,pageSize : 50
   	    },
	   	scrolling : {
           mode            : "standard"
          ,preloadEnabled  : false
        },
        searchPanel				: {visible: true, width: 250},
        noDataText				: '${msgel.getMsg("AML_20_01_10_01_103","조회된 데이터가 없습니다.")}',
        export 					: {allowExportSelectedData : true ,enabled : false ,excelFilterEnabled : true},
	    onExporting: function (e) {
	    	var workbook = new ExcelJS.Workbook();
	    	var worksheet = workbook.addWorksheet("Sheet1");
		    DevExpress.excelExporter.exportDataGrid({
		        component: e.component,
		        worksheet: worksheet,
		        autoFilterEnabled: true,
		    }).then(function(){
		        workbook.xlsx.writeBuffer().then(function(buffer){
		            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${pageTitle}.xlsx");
		        });
		    });
		    e.cancel = true;
        },
        selection				: {allowSelectAll : true, deferred : false, mode : 'multiple', selectAllMode : 'allPages', showCheckBoxesMode : 'always'},
        columns: [
            {dataField:'SSPS_DL_CRT_DT', 	caption:'${msgel.getMsg("AML_20_02_10_01_002","추출일자")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc",  fixed: true},
            {dataField:'SSPS_DL_ID', 		caption:'${msgel.getMsg("AML_20_01_11_01_124","일련번호")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc", cssClass:'link',fixed: true},
            {dataField:'OK_CCD', 			caption:'${msgel.getMsg("AML_20_02_10_02_005","보고구분")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, width:"70px", fixed: true,
				lookup: {dataSource: <%=JSONUtil.listToJson(CodeUtil.getCodes("AML_00_00_00_00_common_getComboData", "A301"))%>, displayExpr: "VALUE", valueExpr: "KEY"}},
			{dataField:'DL_P_NM', 			caption:'${msgel.getMsg("AML_20_01_11_01_102","고객명")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, allowFiltering: true ,"cssClass": "link", fixed: true},
			{dataField:'LGA_AST_YN',		caption:'${msgel.getMsg("AML_20_01_11_01_114","고액자산가여부")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false,width:"100px"},
			{dataField:'STR_RPR_YN',		caption:'기보고', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false,width:"100px"},
			{dataField:'ACNT_NO', 			caption:'${msgel.getMsg("AML_20_01_11_01_105","계좌번호")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, "cssClass": "link",
				  cellTemplate: function(cellElement,cellInfo){ cellElement.text(displayGTDataGridGnlAcNo(cellInfo.text)); } },
			{dataField:'CS_NO', 			caption:'${msgel.getMsg("AML_20_01_10_03_301","실명번호")}',	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, "cssClass": "link"},
			{dataField:'INDV_CORP_CCD', caption:'개인/법인구분', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible: false,
                lookup: {
                            dataSource: <%=JSONUtil.listToJson(CodeUtil.getCodes("AML_00_00_00_00_common_getComboData", "M006"))%>,
                            displayExpr: "VALUE",
                            valueExpr: "KEY"
                        }
            },
            {dataField:'SSPS_TYP_NM', 		caption:'${msgel.getMsg("AML_20_01_11_01_108","시나리오명")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false},
			{dataField:'SSPS_TYP_CD', 		caption:'${msgel.getMsg("AML_20_01_11_01_107","시나리오ID")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
			{dataField:'CNT', 						caption:'${msgel.getMsg("AML_20_01_11_01_109","추출건수")}', 		dataType:'number', cssClass: 'link', alignment:'right', allowResizing:true, allowSorting:true, allowEditing:false, width:"60px", visible:false},
			{dataField:'DNY_RSN_CNTNT',  	caption:'${msgel.getMsg("AML_20_01_10_01_102","반려사유")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false},
            {dataField:'XCL_RSN_CNTNT',  	caption:'${msgel.getMsg("AML_20_01_10_01_101","보고제외사유(본점)")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, width:"200px"},
            {dataField:'XCL_RSN_CNTNT2', 	caption:'${msgel.getMsg("AML_20_01_10_01_100","보고제외사유(지점)")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
            {dataField:'SSPS_DL_CRT_DT_A', 	caption:'${msgel.getMsg("AML_20_02_10_01_002","추출일자")}',	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, sortOrder: "desc", visible:false },
             
			{dataField:'DL_P_RNM_NO_CCD_NM', 	caption:'${msgel.getMsg("AML_20_01_11_01_104","실명확인구분")}', 	alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible: false},
			{dataField:'RSK_GRD_CD_NM', 	caption:'${msgel.getMsg("AML_20_01_11_01_113","KYC등급")}', 		alignment:'center', dataType:'text', allowResizing:true, allowSorting:true, allowEditing:false,  width:"60px", visible: false},
	        {dataField:'TRIG_CTNT', caption:'혐의트리거', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, width:300, visible:false},
	        {dataField:'MN_DL_DPRT_NM', caption:'계좌관리점', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
	        {dataField:'PRFT_BRN_NM', caption:'계좌실적점', alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
	        {dataField:'ACT_NAME', 			caption:'${msgel.getMsg("AML_20_01_11_01_117","결재단계")}', 		alignment:'left', allowResizing:true, allowSorting:true, allowEditing:false, cssClass:'link', visible:true },
            {dataField:'GNL_AC_NO', caption:'계좌ID', alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, visible:false},
	        {dataField:'DL_P_RNMCNO', caption:'고객번호', visible:false},
            
            {dataField:'DL_AMT', 			caption:'${msgel.getMsg("AML_20_01_11_01_106","거래금액")}',		alignment:'right', allowResizing:true, allowSorting:true, allowEditing:false, dataType:'number', format:'fixedPoint', visible:false     },
            {dataField:'RPR_DT', 			caption:'${msgel.getMsg("AML_20_01_11_01_110","최근보고거래일자")}', 	alignment:'center', allowResizing:true, allowSorting:true, allowEditing:false, width:"120px", visible:false },
            {dataField:'MERGE_YN', 			caption:'병합여부', alignment:'center', allowResizing:true, 		allowSorting:true, allowEditing:true, visible:true},
            {
            	dataField: 'SPRN_KEEP_TAGT_YN',
            	caption: '분리보관',
                alignment: "center",
                allowResizing: true,
                allowSearch: true,
                allowSorting: true,
                width:80 
            },
            {dataField:"INST_ID",			caption: 'INST_ID', "alignment": "left", "allowResizing": true, "allowSearch": true, "allowSorting": true, "visible": false},
            {dataField:'WORK_ID', 			visible:false, allowSearch:false},
            {dataField:'ACT_ID', 			visible:false, allowSearch:false},
            {dataField:'RSK_GRD_CD', 		visible:false, allowSearch:false},
            {dataField:'RSK_GRD', 			visible:false, allowSearch:false}
        ],
         "summary" :{totalItems: [{column: 'SSPS_DL_ID', summaryType: 'count', valueFormat: "fixedPoint"}],
 				texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
        onCellClick: function(e){
            if(e.data ){
            	clickCellGrid1('gridId', e, e.data, e.rowIndex, e.columnIndex, e.column.dataField);
            }
            if (e.component.isRowSelected(e.key)) {
                if (e.column.dataField=="OK_CCD"){
                	e.component.editCell(e.rowIndex,e.columnIndex);
                } else if (e.column.dataField=="XCL_RSN_CNTNT") {
                    e.component.editCell(e.rowIndex,e.columnIndex);
                	$("input.dx-texteditor-input").css("ime-mode", "active");
                }
            }
        },
        onInitialized : function(e) {
        	doSearch();
        }
    }).dxDataGrid("instance");
   }

    function makeToolbarButtonGrids(e){

        var cmpnt; cmpnt = e.component;
        var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
        var authC = "${outputAuth.C       }";  // 추가,수정 권한
        var authD = "${outputAuth.D       }";  // 삭제 권한
        if (useYN=="Y") {
            var gridID       = e.element.attr("id");    // 그리드 아이디
            var toolbarItems = e.toolbarOptions.items;
            toolbarItems.splice(0, 0, {
                "locateInMenu"  : "auto"
                ,"location"     : "after"
                ,"widget"       : "dxButton"
                ,"name"         : "filterButton"
                ,"showText"     : "inMenu"
                ,"options"      : {
                         "icon"      : ""
                       	,"elementAttr": { class: "btn-28 filter" }
            			,"text"      : ""
                        ,"hint"      : '필터'
                        ,"disabled"  : false
                        ,"onClick"   : function(){
								setupFilter();
                        }
                 }
            });
        }
    }

    function goAIResult(st_dt, ed_dt, gnl_ac_no, gds_no, dl_sq, DL_P_AML_CUST_ID, ssps_dl_id){
    	parent.setMainsParams({"ST_DT" : st_dt,"ED_DT" : ed_dt, "GNL_AC_NO" : gnl_ac_no, "GDS_NO" : gds_no, "DL_SQ" : dl_sq, "DL_P_AML_CUST_ID" : DL_P_AML_CUST_ID, "SSPS_DL_ID" : ssps_dl_id});
    	parent.goMenu2("AML_21_01_02");
    }


    //결재 회수 기능
    function withdraw(){
    	form2.pageID.value 		= "AML_20_01_10_08";
		form2.stDate.value 	    = getDxDateVal("stDate",true);
		form2.edDate.value 	    = getDxDateVal("edDate",true);
		form2.branchCode2.value  = document.form1.branchCode.value;
		form2.target 			= "AML_20_01_10_08";
		window_popup_open(form2.pageID.value, 1350, 600, '', 'yes');
		form2.action 			= '<c:url value="/"/>0001.do';
		form2.submit();
    }

  //최종결재 완료된 건 결재 회수 기능 - 고객사에서 요구 시 사용
//     function withdrawLastApp(){
//     	form2.lastApp.value = "LAST";
//     	withdraw();
//     }


    //엑셀 다운로드
    function doDownload() {
    	var vPageUrl = pageUrl.replace(/<(\/span|span)([^>]*)>/gi,"");

		from0.pageUrl.value = vPageUrl;
		from0.pageID.value = "AML_00_03_01_01";
		from0.target = from0.pageID.value;
		from0.action = "<c:url value='/'/>0001.do";
		window_popup_open(from0.pageID.value, 600, 320, '','yes');
		from0.submit();
    }


    function comletedAction(result) {
        if (result == "1") {
        	var workbook = new ExcelJS.Workbook();
            var worksheet = workbook.addWorksheet('Main sheet');

            DevExpress.excelExporter.exportDataGrid({
                component: GridObj1,
                worksheet: worksheet,
                autoFilterEnabled: true
            }).then(function () {
                return workbook.xlsx.writeBuffer();
            }).then(function (buffer) {
            	saveAs(new Blob([buffer], { type: 'application/octet-stream' }), '${pageTitle}.xlsx');
            }).catch(function (error) {
                console.error("엑셀 내보내기 오류:", error);
            });
        }
    }

</script>
<form name="from0" method="post">
	<input type="hidden" name="pageID" >
	<input type="hidden" name="classID" >
	<input type="hidden" name="methodID" >
	<input type="hidden" name="pageUrl" >
</form>
<form name="form2" method="post" >
    <input type="hidden" name="pageID"          id="pageID"         />
    <input type="hidden" name="CCD"             id="CCD"            />
    <input type="hidden" name="clientID"        id="clientID"       />
    <input type="hidden" name="rnmcno"          id="rnmcno"         />
    <input type="hidden" name="aml_cust_id"     id="aml_cust_id"    />
    <input type="hidden" name="MASTER_BRANCH"   id="MASTER_BRANCH"  value="${MASTER_BRANCH}"/>
    <input type="hidden" name="KYC_TMS_CCD"     id="KYC_TMS_CCD"    />
    <input type="hidden" name="SSPS_DL_CRT_DT"  id="SSPS_DL_CRT_DT" />
    <input type="hidden" name="SSPS_DL_ID"      id="SSPS_DL_ID"     />
    <input type="hidden" name="ACT_NAME_MASTER" id="ACT_NAME_MASTER"/>
    <input type="hidden" name="ctlBtn02"        id="ctlBtn02"       />
    <input type="hidden" name="cs_nm"           id="cs_nm"          />
    <input type="hidden" name="WORK_ID"         id="WORK_ID"        />
    <input type="hidden" name="INST_ID"         id="INST_ID"		/>
    <input type="hidden" name="approval"        id="approval"       />
	<input type="hidden" name="DNY_RSN_CNTNT"   id="DNY_RSN_CNTNT"  />
    <input type="hidden" name="DNY_RSN_CNTNT_READONLY_YN"          id="DNY_RSN_CNTNT_READONLY_YN"/>
    <input type="hidden" name="modify"          id="modify"         />
    <input type="hidden" name="stDate"          id="${stDate}"      />
    <input type="hidden" name="edDate"          id="${edDate}"		/>
    <input type="hidden" name="GNL_AC_NO"       id="GNL_AC_NO"		/>
    <input type="hidden" name="ACNT_NO"       	id="ACNT_NO"		/>
    <input type="hidden" name="ACT_ID"          id="ACT_ID"			/>
    <input type="hidden" name="dis_flag"        id="dis_flag"       />
    <input type="hidden" name="branchCode2"							/>
    <input type="hidden" name="lastApp"								/>
    <input type="hidden" name="STR_CTR_GB"      id="STR_CTR_GB"     />
    <input type="hidden" name="DL_P_RNMCNO"     id="DL_P_RNMCNO"    />
    <input type="hidden" name="DL_P_NM"     	id="DL_P_NM"    />
    <input type="hidden" name="AML_CUST_ID"     	id="AML_CUST_ID"    />
    
</form>
<form name="form1" method="post">
    <input type="hidden" name="pageID"  id="pageID" />
    <input type="hidden" name="manualID"  id="manualID" />
    <input type="hidden" name="ROLE_ID" id="ROLE_ID" value="<c:out value='${ROLE_ID}'/>" />
<!-- Condition Box[ ----------------------------------------------------------------------------------------------------------------------->
	<div class="cond-btn-row" style="text-align:left;margin-top:10px">
        <span id="AreaUser" style="cursor:default;" title="${msgel.getMsg('AML_00_01_01_01_007','사용자')}">
            <i id="IconUser" class="fa fa-user" aria-hidden="true" style="font-size:14px"></i><span class="text-label">${USER_NAME}</span>
        </span>
        [<span id="AreaBranch" style="cursor:default;" title="${msgel.getMsg('AML_00_00_01_01_013','지점')}">
            <i id="IconBranch" class="fa fa-sitemap" aria-hidden="true" style="font-size:14px"></i><span class="text-label">${BDPT_CD_NAME}</span>
        </span>]
    </div>
	    
	<div class="inquiry-table"> 
		<div class="table-row" style="width:33%;">
			<div class="table-cell">
				${condel.getLabel("AML_20_02_10_01_002","추출일자")}
			<div class="content">
				<div class='calendar'>
					${condel.getInputDateDx('stDate',stDate)} ~ ${condel.getInputDateDx('edDate',edDate)}
				</div>
			<div class="all">
				<input type="checkbox" id="DT_ALL" name="DT_ALL" value="Y" checked>
				<label for="DT_ALL">${msgel.getMsg('AML_10_05_01_01_009','전체')}</label>
			</div>
	        </div>
	        </div>
	        <div class="table-cell">
	           ${condel.getBranchSearch('{msgID:"AML_20_01_11_01_001", defaultValue:"거래지점", name:"branchCode", firstComboWord:"ALL"}')}
	        </div>
	     </div>
	     <div class="table-row" style="width:30%;">
	        <div class="table-cell">
	           ${condel.getInputCustomerNo('{msgID:"AML_20_01_01_08_016", defaultValue:"계좌번호", name:"ACNT_NO1", size:"25"}')}
	      </div>
	        <div class="table-cell">
	          ${condel.getInputCustomerNo('{msgID:"AML_20_01_11_01_012", defaultValue:"거래자명", name:"CS_NM", size:"25"}')}
	        </div>
		</div>
		<div class="table-row" style="width:37%;">
			<div class="table-cell">
				${condel.getSelect("AML_20_01_11_01_005", "혐의명", "SSPS_TYP_CD", "250", "AML_20_01_11_01_getSSPS_TYP_CDList", amlType, "", "ALL")}
			</div>
			<div class="table-cell">
				${condel.getSelect("AML_20_01_11_01_015", "혐의거래", "SSPS_DL_CRT_CCD", "250", "AML_20_01_11_01_getSSPS_DL_CRT_CCDList", amlType, "", "ALL")}
			</div>
		</div>
	</div>
        <div class="button-area" style="margin-bottom: 8px;">
        	${btnel.getButton(outputAuth, '{btnID:"sbtn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass="btn-36 filled"}')}
        	<% if ( "4".equals(ROLEID)) { //본점담당자%>
         	<AMLTag:buttonAuth pageID="${param.pageID}" id="sbtn_04" name="병합/해제" mode="U" function="doMerge" dataObj="${outputAuth}" css="btn-36" show="N" />
         	 ${btnel.getButton(outputAuth, '{btnID:"sbtn_06", cdID:"withdrawBtn", defaultValue:"회수", mode:"U", function:"withdraw", cssClass:"btn-36"}')}
        	<% } %>
        	${btnel.getButton(outputAuth, '{btnID:"sbtn_02", cdID:"approvalBtn", defaultValue:"결재", mode:"U", function:"doSave12", cssClass:"btn-36"}')}
        	<% if ( "5".equals(ROLEID) || "104".equals(ROLEID)) { //본점담당자%>
        	<AMLTag:buttonAuth pageID="${param.pageID}" id="sbtn_03" name="반려" mode="U" function="deny_popup" dataObj="${outputAuth}" css="btn-36" show="N"/>
<% } %>
	        ${btnel.getButton(outputAuth, '{btnID:"sbtn_05", cdID:"RBA010", defaultValue:"다운로드", mode:"C", function:"doDownload", cssClass:"btn-36"}')}
		</div>
	<div class="tab-content-bottom">
		<div id="GTDataGrid1_Area"></div>
	</div>
</form>

<jsp:include page="/WEB-INF/Package/AML/common/main_common_bottom.jsp" flush="true" />
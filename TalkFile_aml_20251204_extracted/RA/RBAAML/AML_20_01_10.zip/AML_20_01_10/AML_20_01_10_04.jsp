<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 혐의거래 결재이력
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 3.
* Alteration      : 1. 신규 레이아웃 적용
*                   2. 코드 정리
*                   3. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>
<%@ include file="/WEB-INF/Package/AML/common/notitle_common_top.jsp" %>
<%
    String INST_ID = request.getParameter("INST_ID") == null ? "" : request.getParameter("INST_ID");
    request.setAttribute("INST_ID",INST_ID);
%>
<!-- [2] init ${msgel.getMsg('AML_20_02_10_02_010')} JavaScript -->
<script language="JavaScript">
    var GridObj1 = null;

    $(document).ready(function(){
    	setupGrids();
    	doSearch();
     	setupFilter("init");
    });

    function setupGrids()
    {
        GridObj1 = $("#GTDataGridPopup_Area").dxDataGrid({
       	 "gridId"            	: "GTDataGrid01",
      	 "height"            	: "calc(65vh - 200px)",
      	"elementAttr"           : { class: "grid-table-type" },
      	"hoverStateEnabled"		: true,
        "wordWrapEnabled"		: false,
        "allowColumnResizing"	: true,
        "columnAutoWidth"		: true,
        "allowColumnReordering"	: true,
        "cacheEnabled"			: false,
        "cellHintEnabled"		: true,
        "showBorders"			: true,
	    "onToolbarPreparing": makeToolbarButtonGrids,
        "showColumnLines"		: true,
        "showRowLines"			: true,
        "export" : {
	        allowExportSelectedData : true
	       ,enabled                 : true
	       ,excelFilterEnabled      : true
	    },
	   "onExporting" 			: function (e) {
		    var workbook = new ExcelJS.Workbook();
		    var worksheet = workbook.addWorksheet("Sheet1");
		    DevExpress.excelExporter.exportDataGrid({
		        component: e.component,
		        worksheet:worksheet,
		        autoFilterEnabled: true,
		    }).then(function() {
		        workbook.xlsx.writeBuffer().then(function(buffer) {
		            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${msgel.getMsg('AML_20_01_10_04_200')}.xlsx");
		        });
		    });
		    e.cancel = true;
       },
       "sorting"				: {"mode": "multiple"},
       "remoteOperations"		: {"filtering": false,"grouping": false,"paging": false,"sorting": false,"summary": false},
       "editing"				: {"mode": "batch","allowUpdating": false,"allowAdding": false,"allowDeleting": false},
       "filterRow"				: {"visible": false},
       "rowAlternationEnabled"	: true,
       "columnFixing"			: {"enabled": true},
       pager: {
	    	visible: true
	    	,showNavigationButtons: true
	    	,showInfo: true
	    },
	    paging: {
	    	enabled : true
	    	,pageSize : 20
	    },
	   	scrolling : {
           mode            : "standard"
          ,preloadEnabled  : false
       },
       "searchPanel"			: {"visible": false,"width": 250},
       "selection"				: {"allowSelectAll": true,"deferred": false,"mode": "none","selectAllMode": "allPages","showCheckBoxesMode": "onClick"},
       "columns": [
           {"dataField": "SEQ"			,"caption": '${msgel.getMsg("AML_20_01_01_15_003","일련번호")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 80},
           {"dataField": "ACT_NAME"		,"caption": '${msgel.getMsg("AML_20_01_11_01_003","결재단계")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 100},
           {"dataField": "OK_CCD"		,"caption": '결재상태'											,	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 90},
           {"dataField": "SN_PRC_CCD_NM","caption": '${msgel.getMsg("AML_20_02_10_02_006","처리구분")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 90},
           {"dataField": "DPRT_NM"		,"caption": '${msgel.getMsg("AML_20_02_10_02_007","처리지점")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 100},
           {"dataField": "RPR_P_NM"		,"caption": '${msgel.getMsg("AML_20_02_10_02_008","처리자")}',		"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 120},
           {"dataField": "RPR_P_DY_TM"	,"caption": '${msgel.getMsg("AML_20_02_10_02_011","처리일시")}',	"alignment": "center","allowResizing": true,"allowSearch": true,"allowSorting": true,width : 140},
           {"dataField": "CNTNT"		,"caption": '${msgel.getMsg("AML_20_02_10_02_009","처리의견")}',	"alignment": "left","allowResizing": true,"allowSearch": true,"allowSorting": true}
		],
//        "summary": {"totalItems": [    {
//            "column": "SEQ",
//            "summaryType": "count",
// 	        "alignment": "center"
// 	    }],texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
       "onCellClick": function(e){ if(e.data ){            Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);        } }
    }).dxDataGrid("instance");

    }

    /**
     * Search
     */
    function doSearch()
    {
        /* GridObj1.refresh({
            actionParam     : {
                "pageID"    : form1.pageID.value
               ,"classID"   : "AML_20_02_10_02"
               ,"methodID"  : "doSearch"
               ,"INST_ID"   : "<c:out value='${INST_ID}'/>"
            }
           ,completedEvent  : doSearch_end
        }); */

        GridObj1.clearSelection();
        GridObj1.option('dataSource', []);

    	var obj = new Object();
		var classID	 = "AML_20_02_10_02";
		var methodID = "doSearch";
		obj.pageID 	 = form1.pageID.value;
		obj.classID = classID;
		obj.methodID = methodID;
		obj.INST_ID = "<c:out value='${INST_ID}'/>";
		sendService(classID, methodID, obj, doSearch_success, doSearch_fail);
    }

    function doSearch_success(gridData, data)
    {
        if(gridData.length > 0) {
            //GridObj1.selectRow(0);
             GridObj1.option('dataSource', gridData);
            setInputBox(gridData[0]);
        }
    }

    function doSearch_fail(data){
    	overlay.hide();
    }

    function Grid1CellClick(id, obj, selectData, rowIdx, colIdx, columnId, colId) {
    	setInputBox(obj);
    }

    function setInputBox(obj)
    {
        form1.SEQ.value             = obj.SEQ;
        form1.ACT_NAME.value        = obj.ACT_NAME;
        form1.OK_CCD.value          = obj.OK_CCD;
        form1.SN_PRC_CCD_NM.value   = obj.SN_PRC_CCD_NM;
        form1.DPRT_NM.value         = obj.DPRT_NM;
        form1.RPR_P_NM.value        = obj.RPR_P_NM;
        form1.CNTNT.value           = obj.CNTNT;
        form1.RPR_P_DY_TM.value           = obj.RPR_P_DY_TM;
    }


    function makeToolbarButtonGrids(e){

	    var cmpnt; cmpnt = e.component;
	    var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
	    var authC = "${outputAuth.C       }";  // 추가,수정 권한
	    var authD = "${outputAuth.D       }";  // 삭제 권한
	    if (useYN=="Y") {
	        var gridID       = e.element.attr("id");    // 그리드 아이디
	        var toolbarItems = e.toolbarOptions.items;
	        toolbarItems.splice(0, 0, {
	            "locateInMenu"  : "auto"
	            ,"location"     : "after"
	            ,"widget"       : "dxButton"
	            ,"name"         : "filterButton"
	            ,"showText"     : "inMenu"
	            ,"options"      : {
	                     "icon"      : ""
	                   	,"elementAttr": { class: "btn-28 filter popupFilter" }
	        			,"text"      : ""
	                    ,"hint"      : '필터'
	                    ,"disabled"  : false
	                    ,"onClick"   : function(){
								setupFilter();
	                    }
	             }
	        });
	    }
	}


    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGridPopup_Area";
    	gridObj.title = "";
    	gridArrs[0] = gridObj;

    	setupGridFilter2(gridArrs , FLAG);
    }

</script>

<form name="form1"  method="post">
    <input type="hidden" name="pageID"  />
    <input type="hidden" name="classID" />
    <input type="hidden" name="methodID" />

    <div class="row" style="padding-top:8px;">
	</div>
<div class="tab-content-bottom">
    <div id="GTDataGridPopup_Area"></div>
	<div class="row">
	    <h4 class="tab-content-title">
	        ${msgel.getMsg('AML_20_02_10_02_002','결재내역 상세정보')}
	    </h4>
	</div>
</div>
 <table class="basic-table">
    <tr>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_003','일련번호')}</th>
        <td><input name="SEQ" type="text" class="input_t_dis" readonly size="40"></td>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_004','결재단계')}</th>
        <td><input name="ACT_NAME" type="text" class="input_t_dis" readonly size="40"></td>
    </tr>
    <tr>
        <th class="title">${msgel.getMsg('AML_20_02_10_02_005')}</th>
        <td style="width:15%"><input name="OK_CCD" type="text" class="input_t_dis" readonly  size="40"></td>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_006','처리구분')}</th>
        <td style="width:15%"><input name="SN_PRC_CCD_NM" type="text" class="input_t_dis" readonly  size="40"></td>
    </tr>
    <tr>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_007','처리지점')}</th>
        <td style="width:15%"><input name="DPRT_NM" type="text" class="input_t_dis" readonly  size="40"></td>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_008','처리자')}</th>
        <td style="width:15%"><input name="RPR_P_NM" type="text" class="input_t_dis" readonly  size="40"></td>
    </tr>
    <tr>
        <th class="title" style="width:10%">${msgel.getMsg('AML_20_02_10_02_011','처리일시')}</th>
        <td colspan="3" style="width:15%"><input name="RPR_P_DY_TM" type="text" class="input_t_dis" readonly  size="40"></td>
    </tr>
    <tr>
        <th class="title">${msgel.getMsg('AML_20_02_10_02_009')}</th>
        <td colspan="3"><textarea style="width:100%" name="CNTNT" rows="6" class="textarea-box" readonly></textarea></td>
    </tr>
</table>
</form>
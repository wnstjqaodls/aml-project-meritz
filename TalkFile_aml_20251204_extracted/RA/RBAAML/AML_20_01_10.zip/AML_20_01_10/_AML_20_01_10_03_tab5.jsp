<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 본점의심내역
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : ?
* Since           : ?
********************************************************************************************************************************************
* Modifier        : 민경진
* Update          : 2017. 5. 15.
* Alteration      : 1. 그디드에 devextreme 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 8.
* Alteration      : 1. 신규 레이아웃 적용, 코드 정리
*                   2. HTML5, Any Browser 적용
* Breakdown       : 1. 서버로부터 조회 된 항목값 표시 안되는 오류 수정
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 12. 14.
* Breakdown       : WebSphere의 EL Parser에서 BtnEL의 function 파라미터를 인식 못하는 문제 해결, 파라미터 별로 JAVASCRIPT function을 작성해줌
********************************************************************************************************************************************
--%>
<!-- [${msgel.getMsg('AML_20_01_01_03_107')}] 의심스러운 거래유형 및 정도와 의심스러운 거래서술 ${msgel.getMsg('AML_20_01_01_03_107')}작(본점) -->
   <div class="row" style="margin-bottom:5px;">
        <h4 class="tab-content-title">
            <span>${msgel.getMsg('AML_20_01_01_03_088','의심스러운 거래유형 등록(본점)')}</span>
         </h4>
    </div>
    
    <table class="basic-table" style="width:100%;">
      <tr>
          <th class="title" style="width:140px;" >${msgel.getMsg('AML_20_01_01_03_116')}</th>
          <td><textarea name="B_XCL_RSN_CNTNT" id="B_XCL_RSN_CNTNT" class='textarea-box' rows="2"></textarea></td>
      </tr>
      <tr>
          <th class="title">${msgel.getMsg('AML_20_01_10_03_119')}</th>
          <td><textarea name="B_DNY_RSN_CNTNT" id="B_DNY_RSN_CNTNT" class='textarea-box' rows="2" disabled></textarea></td>
      </tr>
      <tr>
			<th class="title">
			    ${msgel.getMsg('AML_20_01_01_03_077')}
			<input name="B_RPR_RSN_CNTNT_BYTES" type="text" class="table-box" size="10" style="text-align:right" disabled>
			</th>
			<td>
			 <textarea name="B_RPR_RSN_CNTNT" id="B_RPR_RSN_CNTNT" rows="9" class='textarea-box' onKeyUp="calcBytes('B');"></textarea>
			<div style="color:blue">※${msgel.getMsg('AML_20_01_10_03_208','금칙어를')}( < > & ; \ ) ${msgel.getMsg('AML_20_01_10_03_209','참조해서 작성해주세요.')}</div>
			</td>
	  </tr>
    </table>
              
    <div class="info-area2" style="overflow-y:initial;">
      <div class="info-left" style="width:50%">
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",0)%>
           </h5>
           <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",0);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
            <li>
                <input type="checkbox" id="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="B_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div>
                <textarea name='B_DOBT_TYP_KND_CD_501' rows='5' class='textarea-box' style="font-family: 'SpoqR';font-size: 14px;color: #444;"></textarea>
            </div>
    <%
            }
        }
    %>
         </ul>
        </div>
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",2)%>
            </h5>
             <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",2);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
            <li>
                <input type="checkbox" id="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="B_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div>
                <textarea name='B_DOBT_TYP_KND_CD_501' rows='4' class='textarea-box' style="font-family: 'SpoqR';font-size: 14px;color: #444;"></textarea>
            </div>
    <%
            }
        }
    %>
        </ul>
      </div>
         <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",4)%>
            </h5>
        <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",4);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
             <li>
                <input type="checkbox" id="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="B_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
            if (("501").equals(ELEMENT.getText("DOBT_TYP_KND_CD",i))) {
    %>
            <div style="margin:5px">
                <textarea name='B_DOBT_TYP_KND_CD_501' id='B_DOBT_TYP_KND_CD_501' rows='4' class='textarea-box' style="font-family: 'SpoqR';font-size: 14px;color: #444;"></textarea>
            </div>
    <%
            }
        }
    %>
          </ul>
        </div>
        <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_070','의심스러운 거래의 개요 및 보고 이유')}
        </h5>
        <table class="basic-table" style="width:100%;">
                <tr>
                    <th class="title" style="width:200px;" >${msgel.getMsg('AML_20_01_01_03_071')} </th>
                    <td><textarea name="B_ITEM_CNTNT1" id="B_ITEM_CNTNT1" class='textarea-box' rows="2"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_072')} </th>
                    <td><textarea name="B_ITEM_CNTNT2" id="B_ITEM_CNTNT2" class='textarea-box' rows="2"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_073')}</th>
                    <td><textarea name="B_ITEM_CNTNT3" id="B_ITEM_CNTNT3" class='textarea-box' rows="2"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_074')} </th>
                    <td><textarea name="B_ITEM_CNTNT4" id="B_ITEM_CNTNT4" class='textarea-box' rows="2"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_075')} </th>
                    <td><textarea name="B_ITEM_CNTNT5" id="B_ITEM_CNTNT5" class='textarea-box' rows="3"></textarea></td>
                </tr>
                <tr>
                    <th class="title">${msgel.getMsg('AML_20_01_01_03_076')} </th>
                    <td><textarea name="B_ITEM_CNTNT6" id="B_ITEM_CNTNT6" class='textarea-box' rows="5"></textarea></td>
                </tr>
              </table>
    </div>
    <div class="info-right" style="width:50%">
        <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",1)%>
            </h5>
         <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",1);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
           <li>
                <input type="checkbox" id="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="B_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
        }
    %>
       </ul>
         </div>
         <div class="info-check">
            <h5 class="info-title">
                <%=GROUP.getText("DOBT_TYP_KND_NM",3)%>
            </h5>
             <ul class="checklist">
    <%
        ELEMENT = (DataObj)GROUP.get("ELEMENT",3);
        for(int i=0;i<ELEMENT.getCount("DOBT_TYP_KND_CD");i++) {
    %>
           <li>
                <input type="checkbox" id="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>" name="B_DOBT_TYP_KND_CD" value="<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>">
                <label for="B_DOBT_TYP_KND_CD<%=ELEMENT.getText("DOBT_TYP_KND_CD",i) %>"><%=ELEMENT.getText("DOBT_TYP_KND_NM",i) %></label>
            </li>
    <%
        }
    %>
        </ul>
        </div>

           <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_078','의심스러운 거래의 등급 설정')}
            </h5>
            <div style="line-height:20px;margin-bottom:10px;margin-left: 20px;font-family:SpoqB; font-size:13px;">
                ${msgel.getMsg('AML_20_01_01_03_079')}
            </div>
             <div class="radio-item" style="line-height:20px;margin-left: 20px;">
	                <input id="B_DOBT_DL_GRD_CD1" name="B_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="1" checked>
	                <label for='B_DOBT_DL_GRD_CD1'>1. ${msgel.getMsg('AML_20_01_01_03_080')}</label>
	        </div>
	           <div class="radio-item" style="line-height:20px;">
	                <input id="B_DOBT_DL_GRD_CD2" name="B_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="2" checked>
	                <label for='B_DOBT_DL_GRD_CD2'>2. ${msgel.getMsg('AML_20_01_01_03_081')}</label>
	        </div>
	           <div class="radio-item" style="line-height:20px;">
	                <input id="B_DOBT_DL_GRD_CD3" name="B_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="3" checked>
	                <label for='B_DOBT_DL_GRD_CD3'>3. ${msgel.getMsg('AML_20_01_01_03_082')}</label>
	        </div>
	           <div class="radio-item" style="line-height:20px;">
	                <input id="B_DOBT_DL_GRD_CD4" name="B_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="4" checked>
	                <label for='B_DOBT_DL_GRD_CD4'>4. ${msgel.getMsg('AML_20_01_01_03_083')}</label>
	        </div>
	           <div class="radio-item" style="line-height:20px;">
	                <input id="B_DOBT_DL_GRD_CD5" name="B_DOBT_DL_GRD_CD" type="radio" class="div-cont-box-radio" value="5" checked>
	                <label for='B_DOBT_DL_GRD_CD5'>5. ${msgel.getMsg('AML_20_01_01_03_084')}</label>
	        </div>
<%-- 	        <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_085','별도송부 문서명 작성')}
            </h5>
             <div style="margin:5px">
                <textarea name="B_SEND_DOC_NM" id="B_SEND_DOC_NM" rows="3" class='textarea-box' ></textarea>
            </div> --%>
             <div style="margin-top:5px;"></div>
            <h5 class="info-title">
                ${msgel.getMsg('AML_20_01_01_03_086','첨부파일명 작성')}
            </h5>
            <div style="padding:5px" class="table-box-file">
    <%

        HashMap inputParam5 = new HashMap();
		inputParam5.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
		inputParam5.put("SSPS_DL_ID", SSPS_DL_ID);

        if( "Y".equals(MASTER_BRANCH)) {
    %>
                <div style="width:100%;border:0px;margin-bottom:5px;text-align:right;">
                <%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
                	${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"addFileBtn", defaultValue:"파일추가", mode:"C", function:"addFileTab5", cssClass:"btn-36"}')}
                	${btnel.getButton(outputAuth, '{btnID:"fileAdd", cdID:"createTransactionFileBtn", defaultValue:"3개월거래내역파일생성", mode:"C", function:"addStrXlsFileTab5(0)", cssClass:"btn-36"}')}
                <%}%>
                	<div id="uploaderTab5" style="display:none;"></div>
                </div>
                 <table class="data-table" style="width:100%">
                  <thead>
	                <tr style="background-color:#F5F5F5">
	                	<th height="25px" align="center">${msgel.getMsg('AML_90_01_03_04_001','업로드 된 파일')}</th>
	                </tr>
	              </thead>
	              <tbody>
	                <tr>
	                	<td valign="middle">
		    				<div class="content" id="selected-files">
		    					<div id="fileBox" >
    <%
            output = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam5);
            if(output.getCount("FILE_SEQ") != 0) {
                String FILE_SEQ_M       		= "";
                String FILE_POS_M       		= "";
                String USER_FILE_NM_M   		= "";
                String PHSC_FILE_NM_M   		= "";
                String FILE_SIZE_M      		= "";
                String DOWNLOAD_COUNT_M 	= "";

                for(int i=0; i<output.getCount("FILE_SEQ"); i++) {
                    FILE_SEQ_M          		= output.getText("FILE_SEQ"      ,i);
                    FILE_POS_M          		= output.getText("FILE_POS"      ,i);
                    USER_FILE_NM_M      	= output.getText("USER_FILE_NM"  ,i);
                    PHSC_FILE_NM_M      	= output.getText("PHSC_FILE_NM"  ,i);
                    FILE_SIZE_M         		= output.getText("FILE_SIZE"     ,i);
                    DOWNLOAD_COUNT_M	= output.getText("DOWNLOAD_COUNT",i);

                    request.setAttribute("FILE_SEQ_M"       ,FILE_SEQ_M       );
                    request.setAttribute("FILE_POS_M"       ,FILE_POS_M       );
                    request.setAttribute("USER_FILE_NM_M"   ,USER_FILE_NM_M   );
                    request.setAttribute("PHSC_FILE_NM_M"   ,PHSC_FILE_NM_M   );
                    request.setAttribute("FILE_SIZE_M"      ,FILE_SIZE_M      );
                    request.setAttribute("DOWNLOAD_COUNT_M" ,DOWNLOAD_COUNT_M );

                    HashMap paramMap = new HashMap();
                    paramMap.put("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
                    paramMap.put("SSPS_DL_ID",SSPS_DL_ID);
                    DataObj output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_01_SS", paramMap);
                    String sGNL_AC_NO	= "";
                    String sGDS_NO	= "";
    				String fileNm		= "";
    				String transExcelGubn = "N";
    				DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
    				String toDate = SSPS_DL_CRT_DT;
    				
    		        Calendar cal = Calendar.getInstance();
    		        cal.set(Integer.parseInt(toDate.substring(0,4)), Integer.parseInt(toDate.substring(4,6))-1, Integer.parseInt(toDate.substring(6,8)));
    		        cal.add(Calendar.MONTH, -3);
    		        String fromDate = DL_DT_FORMAT.format(cal.getTime());
    		        
    		        String DL_DT_A = jspeed.base.util.DateHelper.format(toDate, "yyyyMMdd", "yyyy-MM-dd");
    			    DL_DT_A = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(DL_DT_A,"yyyy-MM-dd"), -1), PropertyService.getInstance().getProperty("aml.config","dateFormat"));
 					toDate = DL_DT_A.replaceAll("-","") ;
 					
    				for ( int j = 0; j < output_0.getCount("ACNT_NO"); j++ ) {
	                    sGNL_AC_NO 		= output_0.getText("ACNT_NO_DEC", j);
	                    sGDS_NO 		= output_0.getText("GDS_NO", j);
	                    damoManager damo = new damoManager();
	                    fileNm = damo.pDecrypt(sGNL_AC_NO) + "_" + fromDate + "_" + toDate + ".xls";
	    				if(fileNm.equals(USER_FILE_NM_M)){
	    					transExcelGubn = "Y";
	    				}
    				}
                    request.setAttribute("TRANS_EXCEL_GUBN" ,transExcelGubn );

    %>
	                <div id="file<%=i%>" class="tx" style="height:30px;text-align:left;background-color:#FFFFFF;">
                        <i class="fa fa-floppy-o" style="font-size:14px;padding:6px 5px;" aria-hidden="true"></i>&nbsp;
                        <a class="filedown" href="javascript:downloadFile('${PHSC_FILE_NM_M}','${USER_FILE_NM_M}','${FILE_POS_M}','${FILE_SEQ_M}');">${USER_FILE_NM_M}</a>
                        <a onclick="viewDelete(this);" >
	                        <input name="fileSizes" class="fileSizes" type="hidden" value="${FILE_SIZE_M}"/>
				    		<input name="origFileNms" class="origFileNms" type="hidden" value="${USER_FILE_NM_M}"/>
				    		<input name="storedFileNms" class="storedFileNms" type="hidden" value="${PHSC_FILE_NM_M}"/>
				    		<input name="filePaths" class="filePaths" type="hidden" value="${FILE_POS_M}"/>
				    		<input type='hidden' name='transFileGubn' id='transFileGubn' value="${TRANS_EXCEL_GUBN}"/>
				    		<%if(ctlBtn02 != null && ctlBtn02.length() > 0) {%>
	                    	<div class="dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon strFlag<%=i%>" style="margin-left: 10px; margin-top:0.2em;"  role="button" aria-hidden="true" aria-label="close">
								<div class="dx-button-content" style="padding-left: 0.2em;">&nbsp;<i class="dx-icon dx-icon-close" ></i></div>
							</div>
							<%}%>
						</a>
					</div>
    <%
                }
            }
    %>
    							</div>
    						</div>
	                    </td>
	                </tr>
	                </tbody>
                </table>
    <%
        } else {
    %>
               <table class="grid-table-type" style="width:100%">
                  <thead>
	                <tr style="background-color:#F5F5F5">
	                	<th height="25px" align="center">${msgel.getMsg('AML_90_01_03_04_001','업로드 된 파일')}</th>
	                </tr>
	              </thead>
	              <tbody>
	                <tr>
	                	<td valign="middle">
		    				<div class="content" id="selected-files">
    <%
            output = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam5);
            if(output.getCount("FILE_SEQ") != 0) {
                String FILE_SEQ_M1 			= "";
                String FILE_POS_M1 			= "";
                String USER_FILE_NM_M1 	= "";
                String PHSC_FILE_NM_M1 	= "";
                String FILE_SIZE_M1 		= "";

                for(int i=0; i<output.getCount("FILE_SEQ"); i++) {
                    FILE_SEQ_M1 			= output.getText("FILE_SEQ"    ,i);
                    FILE_POS_M1 			= output.getText("FILE_POS",i);
                    USER_FILE_NM_M1 	= output.getText("USER_FILE_NM",i);
                    PHSC_FILE_NM_M1 	= output.getText("PHSC_FILE_NM",i);
                    FILE_SIZE_M1 			= output.getText("FILE_SIZE",i);

                    request.setAttribute("FILE_SEQ_M1"    ,FILE_SEQ_M1    );
                    request.setAttribute("USER_FILE_NM_M1",USER_FILE_NM_M1);
    %>
	                <div id="file<%=i%>" style="height:30px;text-align:left;background-color:#FFFFFF;">
                        <i class="fa fa-floppy-o" style="font-size:14px;padding:6px 5px;" aria-hidden="true"></i>&nbsp;
                        <a class="filedown" href="javascript:downloadFile('${PHSC_FILE_NM_M1}','${USER_FILE_NM_M1}','${FILE_POS_M1}','${FILE_SEQ_M1}');">${USER_FILE_NM_M1}</a>
					</div>
    <%
                }
            }
    %>
    						</div>
	                    </td>
	                </tr>
	                </tbody>
                </table>
    <%
		}
    %>
            </div>
              <table class="basic-table">
                <tr>
	             <th class="title" style="border-bottom:0px;">
	                <i class="fa fa-chevron-circle-right"></i>${msgel.getMsg('AML_20_01_01_03_087','관련문서번호')}
	            </th>
	            <td>
                <input name="B_RE_DOC" type="text" class="" style="display:inline-block;margin-left:5px;padding-left:5px;width:200px" value="" disabled/></td>
            </table>
            <%-- <h5 class="info-title" style="margin-top:108px;display: flex;padding-left: 16px;justify-content: space-between;align-items: center;">
            	${msgel.getMsg('AML_20_01_10_03_206','AI 참조')}
            </h5>
            <table class="basic-table">
	            <tr>
	            <th class="title" style="width:25%;border-bottom:0px;">
	                <div style="display:flex;align-items: center;justify-content: space-between;">
	                ${msgel.getMsg('AML_20_01_10_03_205','AI 종합의견(직전)')}
	                <div class="button-area" style="display:inline-block;float:right;">
	               		<button type="button" onclick="applyAIopi('batch')" id="B_applyAIopiBtn_Batch" class="btn-28" mode="R">${msgel.getMsg('AML_20_01_10_03_204','적용')}</button>
	            	</div>
	            	</div>
	            </th>
	            <td>
	            	<div style="color:blue;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_201','적용 시 종합의견에 삽입됩니다.')}</div>
	            	<div style="color:blue;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_202','최초에는 배치 수행 시 생성된 AI 종합의견입니다.')}</div>
	            	<textarea name="B_AI_RPR_RSN_CNTNT_BATCH" id="B_AI_RPR_RSN_CNTNT_BATCH" rows="9" class='textarea-box' style="margin-top:10px;"></textarea>
	            </td>
	            </tr>
	            <tr>
	            <th class="title" style="width:25%;border-bottom:0px;">
	                <div style="display:flex;align-items: center;justify-content: space-between;">
	                ${msgel.getMsg('AML_20_01_10_03_207','AI 종합의견')}
	                <div class="button-area" style="display:inline-block;float:right;">
	               		<button type="button" onclick="applyAIopi('base')" id="B_applyAIopiBtn" class="btn-28" mode="R" disabled>${msgel.getMsg('AML_20_01_10_03_204','적용')}</button>
	            	</div>
	            	</div>
	            </th>
	            <td>
	            	<div style="display:flex;align-items: center;justify-content: space-between;">
		            	<div style="color:blue;display:inline-block;font-family:SpoqR;">&nbsp;&nbsp;※${msgel.getMsg('AML_20_01_10_03_201','적용 시 종합의견에 삽입됩니다.')}</div>
		            	<div class="button-area" style="display:inline-block;float:right;">
		            		<button type="button" onclick="createAIopi()" id="B_createAIopiBtn" class="btn-28" mode="R">${msgel.getMsg('AML_20_01_10_03_203','신규생성')}</button>
		            	</div>
		            </div>
	            	<textarea name="B_AI_RPR_RSN_CNTNT" id="B_AI_RPR_RSN_CNTNT" rows="9" class='textarea-box' style="margin-top:10px;"></textarea>
	            </td>
	            </tr>
            </table> --%>
        </div> 
  </div>
 

<script>
	var fileSeq ="";
	//공통 첨부파일
	function addFileTab5() {
		var allowedFileExtensions = "${uploadFile}";
		var fileUploader = gtFileUploader("uploaderTab5",allowedFileExtensions,doSubmitTab5_end);
	}

	//선택한 첨부파일을 화면에 보여주기
	//임시첨부파일은 upload/attachTmp에 등록된다.
	function doSubmitTab5_end(fileData) {
		var addLine;
	    var divId = fileData.storedFileNm.substring(0,fileData.storedFileNm.lastIndexOf("."));

		if(fileData != undefined) {
      		addLine	= "<div id='"+divId+"'  style='height:30px;text-align:left;background-color:#FFFFFF;'>"
      			+"<i class='fa fa-floppy-o' style='font-size: 14px;padding:6px 5px;' aria-hidden='true'></i>&nbsp;&nbsp;"
				+ fileData.origFileNm
				+"<a onclick=\"tempFileDel('"+divId+"','/upload/attachTmp/','"+fileData.storedFileNm+"');\" >"
				+"    <input type='hidden' name='fileSizes' id='fileSizes' value='"+fileData.fileSize+"' />"
				+"    <input type='hidden' name='origFileNms' id='origFileNms' value='"+fileData.origFileNm+"' />"
				+"    <input type='hidden' name='storedFileNms' id='storedFileNms' value='"+fileData.storedFileNm+"' />"
				+"    <input type='hidden' name='filePaths' id='filePaths' value='"+fileData.filePath+"' />"
				+"    <div class='dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon' style='margin-left: 10px; margin-top:0.2em;'  role='button' aria-hidden='true' aria-label='close'>"
				+"	       <div class='dx-button-content'>&nbsp;<i class='dx-icon dx-icon-close'></i></div>"
				+"    </div>"
				+"</a>"
				+"</div>";
      		$("#fileBox").append(addLine);
		}
	}

	function addStrXlsFileTab5(gb) {
		var OK_CCD = $("#OK_CCD1")[0].options[$("#OK_CCD1")[0].selectedIndex].value;

		if(OK_CCD == "2"){
			showAlert("${msgel.getMsg('AML_20_01_10_03_009','보고제외에서는 파일생성을 할 수 없습니다.')}");
			return;
		}
    	if(gb == null) gb = "1";

    	showConfirm("${msgel.getMsg('AML_20_01_10_03_008','파일생성 하시겠습니까?')}", "파일생성",
	    		function(){

	    			addStrXlsFileTab5Action()
    	});
	    //$("#fileAdd"          ).attr("disabled",true);  //버튼 비활성화 주석 처리

	}

	function addStrXlsFileTab5Action() {
		$("#fileAdd"          ).attr("disabled",true);
		 var actionParam = {
                "pageID"        : "AML_20_01_10_03"
               ,"classID"       : "AML_20_01_10_03"
               ,"methodID"      : "doCreateTrExcelFile"
               ,"stDate"        : $("#stDate"        ).val()
               ,"edDate"        : $("#edDate"        ).val()
               ,"SSPS_DL_CRT_DT": $("#SSPS_DL_CRT_DT").val()
               ,"SSPS_DL_ID"    : $("#SSPS_DL_ID"    ).val()
               ,"DL_P_RNMCNO"   : "${DL_P_RNMCNO}"
		 }
		 sendService("AML_20_01_10_03", "doCreateTrExcelFile", actionParam, addStrXlsFileTab5_success, addStrXlsFileTab5_success);

	}

	function addStrXlsFileTab5_success(paramdata,jsonData) {
		var arrValue = jsonData.GRID_DATA[0].fileContent;
		if(arrValue != undefined ) {
			$("#fileBox").empty();
			setTimeout(function() {
			for(var j=0; j<arrValue.length; j++){
					var addLine;
					var storedFileNms = arrValue[j].storedFileNms;
					var divId = storedFileNms[j].substring(0,storedFileNms.lastIndexOf("."));
					var origFileNms = arrValue[j].origFileNms;
					var fileSizes = arrValue[j].fileSizes;
					var filePaths = arrValue[j].filePaths;
					var transFileGubn = arrValue[j].transExcelGubn;
					addLine	= "<div id='"+divId+"'  style='height:30px;text-align:left;background-color:#FFFFFF;'>"
		      			+"<i class='fa fa-floppy-o' style='font-size: 14px;padding:6px 5px;' aria-hidden='true'></i>&nbsp;&nbsp;"
						+ origFileNms
						+" <a onclick=\"tempFileDel('"+divId+"','"+filePaths+"','"+storedFileNms+"');\" >"
						+"<input type='hidden' name='fileSizes' id='fileSizes' value='"+fileSizes+"' />"
						+"<input type='hidden' name='origFileNms' id='origFileNms' value='"+origFileNms+"' />"
						+"<input type='hidden' name='storedFileNms' id='storedFileNms' value='"+storedFileNms+"' />"
						+"<input type='hidden' name='filePaths' id='filePaths' value='"+filePaths+"' />"
						+"<input type='hidden' name='transFileGubn' id='transFileGubn' value='"+transFileGubn+"' />"
						+"<div class='dx-fileuploader-button dx-fileuploader-cancel-button dx-button dx-button-normal dx-button-mode-contained dx-widget dx-button-has-icon' style='margin-left: 10px; margin-top:0.2em;'  role='button' aria-hidden='true' aria-label='close'>"
						+"	<div class='dx-button-content'>&nbsp;<i class='dx-icon dx-icon-close'></i></div>"
						+"</div>"
						+"</a>"
						+"</div>";
						fileSeq=divId;
	      			$("#fileBox").append(addLine);
			}
			$("#fileAdd"          ).attr("disabled",false)
		}, 500);
	}
	}

	function deleteFile(){
		$("#"+fileSeq).remove();
	}
</script>

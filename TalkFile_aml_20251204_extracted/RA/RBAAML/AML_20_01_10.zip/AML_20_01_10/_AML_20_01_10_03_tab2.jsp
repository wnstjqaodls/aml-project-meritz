<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 고객상세(개인)
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : ?
* Since           : ?
********************************************************************************************************************************************
* Modifier        : 민경진
* Update          : 2017. 5. 15.
* Alteration      : 1. 그디드에 devextreme 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 8. 8.
* Alteration      : 1. 신규 레이아웃 적용, 코드 정리
*                   2. HTML5, Any Browser 적용
********************************************************************************************************************************************
--%>
    <% 
    
	    DataObj input_p = new DataObj();
		input_p.add("RNMCNO", "");
		input_p.add("CS_NO", "");
		input_p.add("AML_CUST_ID"     , input.get("AML_CUST_ID"));
		input_p.add("INDV_CORP_CCD"   ,input.get("INDV_CORP_CCD"));
		
		DataObj input_s = new DataObj();
		input_s.add("RNMCNO", input.get("RNMCNO_HIDDEN"));
		input_s.add("CS_NO", "");
		input_s.add("AML_CUST_ID"     ,input.get("AML_CUST_ID"));
		input_s.add("INDV_CORP_CCD"   ,input.get("INDV_CORP_CCD"));
	
		// =================================================================================================================================
	    output = MDaoUtilSingle.getData("AML_10_06_01_01_getSearch_01_SS",input_p);
	    request.setAttribute("output",output);    
	    // =================================================================================================================================
    
   
        // =================================================================================================================================
        output_temp = MDaoUtilSingle.getData("AML_10_06_01_01_getSearch_02_SS",(HashMap)input_s); 
        request.setAttribute("output_temp",output_temp);    
        // =================================================================================================================================
    %>
   
<div style="width:100%">
<div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_642','AML정보')}</h4>
   </div>
</div> 

 	<div class="inquiry-table2 rowtype">
        <div class="table-row">
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_643", "CDD수행일자")}</div>
                <div class="content">${output_temp.CS_CDD_REG_DT}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_603", "위험등급")}</div>
                <div class="content">${output_temp.RSK_GRD_CD}</div>
            </div>
        </div>
        
        <div class="table-row">
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_645", "재수행예정일자")}</div>
                <div class="content">${output_temp.CS_REQ_DT}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_646", "CDD수행채널")}</div>
                <div class="content">${output_temp.CDD_CHNL_NAME}</div>
            </div>
        </div>
        
        <div class="table-row">
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_647", "CTR보고횟수")}</div>
                <div class="content">${output_temp.CTR_TOTAL}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_648", "STR보고횟수")}</div>
                <div class="content">${output_temp.STR_TOTAL}</div>
            </div>
        </div>
        
        <div class="table-row">
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_645", "최근CTR보고횟수")}</div>
                <div class="content">${output_temp.CTR_YEAR}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_646", "최근STR보고횟수")}</div>
                <div class="content">${output_temp.STR_YEAR}</div>
            </div>
        </div> 
    </div>
 
<%if(INDV_CORP_CCD.equals("2")) { %>
<div style="width:100%">
<div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_660','대표자정보')}</h4>
   </div>
</div>
    
    <div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_24_01_03_01_055", "대표자명")}1</div>
                <div class="content">${output.RPRST_P_NM1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_023", "대표자생년월일")}</div>
                <div class="content">${output.RPRST_P_BRDY1}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_009", "대표자국적")}</div>
                <div class="content">${output.RPRST_P_NTNLT1}</div>
            </div>
        </div>
        
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_24_01_03_01_055", "대표자명")}2</div>
                <div class="content">${output.RPRST_P_NM2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_023", "대표자생년월일")}</div>
                <div class="content">${output.RPRST_P_BRDY2}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_009", "대표자국적")}</div>
                <div class="content">${output.RPRST_P_NTNLT2}</div>
            </div>
        </div>
        
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_24_01_03_01_055", "대표자명")}3</div>
                <div class="content">${output.RPRST_P_NM3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_023", "대표자생년월일")}</div>
                <div class="content">${output.RPRST_P_BRDY3}</div>
            </div>
            <div class="table-cell row2">
                <div class="title">${msgel.getMsg("AML_20_01_01_20_009", "대표자국적")}</div>
                <div class="content">${output.RPRST_P_NTNLT3}</div>
            </div>
        </div>
    </div>

<div style="width:100%">
	<div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_665','실제소유자정보')}1</h4>
   </div>
</div>

	<div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_666", "순번")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_667", "성명")}</div>
                <div class="content">${output_temp.RPRST_P_NM1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_668", "소속국적")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_669", "생년월일")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT1}</div>
            </div>
        </div> 
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_671", "확인단계")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법")}</div>
                <div class="content">${output_temp.RPRST_P_NM1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법(기타)")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY1}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_673", "지분율")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT1}</div>
            </div>
        </div>
    </div>

<div style="width:100%">
	<div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_665','실제소유자정보')}2</h4>
   </div>
</div>

	<div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_666", "순번")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_667", "성명")}</div>
                <div class="content">${output_temp.RPRST_P_NM2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_668", "소속국적")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_669", "생년월일")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT2}</div>
            </div>
        </div> 
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_671", "확인단계")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법")}</div>
                <div class="content">${output_temp.RPRST_P_NM2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법(기타)")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY2}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_673", "지분율")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT2}</div>
            </div>
        </div>
    </div>
 
 <div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_665','실제소유자정보')}3</h4>
</div>

	<div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_666", "순번")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_667", "성명")}</div>
                <div class="content">${output_temp.RPRST_P_NM3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_668", "소속국적")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_669", "생년월일")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT3}</div>
            </div>
        </div> 
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_671", "확인단계")}</div>
                <div class="content">${output_temp.REL_OWNR_SQNO3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법")}</div>
                <div class="content">${output_temp.RPRST_P_NM3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_672", "확인방법(기타)")}</div>
                <div class="content">${output_temp.REL_OWNR_NTNY3}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_673", "지분율")}</div>
                <div class="content">${output_temp.REL_OWNR_BRDT3}</div>
            </div>
        </div>
    </div> 
 
<%} %>

<div style="width:100%">
<div class="row">
   	<h4 class="tab-content-title">${msgel.getMsg('AML_20_01_10_03_680','EDD정보')}</h4>
   </div>
</div>    
	<%
        if(INDV_CORP_CCD.equals("1")) {
    %>
    
    <div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_681", "거래목적")}</div>
                <div class="content">${output_temp.NDVL_TRDG_PRPS}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_667", "자금원천및출처")}</div>
                <div class="content">${output_temp.NDVL_FUNS_ORIG}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_668", "예상거래횟수")}</div>
                <div class="content">${output_temp.NDVL_FRCT_TRDG_CNT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_669", "예상거래규모")}</div>
                <div class="content">${output_temp.NDVL_FRCT_TRDG_SCL}</div>
            </div>
        </div> 
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_685", "직장명")}</div>
                <div class="content">${output_temp.SITE_NAME}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_686", "소속국가")}</div>
                <div class="content">${output_temp.SITE_NTNY}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_687", "사업체명")}</div>
                <div class="content">${output_temp.BUSN_ENTP_NAME}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_688", "소속국가")}</div>
                <div class="content">${output_temp.BUSN_ENTP_NTNY}</div>
            </div>
        </div>
    </div> 
    
    <%} else { %>  
    <div class="inquiry-table2 rowtype">
        <div class="table-row">
        	<div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_681", "거래목적")}</div>
                <div class="content">${output_temp.INSN_TRDG_PRPS}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_667", "자금원천및출처")}</div>
                <div class="content">${output_temp.INSN_FUNS_ORIG}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_668", "예상거래횟수")}</div>
                <div class="content">${output_temp.INSN_FRCT_TRDG_CNT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_669", "예상거래규모")}</div>
                <div class="content">${output_temp.INSN_FRCT_TRDG_SCL}</div>
            </div>
        </div> 
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_689", "법인규모구분")}</div>
                <div class="content">${output_temp.INSN_SCL_SECT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_690", "상장정보")}</div>
                <div class="content">${output_temp.INSN_LSTG_MRKT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_687", "상장거래소명")}</div>
                <div class="content">${output_temp.INSN_LSTG_MRKT_NAME}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_688", "홈페이지(이메일)")}</div>
                <div class="content">${output_temp.URL_ADRS}</div>
            </div>
        </div>
        
        <div class="table-row">
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_693", "종업원수")}</div>
                <div class="content">${output_temp.INSN_EMPY_CONT}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_694", "주요상품및서비스")}</div>
                <div class="content">${output_temp.INSN_MJOR_PRDT_NAME}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_695", "주요활동국가")}</div>
                <div class="content">${output_temp.INSN_MJOR_ACTI_CNTY}</div>
            </div>
            <div class="table-cell">
                <div class="title">${msgel.getMsg("AML_20_01_10_03_696", "조직구성원수")}</div>
                <div class="content">${output_temp.INSN_ORGZ_MBR_CONT}</div>
            </div>
        </div>
    </div> 
    <% } %>
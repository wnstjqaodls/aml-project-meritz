<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 상세__상세조회
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : bmy
* Since           : 2018. 08. 09.
--%>

<%@ page import="java.util.*" %>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" /> 
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %> 

<%
	// MASTER_BRANCHd
	String SSPS_DL_CRT_DT   = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_CRT_DT"))); 	
	String SSPS_DL_ID   	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_ID")));
	String DNY_RSN_CNTNT 	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("DNY_RSN_CNTNT")));
	String DNY_RSN_CNTNT_READONLY_YN = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("DNY_RSN_CNTNT_READONLY_YN")));
	
	request.setAttribute("SSPS_DL_ID",SSPS_DL_ID);
	request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	request.setAttribute("DNY_RSN_CNTNT",DNY_RSN_CNTNT); 
%>	

<script language="JavaScript">

	var overlay = new Overlay();

    $(document).ready(function(){
    	
    }); 

	function doSave(){  
		
		showConfirm('${msgel.getMsg("AML_20_01_10_01_005","반려 처리를 하시겠습니까?")}', "반려", doSave2Action);
	}	
	
	 function doSave2Action() {
		 
	   var DNY_RSN_CNTNT = form1.DNY_RSN_CNTNT.value ; 
	   parent.window.opener.focus();		
	   parent.window.opener.openerView.doSave2(DNY_RSN_CNTNT);
	   window.close();
    }
	 
	function doClose(){
		window.close();
	}
	
	// 팝업창을 우측상단에 X로 닫았을때 실행되는 펑션 20170324 KEOL 
	function closePage( event ){
	    if( event.clientY < 0 ){
	    	doClose();
	    }
	}
	
	   // F5새로고침, 뒤로가기 막기
	   document.onkeydown = function(e) 
	   {
	    key = (e) ? e.keyCode : event.keyCode;
	    ctrl = (e) ? e.ctrlKey  : event.ctrlKey;
// 	     if( (ctrl == true && (key == 78 || key == 82)) || key==8 || key==116) 
	     if( (ctrl == true && (key == 78 || key == 82)) || key==116) // key==8은 백스페이스도 막는다
	     {
	       if(e) 
	       {
	         e.preventDefault();
	       } 
	       else 
	       {
	              event.keyCode = 0;
	              event.returnValue = false;
	       }
	     }
	   }
	   
	   // 마우스 우클릭금지
	   document.oncontextmenu = function (e) {
	      return false;
	   }
</script>

<body onunload="closePage(event)">

<form name="form1" method="post">
	<input type="hidden" name="pageID">
	<input type="hidden" name="classID">
	<input type="hidden" name="methodID">

	<div class="popup-cont-box">
	    <div class="cond-box" id="condBox1" style="margin-top:0px;margin-bottom:0px">
	        <div class="cond-row">  	               
            	<textarea name='DNY_RSN_CNTNT' rows='5' class='textarea-box' style='width:100%; margin-top: 8px;'> ${DNY_RSN_CNTNT}</textarea>  
	        </div>		    
		</div>
	 	<div class="button-area"  style="float:right;text-align:right;">
	 	<%  if (!"Y".equals(DNY_RSN_CNTNT_READONLY_YN)) {  System.out.println("sssssss");   %>
			${btnel.getButton(outputAuth, '{btnID:"btn_02", cdID:"saveBtn", defaultValue:"저장", mode:"R", function:"doSave", cssClass:"btn-36 filled"}')} 
		<% }  %> 
		    ${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"doClose", cssClass:"btn-36"}')}
		</div>
	</div>

</form>

<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" /> 

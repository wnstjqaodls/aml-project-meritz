<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%> 
<%--
- File Name  : AML_20_01_10_99.jsp
- Author     : 
- Comment    : Save 후처리
- Version    : 1.0
- history    : 1.0 2015-10-08
--%>
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_top.jsp" flush="true" />
<%
	DataObj dataObj = (DataObj) request.getAttribute("output");
	request.setAttribute("ERRCODE", dataObj.getText("ERRCODE"));
	request.setAttribute("ERRMSG", dataObj.getText("ERRMSG"));	

%>
<html>
<script language="JavaScript">
<!--
alert("${ERRMSG}");

if("${ERRCODE}" == "00000"){
	parent.doSave_end();
	parent.window.close();
}
-->	
</script>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_bottom.jsp" flush="true" />
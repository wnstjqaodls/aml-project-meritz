<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : STR 결재 병합 / 해제
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 권얼
* Since           : 2017. 3. 27.
********************************************************************************************************************************************
* Modifier        : 송지윤
* Update          : 2017. 10. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
*                   2. 코드정리
*                   3. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
--%>

<%@ page import="java.util.*" %>
<%-- <%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01.AML_20_01_01_03" %> --%>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03" %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_06" %>

<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %> 
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_top.jsp" flush="true" /> 

<%
	// MASTER_BRANCHd
	String SSPS_DL_CRT_DT   = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_CRT_DT"))); 	
	String SSPS_DL_ID   	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("SSPS_DL_ID")));
	String ACT_NAME_MASTER 	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("ACT_NAME_MASTER")));
	String approval         = Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("approval")), "false");
	String modify         	= Util.nvl(jspeed.base.xml.XMLHelper.normalize(request.getParameter("modify")), "false");
	
	DataObj in1  = new DataObj();	
	in1.add("SSPS_DL_ID",SSPS_DL_ID);
	in1.add("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	
	DataObj out1 = AML_20_01_10_03.getInstance().getCustInfo(in1);
	
	String SSPS_TYP_CD   	= out1.getText("SSPS_TYP_CD");		
	String SSPS_TYP_NM  	= out1.getText("SSPS_TYP_NM");		
	String RPR_PRGRS_CCD   	= out1.getText("RPR_PRGRS_CCD");	
	String INDV_CORP_CCD   	= out1.getText("INDV_CORP_CCD");	
	String DL_P_RNM_NO_CCD  = out1.getText("DL_P_RNM_NO_CCD");	
	String DL_P_RNM_NO_CCD_NM=out1.getText("DL_P_RNM_NO_CCD_NM");
	String DL_P_RNMCNO   	= out1.getText("DL_P_RNMCNO");		
	String DL_P_NM   		= out1.getText("DL_P_NM");			
	String INST_ID          = out1.getText("INST_ID");
	
	// 병합여부값 가져오기 20170404 KEOL
	out1.clear();
	in1.add("DL_P_RNMCNO", DL_P_RNMCNO);
	out1 = AML_20_01_10_06.getInstance().getMergeInfo(in1);
	String MERGE_YN = out1.getText("MERGE_YN");
	
	request.setAttribute("SSPS_DL_ID",SSPS_DL_ID);
	request.setAttribute("SSPS_DL_CRT_DT",SSPS_DL_CRT_DT);
	request.setAttribute("SSPS_TYP_CD",SSPS_TYP_CD);
	request.setAttribute("SSPS_TYP_NM",SSPS_TYP_NM);
	request.setAttribute("RPR_PRGRS_CCD",RPR_PRGRS_CCD);
	request.setAttribute("INDV_CORP_CCD",INDV_CORP_CCD);
	request.setAttribute("DL_P_RNM_NO_CCD",DL_P_RNM_NO_CCD);
	request.setAttribute("DL_P_RNM_NO_CCD_NM",DL_P_RNM_NO_CCD_NM);
	request.setAttribute("DL_P_RNMCNO",DL_P_RNMCNO);
	request.setAttribute("DL_P_NM",DL_P_NM);
	request.setAttribute("INST_ID",INST_ID);
	request.setAttribute("MERGE_YN",MERGE_YN);
	request.setAttribute("ACT_NAME_MASTER",ACT_NAME_MASTER);
	request.setAttribute("approval",approval);
	request.setAttribute("modify",modify);
	
%>	

<script language="JavaScript">

	var GridObj1 = null;
	var overlay = new Overlay();
    var pageID	 = "AML_20_01_10_06";	
	var classID  = "AML_20_01_10_06";
	var dataSource = [];

    $(document).ready(function(){
        setupGrids();
    });
    

    function setupGrids(){
    	GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
        	dataSource 				: dataSource,
        	gridId 					: "GTDataGrid1",	
        	"elementAttr"           : { class: "grid-table-type" },
			"width" 				:"100%",
			"height" : "calc(70vh - 100px)",
			"hoverStateEnabled"		: true,
			"wordWrapEnabled"		: false,
			"allowColumnResizing"	: true,
			"columnAutoWidth"		: true,
			"allowColumnReordering"	: true,
			"cacheEnabled"			: false,
			"cellHintEnabled"		: true,
			"showBorders"			: true,
			"showColumnLines"		: true,
			"showRowLines"			: true,
    	    "onToolbarPreparing"	: makeToolbarButtonGrids,
			"export"				: {"allowExportSelectedData": true, "enabled": false, "excelFilterEnabled": true, "fileName": "gridExport"},
			"sorting"				: {"mode": "multiple"},
			"remoteOperations"		: {"filtering": false, "grouping": false, "paging": false, "sorting": false, "summary": false},
    	    "editing" 				: {"mode": "cell", "allowUpdating": false, "allowAdding": false, "allowDeleting": false},
    	    "filterRow"				: {"visible": false},
    	    "rowAlternationEnabled"	: true,
    	    "columnFixing"			: {"enabled": true},
    	    pager: {
    	    	visible: true
    	    	,showNavigationButtons: true
    	    	,showInfo: true
    	    },
    	    paging: {
    	    	enabled : true
    	    	,pageSize : 20
    	    },
	 	   	scrolling : {
	            mode            : "standard"
	           ,preloadEnabled  : false
	        },
    	    "searchPanel"			: {"visible": false, "width": 250},
    	    "selection"				: {"allowSelectAll": true, "deferred": false, "mode": "multiple", "selectAllMode": "allPages", "showCheckBoxesMode": "always"},
    	    "columns": [
    	        {"dataField": "SSPS_DL_ID_F", 		"caption": '${msgel.getMsg("AML_20_01_01_03_003","혐의거래ID")}', "alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "SSPS_TYP_NM",    	"caption": '${msgel.getMsg("AML_20_01_01_03_005","혐의명")}', "alignment": "left", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "ACT_NAME",			"caption": '${msgel.getMsg("AML_20_01_11_01_003","결재단계")}', "alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "M_SSPS_DL_CRT_DT", 	"caption": '${msgel.getMsg("AML_20_01_10_06_001","병합여부")}', "alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true},
    	        {"dataField": "SSPS_DL_CRT_DT", 	"caption": '${msgel.getMsg("AML_20_02_10_01_002","추출일자")}', "alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true, "visible": false},
    	        {"dataField": "SSPS_DL_ID", 		"caption": '${msgel.getMsg("AML_20_01_01_03_003","혐의거래ID")}', "alignment": "center", "allowResizing": true, "allowSearch": true, "allowSorting": true, "visible": false},
    	     ],
//     	     "summary": {"totalItems": [    {
//      	        "column": "SSPS_DL_ID_F",
//      	        "summaryType": "count",
//      	        "alignment": "center",
//      			"valueFormat": "fixedPoint"
//      	    }],texts: {count: '${msgel.getMsg("AML_90_02_04_01_202","총: {0}건")}'}},
    	     "onCellClick": function(e){ if(e.data ){            Grid1CellClick('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField);        } },
    	     "onInitialized" : function(e) {
             	doSearch();
             }
         }).dxDataGrid("instance");
    }
  
	function doSearch(){
		var params = new Object();
		var methodID = "doSearch";
		overlay.show(true, true);
		params.SSPS_DL_CRT_DT 	= $("#SSPS_DL_CRT_DT").val();
		params.SSPS_DL_ID 		= $("#SSPS_DL_ID").val();
		params.DL_P_RNMCNO 		= $("#DL_P_RNMCNO").val();
		
		sendService(classID, methodID, params, doSearch_success, doSearch_fail); 
	}	
	
	function doSearch_success(gridData, data){
        try {
   	    	GridObj1.refresh();
   	        GridObj1.option("dataSource",gridData);
   		} catch (e) {
   	        showAlert(e,"ERR");
   	        overlay.hide();
   	    } finally {
   	        overlay.hide();
   	    }
    }
    
    function doSearch_fail(){    	 
    	overlay.hide();
    }
	
	function doMerge() {
		var rowData, selData, count, temp, ACT_NAME, M_SSPS_DL_CRT_DT, row = GridObj1.totalCount();
		
		selData = GridObj1.getSelectedRowsData();
		
		for(var i = 0, count = 0; i < selData.length; i++) {
			rowData = selData[i];
			ACT_NAME = rowData.ACT_NAME;
			M_SSPS_DL_CRT_DT = rowData.M_SSPS_DL_CRT_DT;
			if (count == 0) temp = M_SSPS_DL_CRT_DT;
			else {
				if (temp != M_SSPS_DL_CRT_DT) {
					showAlert("${msgel.getMsg('AML_20_01_10_06_002','선택한 대상들의 병합여부가 같은 상태여야만 진행이 가능합니다.')}","WARN");
					return;
				}
				temp = M_SSPS_DL_CRT_DT;
			}
			
			// 마스터시나리오의 병합여부가 'Y'인 상태에서 병합되지 않았던 시나리오를 선택하고 병합/해제 버튼을 눌렀을경우.
			if (M_SSPS_DL_CRT_DT != "${MERGE_YN}") {
				showAlert("${msgel.getMsg('AML_20_01_10_06_003','병합되지 않은 건을 해제할 수 없습니다. 다시 확인해주세요.')}","WARN");
				return;
			}
			
			// AML_20_01_10_01.jsp 그리드에서 넘어온 결재단계와 현재 팝업창 그리드의 결재단계의 값이 같을 경우에만 병합/해제가 가능하도록해야한다.
			if (ACT_NAME == "${ACT_NAME_MASTER}") {
				count++;
			} else {
				showAlert("${msgel.getMsg('AML_20_01_10_06_004','병합/해제는 지점책임자 결재까지 완료 된 시나리오만 가능합니다.')}","WARN");
				return;
			}
		}
		
		if(selData.length < 1) {
			showAlert("${msgel.getMsg('AML_20_01_10_01_001','대상건이 존재하지 않습니다.')}","WARN");
			return;
        }
		
        var params = new Object();
		var methodID = "doMerge";
		overlay.show(true, true);
		params.pageID = form1.pageID.value;
		params.SSPS_DL_ID_MASTER 		= form1.SSPS_DL_ID_MASTER.value;
		params.SSPS_DL_CRT_DT_MASTER 	= form1.SSPS_DL_CRT_DT_MASTER.value;
		params.ACT_NAME_MASTER 			= form1.ACT_NAME_MASTER.value;
		params.MERGE_YN 				= form1.MERGE_YN.value; 
		params.DL_P_NM                  = form1.DL_P_NM.value;
		params.gridData = selData;
		sendService(classID, methodID, params, doMerge_success, doMerge_fail); 
	}
	   
	function doMerge_success(gridData, data){
		GridObj1.refresh();
	    GridObj1.option("dataSource",gridData);
	    overlay.hide(); 
		form1.pageID.value = "AML_20_01_10_06";

		_url = "?pageID=AML_20_01_10_06" + "&SSPS_DL_CRT_DT=" + $("input[name=SSPS_DL_CRT_DT_MASTER]").val() + "&SSPS_DL_ID=" + $("input[name=SSPS_DL_ID_MASTER]").val();
		_url = _url  + "&ACT_NAME_MASTER" + $("input[name=ACT_NAME_MASTER]").value + "&approval=" + $("input[name=approval]").val() + "&modify=" + 'true';
		//alert(_url);			
	    form1.target = "_self";
		form1.action = "<c:url value='/'/>0001.do" + _url;
			
		form1.submit();
	}
	
	function doMerge_fail(){    	 
    	overlay.hide();
    }
	
	function doClose(){
		doParentReload();
		window.close();
	}
	
	function doParentReload() {
		//AML_20_01_10_01.jsp(STR결재에서 넘어온 팝업일 경우 + 병합/해제처리한 경우에만 새로고침 하도록 수정)
		if ($("#approval").val() == 'true' && $("#modify").val() == 'true') {
			parent.window.opener.location.href = parent.window.opener.document.URL;	// 부모창 새로고침
		}
	}
	
	// 팝업창을 우측상단에 X로 닫았을때 실행되는 펑션 20170324 KEOL 
	function closePage( event ){
	    if( event.clientY < 0 ){
	    	doClose();
	    }
	}
	
	   // F5새로고침, 뒤로가기 막기
	document.onkeydown = function(e) {
		key = (e) ? e.keyCode : event.keyCode;
		ctrl = (e) ? e.ctrlKey  : event.ctrlKey;
// 	     if( (ctrl == true && (key == 78 || key == 82)) || key==8 || key==116) 
	     if( (ctrl == true && (key == 78 || key == 82)) || key==116) {// key==8은 백스페이스도 막는다
	       if(e) {
	         e.preventDefault();
	       } else {
	              event.keyCode = 0;
	              event.returnValue = false;
	       }
		}
	}

	   // 마우스 우클릭금지
	   document.oncontextmenu = function (e) {
	      return false;
	   }

	function makeToolbarButtonGrids(e){
		    var cmpnt; cmpnt = e.component;
		    var useYN = "${outputAuth.USE_YN  }";  // 사용 유무
		    var authC = "${outputAuth.C       }";  // 추가,수정 권한
		    var authD = "${outputAuth.D       }";  // 삭제 권한
		    if (useYN=="Y") {
		        var gridID       = e.element.attr("id");    // 그리드 아이디
		        var toolbarItems = e.toolbarOptions.items;
		        toolbarItems.splice(0, 0, {
		            "locateInMenu"  : "auto"
		            ,"location"     : "after"
		            ,"widget"       : "dxButton"
		            ,"name"         : "filterButton"
		            ,"showText"     : "inMenu"
		            ,"options"      : {
		                     "icon"      : "" 
		                   	,"elementAttr": { class: "btn-28 filter popupFilter" }
		        			,"text"      : ""       
		                    ,"hint"      : '필터'
		                    ,"disabled"  : false
		                    ,"onClick"   : function(){
									setupFilter();
	                    }
	             }
	        });
	    }
	}

    function setupFilter(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid1_Area";
    	gridObj.title = "";
    	gridArrs[0] = gridObj;    	
    	
    	setupGridFilter2(gridArrs , FLAG);	
    }
	    
</script>

<body onunload="closePage(event)">

<form name="form1" method="post">
	<input type="hidden" name="pageID">
	<input type="hidden" name="classID">
	<input type="hidden" name="methodID">
	<input type="hidden" name="DL_P_RNMCNO" value="${DL_P_RNMCNO}" >
	<input type="hidden" name="SSPS_DL_CRT_DT" value="${SSPS_DL_CRT_DT}" >
	<input type="hidden" name="SSPS_DL_ID_MASTER" value="${SSPS_DL_ID}" >
	<input type="hidden" name="SSPS_DL_CRT_DT_MASTER" id="SSPS_DL_CRT_DT_MASTER" value="${SSPS_DL_CRT_DT}" >
	<input type="hidden" name="ACT_NAME_MASTER" value="${ACT_NAME_MASTER}" >
	<input type="hidden" name="approval" value="${approval}">
	<input type="hidden" name="modify" value="${modify}">

<table class="basic-table" style="width:100%">
	<colgroup>
    	<col width="120px">
    	<col width="">
        <col width="120px">
        <col width="">
        <col width="120px">
        <col width="">
	</colgroup>
	<tbody>
       <tr>
       <th class="table-cell" >
            ${condel.getLabel('AML_20_01_01_01_011','추출일자ID')}
        </th>
        <td class="content">
        	<input name="SSPS_DL_CRT_DT" id="SSPS_DL_CRT_DT" type="text" class="cond-input" value="${SSPS_DL_CRT_DT}" readonly>
        </td>
        <th class="table-cell" >
            ${condel.getLabel('AML_20_01_01_03_003','혐의거래ID')}
        </th>
        <td class="content">
        	<input name="SSPS_DL_ID" id="SSPS_DL_ID" type="text" class="cond-input" value="${SSPS_DL_ID}" size="17" readonly>
        </td>
        <th class="table-cell">
	        ${condel.getLabel('AML_20_01_01_03_006','실명확인구분')}</th>
	    <td class="content">
	   		<input name="DL_P_RNM_NO_CCD" id="DL_P_RNM_NO_CCD" type="hidden" value="${DL_P_RNM_NO_CCD}">
	       	<input name="DL_P_RNM_NO_CCD_NM" id="DL_P_RNM_NO_CCD_NM" type="text" class="cond-input" value="${DL_P_RNM_NO_CCD_NM}" size="17" readonly>
	    </td>
       </tr>
       <tr>
       	<th class="table-cell"> 
            ${condel.getLabel('AML_20_01_01_03_004','혐의코드')}</th>
        <td class="content">
        	<input name="SSPS_TYP_CD" id="SSPS_TYP_CD" type="text" class="cond-input" value="${SSPS_TYP_CD}" size="17" readonly>
        </td>
        <th class="table-cell">
            ${condel.getLabel('AML_20_01_01_03_005','혐의명')}</th>
        <td class="content" colspan="3">
        	<input name="SSPS_TYP_NM" id="SSPS_TYP_NM" type="text" class="cond-input" value="${SSPS_TYP_NM}" size="17" readonly>
        </td>
       </tr>
       <tr>
       	<th class="table-cell">
	        ${condel.getLabel('AML_20_01_11_01_013','실명번호')}</th>
	    <td class="content">
	        <input name="DL_P_RNMCNO" id="DL_P_RNMCNO" type="text" class="cond-input" value="${DL_P_RNMCNO}" size="17" readonly>
	    </td>
	    <th class="table-cell">
	        ${condel.getLabel('AML_20_01_01_03_008','고객명')}</th>
	    <td class="content">
	        <input name="DL_P_NM" id="DL_P_NM" type="text" class="cond-input" value="${DL_P_NM}" size="17" readonly>
	    </td>
	    <th class="table-cell">
	    	${condel.getLabel('AML_20_01_10_06_001','병합여부')}</th>
	    <td class="content">
	        <input style="color:red" name="MERGE_YN" id="MERGE_YN" type="text" value="${MERGE_YN}" size="17" readonly>
	    </td>
       </tr>	
	</tbody>																	
</table>

    <div class="tab-content-bottom" style="padding-top:8px;">
        <div id="GTDataGrid1_Area"></div>
    </div>
	<div class="button-area" style="display: flex;justify-content: flex-end; margin-top: 8px;">
	    ${btnel.getButton(outputAuth, '{btnID:"sbtn_04", cdID:"", defaultValue:"병합/해제", mode:"U", function:"doMerge", cssClass:"btn-36"}')}
	    ${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"closeBtn", defaultValue:"닫기", mode:"R", function:"doClose", cssClass:"btn-36"}')}
	</div>
</form>
</body>
<jsp:include page="/WEB-INF/Package/AML/common/popUp_common_bottom.jsp" flush="true" /> 

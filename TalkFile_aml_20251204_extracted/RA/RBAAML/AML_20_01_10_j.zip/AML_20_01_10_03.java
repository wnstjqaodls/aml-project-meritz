/*
 * Copyright (c) 2008-2018 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.util.BizException;
import com.gtone.aml.user.SessionAML;
import com.gtone.aml.workflow.AMLWF4Interface;
import com.gtone.express.Constants;
import com.gtone.express.server.helper.MessageHelper;
import com.gtone.express.util.FileUtil;
import com.itplus.common.server.user.SessionHelper;
import com.penta.scpdb.ScpDbAgent;
import com.penta.scpdb.ScpDbAgentException;

import jspeed.base.util.StringHelper;
import jspeed.websvc.WSParam;
import kr.co.itplus.jwizard.dataformat.DataSet;
import com.ss.common.util.security.damo.damoManager;

/******************************************************************************************************************************************
 * @Description STR 결재 상세
 *              STR決裁の詳細
 *              STR Approval Details
 * @Group       GTONE, R&D센터/개발2본부
 * @Project     AML/RBA/FATCA/CRS/WLF
 * @Java        6.0 이상
 * @Author      서윤경, 김현일
 * @Since       2010. 9. 30.
 ******************************************************************************************************************************************
 * @Modifier    박상훈
 * @Update      2018. 1. 16.
 * @Alteration  코드정리 및 dofileSave 메서드에서  잘못 사용하고 있는 uploadPath.notice => uploadPath.tms 로 수정
 ******************************************************************************************************************************************/

public class AML_20_01_10_03 extends GetResultObject {
    /**************************************************************************************************************************************
     * Attributes
     **************************************************************************************************************************************/

    /** 인스턴스 */
    private static AML_20_01_10_03 instance = null;

    /**************************************************************************************************************************************
     * Methods
     **************************************************************************************************************************************/

    // [ do ]

    @SuppressWarnings("unchecked")
    public void doDeleteFileTrList(DataObj input) {
        try {
            MDaoUtilSingle.setData("AML_20_01_10_03_doDeleteFile_NIC64B", input);
        } catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "doDeleteFileTrList", e.getMessage());
        }
    }

    /**
     * 첨부파일조회
     * <p>
     * @param   input
     *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  <code>DataObj</code>
     *              GRID_DATA(첨부파일조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *              GRID_DATA(@jp DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     */
    public DataObj doFileSearch(DataObj input) {
        DataObj output = new DataObj();
        DataObj output_file = new DataObj();
        try {
            String SSPS_DL_CRT_DT = input.getText("SSPS_DL_CRT_DT");
            String SSPS_DL_ID = input.getText("SSPS_DL_ID");

            HashMap inputParam = new HashMap();
            inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
            inputParam.put("SSPS_DL_ID", SSPS_DL_ID);

            // Attachments ==========================================================
            output_file = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam);
            if ( output_file.getCount("FILE_SEQ") > 0 ) {
                for ( int i = 0; i < output_file.getCount("FILE_SEQ"); i++ ) {
                    output.put("FILE_SEQ", output_file.getText("FILE_SEQ", i), i);
                    output.put("FILE_POS", output_file.getText("FILE_POS", i), i);
                    output.put("USER_FILE_NM", output_file.getText("USER_FILE_NM", i), i);
                    output.put("PHSC_FILE_NM", output_file.getText("PHSC_FILE_NM", i), i);
                    output.put("FILE_SIZE", output_file.getText("FILE_SIZE", i), i);
                }
            }
            // ===============================================================================
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", "");
        } catch (AMLException e) {
            Log.logAML(Log.ERROR, this.getClass(), "doFileSearch", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this.getClass(), "doFileSearch", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
        }
        return output;
    }

    /**
     * STR Alert 상세 정보저장<br>
     * STR Alert 詳細情報の保存
     * <p>
     * @param   input
     *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  <code>DataObj</code>
     *              GRID_DATA(STR Alert 상세 정보저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *              GRID_DATA(STR Alert 詳細情報の保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public DataObj doSave(DataObj input) {
        DataObj output = new DataObj();
        MDaoUtil mdb = null;
        damoManager damo = new damoManager();

        try {
            Log.logAML(Log.INFO, this, "################## doSave-START ##################");
            mdb = new MDaoUtil();
            mdb.begin();

            List gdReq = (List) input.get("gdReq");
            SessionAML sess = (SessionAML) input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();

            Log.logAML(Log.INFO, this, "$$$$$SSPS_DL_ID : " + input.getText("SSPS_DL_ID"));
            Log.logAML(Log.INFO, this, "$$$$$SSPS_DL_CRT_DT : " + input.getText("SSPS_DL_CRT_DT"));

            DataObj input_file = new DataObj();		//파일정보 DataObj에 담기.
            DataObj input_temp = new DataObj();
            input_temp.add("SSPS_DL_ID", input.getText("SSPS_DL_ID").trim());
            input_temp.add("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT").trim());
            input_temp.add("MN_DL_BRN_CD", input.getText("MN_DL_BRN_CD"));
            input_temp.add("LOGIN_ID", sessHelper.getUserId());
            input_temp.add("OK_CCD", input.getText("OK_CCD"));
            input_temp.add("XCL_RSN_CNTNT", input.getText("XCL_RSN_CNTNT")); // 보고제외 사유
            input_temp.add("RPR_RSN_CNTNT", input.getText("RPR_RSN_CNTNT")); // 종합의견

            HashMap map = null;
            for ( int i = 0; i < gdReq.size(); i++ ) {

                map = (HashMap) gdReq.get(i);

                if ( "TEXT".equals(map.get("TYPE")) ) {
                    input_temp.add(map.get("NAME"), map.get("VALUE"));
                } else if ( "CHECK".equals(map.get("TYPE")) ) {
                    input_temp.add("DOBT_TYP_KND_CD", map.get("CODE"));
                    input_temp.add("F_CCD", map.get("VALUE"));
                    input_temp.add("ETC_CNTNT", map.get("ETC"));
                } else if ( "FILE".equals(map.get("TYPE")) ) {
                    //추출한 정보를 input_file에 담는다.
                    input_file.add("FILE_SIZE", map.get("FILE_SIZE"));
                    input_file.add("ORIG_FILE_NM", map.get("ORIG_FILE_NM"));
                    input_file.add("STORED_FILE_NM", map.get("STORED_FILE_NM"));
                    input_file.add("FILE_PATH_TEMP", map.get("FILE_PATH"));
                }

            }

            HashMap inputParam = new HashMap();
            inputParam.put("SSPS_DL_CRT_DT", input_temp.getText("SSPS_DL_CRT_DT") );
            inputParam.put("SSPS_DL_ID", input_temp.getText("SSPS_DL_ID") );
            inputParam.put("LOGIN_ID", input_temp.getText("LOGIN_ID")  );

            if ( "Y".equals(sess.getsAML_MASTER_BRANCH()) ) {
            	input_temp.put("RPR_RSN_CNTNT", damo.pEncrypt(input.getText("RPR_RSN_CNTNT")));
                mdb.setData("AML_20_01_10_03_Delete_NIC67B", (HashMap) input_temp);
                mdb.setData("AML_20_01_10_03_Delete_NIC68B", (HashMap) input_temp);
                mdb.setData("AML_20_01_10_03_Insert_NIC67B", (HashMap) input_temp);

                for ( int i = 0; i < input_temp.getCount("DOBT_TYP_KND_CD"); i++ ) {

                    inputParam.put("DOBT_TYP_KND_CD", input_temp.getText("DOBT_TYP_KND_CD", i) );
                    inputParam.put("F_CCD", input_temp.getText("F_CCD", i) );
                    inputParam.put("ETC_CNTNT", input_temp.getText("ETC_CNTNT", i) );

                    mdb.setData("AML_20_01_10_03_Insert_NIC68B", inputParam);
                }

            } else {

                mdb.setData("AML_20_01_10_03_Delete_NIC88B", (HashMap) input_temp);
                mdb.setData("AML_20_01_10_03_Delete_NIC89B", (HashMap) input_temp);
                mdb.setData("AML_20_01_10_03_Insert_NIC88B", (HashMap) input_temp);

                for ( int i = 0; i < input_temp.getCount("DOBT_TYP_KND_CD"); i++ ) {

                    inputParam.put("MN_DL_BRN_CD", input_temp.getText("MN_DL_BRN_CD") );
                    inputParam.put("DOBT_TYP_KND_CD", input_temp.getText("DOBT_TYP_KND_CD", i) );
                    inputParam.put("F_CCD", input_temp.getText("F_CCD", i) );
                    inputParam.put("ETC_CNTNT", input_temp.getText("ETC_CNTNT", i) );

                    mdb.setData("AML_20_01_10_03_Insert_NIC89B", inputParam);
                }
            }

            // 보고제외 사유 등록
            if ( "Y".equals(sess.getsAML_MASTER_BRANCH()) ) {
                // 본점
                input_temp.put("MASTER_BRANCH", "Y");
                mdb.setData("AML_20_01_10_03_NIC66B_update", (HashMap) input_temp);
            } else {
                // 지점
                input_temp.put("MASTER_BRANCH", "N");
                mdb.setData("AML_20_01_10_03_NIC66B_update", (HashMap) input_temp);
            }

            //~~~~~~~~~~~~~~~~~~~~ 첨부파일 처리 START ~~~~~~~~~~~~~~~~~~~~
            String attachTmpPath = Constants.COMMON_TEMP_FILE_UPLOAD_DIR;		//임시 첨부파일 경로(/rbashared/upload/attachTmp)

            HashMap fileParam = new HashMap();
            fileParam.put("SSPS_DL_CRT_DT", input_temp.getText("SSPS_DL_CRT_DT"));
            fileParam.put("SSPS_DL_ID", input_temp.getText("SSPS_DL_ID"));

            DataObj fileData = mdb.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", fileParam);
            List<HashMap> fileDbList = fileData.getRowsToMap();
            List<HashMap> fileList = input_file.getRowsToMap();

            String FileFullPath = "" ;
            String SSPS_DL_CRT_DT = input.getText("SSPS_DL_CRT_DT").trim();       
            String SSPS_DL_ID     = input.getText("SSPS_DL_ID").trim(); 
            
            if(fileList.size() > 0) {
                //첨부파일이 있으면
                for ( int i = 0; i < fileList.size(); i++ ) {

                    String STORED_FILE_NM 	= fileList.get(i).get("STORED_FILE_NM").toString();
                    String STORED_FILE_NM_ENC 	= fileList.get(i).get("STORED_FILE_NM").toString() + ".enc"; // 암호화명으로 수정
                    String FILE_PATH_TEMP 	= fileList.get(i).get("FILE_PATH_TEMP").toString();

                    //삼성증권용 PropertyService.getInstance().getProperty("aml.config","uploadPath.tms"); 대체 
                    FileFullPath = Constants._UPLOAD_tms_DIR +"/"+SSPS_DL_CRT_DT+"/"+SSPS_DL_ID+"/";
                    
                    if(FILE_PATH_TEMP.indexOf(attachTmpPath) > -1) {
                        File tempDir 	= new File(FILE_PATH_TEMP);
                        File tempFile 	= new File(tempDir, STORED_FILE_NM);

                        //System.out.println("tempDir" + tempDir );
                        //System.out.println("tempFile" + tempFile );
                        //System.out.println("attachTmpPath" + attachTmpPath );
                        
                        if(tempFile.isFile()) {
                        	
                            File realFile = FileUtil.renameTo_Samsung(tempFile,FileFullPath);  // /rbashared/upload/tms/
                            //System.out.println("realFile" + realFile );
                            
                            FileUtil.rename(FileFullPath+STORED_FILE_NM,FileFullPath,STORED_FILE_NM_ENC);
                            
                            File realFile2 = new File(FileFullPath, STORED_FILE_NM_ENC);
                            //System.out.println("realFile" + realFile2 );
                             
                            
                            String filePath = StringUtils.replace(realFile.getParent().replaceAll("\\\\", "/"), FileFullPath , "") +"/"; 
                            input_file.add("FILE_PATH_NEW", filePath.replaceAll("\\\\", "/"));
                            fileList.set(i, input_file);
                        } else {
                            String filePath = FILE_PATH_TEMP;
                            filePath = StringUtils.replace(filePath, attachTmpPath, FileFullPath);

                            System.out.println("filePath2" + filePath );
                            
                            input_file.add("FILE_PATH_NEW", filePath);
                            fileList.set(i, input_file);
                        }

                    } else {
                        String filePath = FILE_PATH_TEMP;
                        filePath = StringUtils.replace(filePath, attachTmpPath, FileFullPath);

                        System.out.println("filePath3" + filePath );
                        input_file.add("FILE_PATH_NEW", filePath.replaceAll("\\\\", "/"));
                        fileList.set(i, input_file);
                    }

                }

                fileList = input_file.getRowsToMap();
                //넘어온 첨부파일 정보가 기존 첨부파일에 없으면 삭제처리한다.
                for(int i=0; i<fileDbList.size(); i++) {
                    boolean bFileChk = false;
                    String db_FILE_POS 			= fileDbList.get(i).get("FILE_POS").toString();
                    String db_PHSC_FILE_NM 	= fileDbList.get(i).get("PHSC_FILE_NM").toString();

                    for(int j=0; j<fileList.size(); j++) {
                        String STORED_FILE_NM = fileList.get(j).get("STORED_FILE_NM").toString();

                        if( STORED_FILE_NM.equals(db_PHSC_FILE_NM) ) {
                            //bFileChk = true;
                            bFileChk = false;
                            break;
                        } else {
                            //bFileChk = false;
                            //break;
                            bFileChk = true;
                        }
                    }

                    if(bFileChk) {
                        String filePath = FileFullPath+db_FILE_POS+File.separator+db_PHSC_FILE_NM;

                        FileUtil.deleteFile(filePath);
                    }
                }

                //혐의거래 첨부파일(NIC64B) DELETE
                mdb.setData("AML_20_01_10_03_doDelete_NIC64B", fileParam);

                //혐의거래 첨부파일(NIC64B) INSERT
                int FILE_SEQ_MAX = 1;

                for ( int i = 0; i < fileList.size(); i++ ) {

                	System.out.println(fileList.get(i).get("STORED_FILE_NM").toString());
                	
                	if(fileList.get(i).get("STORED_FILE_NM").toString().indexOf(".enc") != -1) {
                		fileParam.clear();
                        fileParam.put("SSPS_DL_CRT_DT", input_temp.getText("SSPS_DL_CRT_DT")); //혐의거래생성일자
                        fileParam.put("SSPS_DL_ID", input_temp.getText("SSPS_DL_ID")); //혐의거래ID
                        fileParam.put("FILE_SEQ", FILE_SEQ_MAX ); //파일일련번호
                        fileParam.put("FILE_POS", fileList.get(i).get("FILE_PATH_NEW").toString()); //파일PATH
                        fileParam.put("USER_FILE_NM", fileList.get(i).get("ORIG_FILE_NM").toString()); //파일논리이름
                        fileParam.put("PHSC_FILE_NM", fileList.get(i).get("STORED_FILE_NM").toString()); //파일물리이름
                        fileParam.put("FILE_SIZE", fileList.get(i).get("FILE_SIZE").toString()); //파일사이즈
                        fileParam.put("DOWNLOAD_COUNT", 0); //다운로드수
                        fileParam.put("REG_ID", input_temp.getText("LOGIN_ID") ); //작성자ID

                        mdb.setData("AML_20_01_10_03_doSave_NIC64B", fileParam);
                         
                        FILE_SEQ_MAX++;
                	}else {
                		fileParam.clear();
                        fileParam.put("SSPS_DL_CRT_DT", input_temp.getText("SSPS_DL_CRT_DT")); //혐의거래생성일자
                        fileParam.put("SSPS_DL_ID", input_temp.getText("SSPS_DL_ID")); //혐의거래ID
                        fileParam.put("FILE_SEQ", FILE_SEQ_MAX ); //파일일련번호
                        fileParam.put("FILE_POS", fileList.get(i).get("FILE_PATH_NEW").toString()); //파일PATH
                        fileParam.put("USER_FILE_NM", fileList.get(i).get("ORIG_FILE_NM").toString()); //파일논리이름
                        fileParam.put("PHSC_FILE_NM", fileList.get(i).get("STORED_FILE_NM").toString()+".enc"); //파일물리이름
                        fileParam.put("FILE_SIZE", fileList.get(i).get("FILE_SIZE").toString()); //파일사이즈
                        fileParam.put("DOWNLOAD_COUNT", 0); //다운로드수
                        fileParam.put("REG_ID", input_temp.getText("LOGIN_ID") ); //작성자ID

                        mdb.setData("AML_20_01_10_03_doSave_NIC64B", fileParam);
                         
                        // 팝일 암호화
                        strFileSeedUpdoad(FileFullPath, fileList.get(i).get("STORED_FILE_NM").toString()+".enc");

                        FILE_SEQ_MAX++;
                	}
                    
                }

            } else {

                for(int i=0; i<fileDbList.size(); i++) {
                    String db_FILE_POS 			= fileDbList.get(i).get("FILE_POS").toString();
                    String db_PHSC_FILE_NM 	= fileDbList.get(i).get("PHSC_FILE_NM").toString();
                    String filePath = FileFullPath+db_FILE_POS+File.separator+db_PHSC_FILE_NM;

                    FileUtil.deleteFile(filePath);
                }

                //혐의거래 첨부파일(NIC64B) DELETE
                mdb.setData("AML_20_01_10_03_doDelete_NIC64B", fileParam);

            }
            //~~~~~~~~~~~~~~~~~~~~ 첨부파일 처리 END ~~~~~~~~~~~~~~~~~~~~

            mdb.commit();

            Log.logAML(Log.INFO, this, "################## doSave-END ##################" );

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
            output.put("gdRes", null);
        } catch (IOException e) {
            try {
                if(mdb != null) {
                    mdb.rollback();
                    mdb.close();
                }
            } catch (AMLException ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            } catch (Exception ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            }
            Log.logAML(Log.ERROR, this, "doSave", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } catch (AMLException e) {
            try {
                if(mdb != null) {
                    mdb.rollback();
                    mdb.close();
                }
            } catch (AMLException ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            } catch (Exception ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            }
            Log.logAML(Log.ERROR, this, "doSave", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } catch (Exception e) {
            try {
                if(mdb != null) {
                    mdb.rollback();
                    mdb.close();
                }
            } catch (AMLException ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            } catch (Exception ee) {
                Log.logAML(Log.ERROR, this, "doSave", e);
            }
            Log.logAML(Log.ERROR, this, "doSave", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } finally {
            try {
                if(mdb != null) {
                    mdb.close();
                }
            } catch (Exception ee) {
            }
        }
        return output;
    }

    /**
     * STR 결재처리<br>
     * STR決裁処理<br>
     * 팝업에서 바로 결재처리 20170301 KEOL
     * <p>
     * @param   input
     *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  <code>DataObj</code>
     *              GRID_DATA(STR 결재처리 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *              GRID_DATA(STR決裁処理 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     */
    @SuppressWarnings("unchecked")
    public DataObj doSave1(DataObj input) {
        DataObj output = new DataObj();
        try {
            SessionAML sess = (SessionAML) input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inputStatus, inputDesc, inst_id, work_id;
            String StCheckYn = Util.nvlTrim((String) input.get("ST_CHECK_YN"), "");
            DataObj dbOut = null;
            if ( "Y".equals(sess.getsAML_MASTER_BRANCH()) ) {
                dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_NIC67B_Count", input);
            } else {
                dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_NIC88B_Count", input);
            }

            if ( !"Y".equals(StCheckYn) ) {
                if ( dbOut.getInt("CNT") < 1 ) {
                    throw new BizException(MessageHelper.getInstance().getMessage("0070", input.getText("LANG_CD"), "혐의 의심내역이 등록되지 않았습니다."));
                }
            }
            HashMap<String, Object> wfInput = new HashMap<String, Object>();
            wfInput.put("RPR_P_ENO", sessHelper.getUserId());
            wfInput.put("RPR_P_NM", sessHelper.getUserName());
            wfInput.put("DPRT_CD", sessHelper.getDeptId());
            wfInput.put("DPRT_NM", sessHelper.getDeptName());
            wfInput.put("MN_DL_BRN_CD", sess.getsAML_BDPT_CD());
            wfInput.put("RPR_P_TEL_NO", StringHelper.nvl(sess.getsAML_TEL_NO(), "000-0000-0000"));

            keyDate = input.getText("SSPS_DL_CRT_DT").trim();
            keyID = input.getText("SSPS_DL_ID").trim();
            inputStatus = input.getText("OK_CCD");
            inputDesc = input.getText("XCL_RSN_CNTNT");
            inst_id = input.getText("INST_ID");
            work_id = input.getText("WORK_ID");

            wfInput.put("SSPS_DL_CRT_DT", keyDate);
            wfInput.put("SSPS_DL_ID", keyID);
            wfInput.put("INST_ID", inst_id);
            wfInput.put("WORK_ID", work_id);
            wfInput.put("OK_CCD", inputStatus);
            WSParam param = new WSParam(wfInput);
            param.setSession(sess.getSession());
            AMLWF4Interface wif = new AMLWF4Interface(param, input.getText("LANG_CD"), Integer.parseInt(inst_id));
            wif.executeTrs(Integer.parseInt(work_id), "A", inputDesc);

            /**
             * 본점인 경우 nic66b 입력한 대로 업데이트
             * 아닌경우 입력값  OK_CCD가
             *      '보고제외' 이면  nic66b의 update
             *      '보고제외' 가 아니면  nic66b의 OK_CCD가 체크하여 데이터가 '보고제외' 이면 update 하지 않음.
             * 항상 UPDATE하게 수정함.
             *
             * 2015.04..07 KSY
             * STR 결재 상세 저장시 결재상태를 변경하도록 수정(확인/미확인/보고제외)
             *
             */
            /** KSY 주석 [
                if ("Y".equals(sess.getsAML_MASTER_BRANCH())) {
                    bUpdateNIC66B = true;
                } else {
                    if("2".equals(inputStatus))
                        bUpdateNIC66B = true;
                    else {
                        dbOut = JDaoUtilSingle.getData("AML_20_01_10_01_NIC66B_check", wfInput);
                        bUpdateNIC66B = !"2".equals(dbOut.getText("OK_CCD"));
                        bUpdateNIC66B = true;  //20100825
                    }
                }
                if (bUpdateNIC66B) {
                    JDaoUtilSingle.setData(
                        "AML_20_01_10_01_NIC66B_update"
                       ,new Object[] {inputStatus
                       ,inputDesc
                       ,sessHelper.getUserId()
                       ,keyDate
                       ,keyID}
                    );
                }
                ] KSY 주석
             */
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
        } catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }

    /**
     * STR 결재 반려처리<br>
     * STR決裁差戻し処理<br>
     * 팝업에서 바로 반려처리 20170301 KEOL
     * <p>
     * @param   input
     *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return <code>DataObj</code>
     *              GRID_DATA(STR 결재 반려처리 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *              GRID_DATA(STR決裁差戻し処理 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *              GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    public DataObj doSave2(DataObj input) {
        DataObj output = new DataObj();
        try {
            SessionAML sess = (SessionAML) input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inputStatus, inputDesc, inst_id, work_id;

            HashMap<String, Object> wfInput = new HashMap<String, Object>();
            wfInput.put("RPR_P_ENO", sessHelper.getUserId());
            wfInput.put("RPR_P_NM", sessHelper.getUserName());
            wfInput.put("DPRT_CD", sessHelper.getDeptId());
            wfInput.put("DPRT_NM", sessHelper.getDeptName());
            wfInput.put("MN_DL_BRN_CD", sess.getsAML_BDPT_CD());
            wfInput.put("RPR_P_TEL_NO", StringHelper.nvl(sess.getsAML_TEL_NO(), "000-0000-0000"));

            keyDate = input.getText("SSPS_DL_CRT_DT").trim();
            keyID = input.getText("SSPS_DL_ID").trim();
            inputStatus = input.getText("OK_CCD");
            inputDesc = input.getText("DNY_RSN_CNTNT");
            inst_id = input.getText("INST_ID");
            work_id = input.getText("WORK_ID");

            wfInput.put("SSPS_DL_CRT_DT", keyDate);
            wfInput.put("SSPS_DL_ID", keyID);
            wfInput.put("INST_ID", inst_id);
            wfInput.put("WORK_ID", work_id);
            wfInput.put("OK_CCD", inputStatus);
            WSParam param = new WSParam(wfInput);
            param.setSession(sess.getSession());
            AMLWF4Interface wif = new AMLWF4Interface(param, input.getText("LANG_CD"), Integer.parseInt(inst_id));
            wif.executeTrs(Integer.parseInt(work_id), "D", inputDesc);

            /*
             * JDaoUtilSingle.setData( "AML_20_01_10_01_NIC66B_update" ,new Object[] { inputStatus ,inputDesc ,sessHelper.getUserId() ,keyDate ,keyID} );
             */

            HashMap<Object, Object> tempParam = new HashMap<Object, Object>();
            tempParam.put("SSPS_DL_CRT_DT", keyDate);
            tempParam.put("SSPS_DL_ID", keyID);
            tempParam.put("OK_CCD", inputStatus);
            tempParam.put("DNY_RSN_CNTNT", inputDesc);
            tempParam.put("USERID", sessHelper.getUserId());
            MDaoUtilSingle.setData("AML_20_01_10_01_NIC66B_DNY_update", tempParam);

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
        } catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }

    /**
     * STR 파일 여부 체크
     * @param input
     * @return
     */
    public DataObj doSearchFileTrList(DataObj input) {
        DataObj output = new DataObj();
        String strFileFlag = "N";
        String strFileNm = "";
        DataSet gdRes = null;
        String WINMSG = "";
        String ERRMSG = "";
        try {
            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) START ~~~~~~
            DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");

            //혐의거래생성 일자 기준 3개월 거래내역
//	        String toDate = DL_DT_FORMAT.format(new java.util.Date());
            String toDate = input.getText("SSPS_DL_CRT_DT");
            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(toDate.substring(0,4)), Integer.parseInt(toDate.substring(4,6))-1, Integer.parseInt(toDate.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
            String fromDate = DL_DT_FORMAT.format(cal.getTime());
            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) END ~~~~~~

            DataObj inputParam = new DataObj();
            inputParam.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
            inputParam.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));
            System.out.println("$$$$ input : " + inputParam);

            DataObj output_file = MDaoUtilSingle.getData("AML_20_01_10_03_doSearchFile_NIC64B", inputParam);
            DataObj output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_01_SS", inputParam);
            
            String SSPS_DL_CRT_DT   = input.getText("SSPS_DL_CRT_DT");
            String DL_DT_A = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(SSPS_DL_CRT_DT,"yyyyMMdd"), -1), "yyyyMMdd");
        	String DL_DT_B = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(DL_DT_A,"yyyyMMdd"), -91), "yyyyMMdd");

            for ( int i = 0; i < output_0.getCount("GNL_AC_NO"); i++ ) {
            	String sCS_NM         = output_0.getText("CS_NM"    ,i);
                String sGNL_AC_NO     = output_0.getText("GNL_AC_NO",i);
                String sACNT_NO 	  = output_0.getText("ACNT_NO_DEC",i);
                String fileNm         = sACNT_NO+"_"+DL_DT_B+"_"+DL_DT_A+".xls";

                System.out.println("$$$$$getCount-FILE_NM : " + output_file.getCount("FILE_NM"));
                for ( int j = 0; j < output_file.getCount("FILE_NM"); j++ ) {
                    if ( output_file.getText("FILE_NM", j).equals(fileNm) ) {
                        strFileNm = output_file.getText("FILE_NM", j);
                        strFileFlag = "Y";
                        break;
                    }
                }
            }
            System.out.println("$$$$$strFileFlag : " + strFileFlag);
            output.put("STR_FILE_NM", strFileNm);
            output.put("STR_FILE_FLAG", strFileFlag);
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", ERRMSG);
            output.put("WINMSG", WINMSG);

            gdRes = Common.setGridData(output);
            output.put("gdRes", gdRes);
        } catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
        } catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
        } catch (ParseException e) {
        	Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
		}
        return output;
    }

    /**
     * STR 거래내역 엑셀 삭제 후 생성
     * 3개월 거래내역 화면 REFRESH 후 저장되게 수정
     * @param input
     * @return
     */
    public DataObj doCreateTrExcelFile(DataObj input) {
        DataObj output = new DataObj();
//		String strFileFlag = "N";
//		String strFileNm = "";
        DataSet gdRes = null;
        String WINMSG = "";
        String ERRMSG = "";

        List outputList = new ArrayList();
        try {

            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) START ~~~~~~
            DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
            //혐의거래생성 일자 기준 3개월 거래내역
//	        String toDate = DL_DT_FORMAT.format(new java.util.Date());
            String toDate = input.getText("SSPS_DL_CRT_DT");
            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(toDate.substring(0,4)), Integer.parseInt(toDate.substring(4,6))-1, Integer.parseInt(toDate.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
            String fromDate = DL_DT_FORMAT.format(cal.getTime());
        	
            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) END ~~~~~~

            DataObj inputParam = new DataObj();
            inputParam.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
            inputParam.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));
            System.out.println("$$$$ input : " + inputParam);

            DataObj output_file = MDaoUtilSingle.getData("AML_20_01_10_03_doSearchExcelFile_NIC64B", inputParam);
            DataObj output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_01_SS", inputParam);
            
            String SSPS_DL_CRT_DT   = input.getText("SSPS_DL_CRT_DT");
            String DL_DT_A = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(SSPS_DL_CRT_DT,"yyyyMMdd"), -1), "yyyyMMdd");
        	String DL_DT_B = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(DL_DT_A,"yyyyMMdd"), -91), "yyyyMMdd");
        	

            for ( int i = 0; i < output_0.getCount("GNL_AC_NO"); i++ ) {
            	String sCS_NM       = output_0.getText("CS_NM"    ,i);
                String sGNL_AC_NO 	= output_0.getText("GNL_AC_NO", i);
                String sACNT_NO 	= output_0.getText("ACNT_NO_DEC",i);
                String fileNm 		= sACNT_NO + "_" + DL_DT_B + "_" + DL_DT_A + ".xls";

                System.out.println("$$$$$getCount-FILE_NM : " + output_file.getCount("FILE_NM"));
                
                for ( int j = 0; j < output_file.getCount("FILE_NM"); j++ ) {
                	System.out.println("$$$$$FILE_NM : " + output.getText("FILE_NM", j) + "  $$$$$ fileNm : " + fileNm);
                    if ( output_file.getText("FILE_NM", j).equals(fileNm) ) {
                    	//파일 삭제 및 테이블데이터 삭제 구현
                        DataObj paramTemp = new DataObj();
                        paramTemp.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
                        paramTemp.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));
                        paramTemp.put("FILE_SEQ", output_file.getText("FILE_SEQ", j));
                        String FILE_POS = output_file.getText("FILE_POS", j);
                        String PHSC_FILE_NM = output_file.getText("PHSC_FILE_NM", j);
                        String fullPath = FILE_POS + PHSC_FILE_NM;

                        //파일삭제
                        FileUtil.deleteFile(fullPath);

                        //테이블삭제
                        MDaoUtilSingle.setData("AML_20_01_10_03_doDeleteExcelFile_NIC64B", paramTemp);
                    }else if(output_file.getText("FILE_NM", j) != null) {
                        HashMap keyContent = new HashMap();
                        keyContent.put("fileSizes", output_file.getText("FILE_SIZE", j));	//파일사이즈
                        keyContent.put("origFileNms", output_file.getText("FILE_NM", j));						//파일논리이름
                        keyContent.put("storedFileNms", output_file.getText("PHSC_FILE_NM", j));			//파일물리이름
                        keyContent.put("filePaths", output_file.getText("FILE_POS", j));						//파일PATH
                        keyContent.put("transExcelGubn", "N");						//3개월 거래내역 파일 여부
                        outputList.add(new JSONObject(keyContent));
                    }
                }
            }
            
            //3개월 거래내역 생성 START
            AML_20_01_10_03_Kofiu_Action action = new AML_20_01_10_03_Kofiu_Action();
            DataObj excelResult = action.execute(input);

            JSONArray jArr = (JSONArray) excelResult.get("fileContent");

//			List list = new ArrayList();
//			List <HashMap>  fileList = new ArrayList <HashMap>();
            for(int i = 0; i < jArr.length(); i++) {

                JSONObject jObj = jArr.getJSONObject(i);
                DataObj input_file = new DataObj();

                HashMap map = (HashMap) new ObjectMapper().readValue(jObj.toString(), Map.class);
                System.out.println("#######################################");
                System.out.println("#######################################");
                System.out.println("#######################################");
                System.out.println("#######################################");
                System.out.println(map);
                input_file.add("fileSizes", map.get("fileSizes"));
                input_file.add("origFileNms", map.get("origFileNms"));
                input_file.add("storedFileNms", map.get("storedFileNms"));
                input_file.add("filePaths", map.get("filePaths"));
                input_file.add("transExcelGubn", "Y");						//3개월 거래내역 파일 여부
                outputList.add(new JSONObject(input_file));
            }

            //화면에 뿌려질 파일정보
            output.put("fileContent",new JSONArray(outputList) );

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", ERRMSG);
            output.put("WINMSG", WINMSG);

            gdRes = Common.setGridData(output);
            output.put("gdRes", gdRes);
        } catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doCreateTrExcelFile", e.getMessage());
        } catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "doCreateTrExcelFile", e.getMessage());
        } catch (IOException e) {
            Log.logAML(Log.ERROR, this, "doCreateTrExcelFile", e.getMessage());
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "doCreateTrExcelFile", e.getMessage());
        }

        return output;
    }

    /**
     * STR 거래내역 엑셀 삭제 후 생성
     * 3개월 거래내역 화면 REFRESH 없이 생성 사용 X
     * @param input
     * @return
     */
    public DataObj doCreateTrExcelFile2(DataObj input) {
        DataObj output = new DataObj();
        String strFileFlag = "N";
        String strFileNm = "";
        DataSet gdRes = null;
        String WINMSG = "";
        String ERRMSG = "";
        JDaoUtil jdb = null;

        List outputList = new ArrayList();
        try {
            jdb = new JDaoUtil();
            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) START ~~~~~~
            DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
            //혐의거래생성 일자 기준 3개월 거래내역
//	        String toDate = DL_DT_FORMAT.format(new java.util.Date());
            String toDate = input.getText("SSPS_DL_CRT_DT");
            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(toDate.substring(0,4)), Integer.parseInt(toDate.substring(4,6))-1, Integer.parseInt(toDate.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
            String fromDate = DL_DT_FORMAT.format(cal.getTime());
            //~~~~~~ 날짜추출하기(3개월전일자 ~ 현재일자) END ~~~~~~

            DataObj inputParam = new DataObj();
            inputParam.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
            inputParam.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));
            System.out.println("$$$$ input : " + inputParam);

            DataObj output_file = MDaoUtilSingle.getData("AML_20_01_10_03_doSearchExcelFile_NIC64B", inputParam);
            DataObj output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelAccInfo", inputParam);

            for ( int i = 0; i < output_0.getCount("GNL_AC_NO"); i++ ) {
                String sGNL_AC_NO 		= output_0.getText("GNL_AC_NO", i);
                String sGDS_NO 			= output_0.getText("GDS_NO",i);
                String fileNm = sGNL_AC_NO + "_" + fromDate + "_" + toDate + "_"+sGDS_NO+ ".xls";


                System.out.println("$$$$$getCount-FILE_NM : " + output_file.getCount("FILE_NM"));
                for ( int j = 0; j < output_file.getCount("FILE_NM"); j++ ) {
                //	System.out.println("$$$$$FILE_NM : " + output.getText("FILE_NM", j) + "  $$$$$ fileNm : " + fileNm);
                    if ( output_file.getText("FILE_NM", j).equals(fileNm) ) {
                        //파일 삭제 및 테이블데이터 삭제 구현
                        DataObj paramTemp = new DataObj();
                        paramTemp.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
                        paramTemp.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));
                        paramTemp.put("FILE_SEQ", output_file.getText("FILE_SEQ", j));
                        String FILE_POS = output_file.getText("FILE_POS", j);
                        String PHSC_FILE_NM = output_file.getText("PHSC_FILE_NM", j);
                        String fullPath = Constants._UPLOAD_AML_DIR+FILE_POS + PHSC_FILE_NM;

                        //파일삭제
                        FileUtil.deleteFile(fullPath);

                        //테이블삭제
                        MDaoUtilSingle.setData("AML_20_01_10_03_doDeleteExcelFile_NIC64B", paramTemp);
                    }else if(output_file.getText("FILE_NM", j) != null) {
                        HashMap keyContent = new HashMap();
                        keyContent.put("fileSizes", output_file.getText("FILE_SIZE", j));	//파일사이즈
                        keyContent.put("origFileNms", output_file.getText("FILE_NM", j));						//파일논리이름
                        keyContent.put("storedFileNms", output_file.getText("PHSC_FILE_NM", j));			//파일물리이름
                        keyContent.put("filePaths", output_file.getText("FILE_POS", j));						//파일PATH
                        keyContent.put("transExcelGubn", "N");						//3개월 거래내역 파일 여부
                        outputList.add(new JSONObject(keyContent));
                    }
                }
            }
            //3개월 거래내역 생성 START
            AML_20_01_10_03_Action action = new AML_20_01_10_03_Action();
            DataObj excelResult = action.execute(input);

            JSONArray jArr = (JSONArray) excelResult.get("fileContent");

            DataObj input_file = new DataObj();

            List <HashMap>  fileList = new ArrayList <HashMap>();
            for(int i = 0; i < jArr.length(); i++) {
                JSONObject jObj = jArr.getJSONObject(i);
                HashMap map = (HashMap) new ObjectMapper().readValue(jObj.toString(), Map.class);
                input_file.add("FILE_SIZE", map.get("fileSizes"));
                input_file.add("ORIG_FILE_NM", map.get("origFileNms"));
                input_file.add("STORED_FILE_NM", map.get("storedFileNms"));
                input_file.add("FILE_PATH_TEMP", map.get("filePaths"));
                fileList.add(input_file);
            }
            String attachTmpPath = Constants.COMMON_TEMP_FILE_UPLOAD_DIR;		//임시 첨부파일 경로(/upload/attachTmp)

            DataObj fileData = MDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", inputParam);
            List<HashMap> fileDbList = fileData.getRowsToMap();

            if(fileList.size() > 0) {
                //첨부파일이 있으면
                for ( int i = 0; i < fileList.size(); i++ ) {

                    String STORED_FILE_NM 	= fileList.get(i).get("STORED_FILE_NM").toString();
                    String FILE_PATH_TEMP 	= fileList.get(i).get("FILE_PATH_TEMP").toString();

                    if(FILE_PATH_TEMP.indexOf(attachTmpPath) > -1) {
                        File tempDir 	= new File(FILE_PATH_TEMP);
                        File tempFile 	= new File(tempDir, STORED_FILE_NM);

                        if(tempFile.isFile()) {
                            // 임시경로에 파일이 있는경우
                            File realFile = FileUtil.renameTo(tempFile, Constants._UPLOAD_AML_DIR + "str\\");

                            String filePath = File.separator + StringUtils.replace(realFile.getParent(), Constants._UPLOAD_AML_DIR, "");

                            input_file.add("FILE_PATH_NEW", filePath.replaceAll("\\\\", "/"));

                            fileList.set(i, input_file);
                        } else {
                            // 임시경로에 파일이 없는경우
                            String filePath = FILE_PATH_TEMP;
                            filePath = StringUtils.replace(filePath, attachTmpPath, Constants._UPLOAD_AML_DIR);
                            // 임시경로에 파일이 없어도, 기존DB에 파일이 있는 경우
                             // str상세 팝업화면에서 첨부파일 등록후 저장, 또 저장했을겨우 임시파일경로에는 파일이 진짜 없음 (파일이 옮겨진 상태)..
                            // fileDbList 조회해서 기존에 파일이 있는지 확인후 경로 변경
                             for (int x = 0; x < fileDbList.size(); x++) {
                                if (( fileDbList.get(i).get("PHSC_FILE_NM").toString()).equals(STORED_FILE_NM)) {
                                   filePath = fileDbList.get(x).get("FILE_POS").toString();
                                }
                             }

                            input_file.add("FILE_PATH_NEW", filePath);
                            fileList.set(i, input_file);
                        }

                    } else {
                        String filePath = FILE_PATH_TEMP;
                        filePath = StringUtils.replace(filePath, attachTmpPath, Constants._UPLOAD_AML_DIR);

                        input_file.add("FILE_PATH_NEW", filePath.replaceAll("\\\\", "/"));
                        fileList.set(i, input_file);
                    }

                }

                fileList = input_file.getRowsToMap();

                //혐의거래 첨부파일(NIC64B) INSERT
                int FILE_SEQ_MAX = 1 ;
                DataObj seqObj = MDaoUtilSingle.getData("AML_20_01_10_03_getSearchMaxSeqFile_NIC64B", inputParam);
                FILE_SEQ_MAX = seqObj.getInt("FILE_SEQ");

                HashMap fileParam = new HashMap();

                for ( int i = 0; i < fileList.size(); i++ ) {

                    fileParam.clear();
                    fileParam.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT")); //혐의거래생성일자
                    fileParam.put("SSPS_DL_ID", input.getText("SSPS_DL_ID")); //혐의거래ID
                    fileParam.put("FILE_SEQ", FILE_SEQ_MAX ); //파일일련번호
                    fileParam.put("FILE_POS", fileList.get(i).get("FILE_PATH_NEW").toString()); //파일PATH
                    fileParam.put("USER_FILE_NM", fileList.get(i).get("ORIG_FILE_NM").toString()); //파일논리이름
                    fileParam.put("PHSC_FILE_NM", fileList.get(i).get("STORED_FILE_NM").toString()); //파일물리이름
                    fileParam.put("FILE_SIZE", fileList.get(i).get("FILE_SIZE").toString()); //파일사이즈
                    fileParam.put("DOWNLOAD_COUNT", 0); //다운로드수
                    fileParam.put("REG_ID", input.getText("LOGIN_ID") ); //작성자ID

                    jdb.setData("AML_20_01_10_03_doSave_NIC64B", fileParam );


                    HashMap keyContent = new HashMap();
                    keyContent.put("fileSizes", fileList.get(i).get("FILE_SIZE").toString());			//파일사이즈
                    keyContent.put("origFileNms", fileList.get(i).get("ORIG_FILE_NM").toString());		//파일논리이름
                    keyContent.put("storedFileNms", fileList.get(i).get("STORED_FILE_NM").toString());	//파일물리이름
                    keyContent.put("filePaths", fileList.get(i).get("FILE_PATH_NEW").toString());		//파일PATH
                    keyContent.put("transExcelGubn", "Y");												//3개월 거래내역 파일 여부
                    outputList.add(new JSONObject(keyContent));
                    FILE_SEQ_MAX++;
                }

            }

            jdb.commit();

            //3개월 거래내역 생성 END

            //화면에 뿌려질 파일정보
            output.put("fileContent",new JSONArray(outputList) );

            System.out.println("$$$$$strFileFlag : " + strFileFlag);
            output.put("STR_FILE_NM", strFileNm);
            output.put("STR_FILE_FLAG", strFileFlag);

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", ERRMSG);
            output.put("WINMSG", WINMSG);

            gdRes = Common.setGridData(output);
            output.put("gdRes", gdRes);
        } catch (NumberFormatException e) {
            try {
                if(jdb != null) {
                    jdb.rollback();
                }
            } catch (Exception e1) {
                Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
            }
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
        } catch (AMLException e) {
            try {
                if(jdb != null) {
                    jdb.rollback();
                }
            } catch (Exception e1) {
                Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
            }
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
        } catch (IOException e) {
            try {
                if(jdb != null) {
                    jdb.rollback();
                }
            } catch (Exception e1) {
                Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
            }
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());

        } catch (Exception e) {
            try {
                if(jdb != null) {
                    jdb.rollback();
                }
            } catch (Exception e1) {
                Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());
            }
            Log.logAML(Log.ERROR, this, "doSearchFileTrList", e.getMessage());

        } finally {
            if(jdb != null) {
                jdb.close();
            }
        }
        return output;
    }

    /**
     * <pre>
     * 파일정보 저장
     * </pre>
     * @param input 화면조회 조건 입력값
     * @return
     */
    @SuppressWarnings("unchecked")
    public DataObj doSaveFileTable(DataObj input, DataObj input_file) {

        String fileFullPath = "";
        SessionAML sess = (SessionAML) input.get("SessionAML");
        SessionHelper sessHelper = sess.getSessionHelper();
        DataObj output = new DataObj();
        String SSPS_DL_CRT_DT = input.getText("SSPS_DL_CRT_DT");
        String SSPS_DL_ID = input.getText("SSPS_DL_ID");
        String UPD_ID = Util.nvl(sessHelper.getUserId());
        DataObj output1 = new DataObj();

        Log.logAML(Log.DEBUG, input_file, "#############doSaveFileTable-input_file:#############");

        try {

            HashMap inputParam = new HashMap();
            inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
            inputParam.put("SSPS_DL_ID", SSPS_DL_ID);

            output = MDaoUtilSingle.getData("AML_20_01_10_03_MAX_NIC64B", inputParam );
            int FILE_SEQ_max = output.getInt("FILE_SEQ");
            long fileLen = 0L;
            String fileName = "";

            for ( int i = 0; i < input_file.getCount(); ++i ) {

                ++FILE_SEQ_max;

                fileFullPath = input_file.getText("fileFullPath", i);
                fileName = input_file.getText("fileName", i);
                fileLen = new File(fileFullPath + "/" + fileName).length();
                String PHSC_FILE_NM = fileName; // SSPS_DL_ID + "_" + FILE_SEQ_max;

                if ( fileLen > 1L ) {
                    fileLen -= 2L;
                }

                output1.add("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
                output1.add("SSPS_DL_ID", SSPS_DL_ID);
                output1.add("FILE_SEQ", Integer.toString(FILE_SEQ_max));
                output1.add("FILE_POS", fileFullPath);
                output1.add("USER_FILE_NM", fileName);
                output1.add("PHSC_FILE_NM", PHSC_FILE_NM);
                output1.add("FILE_SIZE", Long.valueOf(fileLen));
                output1.add("DOWNLOAD_COUNT", Integer.valueOf(0));
                output1.add("REG_ID", Integer.parseInt(UPD_ID));

                MDaoUtilSingle.setData("AML_20_01_10_03_doSave_NIC64B", output1);

            }

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", sessHelper.getLangType(), "정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", sessHelper.getLangType(), "정상 처리되었습니다."));

        } catch (NumberFormatException e) {

            Log.logAML(1, this, "doSaveFileTr", e.toString());

            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", sessHelper.getLangType(), "처리중 오류가 발생하였습니다."));
        } catch (AMLException e) {

            Log.logAML(1, this, "doSaveFileTr", e.toString());

            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", sessHelper.getLangType(), "처리중 오류가 발생하였습니다."));
        } catch (Exception e) {

            Log.logAML(1, this, "doSaveFileTr", e.toString());

            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", sessHelper.getLangType(), "처리중 오류가 발생하였습니다."));
        }

        return output;
    }

    // [ get ]

    /**
     * STR Alert 상세 고객정보 조회<br>
     * STR Alert 詳細顧客情報の照会
     * <p>
     * @param   input
     *              화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *              インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *              Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  <code>DataObj</code>
     *              GRID_DATA(STR 결재 상세 고객정보 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *              GRID_DATA(STR決裁_詳細顧客情報 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *              GRID_DATA(DataSet), PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    public DataObj getCustInfo(DataObj input) {
        DataObj output = new DataObj();

        try {
            output = MDaoUtilSingle.getData("AML_20_01_10_03_GetCustInfo", input);
        } catch (AMLException e) {
            Log.logAML(1, this, "getCustInfo", e.toString());
        }

        return output;
    }

    /**
     * 인스턴스 반환.
     * <p>
     * @return  <code>AML_20_01_10_03</code>
     */
    public static AML_20_01_10_03 getInstance() {
        return instance == null ? (instance = new AML_20_01_10_03()) : instance;
    }
    
    private void strFileSeedUpdoad(String fileFullPath, String export_file_name) {
    	try {
    		Properties _prop = new Properties();
            _prop.load(com.ss.common.util.security.damo.damoManager.class.getClassLoader().getResourceAsStream("META-INF/properties/security-damo.properties"));
	        
			String iniFilePath 	= _prop.getProperty("damo.iniPath");
			String Agent_ID = _prop.getProperty("damo.AgentID");
			String DB_Name 	= _prop.getProperty("damo.DBname");
			String Owner 	= _prop.getProperty("damo.Owner");
			String Tbl_name = _prop.getProperty("damo.Tblname");
	       
			System.out.println("iniFilePath " + iniFilePath);
			System.out.println("Agent_ID " + Agent_ID);
			System.out.println("DB_Name " + DB_Name);
			System.out.println("Owner " + Owner);

			byte[] ctx;
			int ret;
			
	    	/* DAMO SCP API 
	    	   ScpDbAgent 객체를 생성한다 
	    	*/
	        ScpDbAgent agt = new ScpDbAgent();
	    	      
	    	/* DAMO SCP API ret : 0,118(성공) 나머지(실패)
	    	   API 를 초기화 한다
	    	*/
	        ret = agt.AgentInit( iniFilePath );
	    	System.out.println("[java] ret : " + ret );
	    	if ( ret != 0 && ret != 118 ){ return; }
	
	    	/* DAMO SCP API 
	    	   키 파일에서 컨택스트를 가져온다
	    	*/
	    	// ctx = agt.AgentCipherCreateContextImportFile( seedKeyFilePath );
	    	ctx = agt.AgentCipherCreateContext( Agent_ID, DB_Name, Owner, Tbl_name, "ENC_KEY" );
	    				
	    	/* DAMO SCP API 
	    	   encrypt file function 
	    	   damo컨택스트, 원본파일, 복구화파일
	    	*/
	    	String inFilePath = (fileFullPath  +export_file_name).replace("/", System.getProperty("file.separator"));
			String encFilePath = (fileFullPath + "enc_" +export_file_name).replace("/", System.getProperty("file.separator"));
			int encFileSize = agt.AgentCipherEncryptFilePath( ctx, inFilePath, encFilePath);

	    	//파일암호화후 원본파일 삭제
			File del_file = new File (inFilePath);
            if(del_file.exists()){
            	del_file.delete();
            }            
            
            //파일 이름 변경
            File new_file = new File (inFilePath);
            File rename_file = new File (encFilePath);
            if(rename_file.exists()){
            	rename_file.renameTo(new_file);
            }
	    		    	
	    	/******** DAMO API **********/
        } catch (ScpDbAgentException e) {
        	System.out.println(e.toString());
        	System.out.println(e.returnedValue());
        } catch (Exception e) {
        	System.out.println(e.toString());
        } 
	}

}

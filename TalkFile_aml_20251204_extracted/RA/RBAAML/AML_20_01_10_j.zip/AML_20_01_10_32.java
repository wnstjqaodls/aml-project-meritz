package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;


import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;


/**
*<pre>
* RBA기반의자금세탁방지체계고도화.STR.유가증권정보
*</pre>
*@author 배민영
*@version 1.0
*/
public class AML_20_01_10_32 extends GetResultObject
{
	private static AML_20_01_10_32 instance = null;

	/**
	 * getInstance
	 * @return AML_20_01_10_32
	 */	
	public static AML_20_01_10_32 getInstance()
	{
		if (instance == null) {
			instance = new AML_20_01_10_32();
	    }
	    return instance;
	}
				
	
	/**
	 * <pre>
	 * STR 유가증권정보 상세조회
	 * </pre>
	 * @param input 화면조회 조건 입력값
	 * @return GRID_DATA(조회 DataSet)
	 */
	public DataObj getSearch(DataObj input)
	{
		DataObj output = new DataObj();
		
		try	{
			
			output = MDaoUtilSingle.getData("AML_20_01_10_32_doSearchInfo", input);
						
			if(output.getCount("SSPS_DL_CRT_DT") > 0) {								
				output.put("ERRCODE","00000");
			}else {
				output.put("ERRCODE","00001");
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다."));
			}				
							
		} catch (AMLException e) {
			Log.logAML(
					 Log.ERROR
					,this
					,"getSearch"
					,e.getMessage()
			);
			output = new DataObj();			
			output.put("ERRCODE"	,"00001");
			output.put("ERRMSG"		,e.toString());					
			
		}

		return output;
	}	
	
	/**
	 * <pre>
	 * STR 유가증권정보 저장
	 * </pre>
	 * @param input 화면조회 조건 입력값
	 * @return 
	 */
	public DataObj doSave(DataObj input)
	{
		DataObj output = new DataObj();
		DataObj output_01 = new DataObj();
		MDaoUtil db = null;
		
	    try {
	    		    	
	    	Log.logAML(Log.DEBUG, input, "#############doSave-input:#############");    		    	
	    		    	
	    		
	    	//정보에 있는지 체크
	    	output_01 = MDaoUtilSingle.getData("AML_20_01_10_32_doSearchInfo", input);
			    	
			if(output_01.getCount("SSPS_DL_CRT_DT") > 0 && ("new").equals(input.getText("SCH_GUBN"))){
			    		
			  	output.put("ERRCODE", "00001");
			    output.put("ERRMSG", "해당 유가증권 정보는 이미 존재합니다.");
			    output.put("WINMSG", "해당 유가증권 정보는 이미 존재합니다.");
			    		
			}else{ 
			  		
			  	input.put("HNDL_P_ENO", ((SessionHelper)input.get("SessionHelper")).getUserId().toString());	
			  	input.put("BLL_TYP_AMT","0");
			  	input.put("CHCK_B","1");
	
			   	db = new MDaoUtil();
			   	db.begin();					   				   	
			    		
			   	if(output_01.getCount("SSPS_DL_CRT_DT") > 0){		    						   							
			   		db.setData("AML_20_01_10_32_doSaveInfo", input);													
				} else { //신규					   	
					db.setData("AML_20_01_10_32_doSave", input);						
				}
	
				db.commit();
				    	
				output.put("ERRCODE", "00000");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다..."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다."));
			}
	    	
	    	
	    }catch (AMLException e) {
	    	try{ if(db != null) {db.rollback();} 
	    	} catch(AMLException ee) {Log.logAML(Log.ERROR,this,"doSave",e.getMessage());}
			Log.logAML(Log.ERROR,this,"doSave",e.getMessage());
			
			output.put("ERRCODE"	, "00001");
			output.put("ERRMSG"		, e.toString());		
			output.put("WINMSG"		, MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	    }finally {
			if(db != null) {
				db.close();
			} 
	    }
	    
	    return output;
	}
	
	/**
	 * <pre>
	 * STR 유가증권정보 삭제
	 * </pre>
	 * @param input 화면조회 조건 입력값
	 * @return 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doDelete(DataObj input)
	{
		DataObj output = new DataObj();
		DataObj inputBean = new DataObj();		
		MDaoUtil db = null;    	
    	
	    try {
	    	
	    	Log.logAML(Log.DEBUG, input, "#############doDelete-input:#############");
	    	
	    	List gdRes = (List)input.get("gdReq");
	    	
	    	db = new MDaoUtil();
	    	db.begin();
	    	
	    	for (int i = 0; i < gdRes.size(); i++) {
				  HashMap gd = (HashMap)gdRes.get(i);		          		          
		          
		          inputBean.put("SSPS_DL_CRT_DT", (String)gd.get("SSPS_DL_CRT_DT"));
		          inputBean.put("SSPS_DL_ID", (String)gd.get("SSPS_DL_ID"));
		          inputBean.put("GNL_AC_NO", (String)gd.get("GNL_AC_NO"));
		          inputBean.put("GDS_NO", (String)gd.get("GDS_NO"));		          
		          inputBean.put("DL_DT", (String)gd.get("DL_DT"));
		          inputBean.put("DL_SQ", (String)gd.get("DL_SQ"));
		          inputBean.put("CHCK_STRT_NO", (String)gd.get("COL1")); //CHCK_STRT_NO         

		          db.setData("AML_20_01_10_32_doDelete", inputBean);	          
	        }
	    	
	    	db.commit();			
	    	
	    	output.put("ERRCODE", "00000");
	    	output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다..."));
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다."));
	    	
	    }catch (AMLException e) {
	    	try{ if(db != null) {db.rollback();} } catch(AMLException ee) {Log.logAML(Log.ERROR,this,"doDelete",e.getMessage());}
			Log.logAML(Log.ERROR,this,"doDelete",e.getMessage());
			
			output.put("ERRCODE"	, "00001");
			output.put("ERRMSG"		, e.toString());		
			output.put("WINMSG"		, MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	    }finally {
			if(db != null) {
				db.close();
			} 
	    }
	    
	    return output;
	}
	
}
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.util.HashMap;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.action.AMLCommonLogAction;
import com.gtone.express.server.actions.ExpressAction;

import jspeed.base.property.PropertyService;

public class AML_20_01_10_03_Action extends ExpressAction {
	@SuppressWarnings({ "rawtypes", "unchecked" })
    public DataObj execute(HashMap input) throws Exception {

    	/* 2020년 STR3개월 거래내역 엑셀파일 생성 시 포맷형식이 변경되었다.
    	 * aml_config.properties : amlType 설정 필요합니다.
    	 * amlType : 01은행-BANK, 02증권-STOCK, 03보험-INSURANCE, 04여신-CARD,05카지노-CASINO
    	 *
    	*/
    	DataObj output = new DataObj();

    	String amlType = PropertyService.getInstance().getProperty("aml.config","amlType");
    	try {
	    	if(("00").equals(amlType)) {
	    		AML_20_01_10_03_Bank  AML_20_01_10_03_Bank = new AML_20_01_10_03_Bank();
	    		output = AML_20_01_10_03_Bank.execute(input);
	    		
	    	}else if(("01").equals(amlType)) {
	    		AML_20_01_10_03_Bank  AML_20_01_10_03_Bank = new AML_20_01_10_03_Bank();
	    		output = AML_20_01_10_03_Bank.execute(input);

	    	}else if(("02").equals(amlType)) {
	    		AML_20_01_10_03_Stock  AML_20_01_10_03_Stock = new AML_20_01_10_03_Stock();
	    		output = AML_20_01_10_03_Stock.execute(input);

	    	}else if(("03").equals(amlType)) {
	    		AML_20_01_10_03_Insurance  AML_20_01_10_03_Insurance = new AML_20_01_10_03_Insurance();
	    		output = AML_20_01_10_03_Insurance.execute(input);

	    	}else if(("04").equals(amlType)) {
	    		AML_20_01_10_03_Card  AML_20_01_10_03_Card = new AML_20_01_10_03_Card();
	    		output = AML_20_01_10_03_Card.execute(input);

	    	}else if(("05").equals(amlType)) {
	    		AML_20_01_10_03_Casino  AML_20_01_10_03_Casino = new AML_20_01_10_03_Casino();
	    		output = AML_20_01_10_03_Casino.execute(input);

 	    	}else if(("06").equals(amlType)) {
	    		AML_20_01_10_03_Crypto AML_20_01_10_03_Crypto = new AML_20_01_10_03_Crypto();
	    		output = AML_20_01_10_03_Crypto.execute(input);
 	    	}

	    	/* AML Page Log 등록 처리 모듈  **********************************************/
        	AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
        	input.put("classNm", "com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03_Action");
        	amlCommonLogAction.amlLogInsert(getRequest(), input);
            /* ***************************************************************************/

    	}catch (RuntimeException e) {
    		Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
    		HashMap map = new HashMap();
    		map.put("ERRCODE" ,"00001");
    		map.put("ERRMSG",e.getMessage());
        }catch (Exception e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());

        }
    	return output;
    }
}
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;


import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.common.commonUtil;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.actions.ExpressAction;
import com.itplus.common.server.user.SessionHelper;
import com.penta.scpdb.ScpDbAgent;
import com.penta.scpdb.ScpDbAgentException;

import jspeed.base.property.PropertyService;
import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class AML_20_01_10_03_Kofiu_Action extends ExpressAction {
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public DataObj execute(HashMap input) throws Exception {
        DataObj output = new DataObj();
        DataObj output_0 = new DataObj();
        DataObj output_1 = new DataObj();
        DataObj output_2 = new DataObj();
        @SuppressWarnings("unused")
        DataObj output_3 = new DataObj();
        WritableWorkbook wwb = null;
        
        String DL_DT_A = input.get("SSPS_DL_CRT_DT").toString();
        DL_DT_A = jspeed.base.util.DateHelper.format(DL_DT_A, "yyyyMMdd", "yyyy-MM-dd");
    	DL_DT_A = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(DL_DT_A,"yyyy-MM-dd"), -1), PropertyService.getInstance().getProperty("aml.config","dateFormat"));

    	String DL_DT_B = jspeed.base.util.DateHelper.format(jspeed.base.util.DateHelper.addDate(jspeed.base.util.DateHelper.toUtilDate(DL_DT_A,"yyyy-MM-dd"), -91), PropertyService.getInstance().getProperty("aml.config","dateFormat"));

//        DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
//        String DL_DT_A   = DL_DT_FORMAT.format(new java.util.Date());
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(new Date());
//        cal.add(Calendar.MONTH, -3);
//        String DL_DT_B = DL_DT_FORMAT.format(cal.getTime());
        
        input.put("DL_DT_B", DL_DT_B);
        input.put("DL_DT_A", DL_DT_A);
        
        // [2-1] session 정보를 객체에 넣는다. 
        //SessionHelper helper = new  SessionHelper(getRequest().getSession());
        //input.put("SessionHelper", helper);            

        // [2-1] AML 에서 사용되는 공통 Session 정보
        
        //SessionAML sessionAML = (SessionAML) Class.forName(commonUtil.getAMLSessionClassName()).getConstructor(new Class[] {HttpServletRequest.class}).newInstance(new Object[] { getRequest()});
        //input.put("SessionAML", sessionAML);
        
        String[] colArr0 = {"계좌주(사업자)명","실명번호 구분","계좌주(사업자)실명번호","계좌주CI번호","계좌주 국적","실명번호 구분코드"};        
        String[] dataArr0 = {"CS_NM","RNM_CNFR_CCD_NM","CS_NO_DEC","CS_CI_NO","NTN_CD","RNM_CNFR_CCD"};

        String[] colArr1 = {"계좌개설 금융기관","계좌번호","계좌종류(상품)","계좌상품명","계좌개설일자","계좌개설점명","계좌관리점명","계좌잔액","개설금융기관코드 "
                        ,"계좌종류코드","계좌개설점코드","계좌관리점코드"};
        String[] dataArr1 = {"RPR_OGN_NM","ACNT_NO_DEC","GOODS","ACNT_GDS_NM","AC_OPN_DT","OPN_BRN_CD_NM","MN_DL_DPRT_CD_NM","AC_BAL","TRNS_OGN_CD_NEW"
            ,"AC_TY_CD","OPN_BRN_CD","MN_DL_DPRT_CD"};

        String[] colArr2 = {"조회일시","조회점명","조회시작일","조회종료일","조회점코드"};
        String[] dataArr2 = {"RP_DT","BRN_NM","DL_DT_B","DL_DT_A","BRN_CD"};

        String[] colArr3 = {"거래일련번호","거래순번","거래발생일시",
        		        "상대금융기관명","상대계좌번호","상대계좌주명","상대계좌주실명구분","상대계좌주실명번호","상대계좌주CI번호","상대계좌주국적",
        		        "거래종류명","거래수단명","거래채널명","적요","거래소명","매매/입고/출고종목명","거래수량","통화구분코드","외환거래금액","거래금액","정산금액","수표금액",
        				"유가증권명","유가증권시작번호","유가증권종료번호","현금지급금융기관명","현금지급영업점명","유가잔고","예수금잔고","미수금잔고","융자금/대주금","취급금융기관명","취급점명",
                        "의심거래보고여부","거래종류코드","거래수단코드","거래채널코드","매매종목코드","유가증권코드","현금지급금융기관코드","현금지급영업점코드","상대금융기관코드",
                        "상대계좌주실명구분코드","취급금융기관코드","취급점코드","정정구분코드"
        };

        String[] dataArr3 = {"GNL_SQ_DEC","DL_SQ","DL_DT_TM",
        		        "CPRTY_TRSNS_FOGN_NM","CPRTY_TRSNS_AC_NO","CPRTY_TRSNS_AC_NM","CPRTY_TRSNS_AC_RNM_CNFR_CCD_NM","CPRTY_TRSNS_AC_RNM_NO","CPRTY_TRSNS_CI_NO","CPRTY_TRSNS_AC_OWN_NTN_CD",
        		        "DL_TYP_NM","DL_WY_NM","DL_CHNNL_NM","A1","BYMK_SECT_NM","A3","A5","CRNCY_CD","FCRNCY_DL_AMT","A6","ADJST_AMT","CHCK_AMT",
        				"CHCK_KND_NM","CHCK_STRT_NO","CHCK_END_NO","CSH_ORG","CSH_BRN","SECBAL_EVAL_AMT","DPS_AMT","RCVBL_BAL_AMT","MLOAN_SLOAN_AMT","RPR_OGN_NM","HANDLNG_BRN_NM",
        				"DOBT_DL_RPR_YN","DL_TYP_CD","DL_WY_CD","DL_CHNNL_CD","A2","CHCK_KND_CD","CSH_ORG_CD","CSH_BRN_CD","CPRTY_TRSNS_OGN_CD",
                        "CPRTY_TRSNS_AC_RNM_CNFR_CCD","TRNS_OGN_CD_NEW","HANDLNG_BRN_CD","GBN_CD"
        };
        
        String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.tms");
        //@SuppressWarnings("unused")
        //SessionAML sess = (SessionAML) input.get("SessionAML");
        
        try    {
            
            Log.logAML(Log.DEBUG, input, "#############doCreateFileTrList-input:#############");
            
            String baseFromDate = DL_DT_B.replaceAll("-", "");
            String baseToDate = DL_DT_A.replaceAll("-", "");
            String sSSPS_DL_CRT_DT = (String) input.get("SSPS_DL_CRT_DT");
            String sSSPS_DL_ID = (String) input.get("SSPS_DL_ID");
            
            input.put("SSPS_DL_CRT_DT",sSSPS_DL_CRT_DT.replaceAll(" ", ""));
            input.put("SSPS_DL_ID",sSSPS_DL_ID.replaceAll(" ", ""));
            
            //계좌정보조회
            output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_01_Kofiu", input);
            if(output_0.getCount("GNL_AC_NO") <= 0){
                output.put("ERRCODE", "00001");
                output.put("ERRMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                output.put("WINMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                return output;
            }
            
            input.put("GNL_AC_NO", output_0.getText("GNL_AC_NO"));
            
            String fileFullPath = filePath +System.getProperty("file.separator") + sSSPS_DL_CRT_DT.replaceAll(" ", "") + System.getProperty("file.separator") + sSSPS_DL_ID.replaceAll(" ", "");
            
            fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));

            File dir = new File(fileFullPath);
            long fileLen = dir.length();

            if(!dir.isDirectory()){
                dir.mkdirs();
            }
            
            List list = new ArrayList();
            
            for (int i = 0; i < output_0.getCount("GNL_AC_NO"); i++) {
                
                    String sGNL_AC_NO = output_0.getText("GNL_AC_NO",i);
                    String sACNT_NO = output_0.getText("ACNT_NO_DEC",i);
                    String sCS_NM = output_0.getText("CS_NM",i);
                    input.put("GNL_AC_NO", sGNL_AC_NO);
                    String sGNL_AC_NO_New =   sGNL_AC_NO.substring(7);
                    
                    //String fileNm = sCS_NM+"_"+sGNL_AC_NO_New+"_"+baseFromDate+"_"+baseToDate+".xls";
                    String fileNm = sACNT_NO+"_"+baseFromDate+"_"+baseToDate+".xls";
                    
                    Object[] obj = {sSSPS_DL_CRT_DT,sSSPS_DL_ID};
                    
                    output_3 = JDaoUtilSingle.getData("AML_20_01_10_03_NIC64B_ATTACH_FILE", obj);

                    //String fileNameFullPath = fileFullPath + fileNm;
                    String fileNameFullPath = (fileFullPath + "/" +fileNm).replace("/", System.getProperty("file.separator"));
                    
                    Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList-fileNameFullPath:#############"+fileNameFullPath);         
                    
                    wwb = Workbook.createWorkbook(new File(fileNameFullPath));                
                    wwb.createSheet("Sheet", 0);
                    
                    WritableSheet sheet = wwb.getSheet(0);
                    
                    WritableCellFormat cellFormat = new WritableCellFormat();
                    cellFormat.setBorder(Border.ALL , BorderLineStyle.THIN);
    
                    WritableCellFormat cellFormat1 = new WritableCellFormat();
                    cellFormat1.setBackground(jxl.format.Colour.YELLOW);
                    cellFormat1.setBorder(Border.ALL , BorderLineStyle.THIN);
    
                    WritableCellFormat cellFormat2 = new WritableCellFormat();
                    cellFormat2.setBackground(jxl.format.Colour.ORANGE);
                    cellFormat2.setBorder(Border.ALL , BorderLineStyle.THIN);
                    int cnt = 0;
    
    
                    Label label = new jxl.write.Label(0,cnt,"버전",cellFormat1);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1,cnt,"S-ASTR-V2.0",cellFormat);
                    sheet.addCell(label);
                    cnt++;
                    sheet.mergeCells(0, cnt, 5, cnt);
                    label = new jxl.write.Label(0,cnt,"고객정보",cellFormat1);
                    sheet.addCell(label);
                    cnt++;
                                    
                    //////// 고객정보 /////////////////////////////////
                    for( int j=0; j<colArr0.length; j++ ){
                            if(j>=3 && j<=4){
                                    label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat2);
                            }else{
                                    label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat1);
                            }
                            sheet.addCell(label);
                    }
                    cnt++;
                    
                    //고객정보조회
                    String DL_P_RNMCNO_NO = (String) input.get("DL_P_RNMCNO");
                    input.put("DL_P_RNMCNO", DL_P_RNMCNO_NO.replaceAll(" ", ""));
                    
                    output_1 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_02_Kofiu", input);
                    
                    for (int ii = 0; ii < output_1.getCount("CS_NO"); ii++) {                    
                        for( int jj=0; jj<dataArr0.length; jj++ ){
                            label = new jxl.write.Label(jj,cnt,output_1.getText(dataArr0[jj],ii),cellFormat);
                            sheet.addCell(label);
    
                        }
                        
                        cnt++;
                    }
                               
                    //////// 계좌정보 /////////////////////////////////
                    sheet.mergeCells(0, cnt, 11, cnt);
                    label = new jxl.write.Label(0,cnt,"계좌정보",cellFormat1);
                    sheet.addCell(label);
                    cnt++;
        
                    for( int k=0; k<colArr1.length; k++ ){
                            if(k<7){
                                    label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat1);
                            }else{
                                    label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat2);
                            }
                            sheet.addCell(label);
                    }
                    cnt++;
                    
                                                        
                      for( int ii=0; ii<dataArr1.length; ii++ ){
                            
                         label = new jxl.write.Label(ii,cnt,output_1.getText(dataArr1[ii],0),cellFormat);
                         sheet.addCell(label);
                    }
                        
                    cnt++;
                    
                    //////// 조회 정보 /////////////////////////////////
                    sheet.mergeCells(0, cnt, 4, cnt);
                    label = new jxl.write.Label(0,cnt,"조회정보",cellFormat1);
                    sheet.addCell(label);
                    cnt++;
                    for( int m=0; m<colArr2.length; m++ ){
                            label = new jxl.write.Label(m,cnt,colArr2[m],cellFormat1);
                            sheet.addCell(label);
                    }
                    cnt++;
                    
                    output_1.add("DL_DT_A", DL_DT_A.replace("-", ""));
                    output_1.add("DL_DT_B", DL_DT_B.replace("-", ""));
                    
                    //조회 정보조회
                    for (int ii = 0; ii < output_1.getCount("BRN_NM"); ii++) {
                        for( int jj=0; jj<dataArr2.length; jj++ ){
                            System.out.println(output_1.getText(dataArr2[jj],ii));
                            label = new jxl.write.Label(jj,cnt,output_1.getText(dataArr2[jj],ii),cellFormat);
                            sheet.addCell(label);
                        }
                           
                        cnt++;
                    }
                    
                    //////// 거래 정보 /////////////////////////////////
                    sheet.mergeCells(0, cnt, 45, cnt);
                    label = new jxl.write.Label(0,cnt,"거래상세",cellFormat1);
                    sheet.addCell(label);
                    cnt++;
                    for( int p=0; p<colArr3.length; p++ ){
                            if(i<29){
                                    label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                            }else{
                                    label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat2);
                            }
                            sheet.addCell(label);
                    }
                    cnt++;
                    
                    input.put("stDate", DL_DT_B.replace("-", ""));
                    input.put("edDate", DL_DT_A.replace("-", ""));
                    
                    output_2 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelInfo_03_Kofiu", input);
                    
                    for (int ii = 0; ii < output_2.getCount("DL_SQ"); ii++) {
                        for( int jj=0; jj<dataArr3.length; jj++ ){
                        	//계좌번호 복화화해서 일련번호를 뒤에 추가
                        	if("GNL_SQ_DEC".equals(dataArr3[jj])) {
                            	String ACNT_NO_DEC = output_2.getText("ACNT_NO_DEC",ii);
                            	String DL_SQ = output_2.getText("DL_SQ",ii);
                            	
                            	int len = 5-DL_SQ.length();
                        		for(int k=0; k<len; k++) DL_SQ = "0" + DL_SQ;
                            	
                        		label = new jxl.write.Label(jj,cnt,ACNT_NO_DEC+DL_SQ,cellFormat);
                        	} else {
                        		label = new jxl.write.Label(jj,cnt,output_2.getText(dataArr3[jj],ii),cellFormat);
                        	}
                            sheet.addCell(label);
                        }
                           
                        cnt++;
                    }
                    
                    
                    wwb.write();
                    wwb.close();
                                    
                    String filePathMark = (fileFullPath + "/").replaceAll("\\\\", "/");
                    
                    Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList:File생성#############"+fileNameFullPath);
                  
                    
                    /*
					 * 암호화시작 - 20211123 - bsr
					 */

 					String a_file = fileNameFullPath;
					String a_file2 = (fileFullPath + "/enc_" +fileNm).replace("/", System.getProperty("file.separator"));
					
					System.out.println("###############" + a_file);
					System.out.println("###############" + a_file2);

					/*
					 * DAMO SCP API ScpDbAgent 객체를 생성한다
					 */
					ScpDbAgent agt = new ScpDbAgent();
					
					byte[] ctx;
					int ret;
					
					Properties _prop;
			        _prop = new Properties();
			        try {
			            _prop.load(com.ss.common.util.security.damo.damoManager.class.getClassLoader().getResourceAsStream("META-INF/properties/security-damo.properties"));
			            //_prop.load(com.ss.common.util.security.PropertiesLoader.class.getClassLoader().getResourceAsStream("properties/security-damo.properties"));
			        } catch(Exception exception) {
			        	
			        }
			        
					String iniPath 	= _prop.getProperty("damo.iniPath");
					String Agent_ID = _prop.getProperty("damo.AgentID");
					String DB_Name 	= _prop.getProperty("damo.DBname");
					String Owner 	= _prop.getProperty("damo.Owner");
					String Tbl_name = _prop.getProperty("damo.Tblname");
					
					agt = new ScpDbAgent();
					/*
					 * DAMO SCP API 설정 파일과 키파일의 풀 패스
					 */
					//
					String inFilePath = a_file;
					ret = agt.AgentInit(iniPath);
					System.out.println("[java] ret : " + ret );
					
					String encFilePath = a_file2;
					
					ctx = agt.AgentCipherCreateContext( Agent_ID, DB_Name, Owner, Tbl_name, "ENC_KEY" );
				    agt.AgentCipherEncryptFilePath( ctx, inFilePath, encFilePath);                
					
					//파일암호화후 원본파일 삭제
					File del_file = new File (a_file);
                    if(del_file.exists()){
                    	del_file.delete();
                    }
                    
                    
                    //파일 이름 변경
                    String phscFile = a_file + ".enc"; // 암호화명으로 수정
                    File new_file = new File (phscFile);
                    File rename_file = new File (a_file2);
                    if(rename_file.exists()){
                    	rename_file.renameTo(new_file);
                    }

                    /*
                     * 파일암호화 끝 - 20211123 - bsr
                     */
                    
                    output = JDaoUtilSingle.getData( "AML_20_01_10_03_MAX_NIC64B",new Object[]{sSSPS_DL_CRT_DT, sSSPS_DL_ID} );
                    int FILE_SEQ_max = output.getInt("FILE_SEQ") + 1;

                    String phscFileName = fileNm + ".enc"; // 암호화명으로 수정
                    HashMap<String, String> keyContent = new HashMap();
                    for(int c = 0; c < output_0.getCount("GNL_AC_NO"); c++){
                    	keyContent.put("fileSeq", String.valueOf(FILE_SEQ_max));
                        keyContent.put("phscFileName", phscFileName);
                        keyContent.put("fileName", fileNm);
                        keyContent.put("origFileNms", fileNm);	 //파일논리이름
                        keyContent.put("storedFileNms", phscFileName);	 //파일물리이름
                        keyContent.put("fileLen", String.valueOf(fileLen)); //파일사이즈
                        keyContent.put("fileSizes", String.valueOf(fileLen));	//파일사이즈
                        keyContent.put("fileFullPath", filePathMark);       //파일PATH
                        keyContent.put("filePaths", filePathMark);			//파일PATH
                        
                    }

                    list.add(new JSONObject(keyContent));
                    
                    
            }//end of for(i)

            output.put("fileContent",new JSONArray(list) );

        }catch (Exception e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Kofiu_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map}; 
            this.genOutputHash(output, result, "ERROR");
        }
        
        return output;
    }
}
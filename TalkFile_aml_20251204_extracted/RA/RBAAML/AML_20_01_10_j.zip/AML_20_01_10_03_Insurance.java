/* 2020.04.24
 * STR 3개월 거래내역 : 보험
 * aml_config.properties : amlType 설정 필요합니다.
 * amlType : 03-INSURANCE
 */
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.Constants;
import com.gtone.express.server.actions.ExpressAction;

import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class AML_20_01_10_03_Insurance extends ExpressAction {
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
    @Override
    public DataObj execute(HashMap input) throws Exception {
        DataObj output 		= new DataObj();
        DataObj output_0 	= new DataObj();		//계약자정보
        DataObj output_1 	= new DataObj();		//고객정보조회
        DataObj output_2 	= new DataObj();		//상품 및 계약정보, 조회정보
        DataObj output_3 	= new DataObj();		//거래상세
        //DataObj output_file 	= new DataObj();		//혐의거래 _첨부파일
        WritableWorkbook wwb = null;

        DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
        //혐의거래생성 일자 기준 3개월 거래내역
//      String DL_DT_A   = DL_DT_FORMAT.format(new java.util.Date());
        String DL_DT_A   = "";
        Calendar cal = Calendar.getInstance();


        try {
        	DL_DT_A   = input.get("SSPS_DL_CRT_DT").toString();
            cal.set(Integer.parseInt(DL_DT_A.substring(0,4)), Integer.parseInt(DL_DT_A.substring(4,6))-1, Integer.parseInt(DL_DT_A.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Insurance", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (Exception e2) {
        	Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Insurance", e2.getMessage());
        	HashMap map = new HashMap();
        	map.put("ERRCODE" ,"00001");
        	map.put("ERRMSG",e2.getMessage());
        	HashMap[]  result = {map};
        	this.genOutputHash(output, result, "ERROR");
        }

        String DL_DT_B = DL_DT_FORMAT.format(cal.getTime());

        input.put("DL_DT_B", DL_DT_B);
        input.put("DL_DT_A", DL_DT_A);

        //계약자정보
        String[] colArr0  = {"계약자명"	 ,"실명번호 구분"					,"계약자(사업자)실명번호"		,"계약자CI번호" 		,"계약자 국적" 		,"실명번호 구분코드"};
        String[] dataArr0 = {"CS_NM"  ,"RNM_CNFR_CCD_NM" 		,"RNMCNO"             		,"CS_CI_NO"   		,"NTN_CD"  		,"RNM_CNFR_CCD"};

        //상품 및 계약정보
         String[] colArr1  = {"상품종류"		,"보험상품명"	,"계약 금융기관"			,"보험계약번호"			,"보험계약일자"				,"보험만기일자"				,"납입주기"						,"총 납입보험료"					,"개설점명"						,"관리점명"							,"상품종류코드"	,"계약금융기관코드 "		,"개설점코드"			,"관리점코드"};
	    String[] dataArr1 = {"GOODS"		,"GDS_NM"	,"FNNC_FCLTY_NM"	,"INSURANCE_NO"		,"INSURANCE_ST_DT"	,"INSURANCE_ED_DT"	,"INSURANCE_CYCLE"	,"INSURANCE_TOT_AMT"	,"OPN_BRN_CD_NM"		,"MN_DL_DPRT_CD_NM"		,"GDS_NO"		,"FNNC_FCLTY_CD "	,"OPN_BRN_CD"	,"MN_DL_DPRT_CD"};

	    //피보험자 정보
	    String[] colArr4    = {"피보험자명"		,"실명번호 구분"	,"피보험자(사업자)실명번호"	,"피해자CI번호"	,"피보험자 국적"	,"실명번호 구분코드"};
	    String[] dataArr4  = {"피보험자명"		,"실명번호 구분"	,"피보험자(사업자)실명번호"	,"피해자CI번호"	,"피보험자 국적"	,"실명번호 구분코드"};
	    //수익자 정보
	    String[] colArr5    = {"수익자명",	"실명번호 구분" ,"수익자(사업자)실명번호"	,"수익자CI번호"	,"수익자 국적"	,"실명번호 구분코드"};
	    String[] dataArr5  = {"수익자명",	"실명번호 구분" ,"수익자(사업자)실명번호"	,"수익자CI번호"	,"수익자 국적"	,"실명번호 구분코드"};
	    //납부자 정보
	    String[] colArr6  = {"납부자명"	,"실명번호 구분"	,"납부자(사업자)실명번호"	,"납부자CI번호	","납부자 국적"	,"결제금융기관명"	,"결제계좌번호" ,"결제금융기관코드","실명번호구분코드"};
	    String[] dataArr6= {"납부자명"	,"실명번호 구분"	,"납부자(사업자)실명번호"	,"납부자CI번호	","납부자 국적"	,"결제금융기관명"	,"결제계좌번호" ,"결제금융기관코드","실명번호구분코드"};
	    //조회정보
        String[] colArr2  =  {"조회일시" 	,"조회점명"  	,"조회시작일"  	,"조회종료일"  	,"조회점코드"};
        String[] dataArr2 = {"RP_DT" 	,"BRN_NM" 	,"DL_DT_B" 		,"DL_DT_A" 		,"BRN_CD"};

        //거래상세
        String[] colArr3 = {"거래일련번호"			,"거래순번"						,"거래발생일시"						,"보험계약번호"						,"거래종류명"						,"거래수단명"						,"거래채널명"				,"유가증권명"			,"적요"					,"거래금액"
	        					,"수표금액"					,"보험료합계"					,"취급점명"								,"상대금융기관명"						,"상대계좌번호"					,"상대계좌주명"					,"의심거래보고여부"		,"거래종류코드"		,"거래수단코드"		,"거래채널코드"
	        					,"유가증권코드"			,"취급점코드"					,"상대금융기관코드"					,"정정구분코드"};
        String[] dataArr3 = {"GNL_SQ"			,"DL_SQ"						,"DL_DT_TM"						,"보험계약번호"						,"DL_TYP_NM"					,"DL_WY_NM"					,"DL_CHNNL_NM"		,"CHCK_KND_NM"	,"SMRY_TYP_NM"	,"OUT_AMT"
								,"CHCK_AMT"			,"TOT_AMT"				,"HANDLNG_BRN_NM"				,"CPRTY_TRSNS_FOGN_NM"	,"CPRTY_TRSNS_AC_NO"	,"CPRTY_TRSNS_AC_NM"	,"DOBT_DL_RPR_YN"	,"DL_TYP_CD"		,"DL_WY_CD"		,"DL_CHNNL_CD"
								,"CHCK_KND_CD"		,"HANDLNG_BRN_CD"		,"CPRTY_TRSNS_OGN_CD"		,"GBN_CD"};

        //String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.tms");
        String filePath = Constants.COMMON_TEMP_FILE_UPLOAD_DIR;		//임시업로드 폴더

        try    {

            Log.logAML(Log.DEBUG, input, "#############doCreateFileTrList-input:#############");

            String baseFromDate 		= ((String) input.get("DL_DT_B")).replaceAll(" ", "").trim();				//거래일자(시작)	조회
			String baseToDate 			= ((String) input.get("DL_DT_A")).replaceAll(" ", "").trim();				//거래일자(종료)	조회
            String sDL_AML_CUST_ID			= ((String) input.get("DL_P_AML_CUST_ID")).replaceAll(" ", "").trim();			//실명번호
            String sSSPS_DL_CRT_DT 	= ((String) input.get("SSPS_DL_CRT_DT")).replaceAll(" ", "").trim();	//혐의거래생성일자
            String sSSPS_DL_ID 			= ((String) input.get("SSPS_DL_ID")).replaceAll(" ", "").trim();			//혐의거래ID

            input.put("SSPS_DL_CRT_DT",sSSPS_DL_CRT_DT);
            input.put("SSPS_DL_ID",sSSPS_DL_ID);
            input.put("DL_AML_CUST_ID", sDL_AML_CUST_ID);

            //계좌정보조회
            output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelAccInfo", input);
            if(output_0.getCount("GNL_AC_NO") <= 0){
                output.put("ERRCODE", "00001");
                output.put("ERRMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                output.put("WINMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                return output;
            }

            input.put("GNL_AC_NO", output_0.getText("GNL_AC_NO"));		//종합계좌번호

            String fileFullPath = filePath;

            fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));
            fileFullPath = fileFullPath.replace("\\", "/");

            File dir = new File(fileFullPath);
            if(!dir.isDirectory()){
                dir.mkdirs();
            }

            List list = new ArrayList();

            for (int i = 0; i < output_0.getCount("GNL_AC_NO"); i++) {

                String sGNL_AC_NO 	= output_0.getText("GNL_AC_NO",i);									//종합계좌번호
                String sGDS_NO 		= output_0.getText("GDS_NO",i);											//상품코드
                String fileNm 			= sGNL_AC_NO+"_"+baseFromDate+"_"+baseToDate+"_"+sGDS_NO +".xls";		//파일논리이름(종합계좌번호_시작거래일자_종료거래일자_상품코드.xls)
                String newfileNm		= String.valueOf(System.currentTimeMillis())+".xls";				//파일물리이름(현재시각을 밀리세컨드 단위로 반환)

                input.put("GNL_AC_NO", sGNL_AC_NO);

                String fileNameFullPath = (fileFullPath + "/" +newfileNm).replace("/", System.getProperty("file.separator"));

                Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList-fileNameFullPath:#############"+fileNameFullPath);

                wwb = Workbook.createWorkbook(new File(fileNameFullPath));
                wwb.createSheet("Sheet", 0);

                WritableSheet sheet = wwb.getSheet(0);

                WritableCellFormat cellFormat = new WritableCellFormat();
                cellFormat.setBorder(Border.ALL , BorderLineStyle.THIN);

                WritableCellFormat cellFormat1 = new WritableCellFormat();
                cellFormat1.setBackground(jxl.format.Colour.YELLOW);
                cellFormat1.setBorder(Border.ALL , BorderLineStyle.THIN);

                WritableCellFormat cellFormat2 = new WritableCellFormat();
                cellFormat2.setBackground(jxl.format.Colour.ORANGE);
                cellFormat2.setBorder(Border.ALL , BorderLineStyle.THIN);

                int cnt = 0;
                Label label = new jxl.write.Label(0,cnt,"버전",cellFormat1);
                sheet.addCell(label);
                label = new jxl.write.Label(1,cnt,"H-ASTR-V2.0",cellFormat);
                sheet.addCell(label);
                cnt++;

                /************** 계약자정보 START *************/
                sheet.mergeCells(0, cnt, 5, cnt);
                label = new jxl.write.Label(0,cnt,"계약자정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int j=0; j<colArr0.length; j++ ){
                    if(j<6){
                    	label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat1);
                    }else{
                        label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                //계약자정보
                output_1 = MDaoUtilSingle.getData("AML_20_01_10_03_getInsuranceInfo_01", input);

                for (int ii = 0; ii < output_1.getCount("RNMCNO"); ii++) {
                    for( int jj=0; jj<dataArr0.length; jj++ ){
                        label = new jxl.write.Label(jj,cnt,output_1.getText(dataArr0[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 계약자정보 END *************/

                /************** 상품 및 계약정보 START *************/
                sheet.mergeCells(0, cnt, 13, cnt);
                label = new jxl.write.Label(0,cnt,"상품 및 계약정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int k=0; k<colArr1.length; k++ ){
                    if(k<14){
                    	label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat1);
                    }else{
                        label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                //상품 및 계약정보, 피보험자 정보, 수익자 정보, 납부자 정보
                output_2 = MDaoUtilSingle.getData("AML_20_01_10_03_getInsuranceInfo_02", input);

                if(output_2.getCount("RNMCNO") > 0) {
                    for( int ii=0; ii<dataArr1.length; ii++ ){
                         Log.logAML(Log.DEBUG, "","#################### ACCOUNT_INFORMATION #######################"+output_2.getText(dataArr1[ii],0));
                         label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr1[ii],0),cellFormat);
                         sheet.addCell(label);
                    }
                }

                cnt++;
                /************** 상품 및 계약정보 END *************/

                /************** 피보험자 정보 START *************/
				sheet.mergeCells(0, cnt, 5, cnt);
				label = new jxl.write.Label(0,cnt,"피보험자 정보",cellFormat1);
				sheet.addCell(label);
				cnt++;

				for( int k=0; k<colArr4.length; k++ ){
			        if(k<6){
			        	label = new jxl.write.Label(k,cnt,colArr4[k],cellFormat1);
			        }else{
			            label = new jxl.write.Label(k,cnt,colArr4[k],cellFormat2);
			        }
			        sheet.addCell(label);
				}
				cnt++;

				if(output_2.getCount("RNMCNO") > 0) {
				for( int ii=0; ii<dataArr4.length; ii++ ){
				     Log.logAML(Log.DEBUG, "","#################### ACCOUNT_INFORMATION #######################"+output_2.getText(dataArr4[ii],0));
				     label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr4[ii],0),cellFormat);
				     sheet.addCell(label);
				    }
				}

				cnt++;
				/************** 피보험자 정보 END *************/

				/************** 수익자 정보 START *************/
				sheet.mergeCells(0, cnt, 5, cnt);
				label = new jxl.write.Label(0,cnt,"수익자 정보",cellFormat1);
				sheet.addCell(label);
				cnt++;

				for( int k=0; k<colArr5.length; k++ ){
			        if(k<6){
			            label = new jxl.write.Label(k,cnt,colArr5[k],cellFormat1);
			        }else{
			            label = new jxl.write.Label(k,cnt,colArr5[k],cellFormat2);
			        }
			        sheet.addCell(label);
				}
				cnt++;

				if(output_2.getCount("RNMCNO") > 0) {
					for( int ii=0; ii<dataArr5.length; ii++ ){
					    Log.logAML(Log.DEBUG, "","#################### ACCOUNT_INFORMATION #######################"+output_2.getText(dataArr5[ii],0));
					    label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr5[ii],0),cellFormat);
					    sheet.addCell(label);
				    }
				}

				cnt++;
				/************** 수익자 정보 END *************/

				/************** 납부자 정보 START *************/
		        sheet.mergeCells(0, cnt, 8, cnt);
		        label = new jxl.write.Label(0,cnt,"납부자 정보",cellFormat1);
		        sheet.addCell(label);
		        cnt++;

		        for( int k=0; k<colArr6.length; k++ ){
	                if(k<9){
	                	label = new jxl.write.Label(k,cnt,colArr6[k],cellFormat1);
	                 }else{
	                    label = new jxl.write.Label(k,cnt,colArr6[k],cellFormat2);
	                 }
	                 sheet.addCell(label);
		        }
		        cnt++;

		        if(output_2.getCount("RNMCNO") > 0) {
		            for( int ii=0; ii<dataArr6.length; ii++ ){
		                 Log.logAML(Log.DEBUG, "","#################### ACCOUNT_INFORMATION #######################"+output_2.getText(dataArr6[ii],0));
		                 label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr6[ii],0),cellFormat);
		                 sheet.addCell(label);
		            }
		        }

		        cnt++;
		        /************** 납부자 정보 END *************/

		        /************** 조회정보 START *************/
                sheet.mergeCells(0, cnt, 4, cnt);
                label = new jxl.write.Label(0,cnt,"조회정보",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int m=0; m<colArr2.length; m++ ){
                    label = new jxl.write.Label(m,cnt,colArr2[m],cellFormat1);
                    sheet.addCell(label);
                }
                cnt++;

                output_2.add("DL_DT_A", DL_DT_A);
                output_2.add("DL_DT_B", DL_DT_B);

                //조회 정보조회
                for (int ii = 0; ii < output_2.getCount("BRN_NM"); ii++) {
                    for( int jj=0; jj<dataArr2.length; jj++ ){
                        System.out.println(output_2.getText(dataArr2[jj],ii));
                        label = new jxl.write.Label(jj,cnt,output_2.getText(dataArr2[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 조회정보 END *************/

                /************** 거래상세 START *************/
                sheet.mergeCells(0, cnt, 23, cnt);
                label = new jxl.write.Label(0,cnt,"거래상세",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int p=0; p<colArr3.length; p++ ){
                        if(p<24){
                        	label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                        }else{
                            label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat2);
                        }
                        sheet.addCell(label);
                }
                cnt++;

                output_3 = MDaoUtilSingle.getData("AML_20_01_10_03_getInsuranceInfo_03", input);

                for (int ii = 0; ii < output_3.getCount("DL_SQ"); ii++) {
                    for( int jj=0; jj<dataArr3.length; jj++ ){
                    	if(jj==0) {//거래발생일시
                    		String GNL_AC_NO_DL_SQ = output_3.getText("GNL_AC_NO",ii) + output_3.getText("DL_SQ_VIEW",ii);
                    		label = new jxl.write.Label(jj,cnt, GNL_AC_NO_DL_SQ, cellFormat);
                    	} else {
                    		label = new jxl.write.Label(jj,cnt,output_3.getText(dataArr3[jj],ii),cellFormat);
                    	}

                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 거래상세 END *************/

                wwb.write();
                wwb.close();

                //String filePathMark = fileFullPath.replaceAll("\\\\", "/");

                long fileLen = 0;	// 파일사이즈
            	File strFile = new File(fileNameFullPath);
            	if(strFile.exists()) {
            		fileLen = strFile.length();
            	}
                Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList:File생성#############"+fileNameFullPath);

                HashMap<String, String> keyContent = new HashMap();

                keyContent.put("fileSizes", String.valueOf(fileLen));	//파일사이즈
                keyContent.put("origFileNms", fileNm);						//파일논리이름
                keyContent.put("storedFileNms", newfileNm);			//파일물리이름
                keyContent.put("filePaths", filePath);						//파일PATH

                list.add(new JSONObject(keyContent));

            }//end of for(i)

            output.put("fileContent",new JSONArray(list) );

        }catch (RowsExceededException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IOException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IndexOutOfBoundsException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (WriteException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (Exception e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }

        return output;
    }
}
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.IOException;
import kr.co.itplus.jwizard.dataformat.DataSet;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

/**
*<pre>
* AI 예측 위험도
*</pre>
*/
public class AML_20_01_10_09 extends GetResultObject {

    private static AML_20_01_10_09 instance = null;
    /**
     * getInstance
     * @return AML_20_01_10_09
     */
    public static AML_20_01_10_09 getInstance() {
        if(instance == null) {
            instance = new AML_20_01_10_09();
        }
        return instance;
    }

    /**
     * <pre>
     *  AI 예측 위험도
     */
    public DataObj doSearch(DataObj input) {
        DataObj output = new DataObj();
        DataSet gdRes = null;
        String top_flag = "5";
        input.put("top_flag", top_flag);
        try {
            DataObj dbOut = MDaoUtilSingle.getData("AML_21_01_02_01_doSearchTopFeature", input);

            gdRes = Common.setGridData(dbOut);
            
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", gdRes.getRowCount() > 0
                    ? MessageHelper.getInstance().getMessage("0043",input.getText("LANG_CD"),"조회 되었습니다.")
                    : MessageHelper.getInstance().getMessage("0039",input.getText("LANG_CD"),"자료가 존재하지 않습니다."));
            output.put("gdRes", gdRes);
        } catch(RuntimeException e) {
        	Log.logAML(Log.ERROR, this, "doSearch", e.toString());
        	output.clear();
        	output.put("ERRCODE", "00001");
        	output.put("ERRMSG", e.getMessage());
        	output.put("WINMSG", e.getMessage());
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSearch", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }
    
	public DataObj createAIopi(DataObj input) throws IOException {
        DataObj output = new DataObj();
        DataSet gdRes = null;
        String DL_F = input.getText("DL_F");
        String DL_L = input.getText("DL_L");
                
        AMLAISTROpinion AMLAISTROpinion = new AMLAISTROpinion();
        String opi = AMLAISTROpinion.toLLM(DL_L, DL_F);
        try {
        	if(!opi.contains("Exception")) {
        		output.put("ERRCODE", "00000");
                output.put("ERRMSG", opi);
                output.put("gdRes", gdRes);
        	}
        	else {
        		Log.logAML(Log.ERROR, this, "createAIopi", "AI 서버가 작동중이지 않습니다. 관리자에게 문의하십시오.");
            	output.clear();
            	output.put("ERRCODE", "00001");
            	output.put("ERRMSG", opi);
            	output.put("WINMSG", opi);
//            	output.put("ERRMSG", "AI 서버가 작동중이지 않습니다. 관리자에게 문의하십시오.");
//            	output.put("WINMSG", "AI 서버가 작동중이지 않습니다. 관리자에게 문의하십시오.");
        	}
        } catch(RuntimeException e) {
        	Log.logAML(Log.ERROR, this, "createAIopi", e.toString());
        	output.clear();
        	output.put("ERRCODE", "00001");
        	output.put("ERRMSG", e.getMessage());
        	output.put("WINMSG", e.getMessage());
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "createAIopi", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }
}

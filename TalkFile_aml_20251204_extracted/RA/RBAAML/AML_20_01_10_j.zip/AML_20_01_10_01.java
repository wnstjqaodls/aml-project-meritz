/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.user.SessionAML;
import com.gtone.aml.workflow.AMLWF4Interface;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import jspeed.base.util.StringHelper;
import jspeed.websvc.WSParam;
import kr.co.itplus.jwizard.dataformat.DataSet;

/******************************************************************************************************************************************
 * @Description STR 결재
 *              STR 決裁
 *              STR Approval
 * @Group       GTONE, R&D센터/개발2본부
 * @Project     AML/RBA/FATCA/CRS/WLF
 * @Java        6.0 이상
 * @Author      서윤경, 김현일
 * @Since       2010. 9. 30.
 ******************************************************************************************************************************************
 * @Modifier    박상훈
 * @Update      2017. 10. 11.
 * @Alteration  1. 결과값이 null 인 경우, 발생하는 오류 수정
 *              2. 코드정리
 ******************************************************************************************************************************************/

public class AML_20_01_10_01 extends GetResultObject
{
    /**************************************************************************************************************************************
     * Attributes
     **************************************************************************************************************************************/

    /** 인스턴스 */
    private static AML_20_01_10_01 instance = null;

    /**************************************************************************************************************************************
     * Methods
     **************************************************************************************************************************************/

    // [ do ]

    /**
     * STR 결재처리<br>
     * STR決裁処理
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(STR 결재처리 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(STR決裁処理 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public DataObj doSave1(DataObj input)
    {
        DataObj output = new DataObj();
       // DataObj input_temp = new DataObj();

        try {
            List gdRes = (List)input.get("gdReq");
            SessionAML sess = (SessionAML)input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inputStatus, inputDesc, inst_id, work_id;
            String StCheckYn = Util.nvlTrim((String)input.get("ST_CHECK_YN"),"");
            DataObj dbOut = null;
            HashMap tmpInput = new HashMap(), map = null;

            String dptRole = ((SessionAML)input.get("SessionAML")).getSessionHelper().getDeptId() + "." + ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();
            Object userId = ((SessionAML)input.get("SessionAML")).getOffDutyUserId();
            if (userId == null) {
                userId = ((SessionAML)input.get("SessionAML")).getSessionHelper().getUserId();
            }

            for (int i = 0; i < gdRes.size(); i++) {
            	String OK_CCD = "";
                map = (HashMap)gdRes.get(i);

                // 결재건 확인
                map.put("USER_ID", userId);
                map.put("DPT_ROLE", dptRole);
                output = MDaoUtilSingle.getData("AML_20_01_10_01_getCount", map);
                if (!"1".equals(output.getText("CNT"))) {
                    output.clear();
                    output.put("ERRCODE", "00001");
                    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    output.put("WINMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    return output;
                }

                tmpInput.clear();
                tmpInput.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT"));
                tmpInput.put("SSPS_DL_ID", map.get("SSPS_DL_ID"));
                tmpInput.put("MN_DL_BRN_CD", sess.getsAML_BDPT_CD());
                OK_CCD = (String)map.get("OK_CCD");

                if ("Y".equals(sess.getsAML_MASTER_BRANCH())) {
                    dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_NIC67B_Count", tmpInput);
                } else {
                    dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_NIC88B_Count", tmpInput);
                }

                if (!"Y".equals(StCheckYn)) {
                    if(!"2".equals(OK_CCD) && dbOut.getInt("CNT") < 1) {
                    	Log.logAML(Log.ERROR, this, "doSave1");
                        output.clear();
                        output.put("ERRCODE", "00001");
                        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0070",input.getText("LANG_CD"),"혐의 의심내역이 등록되지 않았습니다."));
                        output.put("WINMSG", MessageHelper.getInstance().getMessage("0070",input.getText("LANG_CD"),"혐의 의심내역이 등록되지 않았습니다."));
                        return output;
                    }
                }
            }

        	//20180223 대직자 처리
			Object userNm = null;
			if (null == sess.getOffDutyUserId() ) {
				//userNm = sessHelper.getUserName() +"("+sess.getOffDutyUserNm()+" 대직자"+")";
				userNm = sessHelper.getUserName();
			}else{
				userNm = sessHelper.getUserName() +"("+sess.getOffDutyUserNm()+" 대직자"+")";
				//userNm = sessHelper.getUserName();
			}

			HashMap<String, Object> wfInput =  new HashMap<String, Object>();

			HashMap<Object, Object> tempParam = new HashMap<Object, Object>();

           // @SuppressWarnings("unused")
           // boolean bUpdateNIC66B;
            for(int i = 0; i < gdRes.size(); i++) {


                wfInput.put("RPR_P_ENO"     , sessHelper.getUserId());
                wfInput.put("RPR_P_NM"      , userNm);
                wfInput.put("DPRT_CD"       , sessHelper.getDeptId());
                wfInput.put("DPRT_NM"       , sessHelper.getDeptName());
                wfInput.put("MN_DL_BRN_CD"  , sess.getsAML_BDPT_CD());
                wfInput.put("RPR_P_TEL_NO"  , StringHelper.nvl(sess.getsAML_TEL_NO(), "000-0000-0000") );

                map = (HashMap)gdRes.get(i);
                keyDate     = (String)map.get("SSPS_DL_CRT_DT"  );
                keyID       = (String)map.get("SSPS_DL_ID"      );
                if("3".equals((String)map.get("OK_CCD"))){
                	inputStatus = "1";
                }else {
                	inputStatus = (String)map.get("OK_CCD");
                }
                if ( "N".equals(sess.getsAML_MASTER_BRANCH()) ){
                	inputDesc     = (String)map.get("XCL_RSN_CNTNT2");
                }else {
                	inputDesc     = (String)map.get("XCL_RSN_CNTNT");
                }
                inst_id     = (String)map.get("INST_ID"         );
                work_id     = (String)map.get("WORK_ID"         );

                wfInput.put("SSPS_DL_CRT_DT", keyDate       );
                wfInput.put("SSPS_DL_ID"    , keyID         );
                wfInput.put("INST_ID"       , inst_id       );
                wfInput.put("WORK_ID"       , work_id       );
                wfInput.put("OK_CCD"        , inputStatus   );
                WSParam param = new WSParam(wfInput);

                param.setSession(sess.getSession());
                AMLWF4Interface wif = new AMLWF4Interface(param, input.getText("LANG_CD"), Integer.parseInt(inst_id));
                wif.executeTrs(Integer.parseInt(work_id), "A", inputDesc);

                tempParam.put("SSPS_DL_CRT_DT", keyDate);
                tempParam.put("SSPS_DL_ID", keyID);
                tempParam.put("OK_CCD", inputStatus);
                tempParam.put("USERID" , sessHelper.getUserId());

                MDaoUtilSingle.setData("AML_20_01_10_01_appStatusChange", tempParam);
                tempParam.clear();
                wfInput.clear();
                /* 본점인 경우 nic66b 입력한 대로 업데이트
                 * 아닌경우 입력값  OK_CCD가  '보고제외' 이면  nic66b의 update
                 *                       '보고제외' 가 아니면  nic66b의 OK_CCD가 체크하여 데이터가 '보고제외' 이면 update 하지 않음.
                 * 항상 UPDATE하게 수정함.
                 *
                 * 2015.04..07 KSY
                 * STR 결재 상세 저장시 결재상태를 변경하도록 수정(확인/미확인/보고제외)
                 *
                 *
                 */
                /* KSY 주석시작
                 * if("Y".equals(sess.getsAML_MASTER_BRANCH())) {
                    bUpdateNIC66B = true;
                }
                else {
                    if("2".equals(inputStatus))
                        bUpdateNIC66B = true;
                    else {
                        dbOut = JDaoUtilSingle.getData("AML_20_01_10_01_NIC66B_check", wfInput);
                        bUpdateNIC66B = !"2".equals(dbOut.getText("OK_CCD"));
                        bUpdateNIC66B = true;  //20100825
                    }
                }

                if(bUpdateNIC66B) {
                    JDaoUtilSingle.setData("AML_20_01_10_01_NIC66B_update"
                            , new Object[] {inputStatus
                                    , inputDesc
                                    , sessHelper.getUserId()
                                    , keyDate
                                    , keyID}
                    );
                }
                KSY 주석 끝
                */
            }

            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
            output.put("gdRes", gdRes);
        } catch(NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }catch(IOException e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }catch(AMLException e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSave1", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }

        return output;
    }

    /**
     * STR 결재 반려처리<br>
     * STR決裁差戻し処理
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(STR 결재 반려처리 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(STR決裁差戻し処理 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    @SuppressWarnings("rawtypes")
    public DataObj doSave2(DataObj input)
    {
        DataObj output = new DataObj();
        try {
            List gdRes = (List)input.get("gdReq");

            SessionAML sess = (SessionAML)input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inputStatus, inputDesc, inst_id, work_id;

            String dptRole = ((SessionAML)input.get("SessionAML")).getSessionHelper().getDeptId() + "." + ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();
            Object userId = ((SessionAML)input.get("SessionAML")).getOffDutyUserId();
            if (userId == null) {
                userId = ((SessionAML)input.get("SessionAML")).getSessionHelper().getUserId();
            }

            // 결재건 확인
            HashMap map = null;
            for (int i = 0; i < gdRes.size(); i++) {
                map = (HashMap)gdRes.get(i);
                map.put("USER_ID", userId);
                map.put("DPT_ROLE", dptRole);

                output = MDaoUtilSingle.getData("AML_20_01_10_01_getCount", map);
                if (!"1".equals(output.getText("CNT"))) {
                    output.clear();
                    output.put("ERRCODE", "00001");
                    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    output.put("WINMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    return output;
                }
            }

        	//20180223 대직자 처리
			Object userNm = null;
			if (null == sess.getOffDutyUserId() ) {
				//userNm = sessHelper.getUserName() +"("+sess.getOffDutyUserNm()+" 대직자"+")";
				userNm = sessHelper.getUserName();
			}else{
				userNm = sessHelper.getUserName() +"("+sess.getOffDutyUserNm()+" 대직자"+")";
				//userNm = sessHelper.getUserName();
			}

			HashMap<String, Object> wfInput =  new HashMap<String, Object>();

            for(int i = 0; i < gdRes.size(); i++) {


                wfInput.put("RPR_P_ENO"     , sessHelper.getUserId());
                wfInput.put("RPR_P_NM"      , userNm);
                wfInput.put("DPRT_CD"       , sessHelper.getDeptId());
                wfInput.put("DPRT_NM"       , sessHelper.getDeptName());
                wfInput.put("MN_DL_BRN_CD"  , sess.getsAML_BDPT_CD());
                wfInput.put("RPR_P_TEL_NO"  , StringHelper.nvl(sess.getsAML_TEL_NO(), "000-0000-0000") );

                map         = (HashMap)gdRes.get(i);
                keyDate     = (String)map.get("SSPS_DL_CRT_DT"  );
                keyID       = (String)map.get("SSPS_DL_ID"      );
                inputStatus = (String)map.get("OK_CCD"          );
                //inputDesc   = (String)map.get("XCL_RSN_CNTNT"   );
				inputDesc   = (String) input.get("DNY_RSN_CNTNT"   );
                inst_id     = (String)map.get("INST_ID"         );
                work_id     = (String)map.get("WORK_ID"         );

                wfInput.put("SSPS_DL_CRT_DT", keyDate       );
                wfInput.put("SSPS_DL_ID"    , keyID         );
                wfInput.put("INST_ID"       , inst_id       );
                wfInput.put("WORK_ID"       , work_id       );
                wfInput.put("OK_CCD"        , inputStatus   );
                WSParam param = new WSParam(wfInput);

                param.setSession(sess.getSession());
                AMLWF4Interface wif = new AMLWF4Interface(param, input.getText("LANG_CD"), Integer.parseInt(inst_id));
                wif.executeTrs(Integer.parseInt(work_id),  "D", inputDesc);

                HashMap<Object, Object> tempParam = new HashMap<Object, Object>();
                tempParam.put("SSPS_DL_CRT_DT", keyDate);
                tempParam.put("SSPS_DL_ID", keyID);
                tempParam.put("OK_CCD", inputStatus);
                tempParam.put("DNY_RSN_CNTNT" , inputDesc);
                tempParam.put("USERID" , sessHelper.getUserId());
                MDaoUtilSingle.setData("AML_20_01_10_01_NIC66B_DNY_update", tempParam);

                wfInput.clear();

            }

            output.put("ERRCODE", "00000");
            output.put("ERRMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
            output.put("WINMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
            output.put("gdRes"  , gdRes);
        } catch(NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        } catch(IOException e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        } catch(AMLException e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        }
        //finally {}

        return output;
    }

    /**
     * STR 결재 조회<br>
     * STR 決裁照会
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(STR 결재 조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(STR決裁照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    public DataObj doSearch(DataObj input)
    {
        DataObj output = new DataObj();
        DataSet gdRes = null;

        try {

        	//20180223 대직자 처리
			Object userId = null;
			if (null == ((SessionAML)input.get("SessionAML")).getOffDutyUserId() ) {
				//userId = ((SessionAML)input.get("SessionAML")).getOffDutyUserId();
				userId = ((SessionAML)input.get("SessionAML")).getSessionHelper().getUserId();
			}else{
				//userId = ((SessionAML)input.get("SessionAML")).getSessionHelper().getUserId();
				userId = ((SessionAML)input.get("SessionAML")).getOffDutyUserId();
			}

            String dptRole = ((SessionAML)input.get("SessionAML")).getSessionHelper().getDeptId() + "." + ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();

            input.put("userId", userId);
            input.put("dptRole", dptRole);

			String CS_NO = "";
            if(!"".equals(input.getText("CS_NO"))){
            	CS_NO = Util.replace(input.getText("CS_NO"),"-","");
            	input.put("CS_NO", CS_NO);
            }

			DataObj dbOut = MDaoUtilSingle.getData( "AML_20_01_10_01_doSearch", input);

            gdRes = Common.setGridData(dbOut);

            if (dbOut.getCount("SSPS_DL_CRT_DT_A")>0) {
                gdRes = Common.setGridData(dbOut);
            }
            /*
            else {
                output.put("ERRMSG",MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
            }
            */
            output.put("ERRCODE","00000");
            output.put("gdRes"  , gdRes );
        } catch(AMLException e) {
            Log.logAML(Log.ERROR, this, "doSearch", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        }
        return output;
    }

    /**
     * STR 혐의거래 Scoring 항목별 상세 내역조회<br>
     * STR疑わしい取引のスコアリング項目別の詳細照会
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(Scoring 항목별 상세 내역 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(スコアリング項目別の詳細 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    @SuppressWarnings("unused")
    public DataObj doSearch4(DataObj input)
    {
        DataObj output = new DataObj();
        DataSet gdRes  = null;
        try {
           // String AML_CUST_ID           = input.getText("AML_CUST_ID"        ).trim();
           // String KYC_TMS_CCD      = input.getText("KYC_TMS_CCD"   ).trim();
           // String SSPS_DL_ID       = input.getText("SSPS_DL_ID"    ).trim();
           // String SSPS_DL_CRT_DT   = input.getText("SSPS_DL_CRT_DT").trim();

            @SuppressWarnings("unchecked")
			DataObj dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_doSearch4", input);

            if (dbOut.getCount("SCNR_MRK")>0) {
                gdRes = Common.setGridData(dbOut);
            }
            /*
            else {
                output.put("ERRMSG",MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
            }
            */
            output.put("ERRCODE","00000");
            output.put("gdRes"  , gdRes );
        } catch(AMLException e) {
        	Log.logAML(Log.ERROR, this, "doSearch", e.toString());
        	output.clear();
        	output.put("ERRCODE", "00001");
        	output.put("ERRMSG", e.getMessage());
        	output.put("WINMSG", e.getMessage());
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSearch", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }
    
    public DataObj doSearch_code(DataObj input)
    {
        DataObj output = new DataObj();
        DataSet gdRes  = null;
        try {
           
            @SuppressWarnings("unchecked")
			DataObj dbOut = MDaoUtilSingle.getData("AML_20_01_10_01_getCodeData", input);

            gdRes = Common.setGridData(dbOut);
           
            output.put("ERRCODE","00000");
            output.put("gdRes"  , gdRes );
        } catch(AMLException e) {
        	Log.logAML(Log.ERROR, this, "doSearch", e.toString());
        	output.clear();
        	output.put("ERRCODE", "00001");
        	output.put("ERRMSG", e.getMessage());
        	output.put("WINMSG", e.getMessage());
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSearch_code", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        return output;
    }

    // [ get ]

    /**
     * 인스턴스 반환.
     * <p>
     * @return  <code>AML_20_01_10_01</code>
     */
    public static AML_20_01_10_01 getInstance() { return instance==null?(instance=new AML_20_01_10_01()):instance; }

    /**
     * SPA 화면 호출 _조회
     */
    public DataObj doSearch_AML_20_01_10_01(DataObj input)
    {
    	return doSearch(input);
    }

    /**
     * SPA 화면 호출_결재
     */
    public DataObj doSave1_AML_20_01_10_01(DataObj input)
    {
    	return doSave1(input);
    }

    /**
     * SPA 화면 호출_결재
     */
    public DataObj doSave2_AML_20_01_10_01(DataObj input)
    {
    	return doSave2(input);
    }
}

package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

public class AML_20_01_10_06 extends GetResultObject {

	private static AML_20_01_10_06 instance = null;

	public static AML_20_01_10_06 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_01_10_06();
		}
		return instance;
	}

	public DataObj doSearch(DataObj input) throws AMLException{
		DataObj output = new DataObj();
		DataSet gdRes = null;
		try {
			Object userId = ((SessionAML) input.get("SessionAML")).getSessionHelper().getUserId();
			String dptRole = ((SessionAML) input.get("SessionAML")).getSessionHelper().getDeptId() + "." + ((SessionAML) input.get("SessionAML")).getsAML_ROLE_ID();
			input.put("USER_ID", userId);
			input.put("DPT_ROLE", dptRole);

			output = MDaoUtilSingle.getData("AML_20_01_10_06_getSearch_2020", input);
			gdRes = Common.setGridData(output);
			
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", gdRes.getRowCount() > 0 ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"), "조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"), "자료가 존재하지 않습니다."));
			output.put("gdRes", gdRes);
		} catch (AMLException e) {
			Log.logAML(1, this, "doSearch", e.toString());
			output.clear();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", e.getMessage());
		} 
		return output;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public DataObj doMerge(DataObj input) {
		DataObj output = new DataObj();
		String ACT_NAME_MASTER = input.getText("ACT_NAME_MASTER");
		boolean isMerge = "Y".equals(input.getText("MERGE_YN")) ? false : true;

		try {
			List gdRes = (List) input.get("gdReq");
			HashMap map = null;
			HashMap tmpInput = new HashMap();

			for ( int i = 0; i < gdRes.size(); i++ ) {
				map = (HashMap) gdRes.get(i);

				// AML_20_01_10_01.jsp 그리드에서 넘어온 결재단계값(ex. 본점담당자)과 현재 팝업창 그리드의 결재단계의 값과 같을 경우에만 병합/해제가 가능하도록 구현.
				if ( !ACT_NAME_MASTER.equals(map.get("ACT_NAME").toString()) ) {
					continue;
				}
				// if (!"1".equals(map.get("SELECTED").toString())) continue;

				tmpInput.clear();
				tmpInput.put("SSPS_DL_ID_MASTER", input.getText("SSPS_DL_ID_MASTER"));
				tmpInput.put("SSPS_DL_CRT_DT_MASTER", input.getText("SSPS_DL_CRT_DT_MASTER"));
				tmpInput.put("DL_P_NM_MASTER", input.getText("DL_P_NM"));
				tmpInput.put("SSPS_DL_ID", map.get("SSPS_DL_ID"));
				tmpInput.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT"));

				if ( isMerge ) { // 병합
					MDaoUtilSingle.setData("AML_20_01_10_06_updateNIC66B_Merge", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC71B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC72B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC75B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC76B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC77B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC83B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_insertNIC98B", tmpInput);
				} else { // 해제
					MDaoUtilSingle.setData("AML_20_01_10_06_updateNIC66B_Separate", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC71B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC72B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC75B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC76B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC77B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC83B", tmpInput);
					MDaoUtilSingle.setData("AML_20_01_10_06_deleteNIC98B", tmpInput);
				}
			}

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
			output.put("gdRes", gdRes);

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doMerge", e);
			output.clear();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", e.getMessage());
		}

		return output;
	}

	public DataObj getMergeInfo(DataObj input) {
		DataObj ouyput = new DataObj();

		try {
			ouyput = MDaoUtilSingle.getData("AML_20_01_10_06_GetMergeInfo", input);
		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "getMergeInfo", e.toString());
		}

		return ouyput;
	}
}

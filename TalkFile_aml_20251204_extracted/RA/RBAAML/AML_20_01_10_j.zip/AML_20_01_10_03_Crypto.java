
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.action.AMLCommonLogAction;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.Constants;
import com.gtone.express.server.actions.ExpressAction;

import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class AML_20_01_10_03_Crypto extends ExpressAction {
   private static byte[] dek_secret; // Base64.getDecoder().decode("r3SH5w6CyhUkTG3dAub857lO56+x/zj7Yr+QQ9hfEQc=");

   @SuppressWarnings({ "rawtypes", "unchecked", "unused" })
    @Override
    public DataObj execute(HashMap input) throws Exception {
		DataObj output    	= new DataObj();
	    DataObj output_0 	= new DataObj();		//계좌정보조회
	    DataObj output_1 	= new DataObj();		//고객정보조회
	    DataObj output_2 	= new DataObj();		//계좌정보, 조회정보
	    DataObj output_3 	= new DataObj();		//거래상세

	    WritableWorkbook wwb = null;

        String orgSSPS_DL_CRT_DT = (String)input.get("SSPS_DL_CRT_DT");
        DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
        String DL_DT_A   = orgSSPS_DL_CRT_DT;  //DL_DT_FORMAT.format(new java.util.Date());
        Calendar cal = Calendar.getInstance();

        try {
            cal.set(Integer.parseInt(DL_DT_A.substring(0,4)), Integer.parseInt(DL_DT_A.substring(4,6))-1, Integer.parseInt(DL_DT_A.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }

        String DL_DT_B = DL_DT_FORMAT.format(cal.getTime());

        input.put("DL_DT_B", DL_DT_B);
        input.put("DL_DT_A", DL_DT_A);

        //고객정보
        String[] colArr0  = {"거래자(사업자)명",	 "실명번호 구분",	           "거래자(사업자)실명번호",	"고객 국적"	, "고객ID", "지갑번호(지갑주소)", "최초 가입일", "실명번호 구분코드"};
        String[] dataArr0 = {"CS_NM",         "RNM_CNFR_CCD_NM", "RNMCNO",              "NTN_CD", "AML_CUST_ID", "지갑번호(지갑주소)", "최초 가입일", "RNM_CNFR_CCD"};

        //실명확인 입출금계좌 정보
        String[] colArr1  = {"계좌개설 금융기관", "계좌번호",	     "계좌주(사업자)명", "실명번호 구분",	              "계좌주(사업자)실명번호", "계좌등록일자",    "개설금융기관코드",   "실명번호 구분코드"};
        String[] dataArr1 = {"RPR_OGN_NM", "GNL_AC_NO", "CS_NM", 		   "RNM_CNFR_CCD_NM", "RNMCNO",               "AC_OPN_DT", "TRNS_OGN_CD", "RNM_CNFR_CCD"};

        //조회정보
        String[] colArr2  =  {"조회일시" 	,"조회점명"  	,"조회시작일"  	,"조회종료일"  ,"조회점코드"};
        String[] dataArr2 = {"RP_DT" 	,"BRN_NM" 	,"DL_DT_B" 		,"DL_DT_A" ,"BRN_CD"};


        //거래상세
        String[] colArr3 = {"거래일련번호"					,"거래순번"													,"거래발생일시"							,"거래주체 구분 코드(ID/Addr)"					,"거래주체 상세"
        						,"거래종류명"						,"거래수단명"												,"거래채널명"								,"적요"												,"접근국가"
        						,"거래상품명"						,"거래수량"					        						,"통화구분코드"							,"원화환산 거래금액"								,"총잔액(원화환산 잔액)"
        						,"상대금융기관명"					,"상대 거래주체 구분 값(ID/주소)"						,"상대 거래주체 상세"						,"상대거래자명"									,"상대거래자실명구분"
        						,"상대거래자실명번호"				,"상대거래자국적"											,"거래종류코드"							,"거래수단코드"									,"거래채널코드"
        						,"상대금융기관코드	"				,"상대거래자실명구분코드"									,"정정구분코드"};
        String[] dataArr3 = {"GNL_SQ"					,"DL_SQ"													,"DL_DT_TM" 							,"거래주체 구분 코드(ID/Addr)"					,"거래주체 상세"
        						,"DL_TYP_NM" 					,"DL_WY_NM" 											,"DL_CHNNL_NM" 						,"SMRY_TYP_NM"								,"접근국가"
        						,"GDS_NM"						,"거래수량"													,"CRNCY_CD"							,"원화환산 거래금액"								,"총잔액(원화환산 잔액)"
        						,"CPRTY_TRSNS_FOGN_NM" ,"상대 거래주체 구분 값(ID/주소)"						,"상대 거래주체 상세"						,"PRXY_NM"										,"PRXY_RNM_NO_CCD_NM"
        						,"PRXY_RNMCNO"				,"NTN_CD"												,"DL_TYP_CD"							,"DL_WY_CD"									,"DL_CHNNL_CD"
        						,"CPRTY_TRSNS_OGN_CD" ,"CPRTY_TRSNS_AC_RNM_CNFR_CCD"           ,"GBN_CD"};

        //String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.str");
        String filePath = Constants.COMMON_TEMP_FILE_UPLOAD_DIR;		//임시업로드 폴더

        try    {

            Log.logAML(Log.DEBUG, input, "#############doCreateFileTrList-input:#############");

            String baseFromDate 		= ((String) input.get("DL_DT_B")).replaceAll(" ", "").trim();				//거래일자(시작)	조회
			String baseToDate 			= ((String) input.get("DL_DT_A")).replaceAll(" ", "").trim();				//거래일자(종료)	조회
            String sDL_AML_CUST_ID			= ((String) input.get("DL_P_AML_CUST_ID")).replaceAll(" ", "").trim();			//실명번호
            String sSSPS_DL_CRT_DT 	= ((String) input.get("SSPS_DL_CRT_DT")).replaceAll(" ", "").trim();	//혐의거래생성일자
            String sSSPS_DL_ID 			= ((String) input.get("SSPS_DL_ID")).replaceAll(" ", "").trim();			//혐의거래ID

            input.put("SSPS_DL_CRT_DT",sSSPS_DL_CRT_DT);
            input.put("SSPS_DL_ID",sSSPS_DL_ID);
            input.put("DL_AML_CUST_ID", sDL_AML_CUST_ID);

          //계좌정보조회
            output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelAccInfo", input);
            if(output_0.getCount("GNL_AC_NO") <= 0){
                output.put("ERRCODE", "00001");
                output.put("ERRMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                output.put("WINMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                return output;
            }

            input.put("GNL_AC_NO", output_0.getText("GNL_AC_NO"));		//종합계좌번호

            String fileFullPath = filePath;

            fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));
            fileFullPath = fileFullPath.replace("\\", "/");
            File dir = new File(fileFullPath);
            if(!dir.isDirectory()){
                dir.mkdirs();
            }

            List list = new ArrayList();

            for (int i = 0; i < output_0.getCount("GNL_AC_NO"); i++) {

				String sGNL_AC_NO 	= output_0.getText("GNL_AC_NO",i);									//종합계좌번호
				String sGDS_NO 		= output_0.getText("GDS_NO",i);											//상품코드
            	String fileNm 			= sGNL_AC_NO+"_"+baseFromDate+"_"+baseToDate+"_"+sGDS_NO +".xls";		//파일논리이름(종합계좌번호_시작거래일자_종료거래일자_상품코드.xls)
				String newfileNm		= String.valueOf(System.currentTimeMillis())+".xls";				//파일물리이름(현재시각을 밀리세컨드 단위로 반환)

				input.put("GNL_AC_NO", sGNL_AC_NO);

				String fileNameFullPath = (fileFullPath + "/" +newfileNm).replace("/", System.getProperty("file.separator"));

				Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList-fileNameFullPath:#############"+fileNameFullPath);

				wwb = Workbook.createWorkbook(new File(fileNameFullPath));
				wwb.createSheet("Sheet", 0);

				WritableSheet sheet = wwb.getSheet(0);

				WritableCellFormat cellFormat = new WritableCellFormat();
				cellFormat.setBorder(Border.ALL , BorderLineStyle.THIN);

				WritableCellFormat cellFormat1 = new WritableCellFormat();
				cellFormat1.setBackground(jxl.format.Colour.YELLOW);
				cellFormat1.setBorder(Border.ALL , BorderLineStyle.THIN);

				WritableCellFormat cellFormat2 = new WritableCellFormat();
				cellFormat2.setBackground(jxl.format.Colour.ORANGE);
				cellFormat2.setBorder(Border.ALL , BorderLineStyle.THIN);

				int cnt = 0;
				Label label = new jxl.write.Label(0,cnt,"버전",cellFormat1);
				sheet.addCell(label);
				label = new jxl.write.Label(1,cnt,"V-ASTR-V2.0",cellFormat);
				sheet.addCell(label);
				cnt++;

				/************** 고객정보 START *************/
                sheet.mergeCells(0, cnt, 7, cnt);
                label = new jxl.write.Label(0,cnt,"고객정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int j=0; j<colArr0.length; j++ ){
                    if(j<4){
                    	label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat1);
                    }else{
                        label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                //고객정보조회
                output_1 = MDaoUtilSingle.getData("AML_20_01_10_03_getCrypto_01", input);

                for (int ii = 0; ii < output_1.getCount("RNMCNO"); ii++) {
                    for( int jj=0; jj<dataArr0.length; jj++ ){
                        label = new jxl.write.Label(jj,cnt,output_1.getText(dataArr0[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 고객정보 END *************/

                /************** 실명확인 입출금계좌 정보 START *************/
                sheet.mergeCells(0, cnt, 7, cnt);
                label = new jxl.write.Label(0,cnt,"실명확인 입출금계좌 정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int k=0; k<colArr1.length; k++ ){
                    if(k<16){
                    	label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat1);
                    }else{
                        label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                //실명확인 입출금계좌 정보
                output_2 = MDaoUtilSingle.getData("AML_20_01_10_03_getCrypto_02", input);

                if(output_2.getCount("RNMCNO") > 0) {
                    for( int ii=0; ii<dataArr1.length; ii++ ){
                         Log.logAML(Log.DEBUG, "","#################### ACCOUNT_INFORMATION #######################"+output_2.getText(dataArr1[ii],0));
                         label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr1[ii],0),cellFormat);
                         sheet.addCell(label);
                    }
                }

                cnt++;
                /************** 실명확인 입출금계좌 정보 END *************/

                /************** 조회정보 START *************/
                sheet.mergeCells(0, cnt, 4, cnt);
                label = new jxl.write.Label(0,cnt,"조회정보",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int m=0; m<colArr2.length; m++ ){
                        label = new jxl.write.Label(m,cnt,colArr2[m],cellFormat1);
                        sheet.addCell(label);
                }
                cnt++;

                output_2.add("DL_DT_A", DL_DT_A);
                output_2.add("DL_DT_B", DL_DT_B);

                //조회 정보조회
                for (int ii = 0; ii < output_2.getCount("BRN_NM"); ii++) {
                    for( int jj=0; jj<dataArr2.length; jj++ ){
                        System.out.println(output_2.getText(dataArr2[jj],ii));
                        label = new jxl.write.Label(jj,cnt,output_2.getText(dataArr2[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 조회정보 END *************/

                /************** 거래상세 START *************/
                sheet.mergeCells(0, cnt, 27, cnt);
                label = new jxl.write.Label(0,cnt,"거래상세",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int p=0; p<colArr3.length; p++ ){
                    if(p<35){
                    	label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                    }else{
                        label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                output_3 = MDaoUtilSingle.getData("AML_20_01_10_03_getCrypto_03", input);

                for (int ii = 0; ii < output_3.getCount("DL_SQ"); ii++) {
                    for( int jj=0; jj<dataArr3.length; jj++ ){
                    	if(jj==0) {//거래발생일시
                    		String GNL_AC_NO_DL_SQ = output_3.getText("GNL_AC_NO",ii) + output_3.getText("DL_SQ_VIEW",ii);
                    		label = new jxl.write.Label(jj,cnt, GNL_AC_NO_DL_SQ, cellFormat);
                    	} else {
                    		label = new jxl.write.Label(jj,cnt,output_3.getText(dataArr3[jj],ii),cellFormat);
                    	}

                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 거래상세 END *************/

                wwb.write();
                wwb.close();

                //String filePathMark = fileFullPath.replaceAll("\\\\", "/");

                long fileLen = 0;	// 파일사이즈
            	File strFile = new File(fileNameFullPath);
            	if(strFile.exists()) {
            		fileLen = strFile.length();
            	}
                Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList:File생성#############"+fileNameFullPath);

                HashMap<String, String> keyContent = new HashMap();

                keyContent.put("fileSizes", String.valueOf(fileLen));	//파일사이즈
                keyContent.put("origFileNms", fileNm);						//파일논리이름
                keyContent.put("storedFileNms", newfileNm);			//파일물리이름
                keyContent.put("filePaths", filePath);						//파일PATH

                list.add(new JSONObject(keyContent));


            }//end of for(i)

            output.put("fileContent",new JSONArray(list) );

            /* AML Page Log 등록 처리 모듈  **********************************************/
           AMLCommonLogAction amlCommonLogAction =  new AMLCommonLogAction();
           input.put("classNm", "com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03_Action");
           amlCommonLogAction.amlLogInsert(getRequest(), input);
            /* ***************************************************************************/

        }catch (RowsExceededException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IOException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IndexOutOfBoundsException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (WriteException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (Exception e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }

        return output;
    }
}
/* 2020.04.24
 * STR 3개월 거래내역 : 증권용
 * aml_config.properties : amlType 설정 필요합니다.
*  amlType : 02-STOCK
 */
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.Constants;
import com.gtone.express.server.actions.ExpressAction;

import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class AML_20_01_10_03_Stock extends ExpressAction {
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
    @Override
    public DataObj execute(HashMap input) throws Exception {
        DataObj output 		= new DataObj();
        DataObj output_0 	= new DataObj();		//계좌정보조회
        DataObj output_1 	= new DataObj();		//고객정보조회
        DataObj output_2 	= new DataObj();		//종합계좌정보, 개별계좌정보, 조회정보
        DataObj output_3 	= new DataObj();		//거래상세
        //DataObj output_file 	= new DataObj();		//혐의거래 _첨부파일
        WritableWorkbook wwb = null;

        DateFormat DL_DT_FORMAT = new SimpleDateFormat("yyyyMMdd");
        //혐의거래생성 일자 기준 3개월 거래내역
//      String DL_DT_A   = DL_DT_FORMAT.format(new java.util.Date());
        String DL_DT_A   = "";
        Calendar cal = Calendar.getInstance();

        try {
        	DL_DT_A   = input.get("SSPS_DL_CRT_DT").toString();
            cal.set(Integer.parseInt(DL_DT_A.substring(0,4)), Integer.parseInt(DL_DT_A.substring(4,6))-1, Integer.parseInt(DL_DT_A.substring(6,8)));
            cal.add(Calendar.MONTH, -3);
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Stock", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (Exception e2) {
        	Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Stock", e2.getMessage());
        	HashMap map = new HashMap();
        	map.put("ERRCODE" ,"00001");
        	map.put("ERRMSG",e2.getMessage());
        	HashMap[]  result = {map};
        	this.genOutputHash(output, result, "ERROR");
        }

        String DL_DT_B = DL_DT_FORMAT.format(cal.getTime());

        input.put("DL_DT_B", DL_DT_B);
        input.put("DL_DT_A", DL_DT_A);

        //고객정보
        String[] colArr0  = {"계좌주(사업자)명"	 ,"실명번호 구분"	     			,"계좌주(사업자)실명번호" 	,"계좌주CI번호" 		,"계좌주 국적" 		,"실명번호 구분코드"};
        String[] dataArr0 = {"CS_NM"         ,"RNM_CNFR_CCD_NM"  		,"AML_CUST_ID"            		,"CS_CI_NO"		,"NTN_CD"   	,"RNM_CNFR_CCD"};

        //계좌정보
        String[] colArr1  = {"계좌개설 금융기관"	,"개별계좌번호"	, "계좌종류(상품)"	,"계좌상품명"	,"계좌개설일자"		,"계좌개설점명" 			,"계좌관리점명"					,"계좌잔액"	  	,"계좌금융기관코드"	,"계좌종류코드"	,"개별계좌개설점코드" ,"계좌관리점코드"};
        String[] dataArr1 = {"RPR_OGN_NM"	,"GNL_AC_NO"	, "GOODS"		,"GDS_NM"	,"AC_OPN_DT"		,"OPN_BRN_CD_NM" 	,"MN_DL_DPRT_CD_NM"		,"AC_BAL"	,"TRNS_OGN_CD"	,"GDS_NO"		,"OPN_BRN_CD" 	,"MN_DL_DPRT_CD"};

        //조회정보
        String[] colArr2  =  {"조회일시" 		,"조회점명"  	,"조회시작일"  	,"조회종료일"  	,"조회점코드"};
        String[] dataArr2 =  {"RP_DT" 	,"BRN_NM" 	,"DL_DT_B" 		,"DL_DT_A" 		,"BRN_CD"};

      //거래상세
        String[] colArr3  = {"거래일련번호"			,"거래순번"				,"거래발생일시"		      	,"상대금융기관명"		        ,"상대계좌번호"		,"상대계좌주명"				,"상대계좌주실명번호"		,"상대계좌주실명구분"	 ,"상대게좌주CI번호"		,"상대계좌주국적"
					   		      ,"거래종류명"			,"거래수단명"			,"거래채널명"					,"적요"							,"거래소명"				,"매매/입고/출고종목명"		,"거래수량"					,"통화구분코드"		 ,"외환거래금액"			,"거래금액"
					   		      ,"정산금액"			    ,"수표금액"				,"유가증권명"					,"유가증권시작번호"	    	,"유가증권종료번호"	,"현금지급금융기관명"			,"현금지급영업점명"		,"유가잔고"				 ,"예수금잔고 "				,"미수금잔고"
					   		      ,"융자금/대주금"			,"취급금융기관명"		,"취급점명"						,"의심거래보고여부"	    	,"거래종류코드"		,"거래수단코드"				,"거래채널코드"			,"매매종목코드"		 ,"유가증권코드"			,"현금지급금융기관코드"
					   		      ,"현금지급영업점코드"	,"상대금융기관코드"	,"상대계좌주실명구분코드"	    ,"취급금융기관코드"	    	,"취급점코드"			,"정정구분코드"};

        String[] dataArr3 = {"GNL_SQ"					,"DL_SQ"							,"DL_DT_TM"						,"CPRTY_TRSNS_FOGN_NM"	,"CPRTY_TRSNS_AC_NO"	,"CPRTY_TRSNS_AC_NM"	,"CPRTY_TRSNS_AC_RNM_NO" 	,"CPRTY_TRSNS_AC_RNM_CNFR_CCD_NM"	,"CPRTY_TRSNS_CI_NO"	,"CPRTY_TRSNS_AC_OWN_NTN_CD"
				   		    	  ,"DL_TYP_NM" 	    		,"DL_WY_NM" 		    		,"DL_CHNNL_NM" 	 				,"SMRY_TYP_NM"			,"DL_SMRY"					,"STK_NM"		,"QTY"					,"CRNCY_CD"							,"FCRNCY_DL_AMT"	,"OUT_AMT"
				   		    	  ,"IN_AMT"						,"CHCK_AMT"					,"CHCK_KND_NM"	    			,"CHCK_STRT_NO" 		,"CHCK_END_NO"			,"CSH_ORG"		,"CSH_BRN"				,"YUGA_RA"								,"TFND_RA"				,"RCVBL_AMT_RA"
				   		    	  ,"FNCNG_AND_SL_AMT"	,"RPR_OGN_NM"				,"HANDLNG_BRN_NM"				,"DOBT_DL_RPR_YN"		,"DL_TYP_CD"				,"DL_WY_CD"	,"DL_CHNNL_CD"		,"STK_CD"								,"CHCK_KND_CD"		,"CSH_ORG_CD"
				   		    	  ,"CSH_BRN_CD"				,"CPRTY_TRSNS_OGN_CD"	,"CPRTY_TRSNS_AC_RNM_CNFR_CCD"	,"OGN_CD"		,"HANDLNG_BRN_CD"		,"GBN_CD"};

       //String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.tms");
       String filePath = Constants.COMMON_TEMP_FILE_UPLOAD_DIR;		//임시업로드 폴더

        try    {

            Log.logAML(Log.DEBUG, input, "#############doCreateFileTrList-input:#############");

            String baseFromDate 		= ((String) input.get("DL_DT_B")).replaceAll(" ", "").trim();				//거래일자(시작)	조회
			String baseToDate 			= ((String) input.get("DL_DT_A")).replaceAll(" ", "").trim();				//거래일자(종료)	조회
            String sDL_AML_CUST_ID			= ((String) input.get("DL_P_AML_CUST_ID")).replaceAll(" ", "").trim();			//실명번호
            String sSSPS_DL_CRT_DT 	= ((String) input.get("SSPS_DL_CRT_DT")).replaceAll(" ", "").trim();	//혐의거래생성일자
            String sSSPS_DL_ID 			= ((String) input.get("SSPS_DL_ID")).replaceAll(" ", "").trim();			//혐의거래ID

            input.put("SSPS_DL_CRT_DT",sSSPS_DL_CRT_DT);
            input.put("SSPS_DL_ID",sSSPS_DL_ID);
            input.put("DL_AML_CUST_ID", sDL_AML_CUST_ID);

            //계좌정보조회
            output_0 = MDaoUtilSingle.getData("AML_20_01_10_03_getExcelAccInfo", input);
            if(output_0.getCount("GNL_AC_NO") <= 0){
                output.put("ERRCODE", "00001");
                output.put("ERRMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                output.put("WINMSG", "해당 보고건의 수신계좌 거래내역이 없습니다.");
                return output;
            }

            input.put("GNL_AC_NO", output_0.getText("GNL_AC_NO"));

            String fileFullPath = filePath;

            fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));
            fileFullPath = fileFullPath.replace("\\", "/");

            File dir = new File(fileFullPath);
            if(!dir.isDirectory()){
                dir.mkdirs();
            }

            List list = new ArrayList();

            for (int i = 0; i < output_0.getCount("GNL_AC_NO"); i++) {

                String sGNL_AC_NO 	= output_0.getText("GNL_AC_NO",i);									//종합계좌번호
                String sGDS_NO 		= output_0.getText("GDS_NO",i);											//상품코드
            	String fileNm 		= sGNL_AC_NO+"_"+baseFromDate+"_"+baseToDate+"_"+sGDS_NO +".xls";		//파일논리이름(종합계좌번호_시작거래일자_종료거래일자_상품코드.xls)
                String newfileNm	= String.valueOf(System.currentTimeMillis())+".xls";				//파일물리이름(현재시각을 밀리세컨드 단위로 반환)

                input.put("GNL_AC_NO", sGNL_AC_NO);

                String fileNameFullPath = (fileFullPath + "/" +newfileNm).replace("/", System.getProperty("file.separator"));

                Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList-fileNameFullPath:#############"+fileNameFullPath);

                wwb = Workbook.createWorkbook(new File(fileNameFullPath));
                wwb.createSheet("Sheet", 0);

                WritableSheet sheet = wwb.getSheet(0);

                WritableCellFormat cellFormat = new WritableCellFormat();
                cellFormat.setBorder(Border.ALL , BorderLineStyle.THIN);

                WritableCellFormat cellFormat1 = new WritableCellFormat();
                cellFormat1.setBackground(jxl.format.Colour.YELLOW);
                cellFormat1.setBorder(Border.ALL , BorderLineStyle.THIN);

                WritableCellFormat cellFormat2 = new WritableCellFormat();
                cellFormat2.setBackground(jxl.format.Colour.ORANGE);
                cellFormat2.setBorder(Border.ALL , BorderLineStyle.THIN);

                int cnt = 0;
                Label label = new jxl.write.Label(0,cnt,"버전",cellFormat1);
                sheet.addCell(label);
                label = new jxl.write.Label(1,cnt,"S-ASTR-V2.0",cellFormat);
                sheet.addCell(label);
                cnt++;

                /************** 고객정보 START *************/
                sheet.mergeCells(0, cnt, 5, cnt);
                label = new jxl.write.Label(0,cnt,"고객정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int j=0; j<colArr0.length; j++ ){
                    if(j<6){
                    	label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat1);
                    }else{
                        label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                //고객정보조회
                output_1 = MDaoUtilSingle.getData("AML_20_01_10_03_getStockInfo_01", input);

                for (int ii = 0; ii < output_1.getCount("RNMCNO"); ii++) {
                    for( int jj=0; jj<dataArr0.length; jj++ ){
                        label = new jxl.write.Label(jj,cnt,output_1.getText(dataArr0[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 고객정보 END *************/

                /************** 계좌정보 START *************/
                sheet.mergeCells(0, cnt, 11, cnt);
                label = new jxl.write.Label(0,cnt,"계좌정보",cellFormat1);
                sheet.addCell(label);
                cnt++;

                for( int k=0; k<colArr1.length; k++ ){
                    if(k<7){
                    	label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat1);
                    }else{
                        label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

              //계좌정보, 조회정보
                output_2 = MDaoUtilSingle.getData("AML_20_01_10_03_getStockInfo_02", input);

                if(output_2.getCount("RNMCNO") > 0) {
                    for( int ii=0; ii<dataArr1.length; ii++ ){
                         Log.logAML(Log.DEBUG, "","#################### dataArr1 #######################"+output_2.getText(dataArr1[ii],0));
                         label = new jxl.write.Label(ii,cnt,output_2.getText(dataArr1[ii],0),cellFormat);
                         sheet.addCell(label);
                    }
                }

                cnt++;
                /************** 계좌정보 END *************/

                /************** 조회정보 START *************/
                sheet.mergeCells(0, cnt, 4, cnt);
                label = new jxl.write.Label(0,cnt,"조회정보",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int m=0; m<colArr2.length; m++ ){
                    label = new jxl.write.Label(m,cnt,colArr2[m],cellFormat1);
                    sheet.addCell(label);
                }
                cnt++;

                output_2.add("DL_DT_A", DL_DT_A);
                output_2.add("DL_DT_B", DL_DT_B);

                //조회 정보조회
                for (int ii = 0; ii < output_2.getCount("BRN_NM"); ii++) {
                    for( int jj=0; jj<dataArr2.length; jj++ ){
                        System.out.println(output_2.getText(dataArr2[jj],ii));
                        label = new jxl.write.Label(jj,cnt,output_2.getText(dataArr2[jj],ii),cellFormat);
                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 조회정보 END *************/

                /************** 거래상세 START *************/
                sheet.mergeCells(0, cnt, 45, cnt);
                label = new jxl.write.Label(0,cnt,"거래상세",cellFormat1);
                sheet.addCell(label);
                cnt++;
                for( int p=0; p<colArr3.length; p++ ){
                    if(p<47){
                    	label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                    }else{
                        label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat2);
                    }
                    sheet.addCell(label);
                }
                cnt++;

                output_3 = MDaoUtilSingle.getData("AML_20_01_10_03_getStockInfo_03", input);

                for (int ii = 0; ii < output_3.getCount("DL_SQ"); ii++) {
                    for( int jj=0; jj<dataArr3.length; jj++ ){
                    	if(jj==0) {//거래발생일시
                    		String GNL_AC_NO_DL_SQ = output_3.getText("GNL_AC_NO",ii) + output_3.getText("DL_SQ_VIEW",ii);
                    		label = new jxl.write.Label(jj,cnt, GNL_AC_NO_DL_SQ, cellFormat);
                    	} else {
                    		label = new jxl.write.Label(jj,cnt,output_3.getText(dataArr3[jj],ii),cellFormat);
                    	}

                        sheet.addCell(label);
                    }

                    cnt++;
                }
                /************** 거래상세 END *************/

                wwb.write();
                wwb.close();

               // String filePathMark = fileFullPath.replaceAll("\\\\", "/");

                long fileLen = 0;	// 파일사이즈
            	File strFile = new File(fileNameFullPath);
            	if(strFile.exists()) {
            		fileLen = strFile.length();
            	}
                Log.logAML(Log.DEBUG, "", "#############doCreateFileTrList:File생성#############"+fileNameFullPath);

                HashMap<String, String> keyContent = new HashMap();

                keyContent.put("fileSizes", String.valueOf(fileLen));	//파일사이즈
                keyContent.put("origFileNms", fileNm);						//파일논리이름
                keyContent.put("storedFileNms", newfileNm);			//파일물리이름
                keyContent.put("filePaths", filePath);						//파일PATH

                list.add(new JSONObject(keyContent));


            }//end of for(i)

            output.put("fileContent",new JSONArray(list) );

        }catch (RowsExceededException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (NumberFormatException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (AMLException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IOException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (IndexOutOfBoundsException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (WriteException e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }catch (Exception e) {
            Log.logAML(Log.ERROR, this, "AML_20_01_10_03_Action", e.getMessage());
            HashMap map = new HashMap();
            map.put("ERRCODE" ,"00001");
            map.put("ERRMSG",e.getMessage());
            HashMap[]  result = {map};
            this.genOutputHash(output, result, "ERROR");
        }

        return output;
    }
}
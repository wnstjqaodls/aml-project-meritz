/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;
import com.itplus.wf.def.act.WfactModel;
import com.itplus.wf.def.act.WftrsModel;
import com.itplus.wf.def.lane.WflaneModel;
import com.itplus.wf.inst.ProcessInstService;
import com.itplus.wf.internal.WfServiceException;
import com.itplus.wf.internal.dao.wfcd.WfcdDAO;
import com.itplus.wf.internal.dao.wfprocinstance.WfprocworklistDAO;
import com.itplus.wf.internal.dao.wfprocinstance.WfworkperformerDAO;
import com.itplus.wf.work.WorkItem;
import com.itplus.wf.work.WorkParam;
import com.itplus.wf.work.WorkPerformer;
import com.itplus.wf.work.WorkService;

import jspeed.base.jdbc.CacheResultSet;
import jspeed.base.log.Logger;
import jspeed.base.query.DBAssistant;
import jspeed.base.util.StringHelper;
import jspeed.websvc.WSParam;
import kr.co.itplus.jwizard.dataformat.DataSet;

/******************************************************************************************************************************************
 * @Description STR 결재 회수팝업
 *              STR 決裁
 *              STR Approval
 * @Group       GTONE, R&D센터/개발2본부
 * @Project     AML/RBA/FATCA/CRS/WLF
 * @Java        6.0 이상
 * @Author      유성진
 * @Since       2019. 2. 20.
 ******************************************************************************************************************************************
 ******************************************************************************************************************************************/

public class AML_20_01_10_08 extends GetResultObject
{
    /**************************************************************************************************************************************
     * Attributes
     **************************************************************************************************************************************/

    /** 인스턴스 */
    private static AML_20_01_10_08 instance = null;

    private Logger engineLogger;
    /**************************************************************************************************************************************
     * Methods
     **************************************************************************************************************************************/

    // [ do ]

    /**
     * STR 결재 조회<br>
     * STR 決裁照会
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(STR 결재 조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(STR決裁照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws  <code>Exception</code>
     */
    public DataObj doSearch(DataObj input)
    {
        DataObj output = new DataObj();
        DataSet gdRes = null;

        try {

        	//20180223 대직자 처리
			Object userId = ((SessionAML)input.get("SessionAML")).getOffDutyUserId();
			if (userId == null) {
				userId = ((SessionAML) input.get("SessionAML")).getSessionHelper().getUserId();
			}

			String roleId = ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();
			
			if ("4".equals(roleId)){
				roleId = "5";
			} else if ("5".equals(roleId)){
				roleId = "104";
			}
			
            String dptRole = ((SessionAML)input.get("SessionAML")).getSessionHelper().getDeptId() + "." + roleId;

			input.put("param2",dptRole);

			String RNMCNO = "";
            if(!"".equals(input.getText("RNMCNO"))){
            	RNMCNO = Util.replace(input.getText("RNMCNO"),"-","");
            	input.put("RNMCNO", RNMCNO);
            }
            
            DataObj dbOut = null;
            //LAST : 최종결재자 > 결재완료 된 상태의 것을 마지막 결재자에게로 회수함
            if("LAST".equals(input.getText("lastApp"))) {
                // 워크플로우 테이블 상 결재완료 된 
            	dbOut = MDaoUtilSingle.getData( "AML_20_01_10_08_lastAppDoSearch", input);
            }else {
            	dbOut = MDaoUtilSingle.getData( "AML_20_01_10_08_doSearch", input);
            }

            gdRes = Common.setGridData(dbOut);

            if (dbOut.getCount("SSPS_DL_CRT_DT_A")>0) {
                gdRes = Common.setGridData(dbOut);
            }
            /*
            else {
                output.put("ERRMSG",MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
            }
            */
            output.put("ERRCODE","00000");
            output.put("gdRes"  , gdRes );
        } catch(AMLException e) {
            Log.logAML(Log.ERROR, this, "doSearch", e.toString());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        }
        return output;
    }

    /**
     * STR결재 회수처리<br>
     * STR決裁差戻し処理
     * <p>
     * @param   input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *          インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *          Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     * @return  GRID_DATA(STR 결재 반려처리 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *          GRID_DATA(STR決裁差戻し処理 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *          GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     * @throws Exception
     * @throws  <code>Exception</code>
     */
    @SuppressWarnings("rawtypes")
    public DataObj withdrawProcess(DataObj input)
    {
        DataObj output = new DataObj();
        WfcdDAO dao = null;
        try {
        	dao = new WfcdDAO();
        	dao.begin();

            List gdRes = (List)input.get("gdReq");

            SessionAML sess = (SessionAML)input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inst_id, work_id, par_inst_id, roleId, ok_ccd, roleNM;

            String groupID = ((SessionAML)input.get("SessionAML")).getsAML_GROUP_ID();
        	//20180223 대직자 처리
			String userNm = null;
			if (null == sess.getOffDutyUserId() ) {
				userNm = sessHelper.getUserName();
			}else{
				userNm = sessHelper.getUserName() +"("+sess.getOffDutyUserNm()+" 대직자"+")";
			}
			
            roleId = ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();
            roleNM = ((SessionAML)input.get("SessionAML")).getsAML_ROLE_NAME();
            
            if ("4".equals(roleId)){
				roleId = "5";
			} else if ("5".equals(roleId)){
				roleId = "104";
			}
            
            // 결재 처리된 건인지 확인
            /*HashMap map = null;
            String count = "";
            String dptRole = ((SessionAML)input.get("SessionAML")).getSessionHelper().getDeptId() + "." + roleId;
            for(int i = 0; i < gdRes.size(); i++) {
                map = (HashMap)gdRes.get(i);
                map.put("dptRole", dptRole);
                if ("STR".equals(input.getText("typeCode"))) {
                    count = MDaoUtilSingle.getData("AML_20_01_10_08_getCount", map).getText("CNT");
                } else if ("CTR".equals(input.getText("typeCode"))) {
                    count = MDaoUtilSingle.getData("AML_20_02_01_03_getCount", map).getText("CNT");
                } else {
                    output.clear();
                    output.put("ERRCODE", "00001");
                    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
                    output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
                    return output;
                }
                if (!"1".equals(count)) {
                    output.clear();
                    output.put("ERRCODE", "00001");
                    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    output.put("WINMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    return output;
                }
            }*/

			BigDecimal userID= sessHelper.getUserId();
			
			HashMap<Object, Object> tempParam = new HashMap<Object, Object>();

            for(int i = 0; i < gdRes.size(); i++) {

            	HashMap map         = (HashMap)gdRes.get(i);
                keyDate     = (String)map.get("SSPS_DL_CRT_DT"  );
                keyID       = (String)map.get("SSPS_DL_ID"      );
                inst_id     = (String)map.get("INST_ID"         );
                work_id     = (String)map.get("WORK_ID"         );
                par_inst_id = (String)map.get("PAR_INST_ID");
                ok_ccd = (String)map.get("OK_CCD");

                returnsToPrev(dao.getDBAssistant(), Integer.parseInt(par_inst_id), Long.parseLong(inst_id), Long.parseLong(work_id), true,
                					Long.parseLong(groupID), Long.parseLong(roleId), userID.longValue(), userNm, sessHelper.getLoginId());


                tempParam.put("SSPS_DL_CRT_DT", keyDate);
                tempParam.put("SSPS_DL_ID", keyID);
                tempParam.put("OK_CCD", ok_ccd);
                tempParam.put("USERID" , sessHelper.getUserId());
                tempParam.put("INST_ID" , inst_id);
                tempParam.put("WORK_ID" , work_id);
                tempParam.put("MN_DL_BRN_CD"  , sess.getsAML_BDPT_CD());
                tempParam.put("RPR_PRGRS_CCD"  ,"R"); //회수 : W (테이블:C_CD_NM)
                tempParam.put("DPRT_CD"       , sessHelper.getDeptId());
                tempParam.put("DPRT_NM"       , sessHelper.getDeptName());
                tempParam.put("RPR_P_ENO"     , sessHelper.getUserId());
                tempParam.put("RPR_P_NM"      , userNm);
                tempParam.put("RPR_P_TEL_NO"  , StringHelper.nvl(sess.getsAML_TEL_NO(), "000-0000-0000") );
                tempParam.put("CNTNT"  ,roleNM +" 회수 처리 하였습니다." );
                tempParam.put("PAR_INST_ID"  , par_inst_id );

                MDaoUtilSingle.setData("AML_20_01_10_01_appStatusChange", tempParam);

                //MDaoUtilSingle.setData("AML_20_01_10_01_appHistory", tempParam);
                MDaoUtilSingle.setData("AML_20_01_10_08_addReturnHistory", tempParam);

                tempParam.clear();

            }
            	dao.commit();

	            output.put("ERRCODE", "00000");
	            output.put("ERRMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
	            output.put("WINMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
	            output.put("gdRes"  , gdRes);


        } catch(NumberFormatException e) {
      	  if(dao != null ) {
       	     dao.close();
     	  }
         Log.logAML(Log.ERROR, this, "doSave2", e);
         output.clear();
         output.put("ERRCODE", "00001");
         output.put("ERRMSG" , e.getMessage());
         output.put("WINMSG" , e.getMessage());
       }  catch(AMLException e) {
       	     if(dao != null ) {
        	   dao.close();
      	     }
          Log.logAML(Log.ERROR, this, "doSave2", e);
          output.clear();
          output.put("ERRCODE", "00001");
          output.put("ERRMSG" , e.getMessage());
          output.put("WINMSG" , e.getMessage());
        } catch(Exception e) {
        	 if(dao != null ) {
          	   dao.close();
        	 }
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        }
        finally {
       	 if(dao != null ) {
         	   dao.close();
       	     }
       }

        return output;
    }

    public Object[] returnsToPrev(DBAssistant dba, long parInstId, long instId, long workId, boolean checkPerformer, long groupId, long roleId, long userID, String userName, String loginId)
    	    throws Exception
    	  {
    	    WfprocworklistDAO dao = new WfprocworklistDAO(dba);
    	    try
    	    {
    	      WfworkperformerDAO pdao = new WfworkperformerDAO(dba);
    	      HashMap param = new HashMap();
    	     // BigDecimal instId1 = new BigDecimal(instId);
    	      param.put("INST_ID", instId);
    	      param.put("USER_ID", userID);

    	      CacheResultSet rs = dao.findLastWorkIdByInstIdUserId(param);
    	      rs.next();

    	      BigDecimal returnWorkId = rs.getBigDecimal("WORK_ID");
    	      if (returnWorkId.intValue() == 0)
    	      {
    	        throw new AMLException("NOT FOUND LAST WORK");
    	      }
    	      param.put("WORK_ID", returnWorkId);
    	      rs = dao.findByPrimaryKey(param);
    	      if (!rs.next()) {
    	    	  throw new AMLException("NOT FOUND LAST WORK");
    	      }
    	      BigDecimal prevActId = rs.getBigDecimal("ACT_ID");
    	      WfactModel actModel = ProcessInstService.getInstance().getActivity(prevActId.intValue());
    	      WftrsModel[] trs = ProcessInstService.getInstance().getTransition(actModel.getActid().intValue());
    	      HashSet regetWorkIds = new HashSet();
    	      for (int i = 0; i < trs.length; i++)
    	      {
    	    	  System.out.println("trs[i].isReturnTrueFalse() === " + trs[i].isReturnTrueFalse());
    	    	if(trs[i].isReturnTrueFalse()) {
    	    		getNextInputWorkId(dao, regetWorkIds, instId, trs[i].getTrsId().intValue());
    	    	}
    	      }
    	      Iterator it = regetWorkIds.iterator();
    	      while (it.hasNext())
    	      {
    	        param.put("WORK_ID", it.next());

    	        CacheResultSet rs1 = dao.findByPrimaryKey(param);
    	        rs1.next();
    	        if ((!("READY").equals(rs1.getString("WORK_STATUS_CD"))) && (!("ACTIVE").equals(rs1.getString("WORK_STATUS_CD"))))
    	        {
    	          throw new AMLException("ALREADY_APPROVED");
    	        }
    	        if ("SUB_PROCESS".equals(rs1.getString("APP_INVK_TP_CD")))
    	        {
    	          param.put("PROC_ID", ProcessInstService.getInstance().getActivity(rs1.getInt("ACT_ID")).getAttribute("PROC_ID"));
    	          if (pdao.hasPerformerByParIntId(param))
    	          {
    	            throw new AMLException("ALREADY_APPROVED");
    	          }
    	        }
    	        else if (!("READY").equals(rs1.getString("WORK_STATUS_CD")))
    	        {
    	          throw new AMLException("ALREADY_APPROVED");
    	        }

    	      }
			/*
			 * long userId2 = 0L; String a = "4013192443"; userId2 = Long.parseLong(a);
			 */

    	      //WorkService.getInstance().returnsTo(dba, instId, workId, prevActId.intValue(), returnWorkId.intValue(), groupId, roleId, userId.longValue(), userName, loginId, true);
    	      returnsTo(dba, instId, workId, prevActId.intValue(), returnWorkId.intValue(), groupId, roleId, userID, userName, loginId, true);
    	      return regetWorkIds.toArray();
    	    }
    	    catch (SQLException e)
    	    {
    	      this.engineLogger.println(1, this, e.getMessage(), e);
    	      throw e;
    	    }catch (WfServiceException e)
    	    {
    	      this.engineLogger.println(1, this, e.getMessage(), e);
    	      throw e;
    	    }catch (AMLException e)
    	    {
    	      this.engineLogger.println(1, this, e.getMessage(), e);
    	      throw e;
    	    }
    	  }


    protected void getNextInputWorkId(WfprocworklistDAO dao, HashSet result, long instId, int trsId) throws Exception
	{
    	try {
		HashMap param = new HashMap();
		BigDecimal nextActId = ProcessInstService.getInstance().getCreTrsModel(trsId).getNextactid();
		param.put("ACT_ID", nextActId);
		CacheResultSet	rs = dao.findLastWorkByInstAct(instId ,nextActId );
		if(rs.next())
		{
				if(rs.getInt( "WORK_ID")==0) {
					return;
				}
				if("N".equals(ProcessInstService.getInstance().getActivity(nextActId.intValue()).getActconf().getAppautoyn()))
				{
					result.add( rs.getBigDecimal("WORK_ID"));
				}
				else
				{
					param.put("WORK_ID", rs.getBigDecimal("WORK_ID"));
					WftrsModel[] trsIds = ProcessInstService.getInstance().getTransition(nextActId.intValue());
					for( int i=0; i  <trsIds.length; i++)
					{
					getNextInputWorkId(dao,result, instId, trsIds[i].getTrsId().intValue());
					}
				}

			}
    	}
		catch (SQLException e)
	    {
	      this.engineLogger.println(1, this, e.getMessage(), e);
	      throw e;
	    }catch (WfServiceException e)
	    {
	      this.engineLogger.println(1, this, e.getMessage(), e);
	      throw e;
	    }

		}
    /**
     * 인스턴스 반환.
     * <p>
     * @return  <code>AML_20_01_10_08</code>
     */
    public static AML_20_01_10_08 getInstance() {
    	return instance == null ? (instance = new AML_20_01_10_08()) : instance;
    }

    @SuppressWarnings("rawtypes")
    public DataObj lastAppWithdrawProcess(DataObj input) throws AMLException
    {
        DataObj output = new DataObj();
        MDaoUtil dao = new MDaoUtil();

        try {

        	dao.begin();

            List gdRes = (List)input.get("gdReq");

            SessionAML sess = (SessionAML)input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            String keyDate, keyID, inst_id, RPR_PRGRS_STATUS, RPR_PRGRS_CCD;
            
            // 결재 처리된 건인지 확인
            HashMap map = null;
            String count = "";
            for(int i = 0; i < gdRes.size(); i++) {
                map = (HashMap)gdRes.get(i);
                count = MDaoUtilSingle.getData("AML_20_01_10_08_lastApp_getCount", map).getText("CNT");
                if (!"1".equals(count)) {
                    output.clear();
                    output.put("ERRCODE", "00001");
                    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    output.put("WINMSG", MessageHelper.getInstance().getMessage("0100", input.getText("LANG_CD"), "이미 처리된 결재 건입니다."));
                    return output;
                }
                
            }

			RPR_PRGRS_STATUS = "2";

			DataObj tempParam = new DataObj();
			DataObj inObj = new DataObj();
			DataObj beforWorkID = null, afterWorkID= null;
			DataObj workObj = new DataObj();

            for(int i = 0; i < gdRes.size(); i++) {

            	map         = (HashMap)gdRes.get(i);
            	keyDate     = (String)map.get("SSPS_DL_CRT_DT");
                keyID       = (String)map.get("SSPS_DL_ID");
                inst_id     = (String)map.get("INST_ID");
                RPR_PRGRS_CCD = (String)map.get("RPR_PRGRS_CCD");
                inObj.put("INST_ID", inst_id);

                /*결재 WORK_ID 조회하기 > MAX(WORK_ID),MAX(WORK_ID)-1 이전 WORK_ID*/
                beforWorkID     = dao.getData("AML_20_01_10_08_beforWorkIDSearch", inObj);
                afterWorkID  = dao.getData("AML_20_01_10_08_afterWorkIDSearch", inObj);

                /*최종결재에서 바로전 단계로 돌리기*/
                dao.setData("AML_20_01_10_08_deleteWfWorkList", afterWorkID);
                dao.setData("AML_20_01_10_08_updateWfWorkList", beforWorkID);
                dao.setData("AML_20_01_10_08_deleteWfWorkPerformer", beforWorkID);

                workObj.put("INST_ID", inst_id);
                workObj.put("WORK_ID", beforWorkID.get("WORK_ID"));
                workObj.put("USERID", sessHelper.getUserId());
                dao.setData("AML_20_01_10_08_updateWfProcInstance", workObj);
                dao.setData("AML_20_01_10_08_deleteNIC66BW", workObj);
                /*최종결재에서 바로전 단계로 돌리기*/

                /*NIC66B >  회수 상태값 업데이트 로직 */
                tempParam.put("SSPS_DL_CRT_DT", keyDate);
                tempParam.put("SSPS_DL_ID", keyID);
                tempParam.put("USERID" , sessHelper.getUserId());
                tempParam.put("RPR_PRGRS_STATUS" , RPR_PRGRS_STATUS);
                dao.setData("AML_20_01_10_01_lastAppStatusChange", tempParam);
                /*NIC66B >  회수 상태값 업데이트 로직 */

                /*STR 파일 생성 > 파일 생성된 데이터 지우기 */
                if("97".equals(RPR_PRGRS_CCD) || "98".equals(RPR_PRGRS_CCD) || "99".equals(RPR_PRGRS_CCD)) {
                	dao.setData("AML_20_01_10_01_deleteNIC80B", tempParam);
                }
                /*STR 파일 생성 > 파일 생성된 데이터 지우기 */

                inObj.clear();
                beforWorkID.clear();
                afterWorkID.clear();
                workObj.clear();
                tempParam.clear();

            }
            	dao.commit();

	            output.put("ERRCODE", "00000");
	            output.put("ERRMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
	            output.put("WINMSG" , MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
	            output.put("gdRes"  , gdRes);


        } catch(NumberFormatException e) {
      	  if(dao != null ) {
       	     dao.close();
     	  }
         Log.logAML(Log.ERROR, this, "doSave2", e);
         output.clear();
         output.put("ERRCODE", "00001");
         output.put("ERRMSG" , e.getMessage());
         output.put("WINMSG" , e.getMessage());
       }  catch(AMLException e) {
       	     if(dao != null ) {
        	   dao.close();
      	     }
          Log.logAML(Log.ERROR, this, "doSave2", e);
          output.clear();
          output.put("ERRCODE", "00001");
          output.put("ERRMSG" , e.getMessage());
          output.put("WINMSG" , e.getMessage());
        } catch(Exception e) {
        	 if(dao != null ) {
          	   dao.close();
        	 }
            Log.logAML(Log.ERROR, this, "doSave2", e);
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG" , e.getMessage());
            output.put("WINMSG" , e.getMessage());
        }
        finally {
        	 if(dao != null ) {
          	   dao.close();
        	     }
        }

        return output;
    }

    public void returnsTo(jspeed.base.query.DBAssistant dba , long instId, long workId, long returnedActId, long returnWorkId, long groupId,  long roleId, long userId, String userName, String loginId, boolean isReturnAllParticipants) throws Exception
	{
		HashMap param = new HashMap();
		param.put("WORK_ID", "" + workId);
		param.put("RETURNED_ACT_ID", "" + returnedActId);
		param.put("RETURNED_WORK_ID", "" + returnWorkId);
		param.put("GROUP_ID", "" + groupId);
		param.put("ROLE_ID", "" + roleId);
		param.put("INST_ID", "" + instId);
		param.put("USER_ID", "" + userId);
		param.put("USER_NM", userName);
		param.put("LOGIN_USER_ID", loginId);
		param.put("__IS_RETURN_ALL_PARTICIPANTS__", isReturnAllParticipants?"Y":"N");

		returnsTo(dba, param, jspeed.base.util.DateHelper.format(new java.util.Date(), "yyyyMMddHHmmss"));
	}

    public void returnsTo(jspeed.base.query.DBAssistant dba , java.util.HashMap param, String currentDate) throws Exception
	{
		WSParam wsParam = new WSParam(param);
		WorkParam workReq= new WorkParam(wsParam);
		returnsTo(dba, workReq, currentDate);
	}

    public void returnsTo(jspeed.base.query.DBAssistant dba , WorkParam workReq, String currentDate) throws Exception
	{

		long userId=-1L;
		String loginId = null;
		String userName = null;
		try
		{
			userId = workReq.getUserId();
			loginId = workReq.getLoginId();
			userName=workReq.getUserName();
		}
		catch(NumberFormatException e)
		{
	        Log.logAML(Log.ERROR, this, "returnsTo", "NumberFormatException: " + e.getMessage());
			userId = Long.parseLong(workReq.getWSParam().getParameter("USER_ID"));
			loginId = workReq.getWSParam().getParameter("LOGIN_ID");
			userName = workReq.getWSParam().getParameter("USER_NAME");
		}
		catch(Exception e)
		{
			userId = Long.parseLong(workReq.getWSParam().getParameter("USER_ID"));
			loginId = workReq.getWSParam().getParameter("LOGIN_ID");
			userName = workReq.getWSParam().getParameter("USER_NAME");
		}
		WorkService.getInstance().clearSub(dba, workReq.getWSParam().toOneParameterMap(),currentDate );
		WfprocworklistDAO workDao = new WfprocworklistDAO(dba);
		HashMap pk = new HashMap();
		pk.put("WORK_ID", new BigDecimal(workReq.getWorkId()));
		CacheResultSet workRs = workDao.findByPrimaryKey(pk);
		if(!workRs.next()) { throw new AMLException("WORK_LIST data not found"); }
		WflaneModel laneModel = ProcessInstService.getInstance().getLane(workRs.getInt("LANE_ID"));
		WorkService.getInstance().updateWork(dba, workReq.getWorkId(),laneModel==null?true: laneModel.isPerson(),
				workReq.getGroupId(), workReq.getGroupName(),
				workReq.getRoleId(), workReq.getRoleName(),
				workReq.getWFGroupId(), userId, userName,
				loginId, "RETURNED",
				currentDate, workRs.getInt("ACT_ID"));
		workReq.setPrevWorkId(workReq.getWorkId());
		int nextWorkId = WorkService.getInstance().getWorkListSeq();
		WorkItem workItem = WorkService.getInstance().getProcWork().getWorkItemByWorkId(workReq.getReturnedWorkId());
		int nextActId = workItem.getActId().intValue();

		// engineLogger.println(" WFEngine.executeTransition() :: NEXT
		// ACTIVITY ACT_ID["+nextActId+"]");

		// 다음 ACTIVITY Model을 가져온다.
		WfactModel nextActModel = ProcessInstService.getInstance().getActivity(nextActId);



		System.out.println("    WFEngine.executeWorkFlow() :: RETURNED ACTIVITY  SETTING !!["+ nextActModel.getActname()
									+ " ACT_ID="+ nextActModel.getActid()
									+ " WORK_ID="+ nextWorkId+ "]");
		workReq.setNextActModel(nextActModel);
		// 다음 ACTIVITY Model을 가져온다.
		// WfactModel nextActModel =
		// ProcessInstService.getInstance().getActivity(trsModel.getNextactid().intValue());
								// PARTICIPANT를 가져온다.
		/*engineLogger
				.println("    WFEngine.setNextWork() ::  PREVIOUS PERFORMER YN["
						+ trsModel.getPrevperformeryn()
						+ "] PARTICIPANT ALL YN["
						+ trsModel.getParticipantallyn() + "]");
		*/
		ArrayList participant_id_list = new ArrayList();
		if(workReq.isReturnAllParticipants())
		{
			WorkPerformer[] workPerformers = WorkService.getInstance().findWorkPerformerByWorkId(workReq.getReturnedWorkId());

			for(int i=0; i< workPerformers.length; i++){
				if("FINISHED".equals(workPerformers[i].getWorkStatusCd())){
					if (!participant_id_list.contains(workPerformers[i].getPerformerId())) {
						participant_id_list.add(workPerformers[i].getPerformerId());
					}
				}
			}
		}
		else
		{
			if(!"WAITING".equals(workItem.getAppInvkTpCd())){
				/*participant_id_list=ProcessInstService.getInstance().getLaneDef().getParticipants(dba,ProcessInstService.getInstance().getLane(
									workReq.getNextActModel().getProclaneid().intValue()), workReq.request);*/
				participant_id_list=ProcessInstService.getInstance().getLaneDef().getParticipants(ProcessInstService.getInstance().getLane(
						workReq.getNextActModel().getProclaneid().intValue()), workReq.getWSParam());
			}
		}
		workReq.setNextParticipants(participant_id_list);


		System.out.println("    WFEngine.executeWorkFlow() ::  RETURNED ACTITIVY PARTICIPANT_ID LIST[" + participant_id_list + "]");
		if ((participant_id_list == null || participant_id_list.size() == 0) && !"WAITING".equals(workItem.getAppInvkTpCd())) {
			String  langType=jspeed.base.property.PropertyService.getInstance().getProperty("jspeed.properties","default.LangType", "ko-KR");

			throw  new AMLException(com.itplus.wf.def.CodeHandler.getInstance().getCodeValue("MSG","10000", langType ));
		} else {

			//TO-DO : cre_trs_id가 없을 경우 확인할 것
			WorkService.getInstance().createWork(dba, nextWorkId,
						nextActModel.getActid().intValue(),
						workItem.getCreTrsId().intValue(),
						nextActModel.getProclaneid().intValue(),
						workItem.getInstId().intValue(), workItem.getProcId().intValue(),
						workItem.getProcVerId().intValue(), workReq.getGroupId(),
						workReq.getGroupName(), workReq.getRoleId(),
						workReq.getRoleName(),  userId,
						userName, loginId,
						participant_id_list, "READY",
						nextActModel.getActconf().getActinvktpcd(), "", false,   workReq.getPrevWorkId());
 		}


		workReq.getWSParam().setParameter("INST_CLASS_CD", "INST_WORK");
			// wsParam.getRequest().setAttribute("INST_CLASS_CD","INST_WORK");
		workReq.setInstClassCd("INST_WORK");

		/**
		 * @TODO CHECK
		 * ACT_ID 업데이트 추가
		 * WORK_ID 업데이트 추가
		 * INST_ID가 완료가 아니면 INST_FINISHED_DT를 넣지 않는다
		 */
		ProcessInstService.getInstance().updateProcInst(dba,
				workReq.getInstId(),
				nextActId ,
				nextWorkId,
				"RETURNED",
				userId, "");
	}
}

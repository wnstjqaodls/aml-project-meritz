package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.gtone.aml.basic.common.log.Log;
import com.gtone.express.server.config.ServerConfig;

/**
*<pre>
* AI 예측 위험도
*</pre>
*/
public class AMLAISTROpinion {

    private Socket socket = null;
    private DataInputStream din = null;
    private PrintStream pout = null;

    public void send(String msg) throws IOException {
    	byte [] data = msg.getBytes();
    	ByteBuffer b = ByteBuffer.allocate(4); //데이터 크기
    	b.order(ByteOrder.LITTLE_ENDIAN);
    	b.putInt(data.length);
    	pout.write(b.array(), 0, 4);
    	pout.print(msg);
    	pout.flush();
    }

    public String recv() throws IOException {

    	byte[] data = new byte[4];
		din.read(data, 0, 4);
		ByteBuffer b = ByteBuffer.allocate(4);

		b = ByteBuffer.wrap(data);
		b.order(ByteOrder.LITTLE_ENDIAN);
		int length = b.getInt();

		data = new byte[length];

		din.read(data, 0, length);

		String reply = new String(data, "UTF-8");

    	return reply;
    }

    public String toLLM(String dl, String df) throws IOException {
    	String toPy = dl + df;
    	String res = "";
    	String socketIP = ServerConfig.getInstance().getProperty("toLLM_Socket_IP");
    	int socketPort = Integer.parseInt(ServerConfig.getInstance().getProperty("toLLM_Socket_Port"));

    	if (this.socket == null) {
    	    this.socket = new Socket(socketIP, socketPort);
    	}

    	if (this.din == null) {
    	    this.din = new DataInputStream(socket.getInputStream());
    	}

    	if (this.pout == null) {
    	    this.pout = new PrintStream(socket.getOutputStream());
    	}

    	try {
    		send(toPy);

    		res = recv();

    	} catch (IOException e) {
            Log.logAML(Log.ERROR, this, "Communication Error", e.getMessage());
        } catch (Exception e) {
			Log.logAML(Log.ERROR, e.getMessage());
    	} finally {
    	    if (this.socket != null) {
    	        try {
    	            this.socket.close();
    	        } catch (IOException e) {
    	            Log.logAML(Log.ERROR, this, "Connection Error", e.getMessage());
    	        }
    	    }
    	    if (this.din != null) {
    	        try {
    	            this.din.close();
    	        } catch (IOException e) {
    	            Log.logAML(Log.ERROR, this, "Connection Error", e.getMessage());
    	        }
    	    }
    	    if (this.pout != null) {
    	        try {
    	            this.pout.close();
    	        } catch (Exception e) {
    	            Log.logAML(Log.ERROR, this, "Connection Error", e.getMessage());
    	        }
    	    }
        }
    	return res;
    }
}

/*
 * Copyright (c) 2008-2017 GTONE. All rights reserved.
 *
 * This software is the confidential and proprietary information of GTONE. You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered into with GTONE.
 */
package com.gtone.aml.server.AML_20.AML_20_07.AML_20_07_01;

import jspeed.base.property.PropertyService;
import jspeed.base.util.StringHelper;
import kr.co.itplus.jwizard.dataformat.DataSet;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.express.server.helper.MessageHelper;

/**
*<pre>
* 기간별 거래정보 Download
* 期間別取引情報  Download
* Transaction Info.- Period  Download
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_07_01_02 extends GetResultObject {

    private static AML_20_07_01_02 instance = null;
 
    /**
     * getInstance
     * @return AML_20_07_01_02
     */
    public static AML_20_07_01_02 getInstance() {
        if (instance == null) {
            instance = new AML_20_07_01_02();
        }
        return instance;   
    }
    
    /**
     * <pre>
     *   기간별 거래정보 계좌 조회
     * 期間別取引情報_口座照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(기간별 거래정보 계좌 조회 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(期間別取引情報_口座照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */        
    public DataObj doSearch(DataObj input) { 
        DataObj output = new DataObj();
        DataSet gdRes = null;         
        try {

            DataObj dbOut = MDaoUtilSingle.getData("AML_20_07_01_02_getSearch"
                    , new Object[]{input.getText("GNL_AC_NO")
                            , input.getText("GDS_NO")
                            , Util.replace(input.getText("fromDate"), "-", "")
                            , Util.replace(input.getText("toDate"), "-", "")}
                    );
            
            gdRes = Common.setGridData(output);
            
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", dbOut.getCount("GNL_AC_NO") > 0 ? MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다.") : MessageHelper.getInstance().getMessage("0039",input.getText("LANG_CD"),"자료가 존재하지 않습니다."));
            output.put("gdRes", gdRes);
        } catch(Exception e) {
            Log.logAML(Log.ERROR, this, "doSearch", e.getMessage());
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }

        return output;
    }

    /**
     * <pre>
     *   기간별 거래정보 엑셀파일 타이틀 조회
     * 期間別取引情報のExcelファイルタイトルの照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(엑셀파일 타이틀 조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(Excelファイルタイトルの照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */        
    public DataObj AML_20_07_01_02_getExcelTitle(DataObj input) {
        DataObj output = new DataObj();
        try {
 
            String query_id = "";
            Object[] objs = new Object[] {};
            @SuppressWarnings("unused")
            DataObj dbOut;
        
            query_id = "AML_20_07_01_02_getExcelTitle_New_2020";
            
            output = MDaoUtilSingle.getData(query_id, input);

        
        } catch (Exception e) {
            output.clear();
            output.put("ERRCODE", "00001"); 
            output.put("ERRMSG", e.toString());
        }
        return output;
    }
       
    /**
     * <pre>
     *   계좌별 기간 거래정보  조회
     * 口座別期間取引情報の照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(계좌별 기간 거래정보  조회 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(期間別取引情報のExcelファイルタイトルの照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */    
    public DataObj AML_20_07_01_02_getDataRow(DataObj input) {
        DataObj output = new DataObj();
        try {
 
            String query_id = "";
            Object[] objs = new Object[] {};
            @SuppressWarnings("unused")
            DataObj dbOut;
            String moneyType = StringHelper.nvl(PropertyService.getInstance().getProperty("aml.config","MoneyType"),"KRW");
            query_id = "AML_20_07_01_02_getDataRow_New_2020";
            
            input.put("moneyType",moneyType);
            output = MDaoUtilSingle.getData(query_id, input);

        
        } catch (Exception e) {
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.toString());
        }
        return output;
    }
    /**
     * <pre>
     *   기간별 거래정보 엑셀파일 타이틀 조회
     * 期間別取引情報のExcelファイルタイトルの照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(엑셀파일 타이틀 조회 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(Excelファイルタイトルの照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */        
    public DataObj AML_20_07_01_02_getExcelTitle_New(DataObj input) {
        DataObj output = new DataObj();
        try {
 
            String query_id = "";
            Object[] objs = new Object[] {};
            @SuppressWarnings("unused")
            DataObj dbOut;
        
            query_id = "AML_20_07_01_02_getExcelTitle_New";
            
            objs = new Object[] { input.getText("GNL_AC_NO"),
                    input.getText("GDS_NO")};
            
            output = MDaoUtilSingle.getData(query_id, objs);

        
        } catch (Exception e) {
            output.clear();
            output.put("ERRCODE", "00001"); 
            output.put("ERRMSG", e.toString());
        }
        return output;
    }
       
    /**
     * <pre>
     *   계좌별 기간 거래정보  조회
     * 口座別期間取引情報の照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(계좌별 기간 거래정보  조회 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(期間別取引情報のExcelファイルタイトルの照会 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */    
    public DataObj AML_20_07_01_02_getDataRow_New(DataObj input) {
        DataObj output = new DataObj();
        try {
 
            String query_id = "";
            Object[] objs = new Object[] {};
            @SuppressWarnings("unused")
            DataObj dbOut;
            String moneyType = StringHelper.nvl(PropertyService.getInstance().getProperty("aml.config","MoneyType"),"KRW");
            query_id = "AML_20_07_01_02_getDataRow_New";
            
            objs = new Object[] {     moneyType,
                                    input.getText("GNL_AC_NO"),
                                    input.getText("GDS_NO"),
                                    input.getText("FROMDATE"),
                                    input.getText("TODATE")};
            
            output = MDaoUtilSingle.getData(query_id, objs);

        
        } catch (Exception e) {
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.toString());
        }
        return output;
    }    
}

package com.gtone.aml.server.AML_20.AML_20_07.AML_20_07_01;

import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.AML.AML_20.AML_20_07.AML_20_07_01.AML_20_07_01_01_DAO;
import com.gtone.express.server.helper.MessageHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* 기간별 거래정보
* 期間別取引情報
* Transaction Info.- Period
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_07_01_01 extends GetResultObject {

	private static AML_20_07_01_01 instance = null;

	/**
	 * getInstance
	 * @return AML_20_07_01_01
	 */
	public static AML_20_07_01_01 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_07_01_01();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   기간별 거래정보 계좌 조회
	 * 期間別取引情報_口座照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(기간별 거래정보 계좌 조회 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(期間別取引情報_口座照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj getSearch_StrMain(DataObj input) {

		DataObj output = new DataObj();
		DataObj output_01 = null;
		DataSet gdRes = null;

		try {

			// STR Main Grid Row
			output_01 = new AML_20_07_01_01_DAO().getSearch_StrMain(input);

			gdRes = Common.setGridData(output_01);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (RuntimeException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *   계좌별 기간 거래정보  조회
	 * 口座別期間取引情報_口座照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(계좌별 기간 거래정보  조회 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(口座別期間取引情報一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj getSearch_StrSub(DataObj input) {

		DataObj output = new DataObj();
		DataObj output_01 = null;
		DataSet gdRes = null;

		try {

			// STR Main Grid Row
			output_01 = new AML_20_07_01_01_DAO().getSearch_StrSub(input);

			gdRes = Common.setGridData(output_01);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (RuntimeException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}
}

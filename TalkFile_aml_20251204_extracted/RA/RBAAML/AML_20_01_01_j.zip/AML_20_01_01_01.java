package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.DateUtil;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.AML.AML_20.AML_20_01.AML_20_01_01.AML_20_01_01_01_DAO;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_10.AML_20_01_10_03_Action;
import com.gtone.aml.server.AML_20.AML_20_02.AML_20_02_03.AML_20_02_03_01;
import com.gtone.aml.server.common.TmsDefine;
import com.gtone.aml.server.config.SiteServerConfig;
import com.gtone.aml.user.SessionAML;
import com.gtone.aml.util.SEED;
import com.gtone.aml.xmlExporter.str.StrJDomXmlExporter;
import com.gtone.express.Constants;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import jspeed.base.util.StringHelper;
import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* STR 파일생성
* STR ファイル生成
* STR Create
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_01_01_01 extends GetResultObject {

	private static AML_20_01_01_01 instance = null;

	/**
	 * getInstance
	 * @return AML_20_01_01_01
	 */
	public static AML_20_01_01_01 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_01_01_01();
		}
		return instance;
	}

	/**
	 * <pre>
	 *  STR 파일생성 조회
	 * STRファイル生成照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(STR 파일생성 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(STRファイル生成照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj getSearch(DataObj input) {

		DataObj output = new DataObj();
		DataObj output_01 = null;

		DataSet gdRes = null;

		try {


			output_01 = new AML_20_01_01_01_DAO().getSearch(input);

			if ( output_01.getCount("SSPS_DL_ID") > 0 ) {
				gdRes = Common.setGridData(output_01);
			}
			/*
			else {
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
				// output.put("WINMSG" ,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다."));
			}
			*/
			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (RuntimeException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *  STR 파일생성
	 * STRファイル生成
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(STR 파일생성 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(STRファイル生成 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj doWorkFlowProcess(DataObj input) {

		DataObj output = new DataObj();

		String gubun = input.getText("gubun"); // 9 - File Creation
		SessionHelper helper = (SessionHelper) input.get("SessionHelper");
		String login_id = helper.getUserId().toString();
		MDaoUtil db = null;

		try {
			// [0] Make ExcelAttachFile (엑셀파일 생성)
			AML_20_01_10_03_Action excelfileattach = new AML_20_01_10_03_Action();
			excelfileattach.execute(input);

			// gubun [9] File Creation
			if ( "9".equals(gubun) ) {

				//List gdReq = (List) input.get("gdReq");
				//int rowCnt = gdReq.size();

				/*2019.11.01
				STR File생성 시 채번 오류에 대한 처리 :  한건씩 채번은 문제가 없으나
				 2건이상 채번일 경우 = 2 * 2 = 4개가 채번이 되며 앞에 2개를 쓰고 뒤에 2개를 버려지는 현상
				 for ( int i = 0; i < rowCnt; i++ ) {

					HashMap map = (HashMap) gdReq.get(i);

					if ( "".equals(map.get("DOC_NO_TMP")) ) {
						// [1] Document Number
						doDocumentNum(input);
					}
				}*/

				//2019.11.01
				//STR File생성 시 채번 오류에 대한 처리 :  한건씩 채번은 문제가 없으나
				// 2건이상 채번일 경우 = 2 * 2 = 4개가 채번이 되며 앞에 2개를 쓰고 뒤에 2개를 버려지는 현상
				// [1] Document Number
				doDocumentNum(input);

				// [2] XML File Creation
				doExportXML(input);

				output.put("objInput", input);
				output.put("ERRCODE", "00000");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

				// gubun [99] XML File Regeneration
			} else if ( "99".equals(gubun) ) {

				// [2] XML File Creation
				doExportXML(input);

				output.put("ERRCODE", "00000");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

			} else if ( "10".equals(gubun) ) { // 2015.05.06 ksy 보고완료 기능 추가
				db = new MDaoUtil();
				db.begin();
				String toDay = DateUtil.getDate();
				List gdReq = (List) input.get("gdReq");
				int rowCnt = gdReq.size();

				for ( int i = 0; i < rowCnt; i++ ) {

					HashMap map = (HashMap) gdReq.get(i);
					map.put("RPR_PRGRS_CCD", gubun);
					map.put("LOGIN_ID", login_id);
					map.put("RPR_COMPLITE_DT", toDay);
					db.setData("AML_20_02_02_01_doRprtComplete", map);
				}

				output.put("ERRCODE", "00000");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

				db.commit();
			}

			else {
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0050", input.getText("LANG_CD"), "처리구분코드가 없습니다."));
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0050", input.getText("LANG_CD"), "처리구분코드가 없습니다."));
			}

		} catch (AMLException e) {
			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (AMLException ee) {
				Log.logAML(Log.ERROR, this, "doWorkFlowProcess", e.getMessage());
			}

			Log.logAML(Log.ERROR, this, "doWorkFlowProcess", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} catch (Exception e) {
			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (AMLException ee) {
				Log.logAML(Log.ERROR, this, "doWorkFlowProcess", e.getMessage());
			}

			Log.logAML(Log.ERROR, this, "doWorkFlowProcess", e.getMessage());

			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));// PHH 2009.03.02 다국어
		} finally {
			try {
				if ( db != null ) {
					db.close();
				}
			} catch (Exception ee) {
			}
		}

		return output;
	}

	/**
	 * <pre>
	 *  문서번호 부여
	 * 文書番号付与
	 * @en
	 * </pre>
	 *@param input 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values ,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(문서번호 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(文書番号 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public DataObj doDocumentNum(DataObj input) {
		DataObj output = new DataObj();
		DataObj outputTemp = new DataObj();
		MDaoUtil db = null;

		SessionHelper helper = (SessionHelper) input.get("SessionHelper");

		String baseYYYY = null;
		int baseDocNum = 0;

		try {
			baseYYYY = Util.nvlTrim(SiteServerConfig.getInstance().getCustomerDocbase_YYYY(), "");
			baseDocNum = Integer.parseInt(Util.nvlTrim(SiteServerConfig.getInstance().getCustomerDocbase_SN(), "0"));

			List gdReq = (List) input.get("gdReq");
			int rowCnt = gdReq.size();

			DataObj bogoObj = AML_20_02_03_01.getInstance().getBogoInfo();

			String TRNS_OGN_CD = bogoObj.getText("TRNS_OGN_CD"); // TRNS_OGN_CD
			String RPR_OGN_NM = bogoObj.getText("RPR_OGN_NM"); // RPR_OGN_NM
			String RPR_RSPSB_P_ENO = bogoObj.getText("RPR_RSPSB_P_ENO"); // RPR_RSPSB_P_ENO
			String RPR_RSPSB_P_NM = bogoObj.getText("RPR_RSPSB_P_NM"); // RPR_RSPSB_P_NM
			String RPR_CHRG_P_ENO = bogoObj.getText("RPR_CHRG_P_ENO"); // RPR_CHRG_P_ENO
			String RPR_CHRG_P_NM = bogoObj.getText("RPR_CHRG_P_NM"); // RPR_CHRG_P_NM
			String RPR_CHRG_P_TEL_NO = bogoObj.getText("RPR_CHRG_P_TEL_NO"); // RPR_CHRG_P_TEL_NO

			String RPR_DT = Util.toDay("yyyyMMdd"); // Reporting Date
			String RPR_YR = Util.toDay("yyyy"); // Reporting YY
			String RPR_YM = Util.toDay("yyyyMM"); // Reporting MM

			DataObj inputDoc = new DataObj();

			db = new MDaoUtil();
			db.begin();

			String keyYear = "";
			String insert_YY = "";
			//StringBuffer sqlsb = new StringBuffer ();
			//StringBuffer sqlsb2 = new StringBuffer ();
			int DocNum = 0;
			int ins_Master_Num = 0, ins_Doc_Num = 0;
			String prev_SSPS_DL_CRT_DT = null; // Date of previous report

			//ArrayList<Object> arrList = new ArrayList<>();
			//Object[] obj = new Object[15];

			 HashMap inputParam = null;

			 for (int i = 0; i < rowCnt; i++) {

	                HashMap map = (HashMap)gdReq.get(i);

	                if( "1".equals(map.get("OK_CCD").toString()) ) { //보고인건만

	                	inputParam = new HashMap();

	                	//if(map.get("DOC_NO").toString().equals("")) {

	                		if(prev_SSPS_DL_CRT_DT == null){

	                			inputDoc.set("CTR_STR_CCD", TmsDefine.Cmd_SSPS_DL_RPR_CCD_STR);
	                			inputDoc.set("RPR_YR", RPR_YR);
	                			inputDoc.set("RPR_YM", RPR_YM);

	                			outputTemp = MDaoUtilSingle.getData("AML_20_01_01_01_NIC110B_getMaxDocNo", inputDoc);
	                			DocNum = Integer.parseInt(outputTemp.getText("DOC_NO"));
	                        }

	                        // DATA CHECK
	                		inputParam.clear();
	                		inputParam.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT").toString());
	                		inputParam.put("SSPS_DL_ID", map.get("SSPS_DL_ID").toString() );

	                        DataObj dbOut = db.getData("AML_20_01_01_01_NIC80B_chkSelect", inputParam);

	                        if("0".equals(dbOut.getText("CNT"))) {

	                        	inputParam.clear();
	                        	inputParam.put("CTR_STR_CCD", TmsDefine.Cmd_SSPS_DL_RPR_CCD_STR );
		                		inputParam.put("RPR_YR", RPR_YR );
		                		inputParam.put("RPR_DT", RPR_DT );
		                		inputParam.put("IT_CHRG_P_CNFR_ENO", RPR_RSPSB_P_ENO );
		                		inputParam.put("IT_CHRG_P_CNFR_P_NM", RPR_RSPSB_P_NM );
		                		inputParam.put("RPR_OGN_CD", TRNS_OGN_CD ); // TRNS_OGN_CD
		                		inputParam.put("SND_RCPT_DOC_NO", TRNS_OGN_CD+RPR_YM+String.format("%05d", DocNum) ); //  Report number :  Organization Code(4) + YYYYMM(6) + Sequence(5)
		                		inputParam.put("HNDL_P_ENO", helper.getUserId().toString()  );
		                		inputParam.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT").toString() );
		                		inputParam.put("SSPS_DL_ID", map.get("SSPS_DL_ID").toString() );
		                		inputParam.put("TRSMT_ST_CD", "1" ); //  Transfer Status : '1'. Standby , '2'. Generating, '3'. Complete, '9'. ERROR
		                		inputParam.put("SND_RSLT_CD", "S" ); //  Send results
		                		inputParam.put("SND_RCPT_CCD", "01" ); //  Send code( 01 Normal\ 03 Report Cancel (SND_RCPT_CCD)
		                		inputParam.put("SND_RCPT_FILE_NM", "STR_"+TRNS_OGN_CD+"_"+RPR_DT+"_"+String.format("%07d", DocNum)+".xml" ); //STR_기관코드_문서생성일자_일련번호(STR_AA0001_20201001_0000001.xml)

		                		if( db.setData("AML_20_01_01_01_NIC80B_IT_CHK_INSERT", inputParam) != 1){

		                			throw new AMLException("NIC80B(혐의거래일별보고정보) insert error. \n >> 전송정보가 저장되지 못했습니다..");
		                		}

	                        }else{

	                        	inputParam.clear();
		                		inputParam.put("RPR_OGN_CD", TRNS_OGN_CD );
		                		inputParam.put("RPR_OGN_NM", RPR_OGN_NM );
		                		inputParam.put("RPR_RSPSB_P_NM", RPR_RSPSB_P_NM );
		                		inputParam.put("RPR_CHRG_P_NM", RPR_CHRG_P_NM );
		                		inputParam.put("RPR_CHRG_P_TEL_NO", RPR_CHRG_P_TEL_NO );
		                		//inputParam.put("RPR_CHRG_P_CNFR_RCG_ST_CD", TmsDefine.Ctr_RPR_PRGRS_CCD_AC03_9 );
		                		inputParam.put("RPR_CHRG_P_CNFR_RCG_ST_CD", "2");
		                		inputParam.put("RPR_CHRG_P_ENO", RPR_CHRG_P_ENO );
		                		inputParam.put("TRSMT_ST_CD", "1" );
		                		inputParam.put("SND_RSLT_CD", "S" );
		                		inputParam.put("SND_RCPT_CCD", "01" );
		                		inputParam.put("SND_RCPT_FILE_NM", "STR_"+TRNS_OGN_CD+"_"+RPR_DT+"_"+String.format("%07d", DocNum)+".xml" );
		                		inputParam.put("SND_RCPT_DOC_NO", TRNS_OGN_CD+RPR_YM+String.format("%05d", DocNum) ); //STR_기관코드_문서생성일자_일련번호(STR_AA0001_20201001_0000001.xml)
		                		inputParam.put("HNDL_P_ENO", helper.getUserId().toString() );
		                		inputParam.put("SND_BEFORE_RCPT_DOC_NO", ("04".equals(input.get("ReType")) ? map.get("DOC_NO").toString() : "") ); //재보고일 경우 종전문서번호 기입 아니면 "" 처리
		                		inputParam.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT").toString() );
		                		inputParam.put("SSPS_DL_ID", map.get("SSPS_DL_ID").toString()  );

		                		if( db.setData("AML_20_01_01_01_NIC80B_FILESEND_UPDATE", inputParam) != 1){

		                			 throw new AMLException("NIC80B(혐의거래일별보고정보) update error. \n >> 전송정보가 저장되지 못했습니다..");
		                		}
	                        }

	                        inputDoc.set("SQ", String.format("%05d", DocNum));
                        	inputDoc.set("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT").toString());
                        	inputDoc.set("SSPS_DL_ID", map.get("SSPS_DL_ID").toString());

                        	if(MDaoUtilSingle.setData("AML_20_01_01_01_NIC110B_INSERT", inputDoc) !=1) {
                        		throw new AMLException("NIC110B(송수신 문서번호)INSERT ERROR. \\n >> 전송정보가 저장되지 못했습니다..");
                        	}

	                        insert_YY = keyYear;
	                        ins_Doc_Num = DocNum;
	                        ins_Master_Num = DocNum;

	                        inputParam.clear();
	                        inputParam.put("RPR_DOC_NO_DL_YR", insert_YY);
	                        inputParam.put("RPR_DOC_NO_FNL_SQ", ins_Doc_Num);
	                        inputParam.put("DOC_NO_YR", insert_YY);
	                        inputParam.put("DOC_SQ", ins_Master_Num);
	                        inputParam.put("HNDL_P_ENO", helper.getUserId().toString() );
	                        inputParam.put("SSPS_DL_CRT_DT", map.get("SSPS_DL_CRT_DT").toString());
	                        inputParam.put("SSPS_DL_ID", map.get("SSPS_DL_ID").toString());

	                        // Doc_Num, Master_Num update
	                        if ( db.setData("AML_20_01_01_01_NIC66B_update4DocNo", inputParam) != 1) {

	                            throw new AMLException( "NIC66B(혐의거래추출내역) update error. \n >> 해당데이터가 존재하지 않습니다.");
	                        }

	                        DocNum++;

	                        prev_SSPS_DL_CRT_DT = Util.replace(map.get("SSPS_DL_CRT_DT").toString(), "-", "");
	                        //prev_SSPS_DL_ID = map.get("SSPS_DL_ID").toString();


	                	//} // 문서번호가 없는 것만

	                } // ok_ccd

	            }

	            db.commit();

	        } catch (AMLException e) {

	            try {
	                if (db != null) {
	                    db.rollback();
	                }
	            } catch (Exception ee) {
	            	Log.logAML(Log.ERROR, this, "doDocumentNum", e.getMessage());
	            }

	            Log.logAML(Log.ERROR, this, "doDocumentNum", e.getMessage());
	            output = new DataObj();
	            output.put("ERRCODE", "00001");
	            output.put("ERRMSG", e.getMessage());
	            output.put("WINMSG"    ,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
	        }catch (Exception e) {

	            try {
	                if (db != null) {
	                    db.rollback();
	                }
	            } catch (Exception ee) {
	            	Log.logAML(Log.ERROR, this, "doDocumentNum", e.getMessage());
	            }

	            Log.logAML(Log.ERROR, this, "doDocumentNum", e.getMessage());
	            output = new DataObj();
	            output.put("ERRCODE", "00001");
	            output.put("ERRMSG", e.getMessage());
	            output.put("WINMSG"    ,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
	        } finally {
                if (db != null) {
                    db.close();
	            }
	        }

	        return output;
	    }

	/**
	 * <pre>
	 *  파일생성후 정보변경처리
	 * ファイル生成後の情報変更処理
	 * @en
	 * </pre>
	 *@param input 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values ,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(파일생성후 정보변경처리 결과 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(ファイル生成後の情報変更処理結果 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj doUpdateExportState(DataObj input) {
		DataObj output = new DataObj();

		MDaoUtil db = null;

		String SSPS_DL_ID = "";
		String SSPS_DL_CRT_DT = "";
		String TRSMT_ST_CD = "";
		String ERROR_MSG = "";
		String PRGRS_ST_CD = "";
		String AML_LOGIN_ID = "";
		@SuppressWarnings("unused")
		String LOG_MSG = "";

		try {
			db = new MDaoUtil();
			db.begin();

			SSPS_DL_ID = (input.getText("SSPS_DL_ID") == null ? "" : input.getText("SSPS_DL_ID"));
			SSPS_DL_CRT_DT = (input.getText("SSPS_DL_CRT_DT") == null ? "" : input.getText("SSPS_DL_CRT_DT"));
			TRSMT_ST_CD = (input.getText("TRSMT_ST_CD") == null ? "" : input.getText("TRSMT_ST_CD"));
			ERROR_MSG = (input.getText("ERROR_MSG") == null ? "" : input.getText("ERROR_MSG"));
			AML_LOGIN_ID = (input.getText("AML_LOGIN_ID") == null ? "" : input.getText("AML_LOGIN_ID"));

			if ( "2".equals(TRSMT_ST_CD) ) {
				PRGRS_ST_CD = "97";
				LOG_MSG = "XML Report File Generating...";
			} else if ( "3".equals(TRSMT_ST_CD) ) {
				PRGRS_ST_CD = "99";
				LOG_MSG = "XML Report File Generate complete...";
			} else if ( "9".equals(TRSMT_ST_CD) ) {
				PRGRS_ST_CD = "98";
				LOG_MSG = "XML Report File Generates an error : \n" + ERROR_MSG;
			} else {
				PRGRS_ST_CD = "97";
				LOG_MSG = "XML Report File Generating...";
			}

			HashMap inputParam = new HashMap();
			inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
			inputParam.put("SSPS_DL_ID", SSPS_DL_ID);
			inputParam.put("TRSMT_ST_CD", TRSMT_ST_CD);
			inputParam.put("HNDL_P_ENO", AML_LOGIN_ID);
			inputParam.put("RPR_PRGRS_CCD", PRGRS_ST_CD);

			db.setData("AML_20_01_01_01_doUpdateExportState", inputParam);
			db.setData("AML_20_01_01_01_doUpdatePrgrsState", inputParam);

			// NIC35B UPDATE
			if ( "3".equals(TRSMT_ST_CD) ) {

				db.setData("AML_20_01_01_01_NIC35B_update_strcnt", inputParam);
			}

			db.commit();

			if ( "".equals(ERROR_MSG) ) {
				output.put("ERRCODE", "00000");
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어
				output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.
			} else {
				output.put("ERRCODE", "00001");
				output.put("ERRMSG", "XML생성에러 : " + input.getText("ERROR_MSG"));
				output.put("WINMSG", "XML생성에러 : " + input.getText("ERROR_MSG")); // 화면 popUp 메세지 출력시 정의함.
			}
		} catch (RuntimeException e) {
			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doUpdateExportState", e.getMessage());
			}
			Log.logAML(Log.ERROR, this, "doUpdateExportState", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		} catch (Exception e) {
			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doUpdateExportState", e.getMessage());
			}
			Log.logAML(Log.ERROR, this, "doUpdateExportState", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		} finally {
			try {
				if ( db != null ) {
					db.close();
				}
			} catch (Exception ee) {
			}
		}

		return output;
	}

	/**
	 * <pre>
	 *  파일생성
	 * ファイル生成
	 * @en
	 * </pre>
	 *@param input 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values ,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(파일생성 결과 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(ファイル生成結果 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public DataObj doExportXML(DataObj input) {
		DataObj output = new DataObj();
		DataObj output_01 = new DataObj();

		List gdReq = (List) input.get("gdReq");
		SessionAML sess = (SessionAML) input.get("SessionAML");
		SessionHelper helper = (SessionHelper) input.get("SessionHelper");

		StrJDomXmlExporter excelExport = new StrJDomXmlExporter();

		try {
			String _str_date = "";
			String _str_id = "";
			String _doc_no = "";
			String _file_nm    = "";
			String _login_id = helper.getUserId().toString();
			String _user_name = sess.getsAML_USER_NAME();
			String _dept_cd = sess.getsAML_BDPT_CD();
			String _dept_nm = sess.getsAML_BDPT_CD_NAME();

			HashMap inputParam = new HashMap();

			for ( int i = 0; i < gdReq.size(); i++ ) {
				HashMap map = (HashMap) gdReq.get(i);

				_str_date = (String) map.get("SSPS_DL_CRT_DT");
				_str_id = (String) map.get("SSPS_DL_ID");
				output_01.clear();

				inputParam.clear();
				inputParam.put("SSPS_DL_CRT_DT", _str_date);
				inputParam.put("SSPS_DL_ID", _str_id);
				inputParam.put("CTR_STR_CCD", "S");

				output_01 = MDaoUtilSingle.getData("AML_20_01_01_01_getSearch_NIC86B", inputParam);

				_doc_no = output_01.getText("SND_RCPT_DOC_NO");

				//2020.08.01 (STR_기관코드_생성일자_일련번호.xml -> STR_GC0020_YYYYMMDD_0000001.xml)
                //_file_nm = "STR_"+output_01.getText("RPR_OGN_CD")+"_"+output_01.getText("RPR_DT")+"_"+setLPad(output_01.getText("SQ"), 7, "0");
                _file_nm = output_01.getText("SND_RCPT_FILE_NM");
				excelExport.startServiceThread(_str_date, _str_id, _doc_no, _login_id, _user_name, _dept_cd, _dept_nm, _file_nm);

			}

		} catch (RuntimeException e) {
			Log.logAML(Log.ERROR, this, "doExportXML", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "doExportXML", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}
		return output;
	}

	/**
     * 특정 길이만큼 문자열 왼쪽에 채워 넣기
     * @param strContext
     * @param iLen
     * @param strChar
     * @return
     */
    public String setLPad(String strContext, int iLen, String strChar) {
    	String rtn = "";
    	StringBuilder sb = new StringBuilder();

    	for(int i=strContext.length(); i<iLen; i++) {
    		sb.append(strChar);
    	}
    	rtn = sb + strContext;

    	return rtn;
    }

    @SuppressWarnings("rawtypes")
    public DataObj doReportSave( DataObj input){
        DataObj output = null;
        MDaoUtil db = null;
        SessionHelper helper = (SessionHelper)input.get("SessionHelper");
        String login_id=helper.getLoginId();
        try {
            List gdReq = (List)input.get("gdReq");

            db = new MDaoUtil();
            db.begin();

            for(int i=0; i<gdReq.size(); i++){
                HashMap map = (HashMap)gdReq.get(i);
                map.put("RPR_PRGRS_CCD", "10");
                map.put("RPR_COMPLITE_DT", (String)input.getText("reportDate"));
                map.put("LOGIN_ID", login_id);
                db.setData("AML_20_01_01_01_doReportComplete", map);
            }

            db.commit();

            output = new DataObj();
            output.put("ERRCODE"    ,"00000");
            output.put("gdRes", null);

        }catch(AMLException e){
            try{ if(db != null) {
            	db.rollback(); }
            } catch(AMLException ee) {Log.logAML(Log.ERROR,this,"doReportSave",e.getMessage());}
            Log.logAML(Log.ERROR,this,"doReportSave",e.getMessage());

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
        } finally {
            if(db != null) {
            	db.close();
            }
        }
        return output;
    }

	/**
	 * <pre>
	 * FIU 보고정보 저장
	 * @jp
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(FIU 보고정보 저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(@jp DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public DataObj doFiuSave(DataObj input) {
		DataObj output = null;
		JDaoUtil jDb = null;
		MDaoUtil mDb = null;

		try {
			List gdReq = (List) input.get("gdReq");

			SessionHelper helper = (SessionHelper) input.get("SessionHelper");
			String login_id = helper.getUserId().toString();
			String toDay = DateUtil.getDate();

			jDb = new JDaoUtil();
			jDb.begin();

			mDb = new MDaoUtil(jDb.getQueryHelper().getConnection());

			for ( int i = 0; i < gdReq.size(); i++ ) {
				HashMap map = (HashMap) gdReq.get(i);

				//보고완료 처리
				map.put("RPR_PRGRS_CCD"  , "10");
				map.put("LOGIN_ID"       , login_id);
				map.put("RPR_COMPLITE_DT", toDay   );
				mDb.setData("AML_20_01_01_01_doReportComplete", map);

				map.put("FIU_NO", StringHelper.evl(map.get("FIU_NO"), "") );
				map.put("FIU_REG_DT", StringHelper.evl(map.get("FIU_REG_DT"), "") );
				map.put("SSPS_DL_CRT_DT", StringHelper.evl(map.get("SSPS_DL_CRT_DT"), "") );
				map.put("SSPS_DL_ID", StringHelper.evl(map.get("SSPS_DL_ID"), "") );

				//NIC80B
				mDb.setData("AML_20_01_01_01_UPDATE_FIUNO", map);
			}

			jDb.commit();

			output = new DataObj();
			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));// PHH 2009.03.02 다국어 // 화면 popUp 메세지 출력시 정의함.

		} catch (RuntimeException e) {
			try {
				if ( jDb != null ) {
					jDb.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doSaveGroup", e.getMessage());
			}
			Log.logAML(Log.ERROR, this, "doSaveGroup", e.getMessage());

			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			try {
				if ( jDb != null ) {
					jDb.rollback();
				}
			} catch (Exception ee) {
				Log.logAML(Log.ERROR, this, "doSaveGroup", e.getMessage());
			}
			Log.logAML(Log.ERROR, this, "doSaveGroup", e.getMessage());

			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} finally {
			if ( jDb != null ) {
				jDb.close();
			}
		}
		return output;
	}

	/**
	 * <pre>
	 *  일괄파일다운로드
	 */

	public DataObj allFileSave(DataObj input) {
		DataObj output = new DataObj();

		String export_path = Constants._UPLOAD_STR_DIR;
		String filnameArray = input.getText("comFileArray").substring(0, input.getText("comFileArray").length() - 1);
		String[] filenameArray = filnameArray.split(",");
		export_path = export_path.replace("\\", "/");
		String filnalFileName = "STR_XML_FILE.zip";
		SEED seed = new SEED();

		ZipOutputStream out = null;
		FileInputStream in = null;
		FileOutputStream fos = null;
		StringBuilder sb = new StringBuilder();
		try {
			fos = new FileOutputStream(export_path + filnalFileName);
			out = new ZipOutputStream(fos);
			byte[] buffer = new byte[5 * 1024 * 1024];

			for ( int i = 0; i < filenameArray.length; i++ ) {

				//System.out.println("####allFileSave - filenameArray : " + filenameArray[i]);

				//in = new FileInputStream(export_path + filenameArray[i]);
				in = getFile(export_path + filenameArray[i]);
				out.putNextEntry(new ZipEntry(filenameArray[i]));

				int len =0;

				while( len !=-1 ){
					len = in.read(buffer);
					if(len !=-1) {
					//sb.append(buffer.toString().substring(0, len));
					sb.append(new String(buffer, 0, len));
					out.write(seed.decrptCharSet(sb.toString(), "UTF-8").trim().getBytes("EUC-KR"));
					}

					//out.write(buffer, 0, len);
				}
				sb.setLength(0);
				out.closeEntry();
				in.close();
			}
			out.close();

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리 되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리 되었습니다."));
			output.put("FILENAME", "STR_XML_FILE.zip");
			output.put("gdRes", Common.setGridData(output));
		} catch (UnsupportedEncodingException e) {
			Log.logAML(Log.ERROR, this, "allFileSave", e);
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}catch (FileNotFoundException e) {
			Log.logAML(Log.ERROR, this, "allFileSave", e);
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}
		catch (IOException e) {
			Log.logAML(Log.ERROR, this, "allFileSave", e);
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}catch (SecurityException e) {
			Log.logAML(Log.ERROR, this, "allFileSave", e);
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}
		catch (Exception e) {
			Log.logAML(Log.ERROR, this, "allFileSave", e);
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
		}
		finally {
				try {
					if(fos != null) {
						fos.close();
					}
					if(in != null) {
						in.close();
					}
					if(out != null)	{
						out.close();
					}
				} catch (IOException e) {
					Log.logAML(Log.ERROR, this, "allFileSave", e);
					output = new DataObj();
					output.put("ERRCODE", "00001");
					output.put("ERRMSG", e.getMessage());
					output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지 않았습니다."));
				}
			}
		return output;
	}

//	private void BizExc(String str) {
//		throw new BizException(str);
//	}

	/**
     * STR XML 보고파일명 변경으로 XML파일 생성후 UPDATE
     * @param input
     * @return
     */
    public DataObj doUpdateStrXmlFile(DataObj input){
        DataObj   output = null;
        MDaoUtil  db     = null;
        try {
            db = new MDaoUtil();
            db.begin();

            db.setData("AML_20_01_01_01_update_NIC80B", input);

            db.commit();

            output = new DataObj();
            output.put("ERRCODE", "00000");
        }catch(RuntimeException e){
        	try{
        		if(db != null) { db.rollback(); }
        	} catch(Exception ee) {
        		Log.logAML(Log.ERROR, this, "doUpdateStrXmlFile", e.getMessage());
        	}
        	Log.logAML(Log.ERROR, this, "doUpdateStrXmlFile", e.getMessage());
        	output = new DataObj();
        	output.put("ERRCODE", "00001");
        }catch(Exception e){
            try{
            	if(db != null) { db.rollback(); }
            } catch(Exception ee) {
            	Log.logAML(Log.ERROR, this, "doUpdateStrXmlFile", e.getMessage());
            }
            Log.logAML(Log.ERROR, this, "doUpdateStrXmlFile", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
        } finally {
            if(db != null) {
            	db.close();
            }
        }
        return output;
    }

	/**
     * SPA 화면 호출 _조회
     */
    public FileInputStream getFile(String input)
    {
    	FileInputStream in = null;
    	input.replace("\\", "/");
    	try {
    	     in = new FileInputStream(input);
    	}catch (FileNotFoundException e) {
			Log.logAML(Log.ERROR, this, "FileInputStream", e);
		}
    	return in;
    }

    /**
     * SPA 화면 호출 _조회
     */
    public DataObj getSearch_AML_20_01_01_01(DataObj input)
    {
    	return getSearch(input);
    }

    /**
     * SPA 화면 호출 _보고정보저장
     */
    public DataObj doFiuSave_AML_20_01_01_01(DataObj input)
    {
    	return doFiuSave(input);
    }

    /**
     * SPA 화면 호출 _파일생성
     */
    public DataObj doWorkFlowProcess_AML_20_01_01_01(DataObj input)
    {
    	return doWorkFlowProcess(input);
    }

    /**
     * SPA 화면 호출 _파일생성
     */
    public DataObj allFileSave_AML_20_01_01_01(DataObj input)
    {
    	return allFileSave(input);
    }
}

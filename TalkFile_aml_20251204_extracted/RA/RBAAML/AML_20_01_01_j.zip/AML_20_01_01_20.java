package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* 대표자 정보 입력
* STR疑わしい取引の詳細(法人)
* President Info. Input
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_01_01_20 extends GetResultObject {

	private static AML_20_01_01_20 instance = null;

	/**
	 * getInstance
	 * @return AML_20_01_01_20
	 */
	public static AML_20_01_01_20 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_01_01_20();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   대표자 정보 조회
	 * 代表者情報の照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(대표자 정보 리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(代表者情報一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj getSearch(DataObj input) {

		DataObj output = null;
		DataSet gdRes = null;

		try {

			output = MDaoUtilSingle.getData("AML_20_01_01_20_select", new Object[] { input.getText("AML_CUST_ID") });

			gdRes = Common.setGridData(output);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException e) {

			Log.logAML(Log.ERROR, this, "AML_20_01_01_20_select", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지않았습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *   대표자 정보 저장(현재사용안함)
	 * 代表者情報の保存（現在使用しない）
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(대표자 정보저장 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(代表者情報の保存 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public DataObj doSave(DataObj input) {

		DataObj output = new DataObj();
		MDaoUtil db = null;

		try {
			List gdReq = (List) input.get("gdReq");
			int totcount = gdReq.size();

			String AML_CUST_ID = input.getText("AML_CUST_ID");

			String RPRST_P_RNMCNO = "";
			String RPRST_P_NM = "";
			String RPRST_P_TEL_NO = "";
			String RPRST_P_RNM_NO_CCD = "";
			String RPRST_P_NTNLT_CD = "";
			String RPRST_P_HSE_ADDR = "";
			String RPRST_P_HSE_PST_NO = "";
			String RPRST_P_SEX_CD = "";
			String GUBUN = "";

			db = new MDaoUtil();
			db.begin();

			for ( int i = 0; i < totcount; i++ ) {
				HashMap map = (HashMap) gdReq.get(i);

				RPRST_P_RNMCNO = (String) map.get("RPRST_P_RNMCNO");
				RPRST_P_NM = (String) map.get("RPRST_P_NM");
				RPRST_P_TEL_NO = (String) map.get("RPRST_P_TEL_NO");
				RPRST_P_RNM_NO_CCD = (String) map.get("RPRST_P_RNM_NO_CCD");
				RPRST_P_NTNLT_CD = (String) map.get("RPRST_P_NTNLT_CD");
				RPRST_P_HSE_ADDR = (String) map.get("RPRST_P_HSE_ADDR");
				RPRST_P_HSE_PST_NO = (String) map.get("RPRST_P_HSE_PST_NO");
				RPRST_P_SEX_CD = (String) map.get("RPRST_P_SEX_CD");
				GUBUN = (String) map.get("GUBUN");

				if ( "I".equals(GUBUN) ) {
					db.setData("AML_20_01_01_20_insert", new Object[] { AML_CUST_ID
							                                          , RPRST_P_RNMCNO
							                                          , RPRST_P_NM
							                                          , RPRST_P_TEL_NO
							                                          , RPRST_P_RNM_NO_CCD
							                                          , RPRST_P_NTNLT_CD
							                                          , RPRST_P_HSE_ADDR
							                                          , RPRST_P_HSE_PST_NO
							                                          , RPRST_P_SEX_CD 
							                                          });
				} else {
					db.setData("AML_20_01_01_20_update", new Object[] { RPRST_P_RNMCNO
							                                          , RPRST_P_NM
							                                          , RPRST_P_TEL_NO
							                                          , RPRST_P_RNM_NO_CCD
							                                          , RPRST_P_NTNLT_CD
							                                          , RPRST_P_HSE_ADDR
							                                          , RPRST_P_HSE_PST_NO
							                                          , RPRST_P_SEX_CD
							                                          , AML_CUST_ID 
							                                          });
				}

			}

			db.commit();

			output.put("ERRCODE", "00000");
			output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상 처리되었습니다."));

		} catch (AMLException e) {

			try {
				if ( db != null ) {
					db.rollback();
				}
			} catch (AMLException ee) {
				Log.logAML(Log.ERROR, this, "AML_20_01_01_20_insert", e.getMessage());
			}

			Log.logAML(Log.ERROR, this, "AML_20_01_01_20_insert", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0041", input.getText("LANG_CD"), "정상처리 되지않았습니다."));

		} finally {
			try {
				if ( db != null ) {
					db.close();
				}
			} catch (Exception ee) {
			}
		}

		return output;
	}

}

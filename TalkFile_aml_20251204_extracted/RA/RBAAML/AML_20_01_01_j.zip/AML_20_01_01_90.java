package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.basic.common.util.Util;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.AML.AML_20.AML_20_99.AML_20_99_01.AML_20_99_01_01_DAO;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* STR 전문 상세화면
*</pre>
*@author GTOne
*@version 1.0
*@history 1.0 2020-07-01
*/
public class AML_20_01_01_90 extends GetResultObject
{

	private static AML_20_01_01_90 instance = null;
	public static String[] arrORGNAMECODE 				= {"GC0025"}; 						//보고기관코드(4자리->6자리 변경) (★NIC86B 의 TRNS_OGN_CD 값과 동일하게 해야함★)
	public static String[] arrMESSAGETYPECODE 			= {"01","04","96","99"}; 			//보고구분
	public static String[] arrQUESTIONTITLECODE 		= {"100","200","300","400","500"};									//의심유형대분류코드(NIC69B)
	public static String[] arrQUESTIONCODE 				= {"101","102","103","104","105","106","107","108","109","110","201","202","203","204","205","206","207"
													  	  ,"210","211","212","213","214","215","216","217","218","226","301","302","303","304","305","306","307"
													  	  ,"401","402","403","404","405","406","501"}; 						//의심유형코드(NIC69B)
	public static String[] arrCHANNELCODE 				= {"01","02","03","04","05","06","07","08","09","10","11","16","19","99"}; 	//거래채널코드(M044)
	public static String[] arrMEANCODE 					= {"01","02","03","04","05","06","07","08","99"}; 					//거래수단코드(M046)
	public static String[] arrMETHODCODE 				= {"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","99"}; 				//거래종류코드(M045)
	public static String[] arrGOODSCODE 				= {"01","02","03","11","12","21","22","23","24","25","26","31","32","41","42","51","52","53","59","61","62","63","64","65","66","91","99"}; 	//거래상품코드(M034)
	public static String[] arrRELATIONROLECODE 			= {"01","02","03","08","09","10","11","12","13","15","16","17","18","19","20"}; 	//거래자역할코드(M056)
	public static String[] arrREALNUMBERCODE 			= {"01","02","03","04","05","06","07","08","09","11","12","99"}; 					//실명번호구분코드(M002)
	public static String[] arrACCOUNTROLECODE 			= {"01","02"}; 						//계좌유형구분코드(M057)
	public static String[] arrACCOUNTHOLDERTYPECODE 	= {"01","02","91","99"}; 			//계좌주구분코드(M058)
	public static String[] arrCHARGEMETHOD_CD 			= {"01","02","03","04","05","99"}; 	//보험료납입방법코드(M067)
	public static String[] arrACCOUNTOPENPURPOSECODE 	= {"01","02","03","04","05","06","07","08","09","99"}; 				//계좌개설목적코드(M038)
	public static String[] arrRELATIONCODE 				= {"51","52","99"}; 				//거래자관계코드(M061)
	public static String[] arrOCCUPATIONTYPECODE 		= {"01","02","03","91"}; 			//직업구분코드(M059)
	public static String[] arrBIZSCALECODE 				= {"01","02"}; 						//기업규모(M030)
	public static String[] arrSECURITIESTYPECODE 		= {"01","02","03","04","05","06","07","08","09","99"}; 				//수표종류(M052)
	public static String[] arrISSUERDIVCODE 			= {"1","3"}; 						//배서자종류(M055)
	public static String[] arrPURPOSECODE 				= {"01","02","03","04","05","06","07","08","09","91","99"}; 		//거래목적코드(M049)

	public static String[] label_Organization 			= {"보고기관코드","보고담당자명","보고책임자명","보고기관전화번호","보고기관우편번호","보고기관주소","보고기관이메일","보고담당자아이디"};
	public static String[] label_MasterBasic 			= {"거래시작일","거래종료일","입금횟수","출금횟수","입금원화금액","출금원화금액","입금달러화금액","출금달러화금액","거래건수","원화금액","달러화환산금액","보고구분","보고일자"};
	public static String[] label_Suspicion 				= {"의심유형대분류코드","의심유형코드"};
	public static String[] label_MasterReport 			= {"의심거래자","거래발생일","거래발생장소","금융거래수단","금융거래방법","혐의거래판단사유","종합의견","영업점의심점수","본점의심점수","기타특징및유형"};
	public static String[] label_TranBasic 				= {"거래일련번호","거래일자","거래시간","거래채널코드","거래채널명","거래수단코드","거래수단명","거래종류코드","거래종류명","거래상품코드","거래상품명"
   														  ,"통화코드","원화금액","외국환금액","달러화환산금액","금융기관코드","지점명","지점코드","지점우편번호"};
	public static String[] label_UserRelation 			= {"거래자역할코드","실명번호","실명번호구분코드","관계설명"};
	public static String[] label_AccountRelation 		= {"금융기관코드","계좌번호","계좌유형분류코드"};
	public static String[] label_TranSecurities 		= {"유가증권종류명","유가증권종류코드","유가증권번호","지급금융기관명","지급금융기관코드","지급영업점명","발행금융기관명","발행금융기관코드","발행영업점명","유가증권금액"
		   										 			  ,"발행일자","발행인구분","발행인구분코드","실명번호","실명번호구분코드"};
	public static String[] label_TranOtherBank 			= {"송수취계좌번호","계좌주구분코드","계좌주명","상대국가코드","금융기관코드","상대영업점명","상대영업점코드","상대영업점우편번호"};
	public static String[] label_TranStock	 			= {"거래종류명","거래종류코드","매매종목명","매매수량","대상금융기관명","금융기관코드","금융기관영업점명","금융기관영업점코드","금융기관영업점우편번호"};
	//public static String[] label_TranInsurance 			= {"보험가입금액","고가의자산여부","계약일","만기일","보험료납입방법코드","보험료납입방법명"};		//보험사일경우
	public static String[] label_DetailAccount 			= {"금융기관코드","지점명","지점코드","지점우편번호","계좌번호","계좌개설일","계좌주실명번호","계좌주실명번호구분","대리인존재여부","대리인실명번호","대리인실명번호구분","계좌개설목적명","계좌개설목적코드"};
	public static String[] label_InterUserRelation 		= {"거래자관계명","거래자관계코드","계좌주실명번호","계좌주실명번호구분","관계인실명번호","관계인실명번호구분","관계명"};
	public static String[] label_DetailUser 			= {"실명번호","실명번호구분코드","실명번호구분명","성명","국가코드","전화번호","핸드폰번호","주소","우편번호","주소(직장)",
														   "우편번호(직장)","생년월일","직장명","부서명","직위","대표자명","직업구분코드","사업자등록번호","업종코드(KSIC)",
														   "주소(사업장)","우편번호(사업장)","전화번호(사업장)","홈페이지주소","기업규모코드","거래소","거래소코드","성별코드","고액자산가여부","금융기관여부","비영리법인여부","국가공공단체여부","상장여부"};

	public static AML_20_01_01_90 getInstance() {
		if (instance == null) {
			instance = new AML_20_01_01_90();
		}
		return instance;
	}

	/**
	 * 보고기관정보 가져오기
	 * @return
	 * @throws Exception
	 */
	public DataObj getOrganization() throws AMLException {
		DataObj output = new DataObj();
		DataObj tmp = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			output = dao.getOrganization(tmp);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getOrganization", "AMLException: " + e.getMessage());
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getOrganization", "Exception: " + e.getMessage());
	    }

		return output;
	}
	
	public DataObj getOrganization_Kofiu() throws AMLException {
		DataObj output = new DataObj();
		DataObj tmp = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			output = dao.getOrganization_Kofiu(tmp);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getOrganization", "AMLException: " + e.getMessage());
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getOrganization", "Exception: " + e.getMessage());
	    }

		return output;
	}

	/**
	 * STR XML정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getMaster_Basic(DataObj input) throws AMLException {
		DataObj output = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			output = dao.getMaster_Basic(input);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Basic", "AMLException: " + e.getMessage());
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Basic", "Exception: " + e.getMessage());
	    }

		return output;
	}
	
	public DataObj getMaster_Basic_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			output = dao.getMaster_Basic_Kofiu(input);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Basic", "AMLException: " + e.getMessage());
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Basic", "Exception: " + e.getMessage());
	    }

		return output;
	}

	/**
	 * STR XML 의심내역정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getMaster_Report(DataObj input) throws AMLException {
		DataObj output = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			output = dao.getMaster_Report(input);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Report", "AMLException: " + e.getMessage());
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Report", "Exception: " + e.getMessage());
	    }

		return output;
	}

	/**
	 * STR XML 의심내역 타이틀 정보 가져오기 : 의심스러운 거래유형에 관한 정보 [Suspicion]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getMaster_Suspicion_Title(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getMaster_Suspicion_Title(input);

			if (dbOut.getCount("QUESTIONTITLE") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			} else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}

			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Suspicion_Title", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Suspicion_Title", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 의심내역 타이틀 정보 가져오기 : 의심스러운 거래유형에 관한 정보 [Suspicion]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getMaster_Suspicion_Question(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;
		DataObj output2 = new DataObj();
		DataObj output3 = new DataObj();

		input.add("QST_TTL_CD","");

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();

			DataObj dbOut = dao.getMaster_Suspicion_Title(input);

			for (int i = 0; i < dbOut.getCount("QUESTIONTITLECODE"); ++i) {
				input.set("QST_TTL_CD", dbOut.getText("QUESTIONTITLECODE", i));
				output2 = dao.getMaster_Suspicion_Question(input);

		    	output3.append(output2);
			}

			gdRes = Common.setGridData(output3);
			output = output3;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Suspicion_Question", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getMaster_Suspicion_Question", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 상세 거래내역정보 가져오기 : 거래내역 [Transaction]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_Basic(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_Basic(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Basic", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Basic", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_Transaction_Basic_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_Basic_Kofiu(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Basic", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Basic", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 상세 거래자 내역정보 가져오기 : 거래에 대한 거래자역할 [Transaction]_[UserRelation]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_UserRelation(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_UserRelation(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_UserRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_UserRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_Transaction_UserRelation_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_UserRelation_Kofiu(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_UserRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_UserRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 계좌정보 가져오기 : 거래에 대한 계약관계 [Transaction]_[AccountRelation]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_AccountRelation(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_AccountRelation(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_AccountRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_AccountRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_Transaction_AccountRelation_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_AccountRelation_Kofiu(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_AccountRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_AccountRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 수표정보 가져오기 : 거래에 대한 유가증권[Transaction]_[Securities]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_Securities(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_Securities(input);

			if(dbOut.getCount("SECURITIESNUMBER") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Securities", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Securities", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_Transaction_Securities_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_Securities_Kofiu(input);

			if(dbOut.getCount("SECURITIESNUMBER") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Securities", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_Securities", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 외환거래정보 가져오기 : 거래에 대한 외환및환전 [Transaction]_[ForeignExchange]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_ForeignExchange(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_ForeignExchange(input);

			if(dbOut.getCount("PURPOSECODE") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}

			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_ForeignExchange", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_ForeignExchange", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 상대계좌정보 가져오기 : 거래에 대한 타행계좌 [Transaction]_[OtherBank]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_OtherBank(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_OtherBank(input);

			if(dbOut.getCount("ACCOUNTNUMBER") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_OtherBank", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_OtherBank", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	} 

	/**
	 * STR XML 상대계좌정보 가져오기 : 거래에 대한 증권 [Transaction]_[Stock]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_Stock_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_Stock_Kofiu(input);

			if(dbOut.getCount("TRANSTYPECODE") > 0) {
				gdRes = Common.setGridData(dbOut);
				output.put("ERRMSG",MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다."));
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_OtherBank", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_OtherBank", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}


	/**
	 * STR XML 비계좌정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Transaction_NonAccountRelation(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Transaction_NonAccountRelation(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_NonAccountRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Transaction_NonAccountRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 고객정보 가져오기(개인)
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Basic(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Basic(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Basic", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Basic", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 고객정보 가져오기(법인)
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Basic2(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Basic2(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Basic2", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Basic2", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 고객상세정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Personal(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Personal(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Personal", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Personal", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	

	/**
	 * STR XML 의심고객정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Suspicious_Personal(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Suspicious_Personal(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Suspicious_Personal", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Suspicious_Personal", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 고객 회사정보 가져오기(법인)
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Company_Personal(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Company_Personal(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company_Personal", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company_Personal", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 고객 회사정보 가져오기(개인)
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Company(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Company(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 혐의고객 회사정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Suspicious_Company(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Suspicious_Company(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Suspicious_Company", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Suspicious_Company", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 상장정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_User_Company_StockList(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_User_Company_StockList(input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company_StockList", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_User_Company_StockList", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 상장정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_setStockList(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			DataObj dbOut = MDaoUtilSingle.getData("AML_20_99_01_01_setStock", input);

			gdRes = Common.setGridData(dbOut);
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_setStockList", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_setStockList", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 계좌 기타정보 가져오기 : 계약정보[Account]
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_Account(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Account(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Account", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Account", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_Account_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_Account_Kofiu(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Account", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_Account", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 거래대리인정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getDetail_InterUserRelation(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_InterUserRelation(input);

			if(dbOut.getCount("RELATION") > 0) {
				gdRes = Common.setGridData(dbOut);
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}

			output = dbOut;
			output.put("ERRCODE","00000");
			output.put("gdRes", gdRes);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_InterUserRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_InterUserRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}
	
	public DataObj getDetail_InterUserRelation_Kofiu(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getDetail_InterUserRelation(input);

			if(dbOut.getCount("RELATION") > 0) {
				gdRes = Common.setGridData(dbOut);
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}

			output = dbOut;
			output.put("ERRCODE","00000");
			output.put("gdRes", gdRes);
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getDetail_InterUserRelation", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getDetail_InterUserRelation", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR XML 첨부파일정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getFileAttach(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;
		DataObj output_01 = new DataObj();

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getFileAttach(input);

			if( dbOut.getCount("USER_FILE_NM") > 0 ) {

				for (int j = 0; j < dbOut.getCount("USER_FILE_NM"); j++) {
					if( !"".equals(dbOut.getText("USER_FILE_NM",j)) ) {
						output_01.add("FILE_PATH", dbOut.getText("FILEPATH",j));
						output_01.add("USER_FILE_NM", dbOut.getText("USER_FILE_NM",j));
						output_01.add("PHSC_FILE_NM", dbOut.getText("PHSC_FILE_NM",j));
						output_01.add("FILE_SEQ", dbOut.getText("FILE_SEQ",j));
					}
				}

				gdRes = Common.setGridData(output_01);
			}else {
				output.put("ERRMSG"	,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
			}

			output = dbOut;
			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getFileAttach", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getFileAttach", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * Insurance정보 가져오기
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj getInsurance(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			AML_20_99_01_01_DAO dao = new AML_20_99_01_01_DAO();
			DataObj dbOut = dao.getInsurance(input);

			gdRes = Common.setGridData(dbOut);
			output = dbOut;

			output.put("gdRes", gdRes);
			output.put("ERRCODE", "00000");
			output.put("ERRMSG",(gdRes.getRowCount() > 0) ? MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"),"조회 되었습니다.") : MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"),"자료가 존재하지 않습니다."));

		} catch (AMLException e) {
	        Log.logAML(Log.ERROR, this, "getInsurance", "AMLException: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    } catch (Exception e) {
	        Log.logAML(Log.ERROR, this, "getInsurance", "Exception: " + e.getMessage());
	        output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	        output.put("ERRCODE", "00001");
	    }

		return output;
	}

	/**
	 * STR보고항목 저장
	 * @param input 화면조회 조건 입력값
	 * @return
	 * @throws Exception
	 */
	public DataObj doSave(DataObj input) throws AMLException {
		DataObj output = new DataObj();
		MDaoUtil db = null;

		try {
			Log.logAML(Log.DEBUG, input, "#############doSave-input:#############");
			db = new MDaoUtil();
			db.begin();

			SessionHelper helper = (SessionHelper)input.get("SessionHelper");
			String ss_RGST_P_ENO = helper.getUserId().toString();
			if(("admin").equals(ss_RGST_P_ENO)){
				ss_RGST_P_ENO = "0";
			}

			String SSPS_DL_CRT_DT 	= Util.nvlTrim(input.getText("SSPS_DL_CRT_DT"));		//험의거래생성일자
			String SSPS_DL_ID 		= Util.nvlTrim(input.getText("SSPS_DL_ID"));			//혐의거래ID
			String INDV_CORP_CCD 	= Util.nvlTrim(input.getText("US_INDV_CORP_CCD")); 		//개인법인구분코드

			System.out.println("$$$$$ SSPS_DL_CRT_DT : " + SSPS_DL_CRT_DT);
			System.out.println("$$$$$ SSPS_DL_ID : " + SSPS_DL_ID);
			System.out.println("$$$$$ INDV_CORP_CCD : " + INDV_CORP_CCD);

			//~~~~~ 의심스러운 거래에 대한 서술 [SuspicionReport] START ~~~~~
			String CWHO 	= Util.nvlTrim(input.getText("CWHO"));		//의심거래자
			String CWHEN 	= Util.nvlTrim(input.getText("CWHEN"));		//거래발생일
			String CWHERE 	= Util.nvlTrim(input.getText("CWHERE"));	//거래발생장소
			String CWHAT 	= Util.nvlTrim(input.getText("CWHAT"));		//금융거래수단
			String CHOW 	= Util.nvlTrim(input.getText("CHOW"));		//금융거래방법
			String CWHY 	= Util.nvlTrim(input.getText("CWHY"));		//혐의거래 판단 사유
			String BRANCHOFFICESCORE 	= Util.nvlTrim(input.getText("BRANCHOFFICESCORE"));		//영업점의심점수
			String ORGSCORE 			= Util.nvlTrim(input.getText("ORGSCORE"));				//본점의심점수
			String ETCPECULARITYTYPE 	= Util.nvlTrim(input.getText("ETCPECULARITYTYPE"));		//기타 특징 및 유형
			String SYNTHETICOPINION 	= Util.nvlTrim(input.getText("SYNTHETICOPINION"));		//종합의견

			System.out.println("$$$$$ CWHO : " + CWHO);
			System.out.println("$$$$$ CWHEN : " + CWHEN);
			System.out.println("$$$$$ CWHERE : " + CWHERE);
			System.out.println("$$$$$ CWHAT : " + CWHAT);
			System.out.println("$$$$$ CHOW : " + CHOW);
			System.out.println("$$$$$ CWHY : " + CWHY);
			System.out.println("$$$$$ BRANCHOFFICESCORE : " + BRANCHOFFICESCORE);
			System.out.println("$$$$$ ORGSCORE : " + ORGSCORE);
			System.out.println("$$$$$ ETCPECULARITYTYPE : " + ETCPECULARITYTYPE);
			System.out.println("$$$$$ SYNTHETICOPINION : " + SYNTHETICOPINION);
			//~~~~~ 의심스러운 거래에 대한 서술 [SuspicionReport] END ~~~~~

			//~~~~~ 거래자정보 [User] - 공통 START ~~~~~
			String NTN_CD               = Util.nvlTrim(input.getText("US_NATIONALITYCODE"));		//국적코드

			System.out.println("$$$$$ NTN_CD : " + NTN_CD);
			//~~~~~ 거래자정보 [User] - 공통 END ~~~~~

			//~~~~~ 거래자정보 [User] - 개인 START ~~~~~
			String DL_P_BRTDY            = Util.nvlTrim(input.getText("hdn_DL_P_BRTDY"));			//생년월일/설립일 (거래자정보 [User])
			String DL_P_HSE_AREA       	 = Util.nvlTrim(input.getText("hdn_DL_P_HSE_TEL_NO_AREA"));	//전화번호  (거래자정보 [User])
			String DL_P_HSE_ECNO       	 = Util.nvlTrim(input.getText("hdn_DL_P_HSE_TEL_NO_ECNO"));	//전화번호  (거래자정보 [User])
			String DL_P_HSE_NO           = Util.nvlTrim(input.getText("hdn_DL_P_HSE_TEL_NO"));		//전화번호  (거래자정보 [User])
			
			String DL_P_HSE_PST_NO       = Util.nvlTrim(input.getText("hdn_DL_P_HSE_PST_NO"));		//우편번호[자택/본점] (거래자정보 [User])
			String DL_P_HSE_BSC_ADDR     = Util.nvlTrim(input.getText("hdn_DL_P_HSE_ADDR_BSC"));	//주소(자택/본점) (거래자정보 [User])
			String DL_P_HSE_DNG_ADDR     = Util.nvlTrim(input.getText("hdn_DL_P_HSE_ADDR_DNG"));	//주소(자택/본점) (거래자정보 [User])
			
			String DL_P_MBL_AREA         = Util.nvlTrim(input.getText("US_PHONEHANDPHONE_AREA"));	//핸드폰번호
			String DL_P_MBL_ECNO         = Util.nvlTrim(input.getText("US_PHONEHANDPHONE_ECNO"));	//핸드폰번호
			String DL_P_MBL_NO           = Util.nvlTrim(input.getText("US_PHONEHANDPHONE_NO"));		//핸드폰번호
			
			String WP_NM                 = Util.nvlTrim(input.getText("US_COMPANY"));				//직장명
			String DTY_DPRT_NM           = Util.nvlTrim(input.getText("US_DEPTNAME"));				//부서명
			String PSTN_CD               = Util.nvlTrim(input.getText("US_POSITION")); 				//직위명
			String OCPTN_CCD             = Util.nvlTrim(input.getText("US_OCCUPATIONTYPECODE"));	//직업구분
			String ADDRESSCOMPANYZIPCODE = Util.nvlTrim(input.getText("US_ADDRESSCOMPANYZIPCODE"));	//우편번호(직장)
			String DL_P_WP_BSC_ADDR      = Util.nvlTrim(input.getText("US_ADDRESSCOMPANY_BSC"));		//주소(직장)
			String DL_P_WP_DNG_ADDR      = Util.nvlTrim(input.getText("US_ADDRESSCOMPANY_DNG"));		//주소(직장)
			
			
			String DL_P_SEX_CD           = Util.nvlTrim(input.getText("US_GENDERCODE"));			//성별
			String LG_AMT_ASTS_F         = Util.nvlTrim(input.getText("US_ISHIGHASSET"));			//고액자산가여부

			System.out.println("$$$$$ DL_P_BRTDY : " + DL_P_BRTDY);
			System.out.println("$$$$$ DL_P_HSE_TEL_NO : " + DL_P_HSE_AREA + DL_P_HSE_ECNO + DL_P_HSE_NO);
			System.out.println("$$$$$ DL_P_HSE_PST_NO : " + DL_P_HSE_PST_NO );
			System.out.println("$$$$$ DL_P_HSE_ADDR : " + DL_P_HSE_BSC_ADDR + DL_P_HSE_DNG_ADDR);
			System.out.println("$$$$$ PHONEHANDPHONE : " + DL_P_MBL_AREA + DL_P_MBL_ECNO + DL_P_MBL_NO);
			System.out.println("$$$$$ WP_NM : " + WP_NM);
			System.out.println("$$$$$ DTY_DPRT_NM : " + DTY_DPRT_NM);
			System.out.println("$$$$$ PSTN_CD : " + PSTN_CD);
			System.out.println("$$$$$ OCPTN_CCD : " + OCPTN_CCD);
			System.out.println("$$$$$ ADDRESSCOMPANYZIPCODE : " + ADDRESSCOMPANYZIPCODE);
			System.out.println("$$$$$ ADDRESSCOMPANY : " + DL_P_WP_BSC_ADDR + DL_P_WP_DNG_ADDR);
			System.out.println("$$$$$ DL_P_SEX_CD : " + DL_P_SEX_CD);
			System.out.println("$$$$$ LG_AMT_ASTS_F : " + LG_AMT_ASTS_F);
			//~~~~~ 거래자정보 [User] - 개인 END ~~~~~

			//~~~~~ 거래자정보 [User] - 법인 START ~~~~~
			String FNDTN_DT              = Util.nvlTrim(input.getText("hdn_FNDTN_DT"));				//생년월일/설립일 (거래자정보 [User])
			String HD_BRNCH_AREA         = Util.nvlTrim(input.getText("hdn_HD_BRNCH_TEL_NO_AREA"));	//전화번호 (거래자정보 [User])
			String HD_BRNCH_ECNO         = Util.nvlTrim(input.getText("hdn_HD_BRNCH_TEL_NO_ECNO"));	//전화번호 (거래자정보 [User])
			String HD_BRNCH_NO           = Util.nvlTrim(input.getText("hdn_HD_BRNCH_TEL_NO"));		//전화번호 (거래자정보 [User])
			
			String HD_BRNCH_PST_NO       = Util.nvlTrim(input.getText("hdn_HD_BRNCH_PST_NO"));		//우편번호[자택/본점] (거래자정보 [User])
			String HD_BRNCH_BSC_ADDR     = Util.nvlTrim(input.getText("hdn_HD_BRNCH_ADDR_BSC"));	//주소(자택/본점) (거래자정보 [User])
			String HD_BRNCH_DNG_ADDR     = Util.nvlTrim(input.getText("hdn_HD_BRNCH_ADDR_DNG"));	//주소(자택/본점) (거래자정보 [User])
			
			String RPRST_P_NTNLT_CD      = Util.nvlTrim(input.getText("hdn_RPRST_P_NTNLT_CD"));		//국적코드 (거래자정보 [User])

			String IND_TYP_CD            = Util.nvlTrim(input.getText("US_KSICCODE"));				//업종코드
			String HMPG_ADDR             = Util.nvlTrim(input.getText("US_HOMEPAGEURL"));			//홈페이지
			String ENTP_SCL_CCD          = Util.nvlTrim(input.getText("US_BIZSCALECODE")); 			//기업규모코드
			String FOGN_F                = Util.nvlTrim(input.getText("US_ISBANKINGORGAN"));		//금융기관여부
			String NPRFT_GROUP_F         = Util.nvlTrim(input.getText("US_ISNONPROFITCORP"));		//비영리법인여부
			String NTN_PBLIC_GROUP_F     = Util.nvlTrim(input.getText("US_ISNATIONALPUBLICGROUP"));	//국가공공단체여부
			String LSTNG_F               = Util.nvlTrim(input.getText("US_ISSTOCKLIST"));			//상장여부
			String LSTNG_INFO            = Util.nvlTrim(input.getText("US_STOCKLISTINFO"));			//상장여부 코드
			String BSNS_CMPNY_AREA       = Util.nvlTrim(input.getText("US_BIZTELNO_AREA"));			//전화번호(사업장)
			String BSNS_CMPNY_ECNO       = Util.nvlTrim(input.getText("US_BIZTELNO_ECNO"));			//전화번호(사업장)
			String BSNS_CMPNY_NO         = Util.nvlTrim(input.getText("US_BIZTELNO_NO"));			//전화번호(사업장)
		 			
			String BIZADDRESSZIPCODE     = Util.nvlTrim(input.getText("US_BIZADDRESSZIPCODE"));		//우편번호(사업장)
			String BSNS_CMPNY_BSC_ADDR   = Util.nvlTrim(input.getText("US_BIZADDRESS_BSC"));		//주소(사업장)
			String BSNS_CMPNY_DNG_ADDR   = Util.nvlTrim(input.getText("US_BIZADDRESS_DNG"));		//주소(사업장)

			System.out.println("$$$$$ FNDTN_DT : " + FNDTN_DT);
			System.out.println("$$$$$ HD_BRNCH_TEL_NO : " + HD_BRNCH_AREA + HD_BRNCH_ECNO + HD_BRNCH_NO);
			System.out.println("$$$$$ HD_BRNCH_PST_NO : " + HD_BRNCH_PST_NO);
			System.out.println("$$$$$ HD_BRNCH_ADDR : " + HD_BRNCH_BSC_ADDR + HD_BRNCH_DNG_ADDR);
			System.out.println("$$$$$ RPRST_P_NTNLT_CD : " + RPRST_P_NTNLT_CD);
			System.out.println("$$$$$ IND_TYP_CD : " + IND_TYP_CD);
			System.out.println("$$$$$ HMPG_ADDR : " + HMPG_ADDR);
			System.out.println("$$$$$ ENTP_SCL_CCD : " + ENTP_SCL_CCD);
			System.out.println("$$$$$ FOGN_F : " + FOGN_F);
			System.out.println("$$$$$ NPRFT_GROUP_F : " + NPRFT_GROUP_F);
			System.out.println("$$$$$ NTN_PBLIC_GROUP_F : " + NTN_PBLIC_GROUP_F);
			System.out.println("$$$$$ LSTNG_F : " + LSTNG_F);
			System.out.println("$$$$$ LSTNG_INFO : " + LSTNG_INFO);
			System.out.println("$$$$$ BIZTELNO : " + BSNS_CMPNY_AREA + BSNS_CMPNY_ECNO + BSNS_CMPNY_NO);
			System.out.println("$$$$$ BIZADDRESSZIPCODE : " + BIZADDRESSZIPCODE);
			System.out.println("$$$$$ BIZADDRESS : " + BSNS_CMPNY_BSC_ADDR + BSNS_CMPNY_DNG_ADDR);
			//~~~~~ 거래자정보 [User] - 법인 END ~~~~~

			int cnt_70B = Integer.parseInt(input.getText("cnt_70B"));	//거래자정보[User]
			int cnt_78B = Integer.parseInt(input.getText("cnt_78B"));	//거래자정보[User] - 개인(US1)
			int cnt_79B = Integer.parseInt(input.getText("cnt_79B"));	//거래자정보[User] - 법인(US2)
			int cnt_67B = Integer.parseInt(input.getText("cnt_67B"));	//의심거래자, 거래발생일, 거래발생장소, 금융거래수단, 금융거래방법, 혐의거래 판단 사유, 종합의견, 본점의심점수
			int cnt_68B = Integer.parseInt(input.getText("cnt_68B"));	//기타 특징 및 유형
			int cnt_88B = Integer.parseInt(input.getText("cnt_88B"));	//영업점의심점수

			System.out.println("$$$$$ cnt_70B : " + cnt_70B);
			System.out.println("$$$$$ cnt_78B : " + cnt_78B);
			System.out.println("$$$$$ cnt_79B : " + cnt_79B);
			System.out.println("$$$$$ cnt_67B : " + cnt_67B);
			System.out.println("$$$$$ cnt_68B : " + cnt_68B);
			System.out.println("$$$$$ cnt_88B : " + cnt_88B);

			//~~~~~ 거래자 고객ID 추출하기 - 혐의거래추출내역(NIC66B) START ~~~~~
			DataObj output_01 = new DataObj();
			String RNMCNO = "";		//거래자실명번호
			output_01 = MDaoUtilSingle.getData("AML_20_01_01_90_doSearchRnmcno", input);

			System.out.println("$$$$$ DL_P_RNMCNO : " + output_01.getCount("DL_P_RNMCNO"));
			if(output_01.getCount("DL_P_RNMCNO") > 0) {
				RNMCNO = Util.nvlTrim(output_01.getText("DL_P_RNMCNO"));
			}
			System.out.println("$$$$$ RNMCNO : " + RNMCNO);
			//~~~~~ 거래자 고객ID 추출하기 - 혐의거래추출내역(NIC66B) END ~~~~~

			DataObj input_01 = new DataObj();
			input_01.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT); 	//혐의거래생성일자
			input_01.put("SSPS_DL_ID", SSPS_DL_ID); 			//혐의거래ID
			input_01.put("RNMCNO", RNMCNO); 					//고객ID
			input_01.put("HNDL_P_ENO", ss_RGST_P_ENO);
			input_01.put("INDV_CORP_CCD", INDV_CORP_CCD);
			
		    if(cnt_67B > 0){

		    	String contents = String.valueOf(SYNTHETICOPINION);


		    	if(contents.getBytes("EUC-KR").length > 4000) {
		    		StringBuffer sb = new StringBuffer();
		    		StringBuffer sb2 = new StringBuffer();
		    		int cnt = 0;
		    		for(char ch:contents.toCharArray()) {
		    			cnt += String.valueOf(ch).getBytes("EUC-KR").length;
		    			if(cnt > 4000) {
		    				sb2.append(ch);
		    			}else {
		    				sb.append(ch);
		    			}
		    		}
		    		System.out.println(sb.toString()+"########### ");

	            	System.out.println("######### " + sb2.toString());

		    		input_01.put("RPR_RSN_CNTNT",sb.toString()); 	//종합의견
	            	input_01.put("RPR_RSN_CNTNT2",sb2.toString()); 	//종합의견


		    		/*byte[] b1 = new byte[4000];
	            	byte[] b2 = new byte[SYNTHETICOPINION.getBytes().length - 4000];

	            	System.arraycopy(SYNTHETICOPINION.getBytes(), 0, b1, 0, b1.length);
	            	System.arraycopy(SYNTHETICOPINION.getBytes(), b1.length, b2, 0, b2.length);

	            	input_01.put("RPR_RSN_CNTNT",new String(b1)); 	//종합의견
	            	input_01.put("RPR_RSN_CNTNT2",new String(b2)); 	//종합의견*/
		    	} else {
		    		input_01.put("RPR_RSN_CNTNT",SYNTHETICOPINION); 	//종합의견
		    	}
		    	input_01.put("ITEM_CNTNT1",CWHO);					//의심거래자
		    	input_01.put("ITEM_CNTNT2",CWHEN);					//거래발생일
		    	input_01.put("ITEM_CNTNT3",CWHERE);					//거래발생장소
		    	input_01.put("ITEM_CNTNT4",CWHAT);					//금융거래수단
		    	input_01.put("ITEM_CNTNT5",CHOW);					//금융거래방법
		    	input_01.put("ITEM_CNTNT6",CWHY);   				//혐의거래 판단 사유
		    	input_01.put("DOBT_DL_GRD_CD",ORGSCORE);			//본점의심점수
		    	//혐의거래의심내역(NIC67B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC67B", input_01);
		    }

	    	if(cnt_68B > 0){
		    	input_01.put("ETC_CNTNT",ETCPECULARITYTYPE);		//기타 특징 및 유형
		    	//혐의거래의심유형(NIC68B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC68B_ETC", input_01);
		    }

	    	if(cnt_88B > 0){
		    	input_01.put("DOBT_DL_GRD_CD",BRANCHOFFICESCORE);	//영업점의심점수
		    	//혐의거래의심내역지점(NIC88B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC88B_GRDCD", input_01);
		    }

	    	if(cnt_70B > 0){
	    		input_01.put("NTN_CD",NTN_CD);						//국적코드
		    	//고객통합기본(NIC01B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC01B_ETC", input_01);


		    	input_01.put("DL_P_NTNLT_CD",NTN_CD);				//거래자국적코드
		    	//혐의거래고객공통정보(NIC70B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC70B_ETC", input_01);

		    }

	    	if( ("1").equals(INDV_CORP_CCD)  &&  cnt_78B > 0){
		    	input_01.put("BRTDY",DL_P_BRTDY);			    	//생년월일/설립일 (거래자정보 [User])
		    	input_01.put("WP_NM",WP_NM);						//직장명
		    	input_01.put("DTY_DPRT_NM",DTY_DPRT_NM);			//부서명
		    	input_01.put("PSTN_CD",PSTN_CD);					//직위명
		    	//개인고객정보(NIC02B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC02B_ETC", input_01);


		    	input_01.put("DL_P_HSE_AREA",DL_P_HSE_AREA);			//전화번호  (거래자정보 [User])
		    	input_01.put("DL_P_HSE_ECNO",DL_P_HSE_ECNO);			//전화번호  (거래자정보 [User])
		    	input_01.put("DL_P_HSE_NO",DL_P_HSE_NO);				//전화번호  (거래자정보 [User])
		    	input_01.put("HSE_PST_NO",DL_P_HSE_PST_NO);				//우편번호[자택/본점] (거래자정보 [User])
		    	input_01.put("DL_P_HSE_BSC_ADDR",DL_P_HSE_BSC_ADDR);	//주소(자택/본점) (거래자정보 [User])
		    	input_01.put("DL_P_HSE_DNG_ADDR",DL_P_HSE_DNG_ADDR);	//주소(자택/본점) (거래자정보 [User]) 
		    	input_01.put("DL_P_MBL_AREA",DL_P_MBL_AREA);			//핸드폰번호
		    	input_01.put("DL_P_MBL_ECNO",DL_P_MBL_ECNO);			//핸드폰번호
		    	input_01.put("DL_P_MBL_NO",DL_P_MBL_NO);				//핸드폰번호
		    	input_01.put("WP_PST_NO",ADDRESSCOMPANYZIPCODE);		//우편번호(직장)
		    	input_01.put("DL_P_WP_BSC_ADDR",DL_P_WP_BSC_ADDR);		//주소(직장)
		    	input_01.put("DL_P_WP_DNG_ADDR",DL_P_WP_DNG_ADDR);		//주소(직장)
		    	input_01.put("OCPTN_CCD",OCPTN_CCD);					//직업구분
		    	input_01.put("SEX_CD",DL_P_SEX_CD);				//성별구분
		    	input_01.put("LG_AMT_ASTS_F",LG_AMT_ASTS_F);			//고액자산가여부
		    	//혐의거래고객개인정보(NIC78B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC78B_ETC", input_01);
		    }

	    	if(("2").equals(INDV_CORP_CCD)  &&  cnt_79B > 0){
		    	input_01.put("FNDTN_DT",FNDTN_DT);						//생년월일/설립일 (거래자정보 [User])
		    	input_01.put("IND_TYP_CD",IND_TYP_CD);					//업종코드
		    	input_01.put("HMPG_ADDR",HMPG_ADDR);					//홈페이지
		    	input_01.put("ENTP_SCL_CCD",ENTP_SCL_CCD);				//기업규모코드
		    	input_01.put("FOGN_F",FOGN_F);							//금융기관여부
		    	input_01.put("NPRFT_GROUP_F",NPRFT_GROUP_F);			//비영리법인여부
		    	input_01.put("NTN_PBLIC_GROUP_F",NTN_PBLIC_GROUP_F);	//국가공공단체여부
		    	input_01.put("LSTNG_F",LSTNG_F);						//상장여부
		    	input_01.put("LSTNG_INFO",LSTNG_INFO);					//상장여부 코드
		    	//법인고객정보(NIC03B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC03B_ETC", input_01);


		    	input_01.put("HD_BRNCH_AREA",HD_BRNCH_AREA);				//전화번호 (거래자정보 [User])
		    	input_01.put("HD_BRNCH_ECNO",HD_BRNCH_ECNO);				//전화번호 (거래자정보 [User])
		    	input_01.put("HD_BRNCH_NO",HD_BRNCH_NO);					//전화번호 (거래자정보 [User])
		    	input_01.put("HD_BRNCH_PST_NO",HD_BRNCH_PST_NO);			//우편번호[자택/본점] (거래자정보 [User])
		    	input_01.put("HD_BRNCH_BSC_ADDR",HD_BRNCH_BSC_ADDR);		//주소(자택/본점) (거래자정보 [User])
		    	input_01.put("HD_BRNCH_DNG_ADDR",HD_BRNCH_DNG_ADDR);		//주소(자택/본점) (거래자정보 [User])
		    	input_01.put("BSNS_CMPNY_AREA",BSNS_CMPNY_AREA);			//전화번호(사업장)
		    	input_01.put("BSNS_CMPNY_ECNO",BSNS_CMPNY_ECNO);			//전화번호(사업장)
		    	input_01.put("BSNS_CMPNY_NO",BSNS_CMPNY_NO);				//전화번호(사업장)
		    	input_01.put("BSNS_CMPNY_PST_NO",BIZADDRESSZIPCODE);		//우편번호(사업장)
		    	input_01.put("BSNS_CMPNY_BSC_ADDR",BSNS_CMPNY_BSC_ADDR);	//주소(사업장)
		    	input_01.put("BSNS_CMPNY_DNG_ADDR",BSNS_CMPNY_DNG_ADDR);	//주소(사업장)
		    	input_01.put("RPRST_P_NTNLT_CD",RPRST_P_NTNLT_CD);			//국적코드 (거래자정보 [User])
		    	//혐의거래고객법인정보(NIC79B) 테이블에 UPDATE
		    	db.setData("AML_20_01_01_90_doSave_NIC79B_ETC", input_01);
		    }


	    	//보고항목 체크로그 저장
		    output = doProcessCheckAll(input_01);

		    if ("00000".equals(output.getText("ERRCODE"))) {
		        db.commit();
		    } else {
		        db.rollback();
		    }
		    output.put("gdRes", null);
//
//	    	output.put("ERRCODE", "00000");
//		    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다."));
//		    output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다."));
//		    System.out.println("$$$$$$$$$$$$$$$$$ DOSAVE END $$$$$$$$$$$$$$$$$");
		}catch (RuntimeException e) {
			if (db != null) {
				db.rollback();
			}
			Log.logAML(Log.ERROR, this, "doSave", e.getMessage());
			output.put("ERRCODE"	, "00001");
			output.put("ERRMSG"		, e.toString());
			output.put("WINMSG"		, MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	    }catch (Exception e) {
	    	if (db != null) {
	    		db.rollback();
	    	}
	    	Log.logAML(Log.ERROR, this, "doSave", e.getMessage());
	    	output.put("ERRCODE"	, "00001");
	    	output.put("ERRMSG"		, e.toString());
	    	output.put("WINMSG"		, MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
	    } finally {
	    	if(db != null) {
	    		db.close();
	    	}
        }

		return output;

	}

	/**
	 * 보고항목 체크후 저장(NIB80B_LOG)
	 * @param input
	 * @return
	 */
	public DataObj doProcessCheckAll(DataObj input) {

		DataObj output = new DataObj();

		try {

			Log.logAML(Log.DEBUG, input, "doProcessCheckAll START>>>>", "");
			int cntErr = 0;
			DataObj input_log = new DataObj();
			DataObj output_log = new DataObj();
			String msg_notNull_info = " 필수정보 입니다.";
			String msg_lineNo = "";
			String userREALNUMBER = "";
			String userREALNUMBER_aft = "";

			String SSPS_DL_CRT_DT = input.getText("SSPS_DL_CRT_DT");
			String SSPS_DL_ID     = input.getText("SSPS_DL_ID");
			String ss_HNDL_P_ENO  = input.getText("HNDL_P_ENO");
			String ss_INDV_CORP_CCD  = input.getText("INDV_CORP_CCD");
			input_log.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT);
	    	input_log.put("SSPS_DL_ID", SSPS_DL_ID);
	    	input_log.put("HNDL_P_ENO",ss_HNDL_P_ENO);
	    	input_log.put("INDV_CORP_CCD",ss_INDV_CORP_CCD);
	    	
	    	input.put("moneyType","KRW");



			//보고항목 가져오기 Start /////////////////////////////////////////////////////////
	    	DataObj outOrganization = getOrganization_Kofiu();					//Organization
	    	DataObj outMasterBasic = getMaster_Basic_Kofiu(input); 				//Master		    	
	    	DataObj outMstSspTitle = getMaster_Suspicion_Title(input); 		//Suspicion Title
	    	DataObj outMstSspQuestion = getMaster_Suspicion_Question(input);//Suspicion	    	
	    	DataObj outMstReport = getMaster_Report(input); 				//SuspicionReport		
	    	
	    	output_log = doCheckValue("Organization",outOrganization,output_log,""); 			//★보고항목 체크하기★
	    	output_log = doCheckValue("MasterBasic",outMasterBasic,output_log,"");				//★보고항목 체크하기★
	    	output_log = doCheckValue("MasterSuspicionTitle",outMstSspTitle,output_log,""); 	//★보고항목 체크하기★
	    	output_log = doCheckValue("MasterSuspicionQuestion",outMstSspQuestion,output_log,""); //★보고항목 체크하기★
	    	output_log = doCheckValue("MasterReport",outMstReport,output_log,"");				//★보고항목 체크하기★
	    	
	    	DataObj outDetailTranBasic = getDetail_Transaction_Basic_Kofiu(input); //Detail__Transaction
	    	DataObj outDetailTranUserRelation = new DataObj();
	    	DataObj outDetailTranAccountRelation = new DataObj();
	    	DataObj outDetailTranSecurities = new DataObj();
	    	DataObj outDetailTranOtherBank = new DataObj();
	    	DataObj outDetailTranForeignExchange = new DataObj();
	    	//DataObj outDetailTranInsurance = new DataObj();		//보험일경우
	    	DataObj outDetailTranStock = new DataObj();			//증권일경우
	    	//DataObj outDetailUser = new DataObj();
	    	DataObj outDetailUserPersonal = new DataObj();
	    	String sMEANCODE = "";
	    	String sMETHODCODE = "";
	    	String sGOODSCODE = "";
	    	String userRELATIONROLECODE = "";
	    	String userRNMCNO = "";
	    	int cntUser = 0;
	    	int cntRelation = 0;

	    	output_log = doCheckValue("DetailTranBasic",outDetailTranBasic,output_log,"");		//★보고항목 체크하기★

	    	for(int i = 0; i < outDetailTranBasic.getCount("DDATE"); i++){
	    		msg_lineNo = "[거래내역("+(i+1)+"번째)]";
	    		input.put("GNL_AC_NO", outDetailTranBasic.getText("GNL_AC_NO",i));
	    		input.put("GDS_NO", outDetailTranBasic.getText("GDS_NO",i));
	    		input.put("DL_DT", outDetailTranBasic.getText("DDATE",i));
	    		input.put("DL_SQ", outDetailTranBasic.getText("SEQ",i));

	    		Log.logAML(Log.DEBUG, input, "outDetailTranBasic GNL_AC_NO>>>>", "");
	    		
	    		outDetailTranUserRelation = getDetail_Transaction_UserRelation_Kofiu(input); 			//Transaction__UserRelation
	    		outDetailTranAccountRelation = getDetail_Transaction_AccountRelation_Kofiu(input); 	//Transaction__AccountRelation
	    		outDetailTranSecurities = getDetail_Transaction_Securities_Kofiu(input); 				//Transaction__Securities
	    		outDetailTranOtherBank = getDetail_Transaction_OtherBank(input); 				//Transaction__OtherBank
	    		outDetailTranForeignExchange = getDetail_Transaction_ForeignExchange(input); 	//Transaction__ForeignExchange : 거래수단(05:외환) or 거래종류(03:환전) 일 경우 필수
	    		//outDetailTranInsurance = getInsurance(input); 								//Transaction__Insurance -> ★보험회사일 경우 필요
	    		outDetailTranStock = getDetail_setStockList(input); 							//Transaction__Stock : ★증권회사일 경우 필요(매수,매도,입고,출고,대체입고,대체출고)


		    	output_log = doCheckValue("DetailTranUserRelation",outDetailTranUserRelation,output_log,msg_lineNo); 		//★보고항목 체크하기★
		    	output_log = doCheckValue("DetailTranAccountRelation",outDetailTranAccountRelation,output_log,msg_lineNo); //★보고항목 체크하기★
		    	output_log = doCheckValue("DetailTranSecurities",outDetailTranSecurities,output_log,msg_lineNo);			//★보고항목 체크하기★
		    	output_log = doCheckValue("DetailTranOtherBank",outDetailTranOtherBank,output_log,msg_lineNo);				//★보고항목 체크하기★
		    	output_log = doCheckValue("DetailTranForeignExchange",outDetailTranForeignExchange,output_log,msg_lineNo);	//★보고항목 체크하기★
		    	//output_log = doCheckValue("DetailTranInsurance",outDetailTranInsurance,output_log,msg_lineNo); 			//★보고항목 체크하기★ -> ★보험회사일 경우 필요
		    	output_log = doCheckValue("DetailTranStock",outDetailTranStock,output_log,msg_lineNo); 						//★보고항목 체크하기★ -> ★증권일 경우 필요

		    	/* ★보고항목 체크하기★
	    		 * Transaction__UserRelation : 1개 이상 존재
	    		 * Transaction__AccountRelation : 1개 이상 존재
	    		 * Transaction__Securities : 거래수단(02,04,08) or 거래종류(16,17,22,23) 일 경우 필수
	    		 * Transaction__ForeignExchange : 거래수단(05:외환) or 거래종류(03:환전) 일 경우 필수
	    		 * Transaction__Stock : 거래종류(10~15:매수~출고 일 경우 필수)
	    		 * Transaction__Insurance : 거래상품코드(61~66) 일 경우 필수
	    		 */

		    	sMEANCODE = outDetailTranBasic.getText("MEANCODE", i);
		    	sMETHODCODE = outDetailTranBasic.getText("METHODCODE", i);
		    	sGOODSCODE	= outDetailTranBasic.getText("GOODSCODE", i);

		    	if(outDetailTranUserRelation.getCount("RELATIONROLE") <= 0) {
		    		output_log.add("ERR_CTNT",msg_lineNo+"거래자역할[Transaction]_[UserRelation]은"+msg_notNull_info);
		    	}
		    	if(outDetailTranAccountRelation.getCount("ACCOUNTROLECODE") <= 0) {
		    		output_log.add("ERR_CTNT",msg_lineNo+"계약관계[Transaction]_[AccountRelation]은"+msg_notNull_info);
		    	}
		    	
		    	if(("02").equals(sMEANCODE) || ("04").equals(sMEANCODE) || ("08").equals(sMEANCODE)			    		 
		    		 || ("16").equals(sMETHODCODE) || ("17").equals(sMETHODCODE) || ("22").equals(sMETHODCODE) || ("23").equals(sMETHODCODE) ) {

			    	if(outDetailTranSecurities.getCount("SECURITIESNUMBER") <= 0) {
			    		output_log.add("ERR_CTNT",msg_lineNo+"유가증권[Transaction]_[Securities]은 거래수단(02,04,08) or 거래종류(16,17,22,23)일 경우"+msg_notNull_info);
			    	}
		    	}
		    	
		    	if( ("05").equals(sMEANCODE) || ("03").equals(sMEANCODE) ) {				    		
				   	if(outDetailTranForeignExchange.getCount("PURPOSECODE") <= 0) {
				   		output_log.add("ERR_CTNT",msg_lineNo+"외환거래목적은 거래수단(05:외환) or 거래종류(03:환전)일 경우"+msg_notNull_info);	
				   	}
			    }
		    	
		    	if( ("10").equals(sMETHODCODE) || ("11").equals(sMETHODCODE) || ("12").equals(sMETHODCODE) || ("13").equals(sMETHODCODE) || ("14").equals(sMETHODCODE) || ("15").equals(sMETHODCODE) ) {				    		
				   	if(outDetailTranStock.getCount("ISSTOCKLIST") <= 0) {
				   		output_log.add("ERR_CTNT",msg_lineNo+"증권정보[Transaction]_[Stock]은 거래종류(10~15:매수~출고)일 경우"+msg_notNull_info);	
				   	}
			    }

		    	/* 보험일경우
		    	if( ("61").equals(sGOODSCODE) || ("62").equals(sGOODSCODE) || ("63").equals(sGOODSCODE) || ("64").equals(sGOODSCODE) || ("65").equals(sGOODSCODE) || ("66").equals(sGOODSCODE) ) {				    		
				   	if(outDetailTranInsurance.getCount("ContractDate") <= 0) {
				   		output_log.add("ERR_CTNT",msg_lineNo+"보험내역[Transaction]_[Insurance]은 거래상품(61~66)일 경우"+msg_notNull_info);	
				   	}
			    }
			    */
	    	}

	    	Log.logAML(Log.DEBUG, input, "outDetailTranUserRelation REALNUMBER cnt>>>>", outDetailTranUserRelation.getCount("REALNUMBER")+"");

	    	for(int ii = 0; ii < outDetailTranUserRelation.getCount("REALNUMBER"); ii++){
	    		userRNMCNO = outDetailTranUserRelation.getText("RNMCNO",ii);
	    		userREALNUMBER = outDetailTranUserRelation.getText("REALNUMBER",ii);
	    		userRELATIONROLECODE = outDetailTranUserRelation.getText("RELATIONROLECODE", ii);
	    		if(("02").equals(userRELATIONROLECODE) || ("09").equals(userRELATIONROLECODE) || ("10").equals(userRELATIONROLECODE)){ //대표자,대리인(관련계좌 개설 대리인, 관련계좌 개설 대표자)
	    			cntRelation++;
	    		}
	    		Log.logAML(Log.DEBUG, input, "outDetailTranUserRelation REALNUMBER>>>>", userREALNUMBER);
	    		
	    		if(!userREALNUMBER.equals(userREALNUMBER_aft)){		    			
	    			input.put("RNMCNO",userRNMCNO); //고객번호
	    			
	    			if(ss_INDV_CORP_CCD.equals("1")) {
	    				outDetailUserPersonal = getDetail_User_Suspicious_Personal(input); //User 조회
	    			}else {
	    				outDetailUserPersonal = getDetail_User_Suspicious_Company(input); //User 조회
	    			}
	    			
	    			userREALNUMBER_aft = userREALNUMBER;
	    			cntUser++;

	    			outDetailUserPersonal.put("NAME", outDetailUserPersonal.getText("DL_P_NM",ii));
	    			outDetailUserPersonal.put("REALNUMBER", outDetailTranUserRelation.getText("REALNUMBER",ii));
	    			outDetailUserPersonal.put("REALNUMBERCODE", outDetailTranUserRelation.getText("REALNUMBERCODE",ii));
	    			outDetailUserPersonal.put("NATIONALITYCODE", outDetailUserPersonal.getText("DL_P_NTNLT_CD",ii));
	    			
	    			output_log = doCheckValue("DetailUserPersonal",outDetailUserPersonal,output_log,""); //★보고항목 체크하기★
	    		}
	    	}
	    	
	    	DataObj outDetailAccount = getDetail_Account_Kofiu(input); //Account
	    	DataObj outDetailUserRelation = getDetail_InterUserRelation_Kofiu(input); //InterUserRelation
	    	DataObj outFileAttach = getFileAttach(input); //FileAttach		 
	    	
	    	
	    	output_log = doCheckValue("DetailAccount",outDetailAccount,output_log,""); 			//★보고항목 체크하기★
	    	output_log = doCheckValue("DetailUserRelation",outDetailUserRelation,output_log,"");	//★보고항목 체크하기★
	    	output_log = doCheckValue("FileAttach",outFileAttach,output_log,"");					//★보고항목 체크하기★

	    	/*★보고항목 체크하기★
	    	 * Transaction 건수
	    	 * User 건수 (TranUserRelation 건수 (중복제거))
	    	 * Account 건수
	    	 * UserRelation (대표자, 대리인) 건수 = TranUserRelation 건수(대표자, 대리인)
	    	 */

	    	if(outDetailTranBasic.getCount("DDATE") <= 0) {
	    		output_log.add("ERR_CTNT","거래내역[Transaction]은"+msg_notNull_info);
	    	}
	    	if(cntUser <= 0) {
	    		output_log.add("ERR_CTNT","거래자정보[User]은"+msg_notNull_info);
	    	}
	    	if(outDetailAccount.getCount("ACCOUNTNUMBER") <= 0) {
	    		output_log.add("ERR_CTNT","계약정보[Account]은"+msg_notNull_info);
	    	}
	    	if(cntRelation > 0) {
	    		if(outDetailUserRelation.getCount("RELATIONCODE") <= 0) {
		    		output_log.add("ERR_CTNT","거래자간의 관계 [InterUserRelation]은 대표자,대리인이 존재할 경우"+msg_notNull_info);
		    	}
	    	}

	    	//보고항목 가져오기 End /////////////////////////////////////////////////////////


	    	Log.logAML(Log.DEBUG, output_log, "doCheck__sb_msg>>>>", output_log.getCount("ERR_CTNT")+"");

	    	//보고항목 체크결과 insert /////////////////////////////////////////////////////////
            for(int j = 0; j < output_log.getCount("ERR_CTNT"); j++){
            	if(!("").equals(output_log.getText("ERR_CTNT",j))){

	    	    	input_log.put("PROC_FALG","1");
	    	    	input_log.put("PROC_CTNT", output_log.getText("ERR_CTNT",j));

	    	    	cntErr++;

	    	    	//보고항목체크로그_NIC80B_LOG(NIC80B_LOG) 테이블에 INSERT 한다.
			    	MDaoUtilSingle.setData("AML_20_01_01_90_doSaveFiuLog", input_log);
            	}
			}

            if(cntErr == 0){ //정상            	
    	    	input_log.put("PROC_FALG","0");    	    	    	    	
    	    	
    	    	//보고항목체크로그_NIC80B_LOG(NIC80B_LOG) 테이블에 INSERT 한다.
    	    	MDaoUtilSingle.setData("AML_20_01_01_90_doSaveFiuLog", input_log);
            }
			
			output.put("ERRCODE", "00000");
		    output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다..."));
		    output.put("WINMSG", MessageHelper.getInstance().getMessage("0002", input.getText("LANG_CD"), "정상처리되었습니다."));				

			
		} catch(UnsupportedEncodingException e) {
			output.clear();
			Log.logAML(1, this, "doProcessCheckAll()", e.getMessage());
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG"	,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
		} catch(StringIndexOutOfBoundsException e) {
			output.clear();
			Log.logAML(1, this, "doProcessCheckAll()", e.getMessage());
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG"	,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
		} catch(AMLException e) {
			output.clear();
			Log.logAML(1, this, "doProcessCheckAll()", e.getMessage());
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG"	,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
		}catch(Exception e) {
			output.clear();
			Log.logAML(1, this, "doProcessCheckAll()", e.getMessage());
			output.put("ERRCODE", "00001");
			output.put("ERRMSG", e.getMessage());
			output.put("WINMSG"	,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지 않았습니다."));
		}

		return output;
	}

	/**
 	 * KOFIU 보고항목 체크하는 함수
 	 * (필수체크, 숫자체크, 자릿수체크, 코드체크, 금칙어체크 등)
 	 *
 	 * @param gubn
 	 * @param dataObj
 	 * @param outputLog
 	 * @return
 	 * @throws UnsupportedEncodingException, StringIndexOutOfBoundsException
 	 */
 	public DataObj doCheckValue(String gubn, DataObj dataObj, DataObj outputLog_param, String pMsg) throws UnsupportedEncodingException, StringIndexOutOfBoundsException {

		Log.logAML(Log.DEBUG, dataObj, "doCheckValue START>>>>", "gubn:"+gubn);
		String msg_notNull = " 필수항목 입니다.";
		String msg_isNumber = " 숫자타입이어야 합니다.";
		String msg_null = " 확인바랍니다.";
		String msg_overOne = " 1 이상이어야 합니다.";
		String msg_title = "";
		DataObj outputLog = outputLog_param;


		try {
	    	//~~~~~ 보고기관정보 START ~~~~~
			if(("Organization").equals(gubn)){

				msg_title = "[Organization]";
				for(int i = 0; i < dataObj.getCount("ORGNAMECODE"); i++){

					String sORGNAMECODE			= dataObj.getText("ORGNAMECODE", i);		//보고기관코드
					String sMAINAUTHORUSERID 	= dataObj.getText("MAINAUTHORUSERID", i);	//보고자 아이디
					String sMAINAUTHOR 			= dataObj.getText("MAINAUTHOR", i);			//보고담당자명
					String sMANAGER 			= dataObj.getText("MANAGER", i);			//보고책임자명
					String sPHONE 				= dataObj.getText("PHONE", i);				//전화번호
					String sADDRESSZIPCODE 		= dataObj.getText("ADDRESSZIPCODE", i);		//우편번호
					String sADDRESS 			= dataObj.getText("ADDRESS", i);			//주소
					String sEMAIL 				= dataObj.getText("EMAIL", i);				//이메일

					//필수체크
					if(("").equals(sORGNAMECODE)){			//보고기관코드
						outputLog.add("ERR_CTNT",msg_title+label_Organization[0]+msg_notNull);
					}
					if(("").equals(sMAINAUTHORUSERID)){		//보고자 아이디
						outputLog.add("ERR_CTNT",msg_title+label_Organization[1]+msg_notNull);
					}
					if(("").equals(sADDRESSZIPCODE)){		//우편번호
						outputLog.add("ERR_CTNT",msg_title+label_Organization[7]+msg_notNull);
					}

					//숫자체크
					if(!isDigit(sADDRESSZIPCODE)){			//우편번호
						outputLog.add("ERR_CTNT",msg_title+label_Organization[4]+msg_isNumber);
					}

					//자릿수체크
					//"보고기관코드","보고담당자명","보고책임자명","보고기관전화번호","보고기관우편번호","보고기관주소","보고기관이메일"
					String[] chkSizeData = {sORGNAMECODE,sMAINAUTHOR,sMANAGER,sPHONE,sADDRESSZIPCODE,sADDRESS,sEMAIL};
					String[] chkSizeName = {label_Organization[0],label_Organization[1],label_Organization[2],label_Organization[3],label_Organization[4],label_Organization[5],label_Organization[6]};
					int[] chkSize = {6,60,60,25,6,200,30};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"ORGNAMECODE"};
					String[] chkCodeDatas = {sORGNAMECODE};
					String[] chkCodeNames = {label_Organization[0]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}

			}
			//~~~~~ 보고기관정보 END ~~~~~

			//~~~~~ STR 취합내용 + 의심정도 START ~~~~~
			if(("MasterBasic").equals(gubn)){

				msg_title = "[Master]";
				for(int i = 0; i < dataObj.getCount("STARTDATE"); i++){

					String sSTARTDATE 		= dataObj.getText("STARTDATE", i);			//거래시작일
					String sENDDATE 		= dataObj.getText("ENDDATE", i);			//거래종료일
					String sINNERCOUNT		= dataObj.getText("INNERCOUNT", i);			//입금횟수
					String sOUTERCOUNT      = dataObj.getText("OUTERCOUNT", i);			//출금횟수
					String sINNERKRWAMOUNT  = dataObj.getText("INNERKRWAMOUNT", i);		//입금원화금액
					String sOUTERKRWAMOUNT  = dataObj.getText("OUTERKRWAMOUNT", i);		//출금원화금액
					String sINNERUSDAMOUNT  = dataObj.getText("INNERUSDAMOUNT", i);		//입금달러화금액
					String sOUTERUSDAMOUNT  = dataObj.getText("OUTERUSDAMOUNT", i);		//출금달러화금액
					String sCOUNT           = dataObj.getText("COUNT", i);				//거래건수
					String sKRWAMOUNT       = dataObj.getText("KRWAMOUNT", i);			//원화금액
					String sUSDAMOUNT       = dataObj.getText("USDAMOUNT", i);			//달러화환산금액
					String sMESSAGETYPECODE = dataObj.getText("MESSAGETYPECODE", i);	//보고구분
					String sDOCSENDDATE     = dataObj.getText("DOCSENDDATE", i);		//보고일자

					//자릿수체크
					//"거래시작일","거래종료일","입금횟수","출금횟수","입금원화금액","출금원화금액","입금달러화금액","출금달러화금액","거래건수","원화금액","달러화환산금액","보고구분","보고일자"
					String[] chkSizeData = {sSTARTDATE,sENDDATE,sINNERCOUNT,sOUTERCOUNT,sINNERKRWAMOUNT,sOUTERKRWAMOUNT,sINNERUSDAMOUNT,sOUTERUSDAMOUNT,sCOUNT,sKRWAMOUNT,sUSDAMOUNT,sMESSAGETYPECODE,sDOCSENDDATE};
					String[] chkSizeName = {label_MasterBasic[0],label_MasterBasic[1],label_MasterBasic[2],label_MasterBasic[3],label_MasterBasic[4],label_MasterBasic[5],label_MasterBasic[6],label_MasterBasic[7],label_MasterBasic[8],label_MasterBasic[9],label_MasterBasic[10],label_MasterBasic[11],label_MasterBasic[12]};
					int[] chkSize = {8,8,4,4,15,15,15,15,4,15,15,2,8};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"MESSAGETYPECODE"};
					String[] chkCodeDatas = {sMESSAGETYPECODE};
					String[] chkCodeNames = {"보고구분"};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}

			}
			//~~~~~ STR 취합내용 + 의심정도 END ~~~~~

			//~~~~~ 의심스러운 거래유형 및 정도에 관한 정보(대항목코드) START ~~~~~
			if(("MasterSuspicionTitle").equals(gubn)){

				msg_title = "[Suspicion]";
				for(int i = 0; i < dataObj.getCount("QUESTIONTITLECODE"); i++){

					String sQUESTIONTITLECODE = dataObj.getText("QUESTIONTITLECODE", i);	//대항목코드
					//String sQUESTIONTITLE = dataObj.getText("QUESTIONTITLE", i);

					//필수체크
					if(("").equals(sQUESTIONTITLECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_Suspicion[0]+msg_notNull);
					}

					//숫자체크
					if(!isDigit(sQUESTIONTITLECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_Suspicion[0]+msg_isNumber);
					}

					//자릿수체크
					//"의심유형대분류코드"
					String[] chkSizeData = {sQUESTIONTITLECODE};
					String[] chkSizeName = {label_Suspicion[0]};
					int[] chkSize = {3};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"QUESTIONTITLECODE"};
					String[] chkCodeDatas = {sQUESTIONTITLECODE};
					String[] chkCodeNames = {label_Suspicion[0]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}

			}
			//~~~~~ 의심스러운 거래유형 및 정도에 관한 정보(대항목코드) END ~~~~~

			//~~~~~ 의심스러운 거래유형 및 정도에 관한 정보(세부항목코드) START ~~~~~
			if(("MasterSuspicionQuestion").equals(gubn)){

				msg_title = "[Suspicion]";
				for(int i = 0; i < dataObj.getCount("QUESTIONCODE"); i++){

					String sQUESTIONCODE = dataObj.getText("QUESTIONCODE", i);
					//String sQUESTION = dataObj.getText("QUESTION", i);

					//필수체크
					if(("").equals(sQUESTIONCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_Suspicion[1]+msg_notNull);
					}

					//숫자체크
					if(!isDigit(sQUESTIONCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_Suspicion[1]+msg_isNumber);
					}

					//자릿수체크
					String[] chkSizeData = {sQUESTIONCODE};
					String[] chkSizeName = {label_Suspicion[1]};
					int[] chkSize = {3};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"QUESTIONCODE"};
					String[] chkCodeDatas = {sQUESTIONCODE};
					String[] chkCodeNames = {label_Suspicion[1]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}

			}
			//~~~~~ 의심스러운 거래유형 및 정도에 관한 정보(세부항목코드) END ~~~~~

			//~~~~~ 의심스러운 거래에 대한 서술 START ~~~~~
			if(("MasterReport").equals(gubn)){

				msg_title = "[SuspicionReport]";
				for(int i = 0; i < dataObj.getCount("CWHO"); i++){

					String sCWHO				= dataObj.getText("CWHO", i);					//의심스러운 거래자 관련
					String sCWHEN       		= dataObj.getText("CWHEN", i);					//거래 발생일자 관련
					String sCWHERE   			= dataObj.getText("CWHERE", i);					//거래 발생 장소 관련
					String sCWHAT   			= dataObj.getText("CWHAT", i);					//금융거래 수단 관련
					String sCHOW   				= dataObj.getText("CHOW", i);					//금융거래 방법 관련
					String sCWHY   				= dataObj.getText("CWHY", i);					//혐의거래로 판단한 사유관련
					String sSYNTHETICOPINION 	= dataObj.getText("SYNTHETICOPINION", i);		//종합의견
					String sBRANCHOFFICESCORE	= dataObj.getText("BRANCHOFFICESCORE", i);		//영업점의심점수
					String sORGSCORE        	= dataObj.getText("ORGSCORE", i);				//본점의심점수
					String sETCPECULARITYTYPE  	= dataObj.getText("ETCPECULARITYTYPE", i);		//관련문서 문서번호

					//필수체크
					if(("").equals(sCWHY)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[5]+msg_notNull);
					}
					if(("").equals(sSYNTHETICOPINION)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[6]+msg_notNull);
					}
					if(("").equals(sORGSCORE)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[8]+msg_notNull);
					}

					//숫자체크
					if(!isDigit(sBRANCHOFFICESCORE)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[7]+msg_isNumber);
					}
					if(!isDigit(sORGSCORE)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[8]+msg_isNumber);
					}

					//1~5사이 정수 체크
					if(!("").equals(sBRANCHOFFICESCORE) && !("1").equals(sBRANCHOFFICESCORE) && !("2").equals(sBRANCHOFFICESCORE) && !("3").equals(sBRANCHOFFICESCORE) && !("4").equals(sBRANCHOFFICESCORE) && !("5").equals(sBRANCHOFFICESCORE)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[7]+msg_null+"(1~5사이 정수)");
					}
					if(!("1").equals(sORGSCORE) && !("2").equals(sORGSCORE) && !("3").equals(sORGSCORE) && !("4").equals(sORGSCORE) && !("5").equals(sORGSCORE)){
						outputLog.add("ERR_CTNT",msg_title+label_MasterReport[8]+msg_null+"(1~5사이 정수)");
					}

					//자릿수체크
					//"의심거래자","거래발생일","거래발생장소","금융거래수단","금융거래방법","혐의거래판단사유","종합의견","본점의심점수","기타특징및유형"
					String[] chkSizeData = {sCWHO,sCWHEN,sCWHERE,sCWHAT,sCHOW,sCWHY,sSYNTHETICOPINION,sORGSCORE,sETCPECULARITYTYPE};
					String[] chkSizeName = {label_MasterReport[0],label_MasterReport[1],label_MasterReport[2],label_MasterReport[3],label_MasterReport[4],label_MasterReport[5],label_MasterReport[6],label_MasterReport[8],label_MasterReport[9]};
					int[] chkSize = {3000,3000,3000,3000,3000,3000,4000,1,3000};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//금칙어체크
					//"의심거래자","거래발생일","거래발생장소","금융거래수단","금융거래방법","혐의거래판단사유","종합의견","기타특징및유형"
					String[] chkWordData = {sCWHO,sCWHEN,sCWHERE,sCWHAT,sCHOW,sCWHY,sSYNTHETICOPINION,sETCPECULARITYTYPE};
					String[] chkWordName = {label_MasterReport[0],label_MasterReport[1],label_MasterReport[2],label_MasterReport[3],label_MasterReport[4],label_MasterReport[5],label_MasterReport[6],label_MasterReport[9]};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);

				}

			}
			//~~~~~ 의심스러운 거래에 대한 서술 END ~~~~~

			//~~~~~ 상세내용 START ~~~~~
			if(("DetailTranBasic").equals(gubn)){
				msg_title = "[Transaction]";
				String msg_lineNo = "";
				for(int i = 0; i < dataObj.getCount("DDATE"); i++){

					String sDDATE 				= dataObj.getText("DDATE", i);					//거래일자
					String sDTIME  				= dataObj.getText("DTIME", i);					//거래발생시간
					String sCHANNELCODE			= dataObj.getText("CHANNELCODE", i);			//거래채널코드
					String sCHANNEL				= dataObj.getText("CHANNEL", i);				//거래채널명
					String sMEANCODE			= dataObj.getText("MEANCODE", i);				//거래수단코드
					String sMEAN 				= dataObj.getText("MEAN", i);					//거래수단명
					String sMETHODCODE			= dataObj.getText("METHODCODE", i);				//거래종류코드
					String sMETHOD				= dataObj.getText("METHOD", i);					//거래종류명
					String sGOODSCODE			= dataObj.getText("GOODSCODE", i);				//거래상품코드
					String sGOODS  				= dataObj.getText("GOODS", i);					//거래상품명
					String sMONEYTYPECODE 		= dataObj.getText("MONEYTYPECODE", i);			//통화종류코드
					String sKRWAMOUNT			= dataObj.getText("KRWAMOUNT", i);				//원화거래금액
					String sFOREIGNAMOUNT		= dataObj.getText("FOREIGNAMOUNT", i);			//외국환거래금액
					String sUSDAMOUNT			= dataObj.getText("USDAMOUNT", i);				//달러호환산금액
					String sORGNAMECODE			= dataObj.getText("ORGNAMECODE", i);			//금융기관코드
					String sBRANCHOFFICE 		= dataObj.getText("BRANCHOFFICE", i);			//지점명
					String sBRANCHOFFICECODE 	= dataObj.getText("BRANCHOFFICECODE", i);		//지점코드
					String sBRANCHOFFICEZIPCODE = dataObj.getText("BRANCHOFFICEZIPCODE", i);	//우편번호

					msg_lineNo = " ("+(i+1)+"번째)";

					//필수체크
					if(("").equals(sCHANNELCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[3]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sMEANCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[5]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sMETHODCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[7]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sGOODSCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[9]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sMONEYTYPECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[11]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sORGNAMECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[15]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sBRANCHOFFICECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[17]+msg_notNull+msg_lineNo);
					}
					if(("").equals(sBRANCHOFFICEZIPCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[18]+msg_notNull+msg_lineNo);
					}

					//숫자체크
					if(!isDigit(sDTIME)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[2]+msg_isNumber+msg_lineNo);
					}
					if(!isDigit(sKRWAMOUNT)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[12]+msg_isNumber+msg_lineNo);
					}
					if(!isDigit(sFOREIGNAMOUNT)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[13]+msg_isNumber+msg_lineNo);
					}
					if(!isDigit(sUSDAMOUNT)){
						outputLog.add("ERR_CTNT",msg_title+label_TranBasic[14]+msg_isNumber+msg_lineNo);
					}

					//자릿수체크
					//"거래일자","거래시간","거래채널코드","거래채널명","거래수단코드","거래수단명","거래종류코드","거래종류명","거래상품코드",
					//"거래상품명","통화코드","원화금액","외국환금액","달러화환산금액","금융기관코드","지점명","지점코드","지점우편번호"
					String[] chkSizeData = {sDDATE,sDTIME,sCHANNELCODE,sCHANNEL,sMEANCODE,sMEAN,sMETHODCODE,sMETHOD,sGOODSCODE
							,sGOODS,sMONEYTYPECODE,sKRWAMOUNT,sFOREIGNAMOUNT,sUSDAMOUNT,sORGNAMECODE,sBRANCHOFFICE,sBRANCHOFFICECODE,sBRANCHOFFICEZIPCODE};
					String[] chkSizeName = {label_TranBasic[1],label_TranBasic[2],label_TranBasic[3],label_TranBasic[4],label_TranBasic[5],label_TranBasic[6],label_TranBasic[7],label_TranBasic[8],label_TranBasic[9]
							,label_TranBasic[10],label_TranBasic[11],label_TranBasic[12],label_TranBasic[13],label_TranBasic[14],label_TranBasic[15],label_TranBasic[16],label_TranBasic[17],label_TranBasic[18]};
					int[] chkSize = {8,6,3,50,3,50,3,50,3,50,3,17,17,17,6,50,7,6};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_lineNo+msg_title);

					//금칙어체크
					//지점코드
					String[] chkWordData = {sBRANCHOFFICE};
					String[] chkWordName = {label_TranBasic[16]};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);

					//KOFIU 보고코드 체크
					//거래채널코드,거래수단코드,거래종류코드,거래상품코드
					String[] chkCodes = {"CHANNELCODE","MEANCODE","METHODCODE","GOODSCODE"};
					String[] chkCodeDatas = {sCHANNELCODE,sMEANCODE,sMETHODCODE,sGOODSCODE};
					String[] chkCodeNames = {"거래채널코드","거래수단코드","거래종류코드","거래상품코드"};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_lineNo+msg_title);

					/*
					 * sKRWAMOUNT : KRW and 종류코드 99 아닐 경우, 1 이상
					 * sFOREIGNAMOUNT : KRW 아니고 and 종류코드 99 아닐 경우, 1 이상
					 * sUSDAMOUNT : KRW 아니고 and 종류코드 99 아닐 경우, 1 이상
					 */
					if(("KRW").equals(sMONEYTYPECODE) && !("99").equals(sMETHODCODE)){
						if(Integer.parseInt(sKRWAMOUNT) <= 0){
							outputLog.add("ERR_CTNT",msg_title+label_TranBasic[12]+msg_overOne+msg_lineNo);
						}
					}
					if(!("KRW").equals(sMONEYTYPECODE) && !("99").equals(sMETHODCODE)){
						if(Integer.parseInt(sFOREIGNAMOUNT) <= 0){
							outputLog.add("ERR_CTNT",msg_title+label_TranBasic[13]+msg_overOne+msg_lineNo);
						}
					}
					if(!("KRW").equals(sMONEYTYPECODE) && !("99").equals(sMETHODCODE)){
						if(Integer.parseInt(sUSDAMOUNT) <= 0){
							outputLog.add("ERR_CTNT",msg_title+label_TranBasic[14]+msg_overOne+msg_lineNo);
						}
					}

				}
			}
			//~~~~~ 상세내용 END ~~~~~

			//~~~~~ 거래에대한 거래자역할 START ~~~~~
			if(("DetailTranUserRelation").equals(gubn)){

				msg_title = pMsg+"[Transaction_UserRelation]";
				int cnt_01_RoleCode = 0;
				int cnt_08_RoleCode = 0;
				int cnt_09_RoleCode = 0;
				int cnt_11_RoleCode = 0;
				int cnt_12_RoleCode = 0;

				for(int i = 0; i < dataObj.getCount("RELATIONROLECODE"); i++){

					String sRELATIONROLECODE	= dataObj.getText("RELATIONROLECODE", i);	//거래역할코드
					String sREALNUMBER          = dataObj.getText("REALNUMBER", i);			//실명번호
					String sREALNUMBERCODE      = dataObj.getText("REALNUMBERCODE", i);		//실명번호구분코드
					String sINSURELDESC         = dataObj.getText("INSURELDESC", i);		//관계설명

					//필수체크
					if(("").equals(sRELATIONROLECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_UserRelation[0]+msg_notNull);
					}
					if(("").equals(sREALNUMBER)){
						outputLog.add("ERR_CTNT",msg_title+label_UserRelation[1]+msg_notNull);
					}
					if(("").equals(sREALNUMBERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_UserRelation[2]+msg_notNull);
					}

					//자릿수체크
					//"거래자역할코드","실명번호","실명번호구분코드","관계설명"
					String[] chkSizeData = {sRELATIONROLECODE,sREALNUMBER,sREALNUMBERCODE,sINSURELDESC};
					String[] chkSizeName = {label_UserRelation[0],label_UserRelation[1],label_UserRelation[2],label_UserRelation[3]};
					int[] chkSize = {2,15,2,100};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//금칙어체크
					String[] chkWordData = {sINSURELDESC};
					String[] chkWordName = {label_UserRelation[3]};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"RELATIONROLECODE","REALNUMBERCODE"};
					String[] chkCodeDatas = {sRELATIONROLECODE,sREALNUMBERCODE};
					String[] chkCodeNames = {label_UserRelation[0],label_UserRelation[2]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);

					//의심거래자(01)은 반드시 1개 존재, 09일 경우 08 존재, 12 일 경우 11존재.
					if(("01").equals(sRELATIONROLECODE)) {
						cnt_01_RoleCode++;
					}
					if(("08").equals(sRELATIONROLECODE)) {
						cnt_08_RoleCode++;
					}
					if(("09").equals(sRELATIONROLECODE)) {
						cnt_09_RoleCode++;
					}
					if(("11").equals(sRELATIONROLECODE)) {
						cnt_11_RoleCode++;
					}
					if(("12").equals(sRELATIONROLECODE)) {
						cnt_12_RoleCode++;
					}
				}

				if(cnt_01_RoleCode < 0) {
					outputLog.add("ERR_CTNT",msg_title+"[의심거래자]는 반드시 1건 존재해야 합니다.");
				}
				if(cnt_09_RoleCode > 0) {
					if(cnt_08_RoleCode < 0) {
						outputLog.add("ERR_CTNT",msg_title+"[관련계좌 개설 대리인]이 있는 경우 [관련계좌 개설자]가 반드시 1건 존재해야 합니다.");
					}
				}
				if(cnt_12_RoleCode > 0) {
					if(cnt_11_RoleCode < 0) {
						outputLog.add("ERR_CTNT",msg_title+"[당행송수취 계좌개설 대리인]이 있는 경우 [당행송수취 계좌개설자]가 반드시 1건 존재해야 합니다.");
					}
				}

			}
			//~~~~~ 거래에대한 거래자역할 END ~~~~~

			//~~~~~ 거래에대한 계좌 START ~~~~~
			if(("DetailTranAccountRelation").equals(gubn)){

				msg_title = pMsg+"[Transaction_AccountRelation]";
				for(int i = 0; i < dataObj.getCount("ACCOUNTROLECODE"); i++){

					String sORGNAMECODE       = dataObj.getText("ORGNAMECODE", i);		//실명번호구분코드
					String sACCOUNTNUMBER     = dataObj.getText("ACCOUNTNUMBER", i);	//계좌번호
					String sACCOUNTROLECODE   = dataObj.getText("ACCOUNTROLECODE", i);	//계좌유형구분코드

					//필수체크
					if(("").equals(sORGNAMECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_AccountRelation[0]+msg_notNull);
					}
					if(("").equals(sACCOUNTROLECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_AccountRelation[2]+msg_notNull);
					}

					//자릿수체크
					//"금융기관코드","계좌번호","계좌유형분류코드"
					String[] chkSizeData = {sORGNAMECODE,sACCOUNTNUMBER,sACCOUNTROLECODE};
					String[] chkSizeName = {label_AccountRelation[0],label_AccountRelation[1],label_AccountRelation[2]};
					int[] chkSize = {6,30,2};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"ACCOUNTROLECODE"};
					String[] chkCodeDatas = {sACCOUNTROLECODE};
					String[] chkCodeNames = {label_AccountRelation[2]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 거래에대한 계좌 END ~~~~~

			//~~~~~ 유가증권 START ~~~~~
			if(("DetailTranSecurities").equals(gubn)){

				msg_title = pMsg+"[Transaction_Securities]";
				for(int i = 0; i < dataObj.getCount("SECURITIESNUMBER"); i++){

					String sSECURITIESTYPECODE 	= dataObj.getText("SECURITIESTYPECODE", i);		//관련유가증권의 종류
					String sSECURITIESNUMBER  	= dataObj.getText("SECURITIESNUMBER", i);		//관련유가증권번호
					String sORGNAMECODE         = dataObj.getText("ORGNAMECODE", i);			//금융기관코드(지급은행)
					String sBRANCHOFFICE        = dataObj.getText("BRANCHOFFICE", i);			//지급영업점명
					String sISSUEORGNAMECODE    = dataObj.getText("ISSUEORGNAMECODE", i);		//금융기관코드(발행은행)
					String sISSUEBRANCHOFFICE   = dataObj.getText("ISSUEBRANCHOFFICE", i);		//발행영업점명
					String sISSUEAMOUNT         = dataObj.getText("ISSUEAMOUNT", i);			//금액
					String sISSUEDATE       	= dataObj.getText("ISSUEDATE", i);				//발행일
					String sISSUERDIVCODE       = dataObj.getText("ISSUERDIVCODE", i);			//구분코드(발행인/최종소지인 구분)
					String sREALNUMBER          = dataObj.getText("REALNUMBER", i);				//실명번호
					String sREALNUMBERCODE      = dataObj.getText("REALNUMBERCODE", i);			//실명번호구분코드

					//필수체크
					if(("").equals(sSECURITIESTYPECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranSecurities[1]+msg_notNull);
					}
					if(("").equals(sORGNAMECODE) && ("").equals(sISSUEORGNAMECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranSecurities[4]+" OR "+label_TranSecurities[7]+msg_notNull);
					}
					if(("").equals(sISSUERDIVCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranSecurities[12]+msg_notNull);
					}
					if(("").equals(sREALNUMBER)){
						outputLog.add("ERR_CTNT",msg_title+label_TranSecurities[13]+msg_notNull);
					}
					if(("").equals(sREALNUMBERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranSecurities[14]+msg_notNull);
					}

					//자릿수체크
					//"유가증권종류코드","유가증권번호","지급금융기관코드","지급영업점명","발행금융기관코드","발행영업점명",
			 		//"유가증권금액","발행일자","발행인구분","발행인구분코드","실명번호","실명번호구분코드"
					String[] chkSizeData = {sSECURITIESTYPECODE,sSECURITIESNUMBER,sORGNAMECODE,sBRANCHOFFICE,sISSUEORGNAMECODE,sISSUEBRANCHOFFICE
							,sISSUEAMOUNT,sISSUEDATE,sISSUERDIVCODE,sREALNUMBER,sREALNUMBERCODE};
					String[] chkSizeName = {label_TranSecurities[1],label_TranSecurities[2],label_TranSecurities[4],label_TranSecurities[5],label_TranSecurities[7],label_TranSecurities[8]
							,label_TranSecurities[9],label_TranSecurities[10],label_TranSecurities[12],label_TranSecurities[13],label_TranSecurities[14]};
					int[] chkSize = {2,15,6,50,6,50,17,8,1,15,2};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//금칙어체크
					//"유가증권번호","지급영업점명","발행영업점명"
					String[] chkWordData = {sSECURITIESNUMBER,sBRANCHOFFICE,sISSUEBRANCHOFFICE};
					String[] chkWordName = {label_TranSecurities[2],label_TranSecurities[5],label_TranSecurities[8]};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);

					//KOFIU 보고코드 체크
					//"유가증권번호","발행인구분코드"
					String[] chkCodes = {"SECURITIESTYPECODE","ISSUERDIVCODE"};
					String[] chkCodeDatas = {sSECURITIESTYPECODE,sISSUERDIVCODE};
					String[] chkCodeNames = {label_TranSecurities[1],label_TranSecurities[12]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 유가증권 END ~~~~~

			//~~~~~ 타행계좌 START ~~~~~
			if(("DetailTranOtherBank").equals(gubn)){
				msg_title = pMsg+"[Transaction_OtherBank]";
				for(int i = 0; i < dataObj.getCount("ACCOUNTNUMBER"); i++){

					String sACCOUNTNUMBER             = dataObj.getText("ACCOUNTNUMBER", i);			//송/수취계좌번호
					String sACCOUNTHOLDERTYPECODE     = dataObj.getText("ACCOUNTHOLDERTYPECODE", i);	//계좌주구분코드
					String sNAME                      = dataObj.getText("NAME", i);						//계좌주명
					String sNATIONALITYCODE           = dataObj.getText("NATIONALITYCODE", i);			//상대국가코드
					String sORGNAMECODE               = dataObj.getText("ORGNAMECODE", i);				//상대금융기관코드
					String sBRANCHOFFICE              = dataObj.getText("BRANCHOFFICE", i);				//상대영업점명
					String sBRANCHOFFICECODE          = dataObj.getText("BRANCHOFFICECODE", i);			//지점코드
					String sBRANCHOFFICEZIPCODE       = dataObj.getText("BRANCHOFFICEZIPCODE", i);		//우편번호

					//필수체크
					if(("").equals(sACCOUNTHOLDERTYPECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranOtherBank[1]+msg_notNull);
					}
					if(("").equals(sNATIONALITYCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranOtherBank[3]+msg_notNull);
					}
					if(("").equals(sORGNAMECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranOtherBank[4]+msg_notNull);
					}
					if(("").equals(sBRANCHOFFICECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranOtherBank[6]+msg_notNull);
					}
					if(("").equals(sBRANCHOFFICEZIPCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_TranOtherBank[7]+msg_notNull);
					}

					//자릿수체크
					//"송수취계좌번호","계좌주구분코드","계좌주명","상대국가코드","금융기관코드","상대영업점명","상대영업점코드","상대영업점우편번호"
					String[] chkSizeData = {sACCOUNTNUMBER,sACCOUNTHOLDERTYPECODE,sNAME,sNATIONALITYCODE,sORGNAMECODE,sBRANCHOFFICE,sBRANCHOFFICECODE,sBRANCHOFFICEZIPCODE};
					String[] chkSizeName = {label_TranOtherBank[0],label_TranOtherBank[1],label_TranOtherBank[2],label_TranOtherBank[3],label_TranOtherBank[4],label_TranOtherBank[5],label_TranOtherBank[6],label_TranOtherBank[7]};
					int[] chkSize = {30,2,60,2,6,50,7,6};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"ACCOUNTHOLDERTYPECODE"};
					String[] chkCodeDatas = {sACCOUNTHOLDERTYPECODE};
					String[] chkCodeNames = {label_TranOtherBank[1]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 타행계좌 END ~~~~~

			//~~~~~ 거래수단이 외환, 거래종류가 환전일 경우 START ~~~~~
			if(("DetailTranForeignExchange").equals(gubn)){
				msg_title = pMsg+"[Transaction_Exchange]";
				for(int i = 0; i < dataObj.getCount("PURPOSECODE"); i++){

					String sPURPOSECODE     = dataObj.getText("PURPOSECODE", i);	//거래목적코드
					String sPURPOSE         = dataObj.getText("PURPOSE", i);		//거래목적명

					//필수체크
					if(("").equals(sPURPOSECODE)){
						outputLog.add("ERR_CTNT",msg_title+"외환거래목적코드"+msg_notNull);
					}

					//자릿수체크
					String[] chkSizeData = {sPURPOSECODE,sPURPOSE};
					String[] chkSizeName = {"외환거래목적코드","외환거래목적명"};
					int[] chkSize = {3,60};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"PURPOSECODE"};
					String[] chkCodeDatas = {sPURPOSECODE};
					String[] chkCodeNames = {"외환거래목적코드"};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 거래수단이 외환, 거래종류가 환전일 경우 END ~~~~~

			/* 보험일경우
			//~~~~~ 보험 START ~~~~~
			if(("DetailTranInsurance").equals(gubn)){
				msg_title = pMsg+"[Transaction_Insurance]";
				for(int i = 0; i < dataObj.getCount("AMOUNT"); i++){

					String sAMOUNT              = dataObj.getText("AMOUNT", i);				//보험가입금액
					String sISHIGHASSET         = dataObj.getText("ISHIGHASSET", i);		//고액의자산여부
					String sCONTRACTDATE        = dataObj.getText("CONTRACTDATE", i);		//계약일
					String sMATURITYDATE        = dataObj.getText("MATURITYDATE", i);		//만기일
					String sCHARGEMETHOD_CD     = dataObj.getText("CHARGEMETHOD_CD", i);	//보험료납입방법코드
					String sCHARGEMETHOD_NM     = dataObj.getText("CHARGEMETHOD_NM", i);	//보험료납입방법명

					//필수체크
					if(("").equals(sCHARGEMETHOD_CD)){
						outputLog.add("ERR_CTNT",msg_title+label_TranInsurance[4]+msg_notNull);
					}

					//자릿수체크
					//"보험가입금액","고가의자산여부","계약일","만기일","보험료납입방법코드","보험료납입방법명"
					String[] chkSizeData = {sAMOUNT,sISHIGHASSET,sCONTRACTDATE,sMATURITYDATE,sCHARGEMETHOD_CD,sCHARGEMETHOD_NM};
					String[] chkSizeName = {label_TranInsurance[0],label_TranInsurance[1],label_TranInsurance[2],label_TranInsurance[3],label_TranInsurance[4],label_TranInsurance[5]};
					int[] chkSize = {17,1,8,8,3,30};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"CHARGEMETHOD_CD"};
					String[] chkCodeDatas = {sCHARGEMETHOD_CD};
					String[] chkCodeNames = {label_TranInsurance[4]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 보험 END ~~~~~
			*/

			//~~~~~ 증권 START ~~~~~
			if(("DetailTranStock").equals(gubn)){
				msg_title = pMsg+"[Transaction_Stock]";
				for(int i = 0; i < dataObj.getCount("DL_TYP_CD"); i++){
					//String sDL_TYP_NM         	= dataObj.getText("DL_TYP_NM", i);				//거래종류명
					String sDL_TYP_CD           = dataObj.getText("DL_TYP_CD", i);				//거래종류코드
					String sSTBD_NM        		= dataObj.getText("STBD_NM", i);				//매매종목명
					String sDEAL_FLUC_QTY     	= dataObj.getText("DEAL_FLUC_QTY", i);			//매매수량
					//String sCPRTY_TRSNS_FOGN_NM	= dataObj.getText("CPRTY_TRSNS_FOGN_NM", i);	//대상금융기관명
					String sCPRTY_TRSNS_OGN_CD  = dataObj.getText("CPRTY_TRSNS_OGN_CD", i);		//대상금융기관코드
					String sHANDLNG_BRN_NM		= dataObj.getText("HANDLNG_BRN_NM", i);			//금융기관영업점명
					String sHANDLNG_BRN_CD		= dataObj.getText("HANDLNG_BRN_CD", i);			//금융기관영업점코드
					String sHANDLNG_BRN_PST_NO	= dataObj.getText("HANDLNG_BRN_PST_NO", i);		//금융기관영업점우편번호

					//필수체크
					if(("").equals(sDL_TYP_CD)){
						outputLog.add("ERR_CTNT",msg_title+label_TranStock[1]+msg_notNull);
					}

					if("14,15".contains(sDL_TYP_CD)) {
						//대체입고(14), 대체출고(15)일경우 필수체크
						if(("").equals(sCPRTY_TRSNS_OGN_CD)){
							outputLog.add("ERR_CTNT",msg_title+label_TranStock[3]+msg_notNull);
						}
						if(("").equals(sHANDLNG_BRN_CD)){
							outputLog.add("ERR_CTNT",msg_title+label_TranStock[7]+msg_notNull);
						}
						if(("").equals(sHANDLNG_BRN_PST_NO)){
							outputLog.add("ERR_CTNT",msg_title+label_TranStock[8]+msg_notNull);
						}
					}
					//자릿수체크
					//"거래종류코드","매매종목명","매매수량","금융기관코드","금융기관영업점명","금융기관영업점코드","금융기관영업점우편번호"
					String[] chkSizeData = {sDL_TYP_CD,sSTBD_NM,sDEAL_FLUC_QTY,sCPRTY_TRSNS_OGN_CD,sHANDLNG_BRN_NM,sHANDLNG_BRN_CD,sHANDLNG_BRN_PST_NO};
					String[] chkSizeName = {label_TranStock[1],label_TranStock[2],label_TranStock[3],label_TranStock[5],label_TranStock[6],label_TranStock[7],label_TranStock[8]};
					int[] chkSize = {10,30,10,6,50,7,6};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"METHODCODE"};
					String[] chkCodeDatas = {sDL_TYP_CD};
					String[] chkCodeNames = {label_TranStock[1]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 증권 END ~~~~~

			//~~~~~ 거래자 START ~~~~~
			if(("DetailUserPersonal").equals(gubn)){
				msg_title = "[User]";
				for(int i = 0; i < dataObj.getCount("REALNUMBER"); i++){

					String sREALNUMBER              = dataObj.getText("REALNUMBER", i);					//실명번호
					String sREALNUMBERCODE          = dataObj.getText("REALNUMBERCODE", i);				//실명번호구분코드
					String sREALNUMBERTYPENAME      = dataObj.getText("REALNUMBERTYPENAME", i);			//거래자실명번호구분(기타기재)
					String sNAME                    = dataObj.getText("NAME", i);						//성명
					String sNATIONALITYCODE         = dataObj.getText("NATIONALITYCODE", i);			//국적코드

					//~~~~~ 개인 START ~~~~~
					String sPHONE                   = dataObj.getText("PHONE", i);						//전화번호
					String sPHONEHANDPHONE          = dataObj.getText("PHONEHANDPHONE", i);				//핸드폰번호
					String sADDRESS                 = dataObj.getText("ADDRESS", i);					//주소(자택)
					String sADDRESSZIPCODE          = dataObj.getText("ADDRESSZIPCODE", i);				//우편번호(자택)
					String sADDRESSCOMPANY          = dataObj.getText("ADDRESSCOMPANY", i);				//주소(직장)
					String sADDRESSCOMPANYZIPCODE   = dataObj.getText("ADDRESSCOMPANYZIPCODE", i);		//우편번호(직장)
					String sBIRTHDAY                = dataObj.getText("BIRTHDAY", i);					//거래자 생년월일/사업체 설립일
					String sGENDERCODE              = dataObj.getText("GENDERCODE", i);					//성별코드
					String sCOMPANY                 = dataObj.getText("COMPANY", i);					//직장명
					String sDEPTNAME                = dataObj.getText("DEPTNAME", i);					//부서명
					String sPOSITION                = dataObj.getText("POSITION", i);					//직위
					String sOCCUPATIONTYPECODE      = dataObj.getText("OCCUPATIONTYPECODE", i);			//직업구분코드
					String sISHIGHASSET             = dataObj.getText("ISHIGHASSET", i);				//고액자산가여부
					String sCEONAME                 = dataObj.getText("CEONAME", i);					//대포자명
					String sBIZNO                   = dataObj.getText("BIZNO", i);						//사업자등록번호
					String sKSICCODE                = dataObj.getText("KSICCODE", i);					//업종코드
					//~~~~~ 개인 END ~~~~~

					//~~~~~ 법인 START ~~~~~
					String sBIZADDRESS              = dataObj.getText("BIZADDRESS", i);					//주소(사업체사업장)
					String sBIZADDRESSZIPCODE       = dataObj.getText("BIZADDRESSZIPCODE", i);			//우편번호(사업체사업장)
					String sBIZTELNO                = dataObj.getText("BIZTELNO", i);					//전화번호(사업체사업장)
					String sHOMEPAGEURL             = dataObj.getText("HOMEPAGEURL", i);				//홈페이지주소
					String sBIZSCALECODE            = dataObj.getText("BIZSCALECODE", i);				//기업규모코드
					String sISBANKINGORGAN          = dataObj.getText("ISBANKINGORGAN", i);				//금융기관여부
					String sISNONPROFITCORP         = dataObj.getText("ISNONPROFITCORP", i);			//비영리법인여부
					String sISNATIONALPUBLICGROUP   = dataObj.getText("ISNATIONALPUBLICGROUP", i);		//국가공공단체여부
					String sISSTOCKLIST             = dataObj.getText("ISSTOCKLIST", i);				//상장여부
					//~~~~~ 법인 END ~~~~~

					String sINDV_CORP_CCD           = dataObj.getText("INDV_CORP_CCD", i);				//개인법인구분코드

					//필수체크
					if(("").equals(sREALNUMBER)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailUser[0]+msg_notNull);
					}
					if(("").equals(sREALNUMBERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailUser[1]+msg_notNull);
					}
					if(("").equals(sNATIONALITYCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailUser[4]+msg_notNull);
					}
					if(("").equals(sADDRESSZIPCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailUser[8]+msg_notNull);
					}

					//KOFIU 보고코드 체크
					String[] chkCodes = {"REALNUMBERCODE"};
					String[] chkCodeDatas = {sREALNUMBERCODE};
					String[] chkCodeNames = {label_DetailUser[1]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);

					System.out.println("sINDV_CORP_CCD"+ sINDV_CORP_CCD);
					if(("1").equals(sINDV_CORP_CCD)){ //개인
						//1,2 체크
						if(!("").equals(sGENDERCODE) &&!("1").equals(sGENDERCODE) && !("2").equals(sGENDERCODE)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[26]+msg_null+"(1 or 2)");
						}
						//직업구분코드
						if(("").equals(sOCCUPATIONTYPECODE)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[16]+msg_notNull);
						}
						//Y, N 체크
						if(!("Y").equals(sISHIGHASSET) && !("N").equals(sISHIGHASSET)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[27]+msg_null+"(Y or N)");
						}

						//KOFIU 보고코드 체크
						String[] chkCodes2 = {"OCCUPATIONTYPECODE"};
						String[] chkCodeDatas2 = {sOCCUPATIONTYPECODE};
						String[] chkCodeNames2 = {label_DetailUser[16]};
						outputLog = getLogCheckCode(chkCodes2,chkCodeDatas2,chkCodeNames2,outputLog,msg_title);

					}else{ //법인

						//업종코드
						if(("").equals(sKSICCODE)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[18]+msg_notNull);
						}

						//Y, N 체크
						if(!("Y").equals(sISBANKINGORGAN) && !("N").equals(sISBANKINGORGAN)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[28]+msg_null+"(Y or N)");
						}
						if(!("Y").equals(sISNONPROFITCORP) && !("N").equals(sISNONPROFITCORP)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[29]+msg_null+"(Y or N)");
						}
						if(!("Y").equals(sISNATIONALPUBLICGROUP) && !("N").equals(sISNATIONALPUBLICGROUP)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[30]+msg_null+"(Y or N)");
						}
						if(!("Y").equals(sISSTOCKLIST) && !("N").equals(sISSTOCKLIST)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailUser[31]+msg_null+"(Y or N)");
						}


						if(!("").equals(sBIZSCALECODE)){
							String[] chkCodes2 = {"BIZSCALECODE"};
							String[] chkCodeDatas2 = {sBIZSCALECODE};
							String[] chkCodeNames2 = {label_DetailUser[23]};
							outputLog = getLogCheckCode(chkCodes2,chkCodeDatas2,chkCodeNames2,outputLog,msg_title);
						}
					}

					//자릿수체크
					//"실명번호","실명번호구분코드","실명번호구분명","성명","국가코드","전화번호","핸드폰번호","주소","우편번호","주소(직장)",
					//"우편번호(직장)","생년월일","직장명","부서명","직위","대표자명","직업구분코드","사업자등록번호","업종코드(KSIC)",
					//"주소(사업장)","우편번호(사업장)","전화번호(사업장)","홈페이지주소","기업규모코드"
					String[] chkSizeData = {sREALNUMBER,sREALNUMBERCODE,sREALNUMBERTYPENAME,sNAME,sNATIONALITYCODE,sPHONE,sPHONEHANDPHONE,sADDRESS,sADDRESSZIPCODE,sADDRESSCOMPANY,
							                sADDRESSCOMPANYZIPCODE,sBIRTHDAY,sCOMPANY,sDEPTNAME,sPOSITION,sCEONAME,sOCCUPATIONTYPECODE,sBIZNO,sKSICCODE,
							                sBIZADDRESS,sBIZADDRESSZIPCODE,sBIZTELNO,sHOMEPAGEURL,sBIZSCALECODE};
					String[] chkSizeName = {label_DetailUser[0],label_DetailUser[1],label_DetailUser[2],label_DetailUser[3],label_DetailUser[4],label_DetailUser[5],label_DetailUser[6],label_DetailUser[7],label_DetailUser[8],label_DetailUser[9],
											label_DetailUser[10],label_DetailUser[11],label_DetailUser[12],label_DetailUser[13],label_DetailUser[14],label_DetailUser[15],label_DetailUser[16],label_DetailUser[17],label_DetailUser[18],
											label_DetailUser[19],label_DetailUser[20],label_DetailUser[21],label_DetailUser[22],label_DetailUser[23]};
					int[] chkSize = {15,2,30,60,2,25,25,200,6,200,
									 6,8,60,60,60,60,2,15,5,
									 200,6,25,200,2};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

				}
			}
			//~~~~~ 거래자 END ~~~~~

			//~~~~~ 계좌 START ~~~~~
			if(("DetailAccount").equals(gubn)){
				msg_title = "[Account]";
				for(int i = 0; i < dataObj.getCount("ACCOUNTNUMBER"); i++){

					String sORGNAMECODE                = dataObj.getText("ORGNAMECODE", i);					//금융기관코드
					String sBRANCHOFFICE               = dataObj.getText("BRANCHOFFICE", i);				//지점명
					String sBRANCHOFFICECODE           = dataObj.getText("BRANCHOFFICECODE", i);			//지점코드
					String sBRANCHOFFICEZIPCODE        = dataObj.getText("BRANCHOFFICEZIPCODE", i);			//우편번호(지점)
					String sACCOUNTNUMBER              = dataObj.getText("ACCOUNTNUMBER", i);				//계좌번호
					String sREGDATE                    = dataObj.getText("REGDATE", i);						//게좌개설일
					String sACCOUNTUSER                = dataObj.getText("ACCOUNTUSER", i);					//계좌주실명번호
					String sACCOUNTUSERCODE            = dataObj.getText("ACCOUNTUSERCODE", i);				//실명번호구분코드(계좌주)
					String sAGENTFLAG                  = dataObj.getText("AGENTFLAG", i);					//대리인존재여부
					String sAGENTUSER                  = dataObj.getText("AGENTUSER", i);					//대리인실명번호
					String sAGENTUSERCODE              = dataObj.getText("AGENTUSERCODE", i);				//실명번호구분코드(대리인)
					String sACCOUNTOPENPURPOSE         = dataObj.getText("ACCOUNTOPENPURPOSE", i);			//계좌개설목적
					String sACCOUNTOPENPURPOSECODE     = dataObj.getText("ACCOUNTOPENPURPOSECODE", i);		//계좌개설목적코드

					//필수체크
					if(("").equals(sORGNAMECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[0]+msg_notNull);
					}
					if(("").equals(sBRANCHOFFICECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[2]+msg_notNull);
					}
					if(("").equals(sBRANCHOFFICEZIPCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[3]+msg_notNull);
					}
					if(("").equals(sACCOUNTUSERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[7]+msg_notNull);
					}
					if(("").equals(sACCOUNTOPENPURPOSECODE)){
						outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[12]+msg_notNull);
					}

					if(("Y").equals(sAGENTFLAG)){
						if(("").equals(sAGENTUSERCODE)){
							outputLog.add("ERR_CTNT",msg_title+label_DetailAccount[10]+msg_notNull);
						}
					}

					//자릿수체크
					//"금융기관코드","지점명","지점코드","지점우편번호","계좌번호","계좌개설일","계좌주실명번호","계좌주실명번호구분","대리인존재여부","대리인실명번호",
					//"대리인실명번호구분","계좌개설목적명","계좌개설목적코드"
					String[] chkSizeData = {sORGNAMECODE,sBRANCHOFFICE,sBRANCHOFFICECODE,sBRANCHOFFICEZIPCODE,sACCOUNTNUMBER,sREGDATE,sACCOUNTUSER,sACCOUNTUSERCODE,sAGENTFLAG,sAGENTUSER,sAGENTUSERCODE,sACCOUNTOPENPURPOSE,sACCOUNTOPENPURPOSECODE};
					String[] chkSizeName = {label_DetailAccount[0],label_DetailAccount[1],label_DetailAccount[2],label_DetailAccount[3],label_DetailAccount[4],label_DetailAccount[5],label_DetailAccount[6],label_DetailAccount[7],label_DetailAccount[8],label_DetailAccount[9],
										    label_DetailAccount[10],label_DetailAccount[11],label_DetailAccount[12]};
					int[] chkSize = {6,30,7,6,30,8,15,2,1,15,2,100,2};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"ACCOUNTOPENPURPOSECODE"};
					String[] chkCodeDatas = {sACCOUNTOPENPURPOSECODE};
					String[] chkCodeNames = {label_DetailAccount[12]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);
				}
			}
			//~~~~~ 계좌 END ~~~~~

			//~~~~~ User간의 관계 START ~~~~~
			if(("DetailUserRelation").equals(gubn)){
				msg_title = "[InterUserRelation]";
				for(int i = 0; i < dataObj.getCount("RELATIONCODE"); i++){

					String sRELATIONCODE            = dataObj.getText("RELATIONCODE", i);			//거래자관계코드
					String sPRINCIPALUSER           = dataObj.getText("PRINCIPALUSER", i);			//거래자,계좌주,송/수취계좌주,법인/단체
					String sPRINCIPALUSERCODE       = dataObj.getText("PRINCIPALUSERCODE", i);		//실명번호구분코드(거래자,계좌주,송/수취계좌주,법인/단체)
					String sPARTICIPANTUSER         = dataObj.getText("PARTICIPANTUSER", i);		//관계인
					String sPARTICIPANTUSERCODE     = dataObj.getText("PARTICIPANTUSERCODE", i);	//실명번호구분코드(관계인)
					String sREMARK                  = dataObj.getText("REMARK", i);					//관게명

					//필수체크
					if(("").equals(sRELATIONCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_InterUserRelation[1]+msg_notNull);
					}
					if(("").equals(sPRINCIPALUSER)){
						outputLog.add("ERR_CTNT",msg_title+label_InterUserRelation[2]+msg_notNull);
					}
					if(("").equals(sPRINCIPALUSERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_InterUserRelation[3]+msg_notNull);
					}
					if(("").equals(sPARTICIPANTUSER)){
						outputLog.add("ERR_CTNT",msg_title+label_InterUserRelation[4]+msg_notNull);
					}
					if(("").equals(sPARTICIPANTUSERCODE)){
						outputLog.add("ERR_CTNT",msg_title+label_InterUserRelation[5]+msg_notNull);
					}

					//자릿수체크
					//"거래자관계명","거래자관계코드","계좌주실명번호","계좌주실명번호구분","관계인실명번호","관계인실명번호구분","관계명"
					String[] chkSizeData = {sRELATIONCODE,sPRINCIPALUSER,sPRINCIPALUSERCODE,sPARTICIPANTUSER,sPARTICIPANTUSERCODE,sREMARK};
					String[] chkSizeName = {label_InterUserRelation[1],label_InterUserRelation[2],label_InterUserRelation[3],label_InterUserRelation[4],label_InterUserRelation[5],label_InterUserRelation[6]};
					int[] chkSize = {10,15,2,15,2,100};
					outputLog = getLogCheckBytes(chkSizeData,chkSizeName,chkSize,outputLog,msg_title);

					//KOFIU 보고코드 체크
					String[] chkCodes = {"RELATIONCODE"};
					String[] chkCodeDatas = {sRELATIONCODE};
					String[] chkCodeNames = {label_InterUserRelation[0]};
					outputLog = getLogCheckCode(chkCodes,chkCodeDatas,chkCodeNames,outputLog,msg_title);

					//금칙어체크
					String[] chkWordData = {sREMARK};
					String[] chkWordName = {label_InterUserRelation[6]};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);
				}
			}
			//~~~~~ User간의 관계 END ~~~~~

			//~~~~~ 첨부파일 START ~~~~~
			if(("FileAttach").equals(gubn)){
				msg_title = "[FileAttach]";
				for(int i = 0; i < dataObj.getCount("FILENAME"); i++){

					String sFILENAME = dataObj.getText("FILENAME", i);

					//금칙어체크
					String[] chkWordData = {sFILENAME};
					String[] chkWordName = {"파일명"};
					outputLog = getLogCheckWords(chkWordData,chkWordName,outputLog,msg_title);

				}
			}
			//~~~~~ 첨부파일 END ~~~~~

		} catch (NumberFormatException e) {
			Log.logAML(Log.ERROR, this, "doCheckValue(NumberFormatException)", e);
		} catch(IOException e) {
			Log.logAML(Log.ERROR, this, "doCheckValue(IOException)", e);
		} catch(RuntimeException e) {
			Log.logAML(Log.ERROR, this, "doCheckValue(RuntimeException)", e);
		}

		return outputLog;
 	}

 	public boolean isDigit(String digit) {
		if (digit == null) {
			return false;
		}
		char chars[] = digit.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (!Character.isDigit(chars[i])) {
				return false;
			}
		}

		return true;
	}

	public String checkBytes(String str, String strNm, int limitLen) throws UnsupportedEncodingException {
		if (str == null) {
			return "";
		}

		try {

		int valBytes = str.getBytes("EUC-KR").length;
		if(valBytes > limitLen){
			return strNm+" 내용의 길이가 초과되었습니다."+limitLen+"자 초과.("+valBytes+")";
		}
		} catch (UnsupportedEncodingException ee) {
			Log.logAML(Log.ERROR, this, "checkBytes", ee.getMessage());
		}

		return "";
	}


	public DataObj getLogCheckBytes(String[] datas, String[] names, int[] limitSizes, DataObj outputLog, String pMsg) throws UnsupportedEncodingException {
		String sRtnVal = "";
		for(int i = 0; i < datas.length; i++){
			sRtnVal = checkBytes(datas[i],names[i], limitSizes[i]);
			if(!("").equals(sRtnVal)){
		    		outputLog.add("ERR_CTNT",sRtnVal+pMsg);
		    	}
		}

		return outputLog;
	}

	/**
	 * KOFIU 보고코드 유효성 체크
	 * @param chkCodes  : 유효성체크할 코드항목
	 * @param datas
	 * @param names
	 * @param outputLog
	 * @return
	 *
	 *
	 *
	 * 거래채널코드 : SELECT TRNSFRM_CD FROM NIC95B WHERE CD = 'A033'
	 *
	 * 메시지 : (ex)보고기관코드(413x)->KOFIU 보고코드 유효성 에러
	 *
	 */
	public DataObj getLogCheckCode(String[] chkCodes, String[] datas, String[] names, DataObj outputLog, String pMsg) {

		String[] kofiuCodes = null;
		String sChkCode = "";
		String sMsg = "->KOFIU 보고코드 유효성 에러";
		String sMsg_2 = "";
		int isCodeCnt = 0;
		
		for(int i = 0; i < datas.length; i++){
			isCodeCnt = 0;
			sChkCode = chkCodes[i];
			
			//Log.logAML(Log.DEBUG, null, "getLogCheckCode START>>>>", sChkCode);
			
			if(("ORGNAMECODE").equals(sChkCode)){
				kofiuCodes = arrORGNAMECODE;
			}else if(("MESSAGETYPECODE").equals(sChkCode)){
				kofiuCodes = arrMESSAGETYPECODE;
			}else if(("QUESTIONTITLECODE").equals(sChkCode)){
				kofiuCodes = arrQUESTIONTITLECODE;
			}else if(("QUESTIONCODE").equals(sChkCode)){
				kofiuCodes = arrQUESTIONCODE;
			}else if(("CHANNELCODE").equals(sChkCode)){
				kofiuCodes = arrCHANNELCODE;
			}else if(("MEANCODE").equals(sChkCode)){
				kofiuCodes = arrMEANCODE;
			}else if(("METHODCODE").equals(sChkCode)){
				kofiuCodes = arrMETHODCODE;
			}else if(("GOODSCODE").equals(sChkCode)){
				kofiuCodes = arrGOODSCODE;
			}else if(("RELATIONROLECODE").equals(sChkCode)){
				kofiuCodes = arrRELATIONROLECODE;
			}else if(("REALNUMBERCODE").equals(sChkCode)){
				kofiuCodes = arrREALNUMBERCODE;
			}else if(("ACCOUNTROLECODE").equals(sChkCode)){
				kofiuCodes = arrACCOUNTROLECODE;
			}else if(("ACCOUNTHOLDERTYPECODE").equals(sChkCode)){
				kofiuCodes = arrACCOUNTHOLDERTYPECODE;
			}else if(("CHARGEMETHOD_CD").equals(sChkCode)){
				kofiuCodes = arrCHARGEMETHOD_CD;
			}else if(("ACCOUNTOPENPURPOSECODE").equals(sChkCode)){
				kofiuCodes = arrACCOUNTOPENPURPOSECODE;
			}else if(("RELATIONCODE").equals(sChkCode)){
				kofiuCodes = arrRELATIONCODE;
			}else if(("OCCUPATIONTYPECODE").equals(sChkCode)){
				kofiuCodes = arrOCCUPATIONTYPECODE;
			}else if(("BIZSCALECODE").equals(sChkCode)){
				kofiuCodes = arrBIZSCALECODE;			
			}else if(("SECURITIESTYPECODE").equals(sChkCode)){
				kofiuCodes = arrSECURITIESTYPECODE;
			}else if(("ISSUERDIVCODE").equals(sChkCode)){
				kofiuCodes = arrISSUERDIVCODE;
			}else if(("PURPOSECODE").equals(sChkCode)){
				kofiuCodes = arrPURPOSECODE;
			}
						
			for(int j = 0; j < kofiuCodes.length; j++){				
				if(datas[i].equals(kofiuCodes[j])){
					isCodeCnt++;
				}
			}
			
			if(isCodeCnt == 0){
				sMsg_2 = names[i]+"("+datas[i]+")"+sMsg;
				outputLog.add("ERR_CTNT",sMsg_2+pMsg);
			}
		}
					
		return outputLog;
	}

	/*
     * 금칙어체크   (<,>,&,',",;)
     */
	public String checkWords(String sWord, String colName) throws StringIndexOutOfBoundsException {
    	String rtnVal = "";
    	int chkWord = 0;

    	if (sWord == null) {return "";}

    	for(int k=0; k<sWord.length(); k++){
    		if(sWord.length()-k>4){
    			if("&amp;".equals(sWord.substring(k,k+5))){
    				chkWord++;
    			}
    		}
    		if(sWord.length()-k>3){
    			if("&lt;".equals(sWord.substring(k,k+4)) || "&gt;".equals(sWord.substring(k,k+4))){
    				chkWord++;
    			}
    		}
    		if(sWord.length()-k>0){
    			if( "'".equals(sWord.substring(k,k+1)) || "\"".equals(sWord.substring(k,k+1)) || ";".equals(sWord.substring(k,k+1))
    					|| "<".equals(sWord.substring(k,k+1)) || ">".equals(sWord.substring(k,k+1)) || "&".equals(sWord.substring(k,k+1))
    					|| "\\".equals(sWord.substring(k,k+1)) ){

    				chkWord++;
    			}
    		}
    	}

    	//if(chkWord > 0) rtnVal = colName+" 내용에 금칙어가 포함됨. 확인바랍니다=>"+sWord;
    	if(chkWord > 0) {rtnVal = colName+" 내용에 금칙어가 포함됨. 확인바랍니다.";}

    	return rtnVal;
    }

 	public DataObj getLogCheckWords(String[] datas, String[] names, DataObj outputLog, String pMsg) throws StringIndexOutOfBoundsException {
		String sRtnVal = "";
		for(int i = 0; i < datas.length; i++){
			sRtnVal = checkWords(datas[i],names[i]);
			if(!("").equals(sRtnVal)){
   	    		outputLog.add("ERR_CTNT",sRtnVal+pMsg);
   	    	}
		}

		return outputLog;
	}

	/**
	 * 보고항목체크로그_NIC80B_LOG(NIC80B_LOG) 테이블에 SELECT 한다.
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public DataObj doSearchFiuLog(DataObj input) throws AMLException {

		DataObj output = new DataObj();
		DataObj output_01 = null;

		DataSet gdRes = null;

		try {

			output_01 = MDaoUtilSingle.getData("AML_20_01_01_90_doSearchFiuLog", input);

			if ( output_01.getCount("SQ") > 0 ) {
				gdRes = Common.setGridData(output_01);
			} else {
				output.put("ERRMSG", MessageHelper.getInstance().getMessage("0001", input.getText("LANG_CD"), "조회된 정보가 없습니다."));
			}

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "doSearchFiuLog", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

}
package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

public class AML_20_01_01_30 extends GetResultObject
{
  private static AML_20_01_01_30 instance = null;

  public static AML_20_01_01_30 getInstance()
  {
    if (instance == null) {
      instance = new AML_20_01_01_30();
    }
    return instance;
  }

  public DataObj doSearch(DataObj input) throws AMLException {
    DataObj output = new DataObj();
    DataSet gdRes = null;
    try
    {
            
      DataObj dbOut = MDaoUtilSingle.getData("AML_20_01_01_30_doSearch", input);

      gdRes = Common.setGridData(dbOut);

      output.put("ERRCODE", "00000");
      output.put("ERRMSG", gdRes.getRowCount() > 0 ? 
        MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"), "조회 되었습니다.") : 
        MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"), "자료가 존재하지 않습니다."));
      output.put("gdRes", gdRes);
    } catch (AMLException e) {
      Log.logAML(1, this, "doSearch", e.toString());
      output.clear();
      output.put("ERRCODE", "00001");
      output.put("ERRMSG", e.getMessage());
      output.put("WINMSG", e.getMessage());
    }
    return output;
  } 
  
  public DataObj doSearchProdList(DataObj input) throws AMLException {
    DataObj output = new DataObj();
    DataSet gdRes = null;
    try
    {
      
      DataObj dbOut = MDaoUtilSingle.getData("AML_11_06_07_02_doSearchProdList", input);

      gdRes = Common.setGridData(dbOut);

      output.put("ERRCODE", "00000");
      output.put("ERRMSG", gdRes.getRowCount() > 0 ? 
        MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"), "조회 되었습니다.") : 
        MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"), "자료가 존재하지 않습니다."));
      output.put("gdRes", gdRes);
    } catch (AMLException e) {
      Log.logAML(1, this, "doSearchProdList", e.toString());
      output.clear();
      output.put("ERRCODE", "00001");
      output.put("ERRMSG", e.getMessage());
      output.put("WINMSG", e.getMessage());
    }
    return output;
  } 
  
  public DataObj doSearchCustList(DataObj input) throws AMLException {
	  DataObj output = new DataObj();
	    DataSet gdRes = null;
	    try
	    {
	      
	      DataObj dbOut = MDaoUtilSingle.getData("AML_20_01_01_30_doSearchCustList", input);

	      gdRes = Common.setGridData(dbOut);

	      output.put("ERRCODE", "00000");
	      output.put("ERRMSG", gdRes.getRowCount() > 0 ? 
	        MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"), "조회 되었습니다.") : 
	        MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"), "자료가 존재하지 않습니다."));
	      output.put("gdRes", gdRes);
	    } catch (AMLException e) {
	      Log.logAML(1, this, "doSearchCustList", e.toString());
	      output.clear();
	      output.put("ERRCODE", "00001");
	      output.put("ERRMSG", e.getMessage());
	      output.put("WINMSG", e.getMessage());
	    }
	    return output;
  }
  
  public DataObj doSearchKSICList(DataObj input) throws AMLException {
	  DataObj output = new DataObj();
	    DataSet gdRes = null;
	    try
	    {
	      
	      DataObj dbOut = MDaoUtilSingle.getData("AML_20_01_01_30_doSearchKSICList", input);

	      gdRes = Common.setGridData(dbOut);

	      output.put("ERRCODE", "00000");
	      output.put("ERRMSG", gdRes.getRowCount() > 0 ? 
	        MessageHelper.getInstance().getMessage("0043", input.getText("LANG_CD"), "조회 되었습니다.") : 
	        MessageHelper.getInstance().getMessage("0039", input.getText("LANG_CD"), "자료가 존재하지 않습니다."));
	      output.put("gdRes", gdRes);
	    } catch (AMLException e) {
	      Log.logAML(1, this, "doSearchKSICList", e.toString());
	      output.clear();
	      output.put("ERRCODE", "00001");
	      output.put("ERRMSG", e.getMessage());
	      output.put("WINMSG", e.getMessage());
	    }
	    return output;
  }
  
}
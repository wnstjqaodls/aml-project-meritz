package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import java.util.HashMap;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* STR 계좌상세
* STR 口座詳細
* STR Account deatiled.
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_01_01_07 extends GetResultObject {

	private static AML_20_01_01_07 instance = null;

	/**
	 * getInstance
	 * @return AML_20_01_01_07
	 */
	public static AML_20_01_01_07 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_01_01_07();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   STR Alert화면 계좌상세 조회(AML_20_01_01_07.jsp)
	 * STRアラート画面での口座詳細の照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(계좌상세 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(口座詳細の照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj setStrSubPopMain07(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;
		try {
			String query_id = "";

			HashMap inputParam = new HashMap();
			inputParam.put("SSPS_DL_CRT_DT", input.getText("SSPS_DL_CRT_DT"));
			inputParam.put("SSPS_DL_ID", input.getText("SSPS_DL_ID"));

			SessionAML sess = (SessionAML) input.get("SessionAML");
			if ( "Y".equals(sess.getsAML_MASTER_BRANCH()) ) {
				query_id = "AML_20_01_01_07_setStrSubPopMain07_BONJUM";
			} else {
				query_id = "AML_20_01_01_07_setStrSubPopMain07_BONJUM";
			}

			output = MDaoUtilSingle.getData(query_id, inputParam);
			gdRes = Common.setGridData(output);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		} catch (Exception e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *   STR Alert화면 계좌상세 Sub 조회(AML_20_01_01_07.jsp)
	 * STRアラート画面での口座詳細サブ照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(계좌상세 Sub 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(口座詳細サブ照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj setStrSubPopSub07(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			String query_id = "AML_20_01_01_07_setStrSubPopSub07";

			output = MDaoUtilSingle.getData(query_id, input);
            gdRes = Common.setGridData( output);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "setStrSubPopSub07", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}
	public DataObj searchTsusRjctHistory(DataObj input) {
        DataObj output = new DataObj();
        DataSet gdRes = null;
        try {
            String query_id = "AML_20_01_01_07_searchTsusRjctHistory";

            output = MDaoUtilSingle.getData(query_id, input);
            gdRes = Common.setGridData (output );

            output.put("ERRCODE", "00000");
            output.put("gdRes", gdRes);

        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "searchTsusRjctHistory", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.toString());
        }

        return output;
    }
}

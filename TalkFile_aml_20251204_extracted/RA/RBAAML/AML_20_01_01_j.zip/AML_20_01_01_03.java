package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtilSingle;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.express.server.helper.MessageHelper;

import jspeed.base.util.StringHelper;

import com.gtone.aml.user.SessionAML;

import kr.co.itplus.jwizard.dataformat.DataSet;
import com.ss.common.util.security.damo.damoManager;

/**
*<pre>
* STR 결재 상세
* STR決裁の詳細
* STR Approval Details
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_01_01_03 extends GetResultObject {

    private static AML_20_01_01_03 instance = null;

    /**
     * getInstance
     * @return AML_20_01_01_03
     */
    public static AML_20_01_01_03 getInstance() {
        if (instance == null) {
            instance = new AML_20_01_01_03();
        }
        return instance;
    }

    
    /**
     * <pre>
     *   STR 지점 처리 내역정보 조회
     * STR支店処理詳細の照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(STR 지점 처리 내역정보 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(STR支店処理詳細情報 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */    
    public DataObj getSearch_StrMainPOP01(DataObj input) {
        DataObj output = new DataObj();
        DataObj output_01 = null;
        DataSet gdRes = null;
        try {

            String SSPS_DL_ID         = input.getText("SSPS_DL_ID").trim();    
            String SSPS_DL_CRT_DT     = input.getText("SSPS_DL_CRT_DT").trim();    
                        
            
            output_01 = JDaoUtilSingle.getData("AML_20_01_01_02_getSearch_StrMainPOP01"
                    , new Object[]{SSPS_DL_ID
                            , SSPS_DL_CRT_DT}
                    );            
            
            gdRes = Common.setGridData(output_01);

            output.put("ERRCODE", "00000");
            output.put("gdRes", gdRes);

        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.toString());
        } finally {
            output_01.clear();
        }

        return output;
    }  

    /**
     * <pre>
     *   의심내역기준정보 조회
     * 疑い基準情報の照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(의심내역기준정보 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(疑い基準情報 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */
    @SuppressWarnings("unused")
    public DataObj getSuspication_List(DataObj input) {

        DataObj output = new DataObj();
        DataObj GROUP     = new DataObj();
        DataObj ELEMENT = new DataObj();
        try {

            String SSPS_DL_CRT_DT     = input.getText("SSPS_DL_CRT_DT").trim();

        	output = MDaoUtilSingle.getData("AML_20_01_01_03_NIC69B_getList", new DataObj());

            for (int i = 0 ;i < output.getCount("DOBT_TYP_KND_CD") ; i++) {
                if(("T").equals(output.getText("GUBUN",i))) {
                    ELEMENT = new DataObj();
                    GROUP.add("DOBT_TYP_KND_CD",output.getText("DOBT_TYP_KND_CD",i));
                    GROUP.add("DOBT_TYP_KND_NM",output.getText("DOBT_TYP_KND_NM",i));
                    GROUP.add("POSITION",( GROUP.getCount("DOBT_TYP_KND_CD")%2 == 0 ? "L":"R"));
                }else {
                    ELEMENT.add("DOBT_TYP_KND_CD",output.getText("DOBT_TYP_KND_CD",i));
                    ELEMENT.add("DOBT_TYP_KND_NM",output.getText("DOBT_TYP_KND_NM",i));
                }
                if(i!=0 && (("000").equals(output.getText("HG_RNK_CD",i-1))) ) {
                    GROUP.add("ELEMENT",ELEMENT);
                }
            }


        } catch (AMLException e) {
        	Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
        	output = new DataObj();
        	output.put("ERRCODE", "00001");
        	output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
        }
        return GROUP;
    }


    /**
     * <pre>
     *   혐의거래의심정보 조회 (NIC67B, NIC68B)
     * 疑わしい取引の疑い情報の照会
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(혐의거래의심정보 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(疑わしい取引の疑い情報 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */
    @SuppressWarnings({ "unused", "rawtypes" })
    public DataObj getSuspication(
             DataObj             input
    ){
        DataObj         output = new DataObj();
        DataObj         output1 = null;
        DataObj         output2 = null;
        DataObj         output3 = null;
        DataObj         output4 = null;
        DataObj         output5 = null;
        DataObj         output6 = null;
        DataObj         output7 = null;
        DataSet gdRes     = null;
        damoManager damo = new damoManager();
        
        try {
            String MASTER_BRANCH = input.getText("MASTER_BRANCH");
            String GUBUN         = input.getText("GUBUN"        );// Head Office/Branch
            String ROLE_ID = ((SessionAML)input.get("SessionAML")).getsAML_ROLE_ID();

            if(("B").equals(GUBUN)) {
           // [1] Head Office
//            	output6=MDaoUtilSingle.getData("AML_20_01_01_03_NIC88B_getCount", input);
//            	if(output6.getInt("CNT")>=1){
//            		output1= MDaoUtilSingle.getData("AML_20_01_01_03_NIC67B_getSearch0", input);
//                    output2= MDaoUtilSingle.getData("AML_20_01_01_03_NIC68B_getSearch", input);
//            	}else{
//            		//본점에서만 결재하는 경우, NIC88B(지점의심내역)이 없음
//            		output1= MDaoUtilSingle.getData("AML_20_01_01_03_NIC67B_getSearch2", input);
//                    output2= MDaoUtilSingle.getData("AML_20_01_01_03_NIC68B_getSearch2", input);
//            	}
            	output1= MDaoUtilSingle.getData("AML_20_01_01_03_NIC67B_getSearch", input);
                output2= MDaoUtilSingle.getData("AML_20_01_01_03_NIC68B_getSearch2", input);
            }else{
            // [2] Branch
                output1= MDaoUtilSingle.getData("AML_20_01_01_03_NIC88B_getSearch", input);
                output2= MDaoUtilSingle.getData("AML_20_01_01_03_NIC89B_getSearch", input);
            }
            if(output1.getCount("ITEM_CNTNT1") > 0 ) {

                String[] suspicationList = new String[]{"ITEM_CNTNT1","ITEM_CNTNT2","ITEM_CNTNT3","ITEM_CNTNT4","ITEM_CNTNT5","ITEM_CNTNT6"
                        , "XCL_RSN_CNTNT", "DNY_RSN_CNTNT", "RPR_RSN_CNTNT", "ATT_FILE_NM", "DOBT_DL_GRD_CD", "SEND_DOC_NM", "RE_DOC", "AI_RPR_RSN_CNTNT" };

                for(int i = 0 ; i < suspicationList.length ; i++) {
                    output.add("GUBUN"    ,GUBUN);
                    if(suspicationList[i].equals("DOBT_DL_GRD_CD")) {
                        output.add("TYPE"    ,"RADIO");
                    }
                    else {
                        output.add("TYPE"    ,"TEXT");
                    }

                    // RPR_RSN_CNTNT:종합의견 , XCL_RSN_CNTNT: 보고제외 사유
                    if ("XCL_RSN_CNTNT".equals(suspicationList[i])) {
                    	// 66B에 사유데이터를 조회해서 아웃풋에 넣어준다 20170308 KEOL
                    	output4 = MDaoUtilSingle.getData("AML_20_01_01_03_getNIC66B_XCL_RSN_CNTNT", input);
                        output.add("NAME", GUBUN + "_XCL_RSN_CNTNT");

                     // 66B.OK_CCD값이 보고제외상태일때만 화면에 값을 넘겨준다.
                        if ("2".equals(output4.getText("OK_CCD")))
                            output.add("VALUE", ("0".equals(output4.getText("XCL_RSN_CNTNT"))) ? "" : output4.getText("XCL_RSN_CNTNT"));
                        else {
                        	if("4".equals(ROLE_ID)) // 담당자에게 반려된 경우 사유를 보여준다
                        		output.add("VALUE", ("0".equals(output4.getText("XCL_RSN_CNTNT"))) ? "" : output4.getText("XCL_RSN_CNTNT"));
                        	else
                        		output.add("VALUE", "");
                        }
                    } else if ("RPR_RSN_CNTNT".equals(suspicationList[i])) {
                        output.add("NAME", GUBUN + "_RPR_RSN_CNTNT");
                        output.add("VALUE", damo.pDecrypt(output1.getText(suspicationList[i])));
                    } else if ("AI_RPR_RSN_CNTNT".equals(suspicationList[i])) {
                        output.add("NAME", GUBUN + "_AI_RPR_RSN_CNTNT_BATCH");
                        output.add("VALUE", output1.getText(suspicationList[i]));
                    } else if ("DNY_RSN_CNTNT".equals(suspicationList[i])) {
                    	 output.add("NAME", GUBUN + "_DNY_RSN_CNTNT");
//                    	 output.add("VALUE", output4.getText("DNY_RSN_CNTNT"));
                    	 output.add("VALUE", (output4 != null ? output4.getText("DNY_RSN_CNTNT"):null));
                    } else {
                        output.add("NAME", GUBUN + "_" + suspicationList[i]);
                        output.add("VALUE", output1.getText(suspicationList[i]));
                    }
                    output.add("CODE", "");
                    output.add("ETC", "");
                }

                for(int i = 0 ; i < output2.getCount("DOBT_TYP_KND_CD") ; i++) {
                    output.add("GUBUN"    ,GUBUN);
                    output.add("TYPE"    ,"CHECK");
                    output.add("NAME"    ,GUBUN+"_DOBT_TYP_KND_CD");
                    output.add("CODE"    ,output2.getText("DOBT_TYP_KND_CD",i));
                    output.add("VALUE"    ,output2.getText("F_CCD",i));
                    output.add("ETC"    ,output2.getText("ETC_CNTNT",i));
                }

            // [3-2]When not set to default
            } else {

            	//output5   = MDaoUtilSingle.getData("AML_20_01_10_03_GetSuspication",input);  	   //의심내역 추가정보
            	//output7   = MDaoUtilSingle.getData("AML_20_01_10_03_TotalPayment",input);  	   //최근3개월 거래규모: 총입금/총출금

                String SSPS_DL_CRT_DT     = input.getText("SSPS_DL_CRT_DT");

                SSPS_DL_CRT_DT             = SSPS_DL_CRT_DT.substring(0, 4)+"-"+SSPS_DL_CRT_DT.substring(4, 6)+"-"+SSPS_DL_CRT_DT.substring(6, 8);
                String DL_P_NM             = reSultValue(input.getText("DL_P_NM"));
                String MN_DL_BRN_CD_NM     = input.getText("MN_DL_BRN_CD_NM");
                String TRIG_CTNT           = input.getText("TRIG_CTNT");
                //거래자명
                output.add("GUBUN"    ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT1");
                output.add("CODE"    ,"");
                output.add("VALUE"    ,DL_P_NM);
                output.add("ETC"    ,"");

                //추출일자
                output.add("GUBUN"    ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT2");
                output.add("CODE"    ,"");
                output.add("VALUE"    ,SSPS_DL_CRT_DT);
                output.add("ETC"    ,"");

                //거래발생장소
                output.add("GUBUN"    ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT3");
                output.add("CODE"    ,"");
                output.add("VALUE"    ,MN_DL_BRN_CD_NM);
                output.add("ETC"    ,"");



                output1= MDaoUtilSingle.getData("AML_20_01_01_03_NIC81B_getSearch", (HashMap)input);
                output2= MDaoUtilSingle.getData("AML_20_01_01_03_NIC66B_getSearch", input);
                String DOBT_TYP_KND_NM = "";
                String PRDT_NAME = output2.getText("PRDT_NAME");
                String sspsCd = input.getText("SSPS_TYP_CD");

                for(int i = 0 ; i < output1.getCount("DOBT_TYP_KND_CD") ; i++) {

                    DOBT_TYP_KND_NM = DOBT_TYP_KND_NM + (i==0?"":", ") +output1.getText("DOBT_TYP_KND_NM",i);

                    output.add("GUBUN"    ,GUBUN);
                    output.add("TYPE"    ,"CHECK");
                    output.add("NAME"    ,GUBUN+"DOBT_TYP_KND_CD");
                    output.add("CODE"    ,output1.getText("DOBT_TYP_KND_CD",i));
                    output.add("VALUE"    ,"Y");
                    output.add("ETC"    ,"");
                }

                // Reason for decision
                output.add("GUBUN"    ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT6");
                output.add("CODE"    ,"");
                output.add("VALUE"    ,DOBT_TYP_KND_NM);
                output.add("ETC"    ,"");

             // 20181221 추가
                output.add("GUBUN"   ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT3");	// 거래 발생장소(최근 거래 영업점)
                output.add("CODE"    ,"");
                output.add("VALUE"   ,output2.getText("HANDLNG_BRN_NM"));
                output.add("ETC"     ,"");

                output.add("GUBUN"   ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT4");	// 금융거래 수단(상품)
                output.add("CODE"    ,"");
                output.add("VALUE"   ,output2.getText("DL_WY_NM"));
                output.add("ETC"     ,"");

                output.add("GUBUN"   ,GUBUN);
                output.add("TYPE"    ,"TEXT");
                output.add("NAME"    ,GUBUN+"_ITEM_CNTNT6");	// 혐의거래로 판단한 사유
                output.add("CODE"    ,"");
                output.add("VALUE"   ,output2.getText("BIZ_DESC"));
                output.add("ETC"     ,"");

				///////////////////////////////////////////////////////////////////////////////////////////////////////////
				output.add("GUBUN"   ,GUBUN);
				output.add("TYPE"    ,"TEXT");
				// 66B에 사유데이터를 조회해서 아웃풋에 넣어준다 20170308 KEOL
				output4 = MDaoUtilSingle.getData("AML_20_01_01_03_getNIC66B_XCL_RSN_CNTNT", input);
				output.add("NAME", GUBUN + "_RPR_RSN_CNTNT");

				// 66B.OK_CCD값이 보고제외상태일때만 화면에 값을 넘겨준다.
				if ("2".equals(output4.getText("OK_CCD")))
				output.add("VALUE", ("0".equals(output4.getText("XCL_RSN_CNTNT"))) ? "" : output4.getText("XCL_RSN_CNTNT"));
				else {
				if("4".equals(ROLE_ID)) // 담당자에게 반려된 경우 사유를 보여준다
				output.add("VALUE", ("0".equals(output4.getText("XCL_RSN_CNTNT"))) ? "" : output4.getText("XCL_RSN_CNTNT"));
				else
				output.add("VALUE", "");
				}

				output.add("CODE", "");
				output.add("ETC", "");
				///////////////////////////////////////////////////////////////////////////////////////////////////////////

				output.add("GUBUN"   ,GUBUN);
				output.add("TYPE"    ,"TEXT");
				output.add("NAME"    ,GUBUN+"_TRIG_CTNT");		// 종합의견(혐의트리거)
				output.add("CODE"    ,"");
				output.add("ETC"     ,"");

				String tmp = "";
				String date = SSPS_DL_CRT_DT.substring(0, 4) + "년  " + SSPS_DL_CRT_DT.substring(5, 7) + "월 " + SSPS_DL_CRT_DT.substring(8, 10) + "일";
				if("IIL1".equals(sspsCd)){
				tmp = output2.getText("TRIG_CTNT")
				+ "\n\n"
				+ "(허수성매매주문)\n"
				+ "▶ 보고대상자 "+DL_P_NM+"은 "+date+" 결재된 "+PRDT_NAME+"의 매매 과정에서\n"
				+ "허수성 매매주문을 제출하여 시세에 부당한 영향을 줌.\n"
				+ "이에 관련규정에 따라 0건(0000.00.00-0000.00.00) 수탁거부 조치함\n"
				+ "- 한국거래소 시장감시규정 제4조(공정거래질서 저해행위의 금지)\n\n"
				+ "▶ 시세에 영향을 주기위해 거래 성립 가능성이 희박한 호가를 대량으로 제출하거나  직전가격 또는 최우선 호가의 가격이나 이와 유사한 가격으로 호가를 제출한 후 당해 호가를 반복적으로 정정/취소하는 행위는 자본시장법상 불공정거래에 해당한다고  판단되어 의심스러운 거래로 보고함.";
				}else if("IIL2".equals(sspsCd)){
				tmp = output2.getText("TRIG_CTNT")
				+ "\n\n"
				+ "(통정/가장매매)\n"
				+ "▶ 보고대상자 "+DL_P_NM+"은 "+date+" 결재된 "+PRDT_NAME+"의 매매 과정에서\n"
				+ "본인이 매수/매도를 체결시키는 가장매매주문을 제출함.\n"
				+ "이에 관련규정에 따라 0건(0000.00.00-0000.00.00) 수탁거부 조치함\n"
				+ "- 한국거래소 시장감시규정 제4조(공정거래질서 저해행위의 금지)\n\n"
				+ "▶ 주식의 거래량을 부풀리기 위해 매수와 매도주문을 동시에 제출하여 체결시키는 행위는 자본시장법상 불공정거래에 해당한다고 판단되어 의심스러운 거래로 보고함.";
				}else if("IIL3".equals(sspsCd)){
				tmp = output2.getText("TRIG_CTNT")
				+ "\n\n"
				+ "(예상가관여)\n"
				+ "▶ 보고대상자 "+DL_P_NM+"은 "+date+" 결재된 "+PRDT_NAME+"의 매매 과정에서\n"
				+ "동시호가 시간대에 대량의 매수/매도주문을 제출했다가 정정, 취소하는 행위를 반복하여 예상가의 변동을 초래함.\n"
				+ "이에 관련규정에 의거 0간(0000.00.00-0000.00.00)수탁거부 조치함\n"
				+ "- 한국거래소 시장감시규정 제4조(공정거래질서 저해행위의 금지)\n\n"
				+ "▶ 주가를 변동시키기 위해서 대량의 매매주문을 제출했다가 취소하여 예상가를 변동시키는 행위는 자본시장법상 불공정거래에 해당한다고 판단되어 의심스러운 거래로 보고함.";
				}else if("IIL4".equals(sspsCd)){
				tmp = output2.getText("TRIG_CTNT")
				+ "\n\n"
				+ "(특정종목 매매집중)\n"
				+ "▶ 보고대상자 "+DL_P_NM+"은 "+date+" 결재된 "+PRDT_NAME+"의 매매 과정에서\n"
				+ "보유종목의 주가를 상승시키기 위해 과다하게 매수관여하여 해당종목의 급등을 야기함.\n"
				+ "이에 관련규정에 따라 0간(0000.00.00-0000.00.00) 수탁거부 조치함\n"
				+ "- 한국거래소 시장감시규정 제4조(공정거래질서 저해행위의 금지)\n\n"
				+ "▶ 보유종목의 주가를 상승시킬 목적으로 거래량에 비해 과다한 수량을 지속적으로 매수하면서 며칠째 주가를 상승시키는 행위는 자본시장법상 불공정거래에 해당한다고 판단되어 의심스러운 거래로 보고함.";
				}else if("IIL5".equals(sspsCd)){
				tmp = output2.getText("TRIG_CTNT")
				+ "\n\n"
				+ "(종가관여 과대주문)\n"
				+ "▶ 보고대상자 "+DL_P_NM+"은 "+date+" 결재된 "+PRDT_NAME+"의 매매 과정에서\n"
				+ "동시호가 시간대에 거래량 대비 과도한 수량의 주문을 제출하여 종가를 급등/급락시킴.\n"
				+ "이에 관련규정에 따라 0간(0000.00.00-0000.00.00) 수탁거부 조치함\n"
				+ "- 한국거래소 시장감시규정 제4조(공정거래질서 저해행위의 금지)\n\n"
				+ "▶ 종가를 변동시키기 위해 종가 동시호가 시간대에 거래량 대비 과도한 수량을 매매하는 행위는 자본시장법상 불공정거래에 해당한다고 판단되어 의심스러운 거래로 보고함.";
				}

				output.add("VALUE"   ,tmp);
            }


            /*
             * 2015.03.26 ksy
             * STR결재상태 코드 조회/세팅.
             * */
            output3 = MDaoUtilSingle.getData("AML_20_01_01_03_NIC66B_getSearchOkCcd", (HashMap)input);

                output.add("GUBUN"    ,GUBUN);
                output.add("TYPE"    ,"CHECK");
                output.add("NAME"    ,GUBUN+"_OK_CCD");
                output.add("CODE"    ,output3.getText("OK_CCD"));
                output.add("VALUE"    ,output3.getText("OK_CCD_YN"));
                output.add("ETC"    ,"");



            if(output.getCount("GUBUN") > 0) {
                gdRes = Common.setGridData(output);
            }else {
                output.put("ERRMSG"    ,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다.") );
                //output.put("WINMSG"    ,MessageHelper.getInstance().getMessage("0001",input.getText("LANG_CD"),"조회된 정보가 없습니다."));
            }

            output.put("ERRCODE"    ,"00000");
            output.put("gdRes", gdRes);

        }catch(NumberFormatException e){

            Log.logAML(
                     Log.ERROR
                    ,this
                    ,"getSearchGroup"
                    ,e.getMessage()
            );

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());

        }catch(AMLException e){

            Log.logAML(
                     Log.ERROR
                    ,this
                    ,"getSearchGroup"
                    ,e.getMessage()
            );

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());

        }catch(Exception e){

            Log.logAML(
                     Log.ERROR
                    ,this
                    ,"getSearchGroup"
                    ,e.getMessage()
            );

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());

        }
        return output;
    }

    /**
     * <pre>
     *   혐의거래의심정보 저장
     * 疑わしい取引の疑い情報の保存
     * @en
     * </pre>
     *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
     *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
     *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
     *@return GRID_DATA(혐의거래의심정보저장 결과 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
     *GRID_DATA(疑わしい取引の疑い情報の保存結果 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
     *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
     *@throws Exception
     */
    @SuppressWarnings({ "unused", "rawtypes" })
    public DataObj doSave(
             DataObj             input
    ){
        DataObj  output        = null;
        //DataObj  output_temp= null;
        DataObj  input_temp    = new DataObj();
        MDaoUtil  mdb            = null;
        try {

            List gdReq = (List)input.get("gdReq");

            mdb = new MDaoUtil();
            mdb.begin();

            String SSPS_DL_ID         = input.getText("SSPS_DL_ID");
            String SSPS_DL_CRT_DT     = input.getText("SSPS_DL_CRT_DT");
            String MASTER_BRANCH     = input.getText("MASTER_BRANCH");
            String MN_DL_BRN_CD     = input.getText("MN_DL_BRN_CD");
            String ROLE_ID             = input.getText("ROLE_ID");
            String LOGIN_ID         = input.getText("LOGIN_ID");

            String TMS_WORKFLOW_AUTH = input.getText("TMS_WORKFLOW_AUTH");
            String RPR_PRGRS_CCD = input.getText("RPR_PRGRS_CCD");

            boolean result = check_State_add_svbank(TMS_WORKFLOW_AUTH, RPR_PRGRS_CCD);

            if( !result ) {
                output = new DataObj();
                output.put("ERRCODE"    ,"00001");
                output.put("ERRMSG"    ,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지않았습니다.")
                                    + "\\n " + MessageHelper.getInstance().getMessage("0051",input.getText("LANG_CD"),"진행상태를 확인하십시요."));
                output.put("WINMSG"    ,MessageHelper.getInstance().getMessage("0041",input.getText("LANG_CD"),"정상처리 되지않았습니다.")
                                    + "\\n " + MessageHelper.getInstance().getMessage("0051",input.getText("LANG_CD"),"진행상태를 확인하십시요."));

                output.put("gdRes", null);    // Wise Grid Data
                return output;
            }

            // =======================================================================================
            //GUBUN    TYPE    NAME            CODE    VALUE    ETC
            //    J    TEXT    RPR_RSN_CNTNT
            //    J    TEXT    ITEM_CNTNT2
            //    J    TEXT    ITEM_CNTNT3
            //    J    TEXT    ITEM_CNTNT4
            //    J    TEXT    ITEM_CNTNT5
            //    J    TEXT    ITEM_CNTNT6
            //    J    TEXT    ITEM_CNTNT1
            //    J    TEXT    ATT_FILE_NM
            //    J    TEXT    DOBT_DL_GRD_CD            1
            //    J    TEXT    SEND_DOC_NM
            //    J    CHECK    DOBT_TYP_KND_CD    501        Y
            //    J    CHECK    DOBT_TYP_KND_CD    204        Y
            //    J    CHECK    DOBT_TYP_KND_CD    206        Y

            input_temp.add("SSPS_DL_ID"        , SSPS_DL_ID);
            input_temp.add("SSPS_DL_CRT_DT"    , SSPS_DL_CRT_DT);
            input_temp.add("LOGIN_ID"        , LOGIN_ID);
            input_temp.add("MN_DL_BRN_CD"    , MN_DL_BRN_CD);

            for(int i=0; i<gdReq.size(); i++){
                HashMap map = (HashMap)gdReq.get(i);
                if("TEXT".equals(map.get("TYPE"))){
                    input_temp.add(map.get("NAME"), map.get("VALUE"));
                }else{
                    input_temp.add("DOBT_TYP_KND_CD", map.get("CODE"));
                    input_temp.add("F_CCD"            , map.get("VALUE"));
                    input_temp.add("ETC_CNTNT"        , map.get("ETC"));
                }
            }

            // =======================================================================================
            // [4]SAVE
            if(("B1").equals(TMS_WORKFLOW_AUTH)||("BS1").equals(TMS_WORKFLOW_AUTH)) { // IF Head Office

            	mdb.setData("AML_20_01_01_03_NNIC67B_setDelete"    ,(HashMap)input_temp );
            	mdb.setData("AML_20_01_01_03_NNIC67B_setInsert"    ,(HashMap)input_temp );
            	mdb.setData("AML_20_01_01_03_NNIC68B_setDelete"    ,(HashMap)input_temp );

            	HashMap inputParam = new HashMap();
            	inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT );
            	inputParam.put("SSPS_DL_ID", SSPS_DL_ID );
            	inputParam.put("LOGIN_ID", LOGIN_ID);

                for(int i = 0 ; i < input_temp.getCount("DOBT_TYP_KND_CD") ; i++) {

                	inputParam.put("DOBT_TYP_KND_CD", input_temp.getText("DOBT_TYP_KND_CD",i) );
                	inputParam.put("F_CCD", input_temp.getText("F_CCD",i) );
                	inputParam.put("ETC_CNTNT", input_temp.getText("ETC_CNTNT",i));

                	mdb.setData("AML_20_01_01_03_NNIC68B_setInsert" , inputParam);
                }

            }else{  // Branch

            	mdb.setData("AML_20_01_01_03_NNIC88B_setDelete"    ,(HashMap)input_temp );
            	mdb.setData("AML_20_01_01_03_NNIC88B_setInsert"    ,(HashMap)input_temp );
            	mdb.setData("AML_20_01_01_03_NNIC89B_setDelete"    ,(HashMap)input_temp );

            	HashMap inputParam = new HashMap();
            	inputParam.put("SSPS_DL_CRT_DT", SSPS_DL_CRT_DT );
            	inputParam.put("SSPS_DL_ID", SSPS_DL_ID );
            	inputParam.put("MN_DL_BRN_CD", MN_DL_BRN_CD );
            	inputParam.put("LOGIN_ID", LOGIN_ID);

            	for(int i = 0 ; i < input_temp.getCount("DOBT_TYP_KND_CD") ; i++) {

            		inputParam.put("DOBT_TYP_KND_CD", input_temp.getText("DOBT_TYP_KND_CD",i) );
            		inputParam.put("F_CCD", input_temp.getText("F_CCD",i) );
            		inputParam.put("ETC_CNTNT", input_temp.getText("ETC_CNTNT",i));

            		mdb.setData("AML_20_01_01_03_NNIC89B_setInsert", inputParam );
            	}
            }

            mdb.commit();

            output = new DataObj();
            output.put("ERRCODE"    ,"00000");
            output.put("ERRMSG"        ,MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상처리되었습니다..."));
            output.put("WINMSG"        ,MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상처리되었습니다."));
            output.put("gdRes", null);    // Wise Grid Data

        }catch(AMLException e){
            try{ if(mdb != null) {
            	mdb.rollback(); mdb.close();
            }
            }catch(Exception ee) {
            	Log.logAML(Log.ERROR,this,"doSaveGroup",e.getMessage());
            }

            Log.logAML(Log.ERROR,this,"doSaveGroup",e.getMessage());

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
        }catch(Exception e){
            try{ if(mdb != null) {mdb.rollback(); mdb.close();}} catch(Exception ee) {
            	Log.logAML(Log.ERROR,this,"doSaveGroup",e.getMessage());
            }
            Log.logAML(Log.ERROR,this,"doSaveGroup",e.getMessage());

            output = new DataObj();
            output.put("ERRCODE"    ,"00001");
            output.put("ERRMSG"        ,e.toString());
        } finally {
        	if(mdb != null) {
        		mdb.close();
        	}
        }
        return output;
    }



    /**
     * <pre>
     *   저장 유효성 검사 로직
     * 保存有効性検査ロジック
     * @en
     * </pre>
     * @param TMS_WORKFLOW_AUTH 워크플로우 권한
     *                          ワークフロー権限
     *                          @en
     * @param RPR_PRGRS_CCD  진행상태
     *                          @進行状態
     *                          @en
     * @return boolean true/false
     */
    public boolean check_State_add_svbank(
                                 String TMS_WORKFLOW_AUTH
                                ,String RPR_PRGRS_CCD
    ){

        boolean result;

        if((("J1").equals(TMS_WORKFLOW_AUTH) || ("B1").equals(TMS_WORKFLOW_AUTH) || ("BS1").equals(TMS_WORKFLOW_AUTH)) && (("A10").equals(RPR_PRGRS_CCD) || ("A11").equals(RPR_PRGRS_CCD) || ("A40").equals(RPR_PRGRS_CCD))){
            result = true;
        } else {
            result = false;
        }

        return result;
    }
    
    /**
     * <pre>
     *   ext Char Check
     * </pre>
     * @param str STRING
     * @return String
     */
    private static String reSultValue(String str){
        
        // 정규표현식 사용하여 특수문자 필터링처리
        String extch= "<,>,&,',\",;";
        @SuppressWarnings("unused")
        String strArr[]= extch.split(",");
        String result= str;
        for(int i=0; i<strArr.length; i++){
            result =StringHelper.replaceStr(result, strArr[i], " ");
        }    
        return result;
    }

}

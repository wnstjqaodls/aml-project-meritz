package com.gtone.aml.server.AML_20.AML_20_01.AML_20_01_01;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.gtone.aml.admin.AMLException;
import com.gtone.aml.basic.common.data.DataObj;
import com.gtone.aml.basic.common.log.Log;
import com.gtone.aml.common.Common;
import com.gtone.aml.common.action.GetResultObject;
import com.gtone.aml.dao.common.JDaoUtil;
import com.gtone.aml.dao.common.MDaoUtil;
import com.gtone.aml.dao.common.MDaoUtilSingle;
import com.gtone.aml.user.SessionAML;
import com.gtone.express.server.helper.MessageHelper;
import com.itplus.common.server.user.SessionHelper;

import kr.co.itplus.jwizard.dataformat.DataSet;

/**
*<pre>
* STR 거래상세
* STR 取引詳細
* STR Transaction deatiled.
*</pre>
*@author syk, hikim
*@version 1.0
*@history 1.0 2010-09-30
*/
public class AML_20_01_01_08 extends GetResultObject {

	private static AML_20_01_01_08 instance = null;

	/**
	 * getInstance
	 * @return AML_20_01_01_08
	 */
	public static AML_20_01_01_08 getInstance() {
		if ( instance == null ) {
			instance = new AML_20_01_01_08();
		}
		return instance;
	}

	/**
	 * <pre>
	 *   STR Alert화면  거래상세 조회(AML_20_01_01_08.jsp)
	 * STRアラート画面での取引詳細の照会
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(거래상세 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(取引詳細の照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj setStrSubPopMain08(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {

			String query_id = "AML_20_01_01_08_setStrSubPopMain08_MAIN";

            output = MDaoUtilSingle.getData(query_id, input);

            gdRes = Common.setGridData (  output );

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);
		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *   STR Alert화면  거래상세 Sub 조회(AML_20_01_01_08.jsp)
	 * STRアラート画面での取引詳細サブ照会(AML_20_01_01_08.jsp)
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(거래상세 Sub 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(取引詳細サブ照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DataObj setStrSubPopSub08(DataObj input) {
		DataObj output = new DataObj();
		DataObj output_01 = new DataObj();
		DataSet gdRes = null;
		try {

			/*************************************************************/
			// Checks, securities Detail Info.
			/*************************************************************/
			String query_id = "AML_20_01_01_08_setStrSubPopSub08";

            output = MDaoUtilSingle.getData(query_id, input);

			/*************************************************************/
			// Transaction Detail
			/*************************************************************/

            String query_id_01 = "AML_20_01_01_08_setStrSubPopSub08_01";

            output_01 = MDaoUtilSingle.getData(query_id_01, input);

            gdRes = Common.setGridData (  output );

			HashMap paramMap = new HashMap();
			paramMap.put("param01", output_01.getText("COL0"));
			paramMap.put("param02", output_01.getText("COL1"));
			paramMap.put("param03", output_01.getText("COL2"));
			paramMap.put("param04", output_01.getText("COL3"));
			paramMap.put("param05", output_01.getText("COL4"));
			paramMap.put("param06", output_01.getText("COL5"));
			paramMap.put("param07", output_01.getText("COL6"));
			paramMap.put("param08", output_01.getText("COL7"));
			paramMap.put("param09", output_01.getText("COL8"));
			paramMap.put("param10", output_01.getText("COL9"));
			paramMap.put("param11", output_01.getText("COL10"));
			paramMap.put("param12", output_01.getText("CPRTY_TRSNS_AC_RNM_NO"));
			paramMap.put("param13", output_01.getText("CPRTY_TRSNS_AC_NO"));
			paramMap.put("param14", output_01.getText("COL13"));
			paramMap.put("param15", output_01.getText("COL14"));
			paramMap.put("param16", output_01.getText("COL15"));

			output.put("gdParam", paramMap);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);

		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "setStrSubPopSub08", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}

	/**
	 * <pre>
	 *   STR Alert화면  거래상세 Sub2 조회(AML_20_01_01_08.jsp)
	 * STRアラート画面での取引詳細サブ2照会(AML_20_01_01_08.jsp)
	 * @en
	 * </pre>
	 *@param input 화면에서 보낸 입력 값,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<키>")을 통해 값을 얻는다.
	 *        インプット画面からの入力値,SessionHelper, SessionAML, menuID, pageID ==> input.getText("<Key>")を通じて取得します。
	 *        Input values from web page,SessionHelper, SessionAML, menuID, pageID ==>  input.getText("<key>")
	 *@return GRID_DATA(거래상세 Sub2 조회리스트 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 성공, ‘00001’:에러,  MESSAGE =alert 에러메시지, WINMSG= grid 상태 메시지)
	 *GRID_DATA(取引詳細サブ2照会一覧 DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: 成功, ‘00001’: エラー,  MESSAGE =alert エラーメッセージ, WINMSG= grid 状態メッセージ)
	 *GRID_DATA(@en DataSet),  PARAM_DATA ( grid param DataSet, STATUS = ‘00000’: sucess, ‘00001’:error,  MESSAGE =alert error message , WINMSG= grid status bar message  )
	 *@throws Exception
	 */
	public DataObj setStrSubPopSub08_02(DataObj input) {
		DataObj output = new DataObj();
		DataSet gdRes = null;

		try {
			String query_id = "AML_20_01_01_08_setStrSubPopSub08_02";
            
            output = MDaoUtilSingle.getData(query_id, input);

            gdRes = Common.setGridData(output);

			output.put("ERRCODE", "00000");
			output.put("gdRes", gdRes);
		} catch (AMLException e) {
			Log.logAML(Log.ERROR, this, "getSearch", e.getMessage());
			output = new DataObj();
			output.put("ERRCODE", "00001");
			output.put("WINMSG", MessageHelper.getInstance().getMessage("0005", input.getText("LANG_CD"), "처리중 오류가 발생하였습니다."));
		}

		return output;
	}
	
    public DataObj doSearchTrx(DataObj input) {
        DataObj output = new DataObj();
        DataSet gdRes = null;
        
        try {
            String query_id = "AML_20_01_01_08_doSearchTrx";
            
            output = MDaoUtilSingle.getData(query_id, input);

            gdRes = Common.setGridData(output);
            
            output.put("ERRCODE", "00000");
            output.put("gdRes", gdRes);
        } catch (Exception e) {
            Log.logAML(Log.ERROR, this, "doSearchTrx", e.getMessage());
            output = new DataObj();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.toString());
        }
        
        return output;
    }
    
    @SuppressWarnings("rawtypes")
    public DataObj doSave(DataObj input) throws Exception {
        DataObj output = new DataObj();
        DataObj output_temp = new DataObj();
        MDaoUtil db = null;
        JDaoUtil jdb = null;
        
        try {
            
            List gdReq = new ArrayList();
            
            if(!"".equals(input.get("gdReq"))){
               gdReq = (List)input.get("gdReq");
            }
            
            SessionAML sess = (SessionAML)input.get("SessionAML");
            SessionHelper sessHelper = sess.getSessionHelper();
            
            jdb = new JDaoUtil();
            jdb.begin();
            db = new MDaoUtil(jdb.getQueryHelper().getConnection());
                    
            DataObj in = new DataObj();
            HashMap map = null;
            
            in.put("SSPS_DL_CRT_DT", input.get("SSPS_DL_CRT_DT"));
            in.put("SSPS_DL_ID", input.get("SSPS_DL_ID"));
            in.put("GNL_AC_NO", input.get("GNL_AC_NO"));
            in.put("HNDL_P_ENO", sess.getsAML_LOGIN_ID());
            
            //if(gdReq.size() > 0) {
	            db.setData("AML_20_01_01_08_DELETE_NIC71B_ACCOUNT", in);
	            db.setData("AML_20_01_01_08_DELETE_NIC75B_ACCOUNT", in);
            //}

            for(int i = 0; i < gdReq.size(); i++) {
                map = (HashMap)gdReq.get(i);

                in.put("GNL_AC_NO", map.get("GNL_AC_NO"));
                in.put("GDS_NO", map.get("GDS_NO"));
                in.put("DL_DT", map.get("DL_DT"));
                in.put("DL_SQ", map.get("DL_SQ"));
                
                output_temp = MDaoUtilSingle.getData("AML_20_01_01_08_SELECT_NIC61B_CUS", in);
                in.put("RNMCNO", output_temp.get("RNMCNO"));
                
                db.setData("AML_20_01_01_08_INSERT_NIC70B_CUS", in);
                db.setData("AML_20_01_01_08_INSERT_NIC78B_CUS", in);
                db.setData("AML_20_01_01_08_UPDATE_NIC78B_CUS", in);
                db.setData("AML_20_01_01_08_INSERT_NIC79B_CUS", in);
                db.setData("AML_20_01_01_08_UPDATE_NIC79B_CUS", in);
                db.setData("AML_20_01_01_08_UPDATE_NIC79B_CU1", in);
                db.setData("AML_20_01_01_08_UPDATE_NIC79B_CU2", in);
                db.setData("AML_20_01_01_08_INSERT_NIC71B_ACC", in);
                db.setData("AML_20_01_01_08_INSERT_NIC75B_TRX", in);
                db.setData("AML_20_01_01_08_INSERT_NIC102B_CUS", in);
            }
            
            jdb.commit();
            
            output.put("ERRCODE", "00000");
            output.put("ERRMSG", MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));
            output.put("WINMSG", MessageHelper.getInstance().getMessage("0002",input.getText("LANG_CD"),"정상 처리되었습니다."));

            output.put("gdRes", null);
        } catch(Exception e){
            try{ if(jdb != null) jdb.rollback();} catch(Exception ee) {}
            
            Log.logAML(Log.ERROR, this, "doSave", e);
            
            output.clear();
            output.put("ERRCODE", "00001");
            output.put("ERRMSG", e.getMessage());
            output.put("WINMSG", e.getMessage());
        }
        finally {
            try{ if(jdb != null) jdb.close(); } catch(Exception ee) {}
        }
        return output;
    }

}

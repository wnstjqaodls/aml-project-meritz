<%@page contentType="text/html; charset=utf-8" %>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 기간별 거래정보download
					期間別取引情報 download
*                   Transaction Info.- Period download
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
--%>

<%@ page import="com.gtone.aml.basic.common.data.DataObj" %> 
<%@ page import="com.gtone.aml.server.common.commonUtil"  %>
<%@ page import="com.gtone.aml.basic.common.util.*"  %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_07.AML_20_07_01.AML_20_07_01_02"  %>
<%@ page import="jxl.Workbook"  %>
<%@ page import="jxl.format.Border"  %>
<%@ page import="jxl.format.BorderLineStyle"  %>
<%@ page import="jxl.write.Label"  %>
<%@ page import="jxl.write.WritableCellFormat"  %>
<%@ page import="jxl.write.WritableSheet"  %>
<%@ page import="jxl.write.WritableWorkbook"  %>
<%@ page import="jspeed.base.property.PropertyService"  %>
<%@ page import="java.io.*"  %>
<%@ taglib prefix="fmt" uri="http://www.gtone.co.kr/jstl/fmt" %>
<%
String todata  = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
	String title   = "STR ExcelFile";
    String GNL_AC_NO   	= Util.nvl(request.getParameter("ACNT_NO"));
    GNL_AC_NO = GNL_AC_NO.replaceAll("\n", "");
    String FROMDATE				= Util.nvl(request.getParameter("FROMDATE")).replaceAll("-","");  			
    String TODATE				= Util.nvl(request.getParameter("TODATE")).replaceAll("-","");  			
    
    String fromDateView = (FROMDATE.length() == 8)?FROMDATE.substring(0,4)+"-"+FROMDATE.substring(4,6)+"-"+FROMDATE.substring(6,8):FROMDATE;
    String toDateView = (TODATE.length() == 8)?TODATE.substring(0,4)+"-"+TODATE.substring(4,6)+"-"+TODATE.substring(6,8):TODATE;
    
    request.setAttribute("fromDateView",jspeed.base.xml.XMLHelper.normalize(fromDateView));
    request.setAttribute("toDateView",jspeed.base.xml.XMLHelper.normalize(toDateView));
    
    DataObj obj = new DataObj();
    DataObj row_obj = new DataObj();
	DataObj DataParam = new DataObj(); 
	
	

	DataParam.put("ACNT_NO", GNL_AC_NO);
	DataParam.put("FROMDATE", FROMDATE);
	DataParam.put("TODATE",TODATE);
	
	obj = AML_20_07_01_02.getInstance().AML_20_07_01_02_getExcelTitle(DataParam);
	
	DataParam.put("GNL_AC_NO",obj.getText("GNL_AC_NO_ORI"));
	
	row_obj = AML_20_07_01_02.getInstance().AML_20_07_01_02_getDataRow(DataParam);

	
	
	
	String[] colArr0 = {"계좌주(사업자)명","실명번호 구분","계좌주(사업자)실명번호","계좌주CI번호","계좌주 국적","실명번호 구분코드"};        
    String[] dataArr0 = {"CS_NM","RNM_CNFR_CCD_NM","CS_NO_DEC","CS_CI_NO","NTN_CD","RNM_CNFR_CCD"};

    String[] colArr1 = {"계좌개설 금융기관","계좌번호","계좌종류(상품)","계좌상품명","계좌개설일자","계좌개설점명","계좌관리점명","계좌잔액","개설금융기관코드 "
                    ,"계좌종류코드","계좌개설점코드","계좌관리점코드"};
    String[] dataArr1 = {"RPR_OGN_NM","ACNT_NO_DEC","GOODS","ACNT_GDS_NM","AC_OPN_DT","OPN_BRN_CD_NM","MN_DL_DPRT_CD_NM","AC_BAL","TRNS_OGN_CD_NEW"
        ,"AC_TY_CD","OPN_BRN_CD","MN_DL_DPRT_CD"};

    String[] colArr2 = {"조회일시","조회점명","조회시작일","조회종료일","조회점코드"};
    String[] dataArr2 = {"RP_DT","BRN_NM","DL_DT_B","DL_DT_A","BRN_CD"};

    String[] colArr3 = {"거래일련번호","거래순번","거래발생일시",
    		        "상대금융기관명","상대계좌번호","상대계좌주명","상대계좌주실명구분","상대계좌주실명번호","상대계좌주CI번호","상대계좌주국적",
    		        "거래종류명","거래수단명","거래채널명","적요","거래소명","매매/입고/출고종목명","거래수량","통화구분코드","외환거래금액","거래금액","정산금액","수표금액",
    				"유가증권명","유가증권시작번호","유가증권종료번호","현금지급금융기관명","현금지급영업점명","유가잔고","예수금잔고","미수금잔고","융자금/대주금","취급금융기관명","취급점명",
                    "의심거래보고여부","거래종류코드","거래수단코드","거래채널코드","매매종목코드","유가증권코드","현금지급금융기관코드","현금지급영업점코드","상대금융기관코드",
                    "상대계좌주실명구분코드","취급금융기관코드","취급점코드","정정구분코드"
    };

    String[] dataArr3 = {"GNL_SQ_DEC","DL_SQ","DL_DT_TM",
    		        "CPRTY_TRSNS_FOGN_NM","CPRTY_TRSNS_AC_NO","CPRTY_TRSNS_AC_NM","CPRTY_TRSNS_AC_RNM_CNFR_CCD_NM","CPRTY_TRSNS_AC_RNM_NO","CPRTY_TRSNS_CI_NO","CPRTY_TRSNS_AC_OWN_NTN_CD",
    		        "DL_TYP_NM","DL_WY_NM","DL_CHNNL_NM","A1","BYMK_SECT_NM","A3","A5","CRNCY_CD","FCRNCY_DL_AMT","A6","ADJST_AMT","CHCK_AMT",
    				"CHCK_KND_NM","CHCK_STRT_NO","CHCK_END_NO","CSH_ORG","CSH_BRN","SECBAL_EVAL_AMT","DPS_AMT","RCVBL_BAL_AMT","MLOAN_SLOAN_AMT","RPR_OGN_NM","HANDLNG_BRN_NM",
    				"DOBT_DL_RPR_YN","DL_TYP_CD","DL_WY_CD","DL_CHNNL_CD","A2","CHCK_KND_CD","CSH_ORG_CD","CSH_BRN_CD","CPRTY_TRSNS_OGN_CD",
                    "CPRTY_TRSNS_AC_RNM_CNFR_CCD","TRNS_OGN_CD_NEW","HANDLNG_BRN_CD","GBN_CD"
    };
	
	WritableWorkbook wwb = null;
	BufferedInputStream fin = null;
	BufferedOutputStream outs = null;
		
	try {
		
		String filePath = PropertyService.getInstance().getProperty("aml.config", "uploadPath.tms");
		String fileFullPath = filePath;   //filePath +System.getProperty("file.separator") + sSSPS_DL_CRT_DT.replaceAll(" ", "") + System.getProperty("file.separator") + sSSPS_DL_ID.replaceAll(" ", "");
        
        fileFullPath = fileFullPath.replace("/", System.getProperty("file.separator"));

        File dir = new File(fileFullPath);
        long fileLen = dir.length();

        if(!dir.isDirectory()){
            dir.mkdirs();
        }
        
        String fileNm = GNL_AC_NO+"_"+FROMDATE+"_"+TODATE+".xls";
        String fileNameFullPath = (fileFullPath + "/" +fileNm).replace("/", System.getProperty("file.separator"));
        
        wwb = Workbook.createWorkbook(new File(fileNameFullPath));                
        wwb.createSheet("Sheet", 0);
        
        WritableSheet sheet = wwb.getSheet(0);
        
        WritableCellFormat cellFormat = new WritableCellFormat();
        cellFormat.setBorder(Border.ALL , BorderLineStyle.THIN);

        WritableCellFormat cellFormat1 = new WritableCellFormat();
        cellFormat1.setBackground(jxl.format.Colour.YELLOW);
        cellFormat1.setBorder(Border.ALL , BorderLineStyle.THIN);

        WritableCellFormat cellFormat2 = new WritableCellFormat();
        cellFormat2.setBackground(jxl.format.Colour.ORANGE);
        cellFormat2.setBorder(Border.ALL , BorderLineStyle.THIN);
        int cnt = 0;
        
        
        Label label = new jxl.write.Label(0,cnt,"버전",cellFormat1);
        sheet.addCell(label);
        label = new jxl.write.Label(1,cnt,"S-ASTR-V2.0",cellFormat);
        sheet.addCell(label);
        cnt++;
        sheet.mergeCells(0, cnt, 5, cnt);
        label = new jxl.write.Label(0,cnt,"고객정보",cellFormat1);
        sheet.addCell(label);
        cnt++;
        
        
		////////고객정보 /////////////////////////////////
        for( int j=0; j<colArr0.length; j++ ){
                if(j>=3 && j<=4){
                        label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat2);
                }else{
                        label = new jxl.write.Label(j,cnt,colArr0[j],cellFormat1);
                }
                sheet.addCell(label);
        }
        cnt++;
        
        for (int ii = 0; ii < obj.getCount("CS_NO_DEC"); ii++) {                    
            for( int jj=0; jj<dataArr0.length; jj++ ){
                label = new jxl.write.Label(jj,cnt,obj.getText(dataArr0[jj],ii),cellFormat);
                sheet.addCell(label);

            }
            
            cnt++;
        }
        
		////////계좌정보 /////////////////////////////////
        sheet.mergeCells(0, cnt, 11, cnt);
        label = new jxl.write.Label(0,cnt,"계좌정보",cellFormat1);
        sheet.addCell(label);
        cnt++;

        for( int k=0; k<colArr1.length; k++ ){
                if(k<7){
                        label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat1);
                }else{
                        label = new jxl.write.Label(k,cnt,colArr1[k],cellFormat2);
                }
                sheet.addCell(label);
        }
        cnt++;
        
                                            
        for( int ii=0; ii<dataArr1.length; ii++ ){
                
             label = new jxl.write.Label(ii,cnt,obj.getText(dataArr1[ii],0),cellFormat);
             sheet.addCell(label);
        }
        cnt++;
        
		////////조회 정보 /////////////////////////////////
        sheet.mergeCells(0, cnt, 4, cnt);
        label = new jxl.write.Label(0,cnt,"조회정보",cellFormat1);
        sheet.addCell(label);
        cnt++;
        for( int m=0; m<colArr2.length; m++ ){
                label = new jxl.write.Label(m,cnt,colArr2[m],cellFormat1);
                sheet.addCell(label);
        }
        cnt++;
        
        obj.put("DL_DT_A", FROMDATE);
        obj.put("DL_DT_B", TODATE);
        
        //조회 정보조회
        for (int ii = 0; ii < obj.getCount("BRN_NM"); ii++) {
            for( int jj=0; jj<dataArr2.length; jj++ ){
                System.out.println(obj.getText(dataArr2[jj],ii));
                label = new jxl.write.Label(jj,cnt,obj.getText(dataArr2[jj],ii),cellFormat);
                sheet.addCell(label);
            }
               
            cnt++;
        }
        
		////////거래 정보 /////////////////////////////////
        sheet.mergeCells(0, cnt, 45, cnt);
        label = new jxl.write.Label(0,cnt,"거래상세",cellFormat1);
        sheet.addCell(label);
        cnt++;
        for( int p=0; p<colArr3.length; p++ ){
                //if(i<29){
                //        label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                //}else{
                        label = new jxl.write.Label(p,cnt,colArr3[p],cellFormat1);
                //}
                sheet.addCell(label);
        }
        cnt++;
        
        row_obj.put("DL_DT_A", FROMDATE);
        row_obj.put("DL_DT_B", TODATE);
        
        for (int ii = 0; ii < row_obj.getCount("DL_SQ"); ii++) {
            for( int jj=0; jj<dataArr3.length; jj++ ){
            	//계좌번호 복화화해서 일련번호를 뒤에 추가
            	if("GNL_SQ_DEC".equals(dataArr3[jj])) {
                	String ACNT_NO_DEC = row_obj.getText("ACNT_NO_DEC",ii);
                	String DL_SQ = row_obj.getText("DL_SQ",ii);
                	
                	int len = 5-DL_SQ.length();
            		for(int k=0; k<len; k++) DL_SQ = "0" + DL_SQ;
                	
            		label = new jxl.write.Label(jj,cnt,ACNT_NO_DEC+DL_SQ,cellFormat);
            	} else {
            		label = new jxl.write.Label(jj,cnt,row_obj.getText(dataArr3[jj],ii),cellFormat);
            	}
                sheet.addCell(label);
            }
               
            cnt++;
        }
                
        wwb.write();
        wwb.close();
        
        String Full = fileNameFullPath;    
        File file = new File(Full);  
        response.setContentType("text/xml"); 
     
        String Agent=request.getHeader("USER-AGENT");

        if(Agent.indexOf("MSIE")>=0){
            int i=Agent.indexOf('M',2); 
            String IEV=Agent.substring(i+5,i+8);
            if(IEV.equalsIgnoreCase("5.5")){
                response.setHeader("Content-Disposition", "filename="+new String(fileNm.getBytes("utf-8"),"8859_1"));
            }else{
                response.setHeader("Content-Disposition", "attachment;filename="+new String(fileNm.getBytes("utf-8"),"8859_1")); 
            }
        } else {
             response.setHeader("Content-Disposition", "attachment;filename="+new String(fileNm.getBytes("utf-8"),"8859_1"));
        }
        

        fin = new BufferedInputStream(new FileInputStream(file));  
        outs = new BufferedOutputStream(response.getOutputStream());
        String content=null;
        byte b[] = new byte[5 * 1024 * 1024];  //max=5M byte 
        		
        if (file.isFile()){ 
        	int read = 0;  
            while ((read = fin.read(b)) != -1){
                outs.write(b,0,read);
            }

        	outs.flush();
            outs.close();  
            fin.close();  
        }
        
	} catch (Exception e) {
        e.printStackTrace();
    } finally {
    	if(outs != null) outs.close();
        if(fin  != null) fin.close();
    }
%>

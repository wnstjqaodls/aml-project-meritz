<%@page contentType="text/html; charset=utf-8" %>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 기간별 거래정보download
					期間別取引情報 download
*                   Transaction Info.- Period download
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
--%>

<%@ page import="com.gtone.aml.basic.common.data.DataObj" %> 
<%@ page import="com.gtone.aml.basic.common.util.*"  %>
<%@ page import="com.gtone.aml.server.AML_20.AML_20_07.AML_20_07_01.AML_20_07_01_02_backup"  %>
<%@ taglib prefix="fmt" uri="http://www.gtone.co.kr/jstl/fmt" %>
<%@ taglib prefix="c"           uri="http://java.sun.com/jsp/jstl/core"                 %>
<%
//String todata  = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
	//String title   = "STR ExcelFile";
    String GNL_AC_NO_GDS_NO   	= Util.nvl(request.getParameter("GNL_AC_NO_GDS_NO"));
    GNL_AC_NO_GDS_NO = GNL_AC_NO_GDS_NO.replaceAll("\n", "");
    GNL_AC_NO_GDS_NO = GNL_AC_NO_GDS_NO.replaceAll("\r", "");
    String FROMDATE				= Util.nvl(request.getParameter("FROMDATE")).replaceAll("-","");  			
    String TODATE				= Util.nvl(request.getParameter("TODATE")).replaceAll("-","");  			
    String GNL_AC_NO 			= GNL_AC_NO_GDS_NO.substring(0,GNL_AC_NO_GDS_NO.length()-2);
    String GDS_NO 				= GNL_AC_NO_GDS_NO.substring(GNL_AC_NO_GDS_NO.length()-2,GNL_AC_NO_GDS_NO.length());
    
    String fromDateView = (FROMDATE.length() == 8)?FROMDATE.substring(0,4)+"-"+FROMDATE.substring(4,6)+"-"+FROMDATE.substring(6,8):FROMDATE;
    String toDateView = (TODATE.length() == 8)?TODATE.substring(0,4)+"-"+TODATE.substring(4,6)+"-"+TODATE.substring(6,8):TODATE;
    
    request.setAttribute("fromDateView",jspeed.base.xml.XMLHelper.normalize(fromDateView));
    request.setAttribute("toDateView",jspeed.base.xml.XMLHelper.normalize(toDateView));
    
    response.setHeader("Content-Disposition", "attachment; filename="+GNL_AC_NO_GDS_NO+".xls"); 
	response.setHeader("Content-Description", "JSP Generated Data"); 
	response.setHeader("Content-Description", "style=mso-number-format:'\\@'"); 
	response.setContentType("application/vnd.ms-excel");
    
    DataObj obj = new DataObj();
    DataObj row_obj = new DataObj();
	DataObj DataParam = new DataObj(); 
	
	

	DataParam.put("GNL_AC_NO", GNL_AC_NO);
	DataParam.put("GDS_NO", GDS_NO);
	DataParam.put("FROMDATE", FROMDATE);
	DataParam.put("TODATE",TODATE);
	
	obj = AML_20_07_01_02_backup.getInstance().AML_20_07_01_02_getExcelTitle(DataParam);
	
	row_obj = AML_20_07_01_02_backup.getInstance().AML_20_07_01_02_getDataRow(DataParam);
%>
<html>
<meta http-equiv="Content-Type content=text/html; charset=utf-8"  >
<head>
	<title>STR ExcelFile</title>
</head>
<body>
	<table border='1'>
		<tr>
			<td bgcolor="#FFFF99">Version</td>
			<td>S-ASTR-V1.0</td>
		</tr>
	</table>
	<table border='1'>
		<tr>
			<td colspan='6' bgcolor="#FFFF00"><fmt:message key="AML_20_07_01_01_009" initVal="고객정보"/></td>			
		</tr>
		<tr>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_010" initVal="거래자(사업자)명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_011" initVal="실명확인번호 구분"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_012" initVal="거래자(사업자)실명확인번호"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_013" initVal="거래자국적"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_014" initVal="실명확인번호 구분코드"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_015" initVal="직업"/></td>
		</tr>
		<tr>
			<td><c:out value='<%=obj.getText("CS_NM")%>'/></td>
			<td><c:out value='<%=obj.getText("RNM_CNFR_CCD_NM")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("AML_CUST_ID")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("NTN_CD")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("RNM_CNFR_CCD")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("OCPTN_CD")%>'/></td>
		</tr>
	</table>
	<table border='1'>
		<tr>
			<td colspan='13' bgcolor="#FFFF00"><fmt:message key="AML_20_07_01_01_016" initVal="계좌정보"/></td>			
		</tr>
		<tr>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_017" initVal="계좌개설 금융기관"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_018" initVal="계좌번호"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_019" initVal="계좌개설지점명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_020" initVal="주거래지점명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_021" initVal="개설지점우편번호"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_022" initVal="개설일자"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_023" initVal="대리인명"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_024" initVal="계좌주관계"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_025" initVal="실명확인구분"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_026" initVal="실명확인구분코드"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_027" initVal="대리인실명확인번호"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_028" initVal="대리인전화번호"/></td>
			<td bgcolor="#FF9900"><fmt:message key="AML_20_07_01_01_029" initVal="대리인국적"/></td>
		</tr>
		<tr>
			<td><c:out value='<%=obj.getText("RPR_OGN_NM")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("GNL_AC_NO")%>'/></td>
			<td><c:out value='<%=obj.getText("OPN_BRN_CD_NM")%>'/></td>
			<td><c:out value='<%=obj.getText("MN_DL_DPRT_CD_NM")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("OPN_BRN_CD_POST")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("GDS_OPN_DT")%>'/></td>
			<td><c:out value='<%=obj.getText("PRXY_NM")%>'/></td>
			<td><c:out value='<%=obj.getText("PRXY_RLTNS_CD")%>'/></td>
			<td><c:out value='<%=obj.getText("PRXY_RNM_NO_CCD_NM")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("PRXY_RNM_NO_CCD")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("PRXY_RNMCNO")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("PRXY_TEL_NO")%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("NTN_CD")%>'/></td>
		</tr>
	</table>
	<table border='1'>
		<tr>
			<td colspan='5' bgcolor="#FFFF00"><fmt:message key="AML_20_07_01_01_030" initVal="조회정보"/></td>			
		</tr>
		<tr>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_031" initVal="조회일시"/></td>   
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_032" initVal="조회점명"/></td>   
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_033" initVal="조회시작일"/></td>   
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_034" initVal="조회종료일"/></td>   
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_035" initVal="조회점코드"/></td>
		</tr>
		<tr>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("RP_DT")%>'/></td>   
			<td><c:out value='<%=obj.getText("BRN_NM")%>'/></td>   
			<td style="mso-number-format:\@"  align='center'>${fromDateView}</td>   
			<td style="mso-number-format:\@"  align='center'>${toDateView}</td>   
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=obj.getText("BRN_CD")%>'/></td>
		</tr>
	</table>
	<table border='1'>
		<tr>
			<td colspan='15' bgcolor="#FFFF00"><fmt:message key="AML_20_07_01_01_036" initVal="거래상세"/></td>			
		</tr>
		<tr>		
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_037" initVal="일련번호"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_038" initVal="거래발생일시"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_039" initVal="거래종류명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_040" initVal="거래수단명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_041" initVal="거래채널명"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_042" initVal="거래금액"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_043" initVal="현금"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_044" initVal="수표"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_045" initVal="기타수표"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_046" initVal="잔액"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_047" initVal="거래통화"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_048" initVal="외국환금액"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_049" initVal="달러환산금액"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_050" initVal="취급지점"/></td>
			<td bgcolor="#FFFF99"><fmt:message key="AML_20_07_01_01_051" initVal="처리자"/></td>
		</tr>
		<%
			for(int i = 0; i < row_obj.getCount("DL_SQ"); i++) {
		%>
		<tr>			
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("DL_SQ"					          		,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("DL_DT_TM"					          		,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("DL_TYP_NM"					    		,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("DL_WY_NM"					          	,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("DL_CHNNL_NM"					      	,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("DL_AMT"					    ,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("CSH"					    	,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("CHCK_AMT"						,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("ETC_CHCK_AMT"					    	,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("TFND_RA"				   	,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("CRNCY_CD"					      		,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("FCRNCY_DL_AMT"				   	,i)%>'/></td>
			<td style="mso-number-format:\#\,\#\#0\"  align='right'><c:out value='<%=row_obj.getText("USD_EXCH_AMT"				   	,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("HANDLNG_BRN_NM"						,i)%>'/></td>
			<td style="mso-number-format:\@"  align='center'><c:out value='<%=row_obj.getText("HNDL_P_ENO"					      	,i)%>'/></td>
		</tr>
		<%
			}
		%>
	</table>
</body>


           
               
 
    
     
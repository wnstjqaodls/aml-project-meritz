<%@ page language="java" contentType="text/html; charset=utf-8" pageEncoding="utf-8"%>
<%--
********************************************************************************************************************************************
* Copyright (C) 2008-2018 GTOne. All Right Reserved.
********************************************************************************************************************************************
* Description     : 기간별 거래정보
*                   期間別取引情報
*                   Transaction Info.- Period
* Group           : GTONE, R&D센터/개발2본부
* Project         : AML/RBA/FATCA/CRS/WLF
* Author          : 서윤경, 김현일
* Since           : 2010. 9. 30.
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 6. 12.
* Alteration      : 1. window popup open시 form의 submit을 사용하지 않도록 수정
********************************************************************************************************************************************
* Modifier        : 송지윤
* Update          : 2017. 7. 6.
* Alteration      : 1. 코드 정리
*                   2. HTML5, devextreme, Any Browser 적용
********************************************************************************************************************************************
* Modifier        : 박상훈
* Update          : 2017. 12. 20.
* Alteration      : 1. 그리드 필터 추가
*                   2. 스타일 오류 수정
********************************************************************************************************************************************
--%>
<%@ page import="java.text.ParseException" %>
<%@ page import="com.gtone.aml.basic.common.log.Log"%>
<jsp:include page="/WEB-INF/Package/AML/common/main_common_top.jsp" flush="true" />
<%@ include file="/WEB-INF/Package/AML/common/common.jsp" %>
<%
    String startDate = "";
    String endDate   = "";

    try{
        if(("").equals(startDate)) {
        	startDate = DateUtil.addDays(DateUtil.getDateString(), -90, "yyyy-MM-dd");
        }
        if(("").equals(endDate)) {
        	endDate = DateUtil.addDays(DateUtil.getDateString(), 0, "yyyy-MM-dd");
        }
        }catch(ParseException e){
        	Log.logAML(Log.ERROR, e);
        }

    request.setAttribute("startDate",startDate);
    request.setAttribute("endDate",endDate);
%>
<script>
    // [ Attributes ]
    var GridObj1;
    var GridObj2;
    var classID = "AML_20_07_01_01";
    var pageID  = "AML_20_07_01_01";
    var selectedGrid1Row = "";
    var overlay = new Overlay();

    // [ Initialize ]
    $(document).ready(function(){
        setupGrids();
        setupGrids2();
        $("button").click(function(){
            $("#div1").load("demo_test.txt");
        });
        $("#ACNT_NO").keydown(function(e){
            if (e.keyCode==13) doSearch();
        });
		setupFilter1("init");
		setupFilter2("init");
    });

    function setupGrids() {
        GridObj1 = $("#GTDataGrid1_Area").dxDataGrid({
    	    gridId          : "GTDataGrid01"
            	   ,height : "calc(90vh - 150px)"
               ,elementAttr: { class: "grid-table-type" }
          	   ,hoverStateEnabled      : true
          	   ,wordWrapEnabled 	   : false
          	   ,allowColumnResizing    : true
          	   ,columnAutoWidth        : true
          	   ,allowColumnReordering  : true
				,onToolbarPreparing	: makeToolbarButtonGrids
          	   ,columnResizingMode     : "widget"   /* "widget" "nextColumn" */
          	   ,cacheEnabled           : false
          	   ,cellHintEnabled        : true
          	   ,showBorders     	   : true
          	   ,showColumnLines 	   : true
          	   ,showRowLines    	   : true
          	   ,loadPanel              : { enabled: false }
  		       ,export : {
  			        allowExportSelectedData : false
  			       ,enabled                 : false
  			       ,excelFilterEnabled      : false
  			    }
  			   ,onExporting: function (e) {
	  				var workbook = new ExcelJS.Workbook();
	  				var worksheet = workbook.addWorksheet("Sheet1");
  				    DevExpress.excelExporter.exportDataGrid({
  				        component: e.component,
  				        worksheet: worksheet,
  				        autoFilterEnabled: true,
  				    }).then(function() {
  				        workbook.xlsx.writeBuffer().then(function(buffer) {
  				            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "기간별거래정보.xlsx");
  				        });
  				    });
  				    e.cancel = true;
  		       }
  			   ,"sorting": {"mode": "multiple"},
  			    "remoteOperations":                  {
  			        "filtering": false,
  			        "grouping": false,
  			        "paging": false,
  			        "sorting": false,
  			        "summary": false
  			    },
  			    "editing":                  {
  			        "mode": "batch",
  			        "allowUpdating": false,
  			        "allowAdding": false,
  			        "allowDeleting": false
  			    },
  			    "filterRow": {"visible": false},
  			    "rowAlternationEnabled": true,
  			    "columnFixing": {"enabled": true},
	  			pager: {
	       	    	visible: true
	       	    	,showNavigationButtons: true
	       	    	,showInfo: true
	      	 	},
	      	 	paging: {
	      	 	  	enabled : true
	      	 		,pageSize : 20
	      	 	},
	      	 	scrolling : {
	      	        mode            : "standard"
	      	        ,preloadEnabled  : false
	      	    },
  			    "searchPanel":{
  			        "visible": false,
  			        "width": 250
  			    },
  			    "selection":{
  				    "allowSelectAll": true,
  				    "deferred": false,
  				    "mode": "single",
  				    "selectAllMode": "allPages",
  				    "showCheckBoxesMode": "onClick"
  			    },
  			    "columns":[
  			    {
  			        "dataField": "GNL_AC_NO_VIEW",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_018','계좌번호')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        cellTemplate: function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate_GTONE(cellInfo.text,"GNL_AC_NO")); },
  			        "visible": false
  			    },
  			  {
  			        "dataField": "GNL_AC_NO",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_018','계좌번호')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true ,
			        "visible": false
  			    },
  			    {
  			        "dataField": "ACNT_NO",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_018','계좌번호')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        "visible": true
  			    },
  			    {
  			        "dataField": "GDS_NO",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_100','상품번호')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        "visible": false
  			    },
  			    {
  			        "dataField": "GDS_NM",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_101','상품명')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        "visible": false
  			    },
  			    {
  			        "dataField": "AML_CUST_ID",
  			        "caption": "${msgel.getMsg('AML_10_03_03_01_103','고객관리번호')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        "visible": false
  			    },
  			    {
  			        "dataField": "CS_NM",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_007','고객명')}",
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true,
  			        "visible": false
  			    },
  			    {
  			        "dataField": "CLSD_YN",
  			        "caption": "${msgel.getMsg('AML_20_07_01_01_102','상태')}",
  			        "lookup":                          {
  			        "dataSource":
  			            [{"KEY": "Y","VALUE": "해지"},{"KEY": "N","VALUE": "정상"}],
  			            "displayExpr": "VALUE",
  			            "valueExpr": "KEY"
  			        },
  			        "alignment": "center",
  			        "allowResizing": true,
  			        "allowSearch": true,
  			        "allowSorting": true
  			        },
  			        {
  			            "dataField": "CLSD_DT",
  			            "caption": "${msgel.getMsg('AML_20_07_01_01_103','해지일자')}",
  			            "alignment": "center",
  			            "allowResizing": true,
  			            "allowSearch": true,
  			            "allowSorting": true,
  			        "visible": false
  			        }
  			    ],
//   			  "summary" :{totalItems: [{column: 'GNL_AC_NO_VIEW', alignment:'center', summaryType: 'count', valueFormat: "fixedPoint"}],
// 					texts: {count: "총: {0}건"}},
  			    "onCellClick": function(e){ if(e.data ){ clickGrid1Cell('gridId', e.data, e.data, e.rowIndex, e.columnIndex, e.column.dataField); } }
  			}).dxDataGrid("instance");
    }

    function setupGrids2()
    {
        GridObj2 = $("#GTDataGrid2_Area").dxDataGrid({
    	    gridId          : "GTDataGrid02"
            	   ,height : "calc(90vh - 150px)"
            	   ,elementAttr: { class: "grid-table-type" }
            		   ,"hoverStateEnabled": true
            		    ,"wordWrapEnabled": false
            		    ,"allowColumnResizing": true
            		    ,"columnAutoWidth": true
    					,"onToolbarPreparing"	: makeToolbarButtonGrids
            		    ,"allowColumnReordering": true
            		    ,"cacheEnabled": false
            		    ,"cellHintEnabled": true
            		    ,"showBorders": true
            		    ,"showColumnLines": true
            		    ,"showRowLines": true
            		    ,"loadPanel" : { enabled: false }
  		       ,export : {
  			        allowExportSelectedData : false
  			       ,enabled                 : false
  			       ,excelFilterEnabled      : false
  			    }
  			   ,onExporting: function (e) {
	  				var workbook = new ExcelJS.Workbook();
	  				var worksheet = workbook.addWorksheet("Sheet1");
  				    DevExpress.excelExporter.exportDataGrid({
  				        component: e.component,
  				        worksheet: worksheet,
  				        autoFilterEnabled: true,
  				    }).then(function() {
  				        workbook.xlsx.writeBuffer().then(function(buffer) {
  				            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "기간별거래정보.xlsx");
  				        });
  				    });
  				    e.cancel = true;
  		       }
  			   ,"sorting": {"mode": "multiple"},
  			    "remoteOperations":               {
  			        "filtering": false,
  			        "grouping": false,
  			        "paging": false,
  			        "sorting": false,
  			        "summary": false
  			    },
  			    "filterRow": {"visible": false},
  			    "rowAlternationEnabled": true,
  			    "columnFixing": {"enabled": true},
	  			pager: {
	       	    	visible: false
	       	    	,showNavigationButtons: true
	       	    	,showInfo: true
	      	 	},
	      	 	paging: {
	      	 	  	enabled : false
	      	 		,pageSize : 50
	      	 	},
	      	 	scrolling : {
	      	        mode            : "infinite"
	      	        ,preloadEnabled  : false
	      	    },
  			    "searchPanel":               {
  			        "visible": false,
  			        "width": 250
  			    },
  			    "selection":               {
  			        "allowSelectAll": true,
  			        "deferred": false,
  			        "mode": "single",
  			        "selectAllMode": "allPages",
  			        "showCheckBoxesMode": "onClick"
  			    },
  			    "columns":               [
  			                        {
  			           "dataField": "ACNT_NO",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_018','계좌번호')}",
  			           "cellTemplate": function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate(cellInfo.text)); },
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true 
  			        },{
  			           "dataField": "GNL_AC_NO",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_018','계좌번호')}",
  			           "cellTemplate": function(cellElement,cellInfo){ cellElement.text(displayGTDataGridDate(cellInfo.text)); },
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true ,
  			           "visible": false
  			        },
  			                        {
  			           "dataField": "GDS_NO",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_100','상품번호')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           "visible": false
  			        },
  			                        {
  			           "dataField": "DL_SQ",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_104','일련번호')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           "visible": false
  			        },
  			                        {
  			           "dataField": "DL_DT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_105','거래발생일자')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           "visible": false
  			        },
  			                        {
  			           "dataField": "DL_DT_TM",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_106','거래발생일시')}",
  			           width : 160,
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "DL_TYP_NM",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_107','방법')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "DL_WY_NM",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_040','수단')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "DL_CHNNL_NM",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_041','채널')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "DL_AMT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_042','거래금액')}",
  			           width : 140,
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "CSH",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_043','현금')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "CHCK_AMT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_044','수표')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "ETC_CHCK_AMT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_045','기타수표')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "CRNCY_CD",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_047','통화')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "FCRNCY_DL_AMT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_048','외국환')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "USD_EXCH_AMT",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_049','달러환산')}",
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "TFND_RA",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_046','잔액')}",
  			           width : 150,
  			           "dataType": "number",
  			           "format": "fixedPoint",
  			           "precision": 0,
  			           "alignment": "right",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true,
  			           width : 140
  			        },
  			                        {
  			           "dataField": "HANDLNG_BRN_NM",
  			           "caption": "${msgel.getMsg('AML_20_07_01_01_050','취급지점')}",
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        },
  			                        {
  			           "dataField": "HNDL_P_ENO",
  			           "caption": "${msgel.getMsg('AML_20_01_01_15_007','처리자')}",
  			           width : 130,
  			           "alignment": "center",
  			           "allowResizing": true,
  			           "allowSearch": true,
  			           "allowSorting": true
  			        }
  			    ],
//   			  "summary" :{totalItems: [{column: 'DL_DT_TM', alignment:'center', summaryType: 'count', valueFormat: "fixedPoint"}],
// 					texts: {count: "총: {0}건"}},
  			 }).dxDataGrid("instance");
    }

    function clickGrid1Cell(id, obj, selectData, rowIdx, colIdx, columnId, colId)
    {
    	overlay.show(true, true);
        selectedGrid1Row = rowIdx;
        doSearch2(obj);
    }

    function doSearch()
    {
        /* if ($("#clientNo").val().trim()=="") {
            msgEmptyCustId($("#clientNo"));
            return;
        } */
         
        if ($('#CS_NO').val() =="" && $('#ACNT_NO').val() == "") {
            alert("검색조건을 입력하세요.");
            return;
        } 
        
        form1.clientNM.value = "";
 
        overlay.show(true, true);
        GridObj1.clearSelection();
        GridObj1.option('dataSource', []);
        GridObj2.clearSelection();
        GridObj2.option('dataSource', []);

        var methodID	= "getSearch_StrMain";
        var params = new Object();
    	params.pageID = pageID;
    	params.RNMCNO = $("#RNMCNO").val();
    	params.CS_NO  = $("#CS_NO").val();
    	params.ACNT_NO = $('#ACNT_NO').val(); 
    	sendService(classID, methodID, params, doSearch_success, doSearch_fail);

    }

    function doSearch_success(gridData, data)
    { 
 
    	overlay.hide();
        if (gridData.length > 0){
 
            if($("#ACNT_NO").val() == "") {
            	
        		selectedGrid1Row = 0;
            	GridObj1.option("dataSource", gridData); 
        		doSearch2(gridData[selectedGrid1Row]);
            	
        	}else {

                var firstRowData = gridData[0]; 
        		$("#clientNM").val(firstRowData.CS_NM );
            	GridObj1.option("dataSource", gridData); 
                var currAcnt = $("#ACNT_NO").val(); 
            	 
        			GridObj1.refresh().then(function(){
            		GridObj1.selectRowsByIndexes(0);
            	});
        		
                 for(var i=0; i< gridData.length; i++) {
                    if(currAcnt == gridData[i].ACNT_NO) {
                    	firstRowData = i;
                    	selectedGrid1Row = i;
                    	break;
                    }
        		} 
                 
                doSearch2(gridData[firstRowData]);
        	}

        } else {
            selectedGrid1Row = "";
            GridObj2.clearSelection();
            GridObj2.option('dataSource', []);
        }
    }

    function doSearch_fail(data){
    	overlay.hide();
    }

    function doSearch2(rowData) {
 
    	overlay.show(true, true);
    	var methodID  = "getSearch_StrSub";
        var params    = new Object();
     	params.pageID = pageID;
     	params.CS_NO  = $("#CS_NO").val().replace('-','');
     	params.GNL_AC_NO = rowData["GNL_AC_NO"];
     	//params.GdsNo = rowData["GDS_NO"];
     	params.startDate = getDxDateVal("startDate",true);
     	params.endDate = getDxDateVal("endDate"  ,true);
     	sendService(classID, methodID, params, doSearch_success2, doSearch_fail);

    }

    function doSearch_success2(gridData, data)
    {
    	overlay.hide();
        if (gridData.length > 0){
        	GridObj2.option("dataSource", gridData);
        } else {
            selectedGrid1Row = "";
            GridObj2.clearSelection();
            GridObj2.option('dataSource', []);
        }
    }
    
    function doSearchAll()
    {
 
        if ($("#CS_NO").val().trim()=="") {
            alert("실명번호를 입력하세요.");
            return;
        }else if($("#CS_NO").val().trim()!="" && $("#ACNT_NO").val().trim()!=""){
        	alert("입력된 실명번호의 전체 계좌 정보를 조회합니다.");
        }
        overlay.show(true, true);
        
        form1.ACNT_NO.value = "";
        form1.clientNM.value = "";
        
        GridObj1.clearSelection(); 
        GridObj1.option('dataSource', []);
        GridObj2.clearSelection();
        GridObj2.option('dataSource', []);

        var methodID	= "getSearch_StrMain";
        var params = new Object();
    	params.pageID = pageID;
    	params.RNMCNO = $("#RNMCNO").val();
    	params.CS_NO  = $("#CS_NO").val();
    	params.ACNT_NO = $('#ACNT_NO').val(); 
    	sendService(classID, methodID, params, doSearchAll_end, doSearch_fail);
    	 
    }
    
    function doSearchAll_end(gridData, data)
    {

    	overlay.hide();
        if (gridData.length > 0){
        	var selectedGrid1Row = 0;
        	GridObj1.option("dataSource", gridData); 
    		doSearchAll2(gridData[selectedGrid1Row]);
        } else {
            selectedGrid1Row = "";
            GridObj2.clearSelection();
            GridObj2.option('dataSource', []);
        }
    }
    
    function doSearchAll2(rowData) {
    	 
    	overlay.show(true, true);
    	var methodID  = "getSearch_StrSub";
        var params    = new Object();
     	params.pageID = pageID;
     	params.CS_NO  = $("#CS_NO").val().replace('-','');
     	params.GNL_AC_NO = "";
     	params.startDate = getDxDateVal("startDate",true);
     	params.endDate = getDxDateVal("endDate"  ,true);
     	sendService(classID, methodID, params, doSearch_success2, doSearch_fail);

    } 

    function doExcelDown()
    {
        if (GridObj2.length == 0) {
        	showAlert("${msgel.getMsg('AML_20_07_01_01_002','계좌정보가 없습니다.')}","WARN");
            return;
        }
        if (selectedGrid1Row+'' == "") {
        	showAlert("${msgel.getMsg('AML_20_07_01_01_003','선택된 계좌가 없습니다.')}","WARN");
            return;
        }
        if (GridObj2.length == 0){
        	showAlert("${msgel.getMsg('AML_20_07_01_01_004','거래정보가 없습니다.')}","WARN");
            return;
        } 
        var obj = GridObj1.getVisibleRows()[selectedGrid1Row].data; 
        $("#ACNT_NO"   ).val(obj.ACNT_NO);
        $("#FROMDATE"           ).val(getDxDateVal("startDate",true));
        $("#TODATE"             ).val(getDxDateVal("endDate"  ,true));
        
        form1.pageID.value = 'exceldown';
        form1.target = 'down_frame1';
        form1.action = "<c:url value='/'/>0001.do";
        form1.submit();
    }

    /** 툴바 버튼 설정 */
    function makeToolbarButtonGrids(e)
    {
        var useYN  = "${outputAuth.USE_YN  }";  // 사용 유무
        var authC  = "${outputAuth.C       }";  // 추가,수정 권한
        var authD  = "${outputAuth.D       }";  // 삭제 권한
        if (useYN=="Y") {
            var gridID       = e.element.attr("id");    // 그리드 아이디
            var toolbarItems = e.toolbarOptions.items;

            toolbarItems.splice(0, 0, {
                "locateInMenu"  : "auto"
                ,"location"     : "after"
                ,"widget"       : "dxButton"
                ,"name"         : "filterButton"
                ,"showText"     : "inMenu"
                ,"options"      : {
                         "icon"      : ""
                       	,"elementAttr": { class: "btn-28 filter" }
            			,"text"      : ""
                        ,"hint"      : '필터'
                        ,"disabled"  : false
                        ,"onClick"   : gridID=="GTDataGrid1_Area"?setupFilter1:setupFilter2
                 }
            });
        }
    }

    function setupFilter1(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid1_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_07_01_01_200','계좌목록')}";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }

    function setupFilter2(FLAG){
    	var gridArrs = new Array();
    	var gridObj = new Object();
    	gridObj.gridID = "GTDataGrid2_Area";
    	gridObj.title = "${msgel.getMsg('AML_20_07_01_01_201','거래내역')}";
    	gridArrs[0] = gridObj;
    	setupGridFilter2(gridArrs, FLAG);
    }
    
    //그리드를 엑셀로 다운로드
    function doDownload() {
    	var vPageUrl = pageUrl.replace(/<(\/span|span)([^>]*)>/gi,"");

    	form2.pageUrl.value = vPageUrl;
    	form2.pageID.value = "AML_00_03_01_01";
    	 
    	window_popup_open(form2.pageID.value, 600, 320, '','yes');
    	form2.target = form2.pageID.value;
    	form2.action = "<c:url value='/'/>0001.do";
    	form2.submit();
    }
    
    function comletedAction(result) {
    	if(result =="1"){
 			$("#GTDataGrid2_Area").dxDataGrid({
				export: {enabled: false},
	 		 		onToolbarPreparing: function (e) {
						var workbook = new ExcelJS.Workbook(); 
						var worksheet = workbook.addWorksheet('Main sheet'); 
						DevExpress.excelExporter.exportDataGrid({
							component: e.component,
					        worksheet: worksheet,
					        autoFilterEnabled: true
					    }).then(function(){
					        workbook.xlsx.writeBuffer().then(function(buffer){
					            saveAs(new Blob([buffer], { type: "application/octet-stream" }), "${pageTitle}.xlsx");
					        });
					    });
	 				},
 				location : "after"
			});
		}
	}
     

</script>
<!-- Main Body Start -->
<!-- 파일 다운로드 -->
<form name="fileFrm" id="fileFrm" method="POST">
<input type="hidden" name="pageID" />
<input type="hidden" name="downFileName" id="downFileName" value="" />
<input type="hidden" name="orgFileName" id="orgFileName" value="" />
<input type="hidden" name="downFilePath" id="downFilePath" value="" />
<input type="hidden" name="downType" id="downType" value="" />
</form>
<form name="form2" id="form2" method="post">
<input type="hidden" name="pageID" />
<input type="hidden" name="pageUrl" >
</form>
<form name="form1" id="form1" method="post">
<input type="hidden" name="pageID"              id="pageID"     >
<input type="hidden" name="manualID"            id="manualID"   >
<input type="hidden" name="classID"             id="classID"    >
<input type="hidden" name="methodID"            id="methodID"   >
<input type="hidden" name="FROMDATE"            id="FROMDATE"    value="" />
<input type="hidden" name="TODATE"              id="TODATE"      value="" />
<input type="hidden" name="RNMCNO"              id="RNMCNO"  >
<div class="page-contents">
	<div class="inquiry-table type1">
		<div class="table-row">
			<div class="table-cell">
				${condel.getLabel('AML_20_01_10_03_301','실명번호', "required")}
         		<div class="content search">
	         	 	${condel.getInputCustomerNoSearch('CS_NO','','','','')}
	            	<button class="btn-36" type="button" onclick='popupCustWindow()'>${msgel.getMsg('ADMIN_createMenuForm_040','검색')}</button>
	        	</div>
			</div>
		</div>
		<div class="table-row">
			<div class="table-cell">
			${condel.getInputCustomerNo('{msgID:"AML_20_01_01_03_009", defaultValue:"계좌번호", name:"ACNT_NO", size:"20"}')}
			</div>
		</div>
		<div class="table-row">
			<div class="table-cell">
				${condel.getLabel('AML_20_07_01_01_007','고객명')}
				<div class="content">
					<input name="clientNM" id="clientNM" type="text"  maxlength="20" class="cond-input-text" readonly="readonly"/>
				</div>
			</div>
		</div>
		<div class="table-row">
			<div class="table-cell">
				${condel.getInputDateDxPair('AML_20_07_01_01_008','거래일자','startDate',startDate,'endDate',endDate)}
			</div>
		</div>
	</div>

	<div class="button-area">
		${btnel.getButton(outputAuth, '{btnID:"sbtn_05", cdID:"AML_20_01_01_01_sbtn_06", defaultValue:"파일생성", mode:"C", function:"doExcelDown", cssClass:"btn-36"}')}
		${btnel.getButton(outputAuth, '{btnID:"btn_03", cdID:"searchAllBtn", defaultValue:"일괄조회", mode:"R", function:"doSearchAll", cssClass:"btn-36 filled"}')}
		${btnel.getButton(outputAuth, '{btnID:"btn_01", cdID:"queryBtn", defaultValue:"조회", mode:"R", function:"doSearch", cssClass:"btn-36 filled"}')}
        <!--
        ${btnel.getButton(outputAuth, '{btnID:"btn_02", name="ExcelDown", mode:"R", function:"doExcelDown", cssClass:"flat-btn flat-btn-white", icssClass:"fa fa-file-excel-o"}')}
        -->
	</div>

	<div class="tab-content-bottom">
		<div class="inquiry-content-wrap" style="padding-top:10px;">
			<div class="content-left" style="min-width:23%;width:23%;">
				<div id="GTDataGrid1_Area"></div>
			</div>
			<div class="content-right">
				<div id="GTDataGrid2_Area"></div>
			</div>
		</div>
	</div>
</div>
<iframe name="down_frame1" width="0" height="0" frameborder="0" marginheight="0" marginwidth="0" scrolling="no"></iframe>
</form>

<jsp:include page="/WEB-INF/Package/AML/common/main_common_bottom.jsp" flush="true" />